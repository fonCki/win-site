var Hb=r=>{throw TypeError(r)};var sf=(r,t,e)=>t.has(r)||Hb("Cannot "+e);var le=(r,t,e)=>(sf(r,t,"read from private field"),e?e.call(r):t.get(r)),ti=(r,t,e)=>t.has(r)?Hb("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(r):t.set(r,e),an=(r,t,e,s)=>(sf(r,t,"write to private field"),s?s.call(r,e):t.set(r,e),e),ei=(r,t,e)=>(sf(r,t,"access private method"),e);var Ub=(r,t,e,s)=>({set _(a){an(r,t,a,e)},get _(){return le(r,t,s)}});(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))s(a);new MutationObserver(a=>{for(const l of a)if(l.type==="childList")for(const c of l.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&s(c)}).observe(document,{childList:!0,subtree:!0});function e(a){const l={};return a.integrity&&(l.integrity=a.integrity),a.referrerPolicy&&(l.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?l.credentials="include":a.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function s(a){if(a.ep)return;a.ep=!0;const l=e(a);fetch(a.href,l)}})();function op(r){return r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r}var af={exports:{}},Po={};var Gb;function eS(){if(Gb)return Po;Gb=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.fragment");function e(s,a,l){var c=null;if(l!==void 0&&(c=""+l),a.key!==void 0&&(c=""+a.key),"key"in a){l={};for(var d in a)d!=="key"&&(l[d]=a[d])}else l=a;return a=l.ref,{$$typeof:r,type:s,key:c,ref:a!==void 0?a:null,props:l}}return Po.Fragment=t,Po.jsx=e,Po.jsxs=e,Po}var Vb;function nS(){return Vb||(Vb=1,af.exports=eS()),af.exports}var y=nS(),rf={exports:{}},Mt={};var qb;function iS(){if(qb)return Mt;qb=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.portal"),e=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),a=Symbol.for("react.profiler"),l=Symbol.for("react.consumer"),c=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),h=Symbol.for("react.suspense"),f=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),m=Symbol.for("react.activity"),x=Symbol.iterator;function v(z){return z===null||typeof z!="object"?null:(z=x&&z[x]||z["@@iterator"],typeof z=="function"?z:null)}var E={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},S=Object.assign,C={};function T(z,H,q){this.props=z,this.context=H,this.refs=C,this.updater=q||E}T.prototype.isReactComponent={},T.prototype.setState=function(z,H){if(typeof z!="object"&&typeof z!="function"&&z!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,z,H,"setState")},T.prototype.forceUpdate=function(z){this.updater.enqueueForceUpdate(this,z,"forceUpdate")};function _(){}_.prototype=T.prototype;function k(z,H,q){this.props=z,this.context=H,this.refs=C,this.updater=q||E}var R=k.prototype=new _;R.constructor=k,S(R,T.prototype),R.isPureReactComponent=!0;var D=Array.isArray;function L(){}var O={H:null,A:null,T:null,S:null},B=Object.prototype.hasOwnProperty;function F(z,H,q){var tt=q.ref;return{$$typeof:r,type:z,key:H,ref:tt!==void 0?tt:null,props:q}}function W(z,H){return F(z.type,H,z.props)}function Z(z){return typeof z=="object"&&z!==null&&z.$$typeof===r}function rt(z){var H={"=":"=0",":":"=2"};return"$"+z.replace(/[=:]/g,function(q){return H[q]})}var dt=/\/+/g;function lt(z,H){return typeof z=="object"&&z!==null&&z.key!=null?rt(""+z.key):H.toString(36)}function ut(z){switch(z.status){case"fulfilled":return z.value;case"rejected":throw z.reason;default:switch(typeof z.status=="string"?z.then(L,L):(z.status="pending",z.then(function(H){z.status==="pending"&&(z.status="fulfilled",z.value=H)},function(H){z.status==="pending"&&(z.status="rejected",z.reason=H)})),z.status){case"fulfilled":return z.value;case"rejected":throw z.reason}}throw z}function P(z,H,q,tt,st){var ot=typeof z;(ot==="undefined"||ot==="boolean")&&(z=null);var at=!1;if(z===null)at=!0;else switch(ot){case"bigint":case"string":case"number":at=!0;break;case"object":switch(z.$$typeof){case r:case t:at=!0;break;case g:return at=z._init,P(at(z._payload),H,q,tt,st)}}if(at)return st=st(z),at=tt===""?"."+lt(z,0):tt,D(st)?(q="",at!=null&&(q=at.replace(dt,"$&/")+"/"),P(st,H,q,"",function(xt){return xt})):st!=null&&(Z(st)&&(st=W(st,q+(st.key==null||z&&z.key===st.key?"":(""+st.key).replace(dt,"$&/")+"/")+at)),H.push(st)),1;at=0;var kt=tt===""?".":tt+":";if(D(z))for(var et=0;et<z.length;et++)tt=z[et],ot=kt+lt(tt,et),at+=P(tt,H,q,ot,st);else if(et=v(z),typeof et=="function")for(z=et.call(z),et=0;!(tt=z.next()).done;)tt=tt.value,ot=kt+lt(tt,et++),at+=P(tt,H,q,ot,st);else if(ot==="object"){if(typeof z.then=="function")return P(ut(z),H,q,tt,st);throw H=String(z),Error("Objects are not valid as a React child (found: "+(H==="[object Object]"?"object with keys {"+Object.keys(z).join(", ")+"}":H)+"). If you meant to render a collection of children, use an array instead.")}return at}function V(z,H,q){if(z==null)return z;var tt=[],st=0;return P(z,tt,"","",function(ot){return H.call(q,ot,st++)}),tt}function K(z){if(z._status===-1){var H=z._result;H=H(),H.then(function(q){(z._status===0||z._status===-1)&&(z._status=1,z._result=q)},function(q){(z._status===0||z._status===-1)&&(z._status=2,z._result=q)}),z._status===-1&&(z._status=0,z._result=H)}if(z._status===1)return z._result.default;throw z._result}var ct=typeof reportError=="function"?reportError:function(z){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var H=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof z=="object"&&z!==null&&typeof z.message=="string"?String(z.message):String(z),error:z});if(!window.dispatchEvent(H))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",z);return}console.error(z)},bt={map:V,forEach:function(z,H,q){V(z,function(){H.apply(this,arguments)},q)},count:function(z){var H=0;return V(z,function(){H++}),H},toArray:function(z){return V(z,function(H){return H})||[]},only:function(z){if(!Z(z))throw Error("React.Children.only expected to receive a single React element child.");return z}};return Mt.Activity=m,Mt.Children=bt,Mt.Component=T,Mt.Fragment=e,Mt.Profiler=a,Mt.PureComponent=k,Mt.StrictMode=s,Mt.Suspense=h,Mt.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=O,Mt.__COMPILER_RUNTIME={__proto__:null,c:function(z){return O.H.useMemoCache(z)}},Mt.cache=function(z){return function(){return z.apply(null,arguments)}},Mt.cacheSignal=function(){return null},Mt.cloneElement=function(z,H,q){if(z==null)throw Error("The argument must be a React element, but you passed "+z+".");var tt=S({},z.props),st=z.key;if(H!=null)for(ot in H.key!==void 0&&(st=""+H.key),H)!B.call(H,ot)||ot==="key"||ot==="__self"||ot==="__source"||ot==="ref"&&H.ref===void 0||(tt[ot]=H[ot]);var ot=arguments.length-2;if(ot===1)tt.children=q;else if(1<ot){for(var at=Array(ot),kt=0;kt<ot;kt++)at[kt]=arguments[kt+2];tt.children=at}return F(z.type,st,tt)},Mt.createContext=function(z){return z={$$typeof:c,_currentValue:z,_currentValue2:z,_threadCount:0,Provider:null,Consumer:null},z.Provider=z,z.Consumer={$$typeof:l,_context:z},z},Mt.createElement=function(z,H,q){var tt,st={},ot=null;if(H!=null)for(tt in H.key!==void 0&&(ot=""+H.key),H)B.call(H,tt)&&tt!=="key"&&tt!=="__self"&&tt!=="__source"&&(st[tt]=H[tt]);var at=arguments.length-2;if(at===1)st.children=q;else if(1<at){for(var kt=Array(at),et=0;et<at;et++)kt[et]=arguments[et+2];st.children=kt}if(z&&z.defaultProps)for(tt in at=z.defaultProps,at)st[tt]===void 0&&(st[tt]=at[tt]);return F(z,ot,st)},Mt.createRef=function(){return{current:null}},Mt.forwardRef=function(z){return{$$typeof:d,render:z}},Mt.isValidElement=Z,Mt.lazy=function(z){return{$$typeof:g,_payload:{_status:-1,_result:z},_init:K}},Mt.memo=function(z,H){return{$$typeof:f,type:z,compare:H===void 0?null:H}},Mt.startTransition=function(z){var H=O.T,q={};O.T=q;try{var tt=z(),st=O.S;st!==null&&st(q,tt),typeof tt=="object"&&tt!==null&&typeof tt.then=="function"&&tt.then(L,ct)}catch(ot){ct(ot)}finally{H!==null&&q.types!==null&&(H.types=q.types),O.T=H}},Mt.unstable_useCacheRefresh=function(){return O.H.useCacheRefresh()},Mt.use=function(z){return O.H.use(z)},Mt.useActionState=function(z,H,q){return O.H.useActionState(z,H,q)},Mt.useCallback=function(z,H){return O.H.useCallback(z,H)},Mt.useContext=function(z){return O.H.useContext(z)},Mt.useDebugValue=function(){},Mt.useDeferredValue=function(z,H){return O.H.useDeferredValue(z,H)},Mt.useEffect=function(z,H){return O.H.useEffect(z,H)},Mt.useEffectEvent=function(z){return O.H.useEffectEvent(z)},Mt.useId=function(){return O.H.useId()},Mt.useImperativeHandle=function(z,H,q){return O.H.useImperativeHandle(z,H,q)},Mt.useInsertionEffect=function(z,H){return O.H.useInsertionEffect(z,H)},Mt.useLayoutEffect=function(z,H){return O.H.useLayoutEffect(z,H)},Mt.useMemo=function(z,H){return O.H.useMemo(z,H)},Mt.useOptimistic=function(z,H){return O.H.useOptimistic(z,H)},Mt.useReducer=function(z,H,q){return O.H.useReducer(z,H,q)},Mt.useRef=function(z){return O.H.useRef(z)},Mt.useState=function(z){return O.H.useState(z)},Mt.useSyncExternalStore=function(z,H,q){return O.H.useSyncExternalStore(z,H,q)},Mt.useTransition=function(){return O.H.useTransition()},Mt.version="19.2.3",Mt}var Yb;function lp(){return Yb||(Yb=1,rf.exports=iS()),rf.exports}var j=lp();const X=op(j);var of={exports:{}},Io={},lf={exports:{}},cf={};var Xb;function sS(){return Xb||(Xb=1,(function(r){function t(P,V){var K=P.length;P.push(V);t:for(;0<K;){var ct=K-1>>>1,bt=P[ct];if(0<a(bt,V))P[ct]=V,P[K]=bt,K=ct;else break t}}function e(P){return P.length===0?null:P[0]}function s(P){if(P.length===0)return null;var V=P[0],K=P.pop();if(K!==V){P[0]=K;t:for(var ct=0,bt=P.length,z=bt>>>1;ct<z;){var H=2*(ct+1)-1,q=P[H],tt=H+1,st=P[tt];if(0>a(q,K))tt<bt&&0>a(st,q)?(P[ct]=st,P[tt]=K,ct=tt):(P[ct]=q,P[H]=K,ct=H);else if(tt<bt&&0>a(st,K))P[ct]=st,P[tt]=K,ct=tt;else break t}}return V}function a(P,V){var K=P.sortIndex-V.sortIndex;return K!==0?K:P.id-V.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var l=performance;r.unstable_now=function(){return l.now()}}else{var c=Date,d=c.now();r.unstable_now=function(){return c.now()-d}}var h=[],f=[],g=1,m=null,x=3,v=!1,E=!1,S=!1,C=!1,T=typeof setTimeout=="function"?setTimeout:null,_=typeof clearTimeout=="function"?clearTimeout:null,k=typeof setImmediate<"u"?setImmediate:null;function R(P){for(var V=e(f);V!==null;){if(V.callback===null)s(f);else if(V.startTime<=P)s(f),V.sortIndex=V.expirationTime,t(h,V);else break;V=e(f)}}function D(P){if(S=!1,R(P),!E)if(e(h)!==null)E=!0,L||(L=!0,rt());else{var V=e(f);V!==null&&ut(D,V.startTime-P)}}var L=!1,O=-1,B=5,F=-1;function W(){return C?!0:!(r.unstable_now()-F<B)}function Z(){if(C=!1,L){var P=r.unstable_now();F=P;var V=!0;try{t:{E=!1,S&&(S=!1,_(O),O=-1),v=!0;var K=x;try{e:{for(R(P),m=e(h);m!==null&&!(m.expirationTime>P&&W());){var ct=m.callback;if(typeof ct=="function"){m.callback=null,x=m.priorityLevel;var bt=ct(m.expirationTime<=P);if(P=r.unstable_now(),typeof bt=="function"){m.callback=bt,R(P),V=!0;break e}m===e(h)&&s(h),R(P)}else s(h);m=e(h)}if(m!==null)V=!0;else{var z=e(f);z!==null&&ut(D,z.startTime-P),V=!1}}break t}finally{m=null,x=K,v=!1}V=void 0}}finally{V?rt():L=!1}}}var rt;if(typeof k=="function")rt=function(){k(Z)};else if(typeof MessageChannel<"u"){var dt=new MessageChannel,lt=dt.port2;dt.port1.onmessage=Z,rt=function(){lt.postMessage(null)}}else rt=function(){T(Z,0)};function ut(P,V){O=T(function(){P(r.unstable_now())},V)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(P){P.callback=null},r.unstable_forceFrameRate=function(P){0>P||125<P?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):B=0<P?Math.floor(1e3/P):5},r.unstable_getCurrentPriorityLevel=function(){return x},r.unstable_next=function(P){switch(x){case 1:case 2:case 3:var V=3;break;default:V=x}var K=x;x=V;try{return P()}finally{x=K}},r.unstable_requestPaint=function(){C=!0},r.unstable_runWithPriority=function(P,V){switch(P){case 1:case 2:case 3:case 4:case 5:break;default:P=3}var K=x;x=P;try{return V()}finally{x=K}},r.unstable_scheduleCallback=function(P,V,K){var ct=r.unstable_now();switch(typeof K=="object"&&K!==null?(K=K.delay,K=typeof K=="number"&&0<K?ct+K:ct):K=ct,P){case 1:var bt=-1;break;case 2:bt=250;break;case 5:bt=1073741823;break;case 4:bt=1e4;break;default:bt=5e3}return bt=K+bt,P={id:g++,callback:V,priorityLevel:P,startTime:K,expirationTime:bt,sortIndex:-1},K>ct?(P.sortIndex=K,t(f,P),e(h)===null&&P===e(f)&&(S?(_(O),O=-1):S=!0,ut(D,K-ct))):(P.sortIndex=bt,t(h,P),E||v||(E=!0,L||(L=!0,rt()))),P},r.unstable_shouldYield=W,r.unstable_wrapCallback=function(P){var V=x;return function(){var K=x;x=V;try{return P.apply(this,arguments)}finally{x=K}}}})(cf)),cf}var Wb;function aS(){return Wb||(Wb=1,lf.exports=sS()),lf.exports}var uf={exports:{}},Ge={};var Qb;function rS(){if(Qb)return Ge;Qb=1;var r=lp();function t(h){var f="https://react.dev/errors/"+h;if(1<arguments.length){f+="?args[]="+encodeURIComponent(arguments[1]);for(var g=2;g<arguments.length;g++)f+="&args[]="+encodeURIComponent(arguments[g])}return"Minified React error #"+h+"; visit "+f+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function e(){}var s={d:{f:e,r:function(){throw Error(t(522))},D:e,C:e,L:e,m:e,X:e,S:e,M:e},p:0,findDOMNode:null},a=Symbol.for("react.portal");function l(h,f,g){var m=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:a,key:m==null?null:""+m,children:h,containerInfo:f,implementation:g}}var c=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function d(h,f){if(h==="font")return"";if(typeof f=="string")return f==="use-credentials"?f:""}return Ge.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=s,Ge.createPortal=function(h,f){var g=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!f||f.nodeType!==1&&f.nodeType!==9&&f.nodeType!==11)throw Error(t(299));return l(h,f,null,g)},Ge.flushSync=function(h){var f=c.T,g=s.p;try{if(c.T=null,s.p=2,h)return h()}finally{c.T=f,s.p=g,s.d.f()}},Ge.preconnect=function(h,f){typeof h=="string"&&(f?(f=f.crossOrigin,f=typeof f=="string"?f==="use-credentials"?f:"":void 0):f=null,s.d.C(h,f))},Ge.prefetchDNS=function(h){typeof h=="string"&&s.d.D(h)},Ge.preinit=function(h,f){if(typeof h=="string"&&f&&typeof f.as=="string"){var g=f.as,m=d(g,f.crossOrigin),x=typeof f.integrity=="string"?f.integrity:void 0,v=typeof f.fetchPriority=="string"?f.fetchPriority:void 0;g==="style"?s.d.S(h,typeof f.precedence=="string"?f.precedence:void 0,{crossOrigin:m,integrity:x,fetchPriority:v}):g==="script"&&s.d.X(h,{crossOrigin:m,integrity:x,fetchPriority:v,nonce:typeof f.nonce=="string"?f.nonce:void 0})}},Ge.preinitModule=function(h,f){if(typeof h=="string")if(typeof f=="object"&&f!==null){if(f.as==null||f.as==="script"){var g=d(f.as,f.crossOrigin);s.d.M(h,{crossOrigin:g,integrity:typeof f.integrity=="string"?f.integrity:void 0,nonce:typeof f.nonce=="string"?f.nonce:void 0})}}else f==null&&s.d.M(h)},Ge.preload=function(h,f){if(typeof h=="string"&&typeof f=="object"&&f!==null&&typeof f.as=="string"){var g=f.as,m=d(g,f.crossOrigin);s.d.L(h,g,{crossOrigin:m,integrity:typeof f.integrity=="string"?f.integrity:void 0,nonce:typeof f.nonce=="string"?f.nonce:void 0,type:typeof f.type=="string"?f.type:void 0,fetchPriority:typeof f.fetchPriority=="string"?f.fetchPriority:void 0,referrerPolicy:typeof f.referrerPolicy=="string"?f.referrerPolicy:void 0,imageSrcSet:typeof f.imageSrcSet=="string"?f.imageSrcSet:void 0,imageSizes:typeof f.imageSizes=="string"?f.imageSizes:void 0,media:typeof f.media=="string"?f.media:void 0})}},Ge.preloadModule=function(h,f){if(typeof h=="string")if(f){var g=d(f.as,f.crossOrigin);s.d.m(h,{as:typeof f.as=="string"&&f.as!=="script"?f.as:void 0,crossOrigin:g,integrity:typeof f.integrity=="string"?f.integrity:void 0})}else s.d.m(h)},Ge.requestFormReset=function(h){s.d.r(h)},Ge.unstable_batchedUpdates=function(h,f){return h(f)},Ge.useFormState=function(h,f,g){return c.H.useFormState(h,f,g)},Ge.useFormStatus=function(){return c.H.useHostTransitionStatus()},Ge.version="19.2.3",Ge}var Kb;function Vx(){if(Kb)return uf.exports;Kb=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),uf.exports=rS(),uf.exports}var Zb;function oS(){if(Zb)return Io;Zb=1;var r=aS(),t=lp(),e=Vx();function s(n){var i="https://react.dev/errors/"+n;if(1<arguments.length){i+="?args[]="+encodeURIComponent(arguments[1]);for(var o=2;o<arguments.length;o++)i+="&args[]="+encodeURIComponent(arguments[o])}return"Minified React error #"+n+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function a(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function l(n){var i=n,o=n;if(n.alternate)for(;i.return;)i=i.return;else{n=i;do i=n,(i.flags&4098)!==0&&(o=i.return),n=i.return;while(n)}return i.tag===3?o:null}function c(n){if(n.tag===13){var i=n.memoizedState;if(i===null&&(n=n.alternate,n!==null&&(i=n.memoizedState)),i!==null)return i.dehydrated}return null}function d(n){if(n.tag===31){var i=n.memoizedState;if(i===null&&(n=n.alternate,n!==null&&(i=n.memoizedState)),i!==null)return i.dehydrated}return null}function h(n){if(l(n)!==n)throw Error(s(188))}function f(n){var i=n.alternate;if(!i){if(i=l(n),i===null)throw Error(s(188));return i!==n?null:n}for(var o=n,u=i;;){var p=o.return;if(p===null)break;var b=p.alternate;if(b===null){if(u=p.return,u!==null){o=u;continue}break}if(p.child===b.child){for(b=p.child;b;){if(b===o)return h(p),n;if(b===u)return h(p),i;b=b.sibling}throw Error(s(188))}if(o.return!==u.return)o=p,u=b;else{for(var A=!1,M=p.child;M;){if(M===o){A=!0,o=p,u=b;break}if(M===u){A=!0,u=p,o=b;break}M=M.sibling}if(!A){for(M=b.child;M;){if(M===o){A=!0,o=b,u=p;break}if(M===u){A=!0,u=b,o=p;break}M=M.sibling}if(!A)throw Error(s(189))}}if(o.alternate!==u)throw Error(s(190))}if(o.tag!==3)throw Error(s(188));return o.stateNode.current===o?n:i}function g(n){var i=n.tag;if(i===5||i===26||i===27||i===6)return n;for(n=n.child;n!==null;){if(i=g(n),i!==null)return i;n=n.sibling}return null}var m=Object.assign,x=Symbol.for("react.element"),v=Symbol.for("react.transitional.element"),E=Symbol.for("react.portal"),S=Symbol.for("react.fragment"),C=Symbol.for("react.strict_mode"),T=Symbol.for("react.profiler"),_=Symbol.for("react.consumer"),k=Symbol.for("react.context"),R=Symbol.for("react.forward_ref"),D=Symbol.for("react.suspense"),L=Symbol.for("react.suspense_list"),O=Symbol.for("react.memo"),B=Symbol.for("react.lazy"),F=Symbol.for("react.activity"),W=Symbol.for("react.memo_cache_sentinel"),Z=Symbol.iterator;function rt(n){return n===null||typeof n!="object"?null:(n=Z&&n[Z]||n["@@iterator"],typeof n=="function"?n:null)}var dt=Symbol.for("react.client.reference");function lt(n){if(n==null)return null;if(typeof n=="function")return n.$$typeof===dt?null:n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case S:return"Fragment";case T:return"Profiler";case C:return"StrictMode";case D:return"Suspense";case L:return"SuspenseList";case F:return"Activity"}if(typeof n=="object")switch(n.$$typeof){case E:return"Portal";case k:return n.displayName||"Context";case _:return(n._context.displayName||"Context")+".Consumer";case R:var i=n.render;return n=n.displayName,n||(n=i.displayName||i.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case O:return i=n.displayName||null,i!==null?i:lt(n.type)||"Memo";case B:i=n._payload,n=n._init;try{return lt(n(i))}catch{}}return null}var ut=Array.isArray,P=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,V=e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,K={pending:!1,data:null,method:null,action:null},ct=[],bt=-1;function z(n){return{current:n}}function H(n){0>bt||(n.current=ct[bt],ct[bt]=null,bt--)}function q(n,i){bt++,ct[bt]=n.current,n.current=i}var tt=z(null),st=z(null),ot=z(null),at=z(null);function kt(n,i){switch(q(ot,i),q(st,n),q(tt,null),i.nodeType){case 9:case 11:n=(n=i.documentElement)&&(n=n.namespaceURI)?db(n):0;break;default:if(n=i.tagName,i=i.namespaceURI)i=db(i),n=hb(i,n);else switch(n){case"svg":n=1;break;case"math":n=2;break;default:n=0}}H(tt),q(tt,n)}function et(){H(tt),H(st),H(ot)}function xt(n){n.memoizedState!==null&&q(at,n);var i=tt.current,o=hb(i,n.type);i!==o&&(q(st,n),q(tt,o))}function ht(n){st.current===n&&(H(tt),H(st)),at.current===n&&(H(at),jo._currentValue=K)}var Ct,At;function yt(n){if(Ct===void 0)try{throw Error()}catch(o){var i=o.stack.trim().match(/\n( *(at )?)/);Ct=i&&i[1]||"",At=-1<o.stack.indexOf(`
    at`)?" (<anonymous>)":-1<o.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Ct+n+At}var Et=!1;function Vt(n,i){if(!n||Et)return"";Et=!0;var o=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var u={DetermineComponentFrameRoot:function(){try{if(i){var it=function(){throw Error()};if(Object.defineProperty(it.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(it,[])}catch(Q){var Y=Q}Reflect.construct(n,[],it)}else{try{it.call()}catch(Q){Y=Q}n.call(it.prototype)}}else{try{throw Error()}catch(Q){Y=Q}(it=n())&&typeof it.catch=="function"&&it.catch(function(){})}}catch(Q){if(Q&&Y&&typeof Q.stack=="string")return[Q.stack,Y.stack]}return[null,null]}};u.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var p=Object.getOwnPropertyDescriptor(u.DetermineComponentFrameRoot,"name");p&&p.configurable&&Object.defineProperty(u.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var b=u.DetermineComponentFrameRoot(),A=b[0],M=b[1];if(A&&M){var N=A.split(`
`),G=M.split(`
`);for(p=u=0;u<N.length&&!N[u].includes("DetermineComponentFrameRoot");)u++;for(;p<G.length&&!G[p].includes("DetermineComponentFrameRoot");)p++;if(u===N.length||p===G.length)for(u=N.length-1,p=G.length-1;1<=u&&0<=p&&N[u]!==G[p];)p--;for(;1<=u&&0<=p;u--,p--)if(N[u]!==G[p]){if(u!==1||p!==1)do if(u--,p--,0>p||N[u]!==G[p]){var J=`
`+N[u].replace(" at new "," at ");return n.displayName&&J.includes("<anonymous>")&&(J=J.replace("<anonymous>",n.displayName)),J}while(1<=u&&0<=p);break}}}finally{Et=!1,Error.prepareStackTrace=o}return(o=n?n.displayName||n.name:"")?yt(o):""}function Xt(n,i){switch(n.tag){case 26:case 27:case 5:return yt(n.type);case 16:return yt("Lazy");case 13:return n.child!==i&&i!==null?yt("Suspense Fallback"):yt("Suspense");case 19:return yt("SuspenseList");case 0:case 15:return Vt(n.type,!1);case 11:return Vt(n.type.render,!1);case 1:return Vt(n.type,!0);case 31:return yt("Activity");default:return""}}function Sn(n){try{var i="",o=null;do i+=Xt(n,o),o=n,n=n.return;while(n);return i}catch(u){return`
Error generating stack: `+u.message+`
`+u.stack}}var Qe=Object.prototype.hasOwnProperty,In=r.unstable_scheduleCallback,ui=r.unstable_cancelCallback,En=r.unstable_shouldYield,ya=r.unstable_requestPaint,Ue=r.unstable_now,Gu=r.unstable_getCurrentPriorityLevel,vl=r.unstable_ImmediatePriority,Al=r.unstable_UserBlockingPriority,ln=r.unstable_NormalPriority,Pi=r.unstable_LowPriority,Fn=r.unstable_IdlePriority,Gr=r.log,P1=r.unstable_setDisableYieldValue,Vr=null,cn=null;function Ii(n){if(typeof Gr=="function"&&P1(n),cn&&typeof cn.setStrictMode=="function")try{cn.setStrictMode(Vr,n)}catch{}}var un=Math.clz32?Math.clz32:$1,I1=Math.log,F1=Math.LN2;function $1(n){return n>>>=0,n===0?32:31-(I1(n)/F1|0)|0}var wl=256,Sl=262144,El=4194304;function ks(n){var i=n&42;if(i!==0)return i;switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return n&261888;case 262144:case 524288:case 1048576:case 2097152:return n&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return n&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return n}}function Tl(n,i,o){var u=n.pendingLanes;if(u===0)return 0;var p=0,b=n.suspendedLanes,A=n.pingedLanes;n=n.warmLanes;var M=u&134217727;return M!==0?(u=M&~b,u!==0?p=ks(u):(A&=M,A!==0?p=ks(A):o||(o=M&~n,o!==0&&(p=ks(o))))):(M=u&~b,M!==0?p=ks(M):A!==0?p=ks(A):o||(o=u&~n,o!==0&&(p=ks(o)))),p===0?0:i!==0&&i!==p&&(i&b)===0&&(b=p&-p,o=i&-i,b>=o||b===32&&(o&4194048)!==0)?i:p}function qr(n,i){return(n.pendingLanes&~(n.suspendedLanes&~n.pingedLanes)&i)===0}function H1(n,i){switch(n){case 1:case 2:case 4:case 8:case 64:return i+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function qp(){var n=El;return El<<=1,(El&62914560)===0&&(El=4194304),n}function Vu(n){for(var i=[],o=0;31>o;o++)i.push(n);return i}function Yr(n,i){n.pendingLanes|=i,i!==268435456&&(n.suspendedLanes=0,n.pingedLanes=0,n.warmLanes=0)}function U1(n,i,o,u,p,b){var A=n.pendingLanes;n.pendingLanes=o,n.suspendedLanes=0,n.pingedLanes=0,n.warmLanes=0,n.expiredLanes&=o,n.entangledLanes&=o,n.errorRecoveryDisabledLanes&=o,n.shellSuspendCounter=0;var M=n.entanglements,N=n.expirationTimes,G=n.hiddenUpdates;for(o=A&~o;0<o;){var J=31-un(o),it=1<<J;M[J]=0,N[J]=-1;var Y=G[J];if(Y!==null)for(G[J]=null,J=0;J<Y.length;J++){var Q=Y[J];Q!==null&&(Q.lane&=-536870913)}o&=~it}u!==0&&Yp(n,u,0),b!==0&&p===0&&n.tag!==0&&(n.suspendedLanes|=b&~(A&~i))}function Yp(n,i,o){n.pendingLanes|=i,n.suspendedLanes&=~i;var u=31-un(i);n.entangledLanes|=i,n.entanglements[u]=n.entanglements[u]|1073741824|o&261930}function Xp(n,i){var o=n.entangledLanes|=i;for(n=n.entanglements;o;){var u=31-un(o),p=1<<u;p&i|n[u]&i&&(n[u]|=i),o&=~p}}function Wp(n,i){var o=i&-i;return o=(o&42)!==0?1:qu(o),(o&(n.suspendedLanes|i))!==0?0:o}function qu(n){switch(n){case 2:n=1;break;case 8:n=4;break;case 32:n=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:n=128;break;case 268435456:n=134217728;break;default:n=0}return n}function Yu(n){return n&=-n,2<n?8<n?(n&134217727)!==0?32:268435456:8:2}function Qp(){var n=V.p;return n!==0?n:(n=window.event,n===void 0?32:Nb(n.type))}function Kp(n,i){var o=V.p;try{return V.p=n,i()}finally{V.p=o}}var Fi=Math.random().toString(36).slice(2),Ne="__reactFiber$"+Fi,Ke="__reactProps$"+Fi,xa="__reactContainer$"+Fi,Xu="__reactEvents$"+Fi,G1="__reactListeners$"+Fi,V1="__reactHandles$"+Fi,Zp="__reactResources$"+Fi,Xr="__reactMarker$"+Fi;function Wu(n){delete n[Ne],delete n[Ke],delete n[Xu],delete n[G1],delete n[V1]}function va(n){var i=n[Ne];if(i)return i;for(var o=n.parentNode;o;){if(i=o[xa]||o[Ne]){if(o=i.alternate,i.child!==null||o!==null&&o.child!==null)for(n=xb(n);n!==null;){if(o=n[Ne])return o;n=xb(n)}return i}n=o,o=n.parentNode}return null}function Aa(n){if(n=n[Ne]||n[xa]){var i=n.tag;if(i===5||i===6||i===13||i===31||i===26||i===27||i===3)return n}return null}function Wr(n){var i=n.tag;if(i===5||i===26||i===27||i===6)return n.stateNode;throw Error(s(33))}function wa(n){var i=n[Zp];return i||(i=n[Zp]={hoistableStyles:new Map,hoistableScripts:new Map}),i}function Me(n){n[Xr]=!0}var Jp=new Set,tg={};function Ms(n,i){Sa(n,i),Sa(n+"Capture",i)}function Sa(n,i){for(tg[n]=i,n=0;n<i.length;n++)Jp.add(i[n])}var q1=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),eg={},ng={};function Y1(n){return Qe.call(ng,n)?!0:Qe.call(eg,n)?!1:q1.test(n)?ng[n]=!0:(eg[n]=!0,!1)}function Cl(n,i,o){if(Y1(i))if(o===null)n.removeAttribute(i);else{switch(typeof o){case"undefined":case"function":case"symbol":n.removeAttribute(i);return;case"boolean":var u=i.toLowerCase().slice(0,5);if(u!=="data-"&&u!=="aria-"){n.removeAttribute(i);return}}n.setAttribute(i,""+o)}}function _l(n,i,o){if(o===null)n.removeAttribute(i);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":n.removeAttribute(i);return}n.setAttribute(i,""+o)}}function di(n,i,o,u){if(u===null)n.removeAttribute(o);else{switch(typeof u){case"undefined":case"function":case"symbol":case"boolean":n.removeAttribute(o);return}n.setAttributeNS(i,o,""+u)}}function Tn(n){switch(typeof n){case"bigint":case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function ig(n){var i=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function X1(n,i,o){var u=Object.getOwnPropertyDescriptor(n.constructor.prototype,i);if(!n.hasOwnProperty(i)&&typeof u<"u"&&typeof u.get=="function"&&typeof u.set=="function"){var p=u.get,b=u.set;return Object.defineProperty(n,i,{configurable:!0,get:function(){return p.call(this)},set:function(A){o=""+A,b.call(this,A)}}),Object.defineProperty(n,i,{enumerable:u.enumerable}),{getValue:function(){return o},setValue:function(A){o=""+A},stopTracking:function(){n._valueTracker=null,delete n[i]}}}}function Qu(n){if(!n._valueTracker){var i=ig(n)?"checked":"value";n._valueTracker=X1(n,i,""+n[i])}}function sg(n){if(!n)return!1;var i=n._valueTracker;if(!i)return!0;var o=i.getValue(),u="";return n&&(u=ig(n)?n.checked?"true":"false":n.value),n=u,n!==o?(i.setValue(n),!0):!1}function kl(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch{return n.body}}var W1=/[\n"\\]/g;function Cn(n){return n.replace(W1,function(i){return"\\"+i.charCodeAt(0).toString(16)+" "})}function Ku(n,i,o,u,p,b,A,M){n.name="",A!=null&&typeof A!="function"&&typeof A!="symbol"&&typeof A!="boolean"?n.type=A:n.removeAttribute("type"),i!=null?A==="number"?(i===0&&n.value===""||n.value!=i)&&(n.value=""+Tn(i)):n.value!==""+Tn(i)&&(n.value=""+Tn(i)):A!=="submit"&&A!=="reset"||n.removeAttribute("value"),i!=null?Zu(n,A,Tn(i)):o!=null?Zu(n,A,Tn(o)):u!=null&&n.removeAttribute("value"),p==null&&b!=null&&(n.defaultChecked=!!b),p!=null&&(n.checked=p&&typeof p!="function"&&typeof p!="symbol"),M!=null&&typeof M!="function"&&typeof M!="symbol"&&typeof M!="boolean"?n.name=""+Tn(M):n.removeAttribute("name")}function ag(n,i,o,u,p,b,A,M){if(b!=null&&typeof b!="function"&&typeof b!="symbol"&&typeof b!="boolean"&&(n.type=b),i!=null||o!=null){if(!(b!=="submit"&&b!=="reset"||i!=null)){Qu(n);return}o=o!=null?""+Tn(o):"",i=i!=null?""+Tn(i):o,M||i===n.value||(n.value=i),n.defaultValue=i}u=u??p,u=typeof u!="function"&&typeof u!="symbol"&&!!u,n.checked=M?n.checked:!!u,n.defaultChecked=!!u,A!=null&&typeof A!="function"&&typeof A!="symbol"&&typeof A!="boolean"&&(n.name=A),Qu(n)}function Zu(n,i,o){i==="number"&&kl(n.ownerDocument)===n||n.defaultValue===""+o||(n.defaultValue=""+o)}function Ea(n,i,o,u){if(n=n.options,i){i={};for(var p=0;p<o.length;p++)i["$"+o[p]]=!0;for(o=0;o<n.length;o++)p=i.hasOwnProperty("$"+n[o].value),n[o].selected!==p&&(n[o].selected=p),p&&u&&(n[o].defaultSelected=!0)}else{for(o=""+Tn(o),i=null,p=0;p<n.length;p++){if(n[p].value===o){n[p].selected=!0,u&&(n[p].defaultSelected=!0);return}i!==null||n[p].disabled||(i=n[p])}i!==null&&(i.selected=!0)}}function rg(n,i,o){if(i!=null&&(i=""+Tn(i),i!==n.value&&(n.value=i),o==null)){n.defaultValue!==i&&(n.defaultValue=i);return}n.defaultValue=o!=null?""+Tn(o):""}function og(n,i,o,u){if(i==null){if(u!=null){if(o!=null)throw Error(s(92));if(ut(u)){if(1<u.length)throw Error(s(93));u=u[0]}o=u}o==null&&(o=""),i=o}o=Tn(i),n.defaultValue=o,u=n.textContent,u===o&&u!==""&&u!==null&&(n.value=u),Qu(n)}function Ta(n,i){if(i){var o=n.firstChild;if(o&&o===n.lastChild&&o.nodeType===3){o.nodeValue=i;return}}n.textContent=i}var Q1=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function lg(n,i,o){var u=i.indexOf("--")===0;o==null||typeof o=="boolean"||o===""?u?n.setProperty(i,""):i==="float"?n.cssFloat="":n[i]="":u?n.setProperty(i,o):typeof o!="number"||o===0||Q1.has(i)?i==="float"?n.cssFloat=o:n[i]=(""+o).trim():n[i]=o+"px"}function cg(n,i,o){if(i!=null&&typeof i!="object")throw Error(s(62));if(n=n.style,o!=null){for(var u in o)!o.hasOwnProperty(u)||i!=null&&i.hasOwnProperty(u)||(u.indexOf("--")===0?n.setProperty(u,""):u==="float"?n.cssFloat="":n[u]="");for(var p in i)u=i[p],i.hasOwnProperty(p)&&o[p]!==u&&lg(n,p,u)}else for(var b in i)i.hasOwnProperty(b)&&lg(n,b,i[b])}function Ju(n){if(n.indexOf("-")===-1)return!1;switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var K1=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Z1=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Ml(n){return Z1.test(""+n)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":n}function hi(){}var td=null;function ed(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var Ca=null,_a=null;function ug(n){var i=Aa(n);if(i&&(n=i.stateNode)){var o=n[Ke]||null;t:switch(n=i.stateNode,i.type){case"input":if(Ku(n,o.value,o.defaultValue,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name),i=o.name,o.type==="radio"&&i!=null){for(o=n;o.parentNode;)o=o.parentNode;for(o=o.querySelectorAll('input[name="'+Cn(""+i)+'"][type="radio"]'),i=0;i<o.length;i++){var u=o[i];if(u!==n&&u.form===n.form){var p=u[Ke]||null;if(!p)throw Error(s(90));Ku(u,p.value,p.defaultValue,p.defaultValue,p.checked,p.defaultChecked,p.type,p.name)}}for(i=0;i<o.length;i++)u=o[i],u.form===n.form&&sg(u)}break t;case"textarea":rg(n,o.value,o.defaultValue);break t;case"select":i=o.value,i!=null&&Ea(n,!!o.multiple,i,!1)}}}var nd=!1;function dg(n,i,o){if(nd)return n(i,o);nd=!0;try{var u=n(i);return u}finally{if(nd=!1,(Ca!==null||_a!==null)&&(mc(),Ca&&(i=Ca,n=_a,_a=Ca=null,ug(i),n)))for(i=0;i<n.length;i++)ug(n[i])}}function Qr(n,i){var o=n.stateNode;if(o===null)return null;var u=o[Ke]||null;if(u===null)return null;o=u[i];t:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(u=!u.disabled)||(n=n.type,u=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!u;break t;default:n=!1}if(n)return null;if(o&&typeof o!="function")throw Error(s(231,i,typeof o));return o}var fi=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),id=!1;if(fi)try{var Kr={};Object.defineProperty(Kr,"passive",{get:function(){id=!0}}),window.addEventListener("test",Kr,Kr),window.removeEventListener("test",Kr,Kr)}catch{id=!1}var $i=null,sd=null,Dl=null;function hg(){if(Dl)return Dl;var n,i=sd,o=i.length,u,p="value"in $i?$i.value:$i.textContent,b=p.length;for(n=0;n<o&&i[n]===p[n];n++);var A=o-n;for(u=1;u<=A&&i[o-u]===p[b-u];u++);return Dl=p.slice(n,1<u?1-u:void 0)}function Rl(n){var i=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&i===13&&(n=13)):n=i,n===10&&(n=13),32<=n||n===13?n:0}function Ll(){return!0}function fg(){return!1}function Ze(n){function i(o,u,p,b,A){this._reactName=o,this._targetInst=p,this.type=u,this.nativeEvent=b,this.target=A,this.currentTarget=null;for(var M in n)n.hasOwnProperty(M)&&(o=n[M],this[M]=o?o(b):b[M]);return this.isDefaultPrevented=(b.defaultPrevented!=null?b.defaultPrevented:b.returnValue===!1)?Ll:fg,this.isPropagationStopped=fg,this}return m(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var o=this.nativeEvent;o&&(o.preventDefault?o.preventDefault():typeof o.returnValue!="unknown"&&(o.returnValue=!1),this.isDefaultPrevented=Ll)},stopPropagation:function(){var o=this.nativeEvent;o&&(o.stopPropagation?o.stopPropagation():typeof o.cancelBubble!="unknown"&&(o.cancelBubble=!0),this.isPropagationStopped=Ll)},persist:function(){},isPersistent:Ll}),i}var Ds={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Ol=Ze(Ds),Zr=m({},Ds,{view:0,detail:0}),J1=Ze(Zr),ad,rd,Jr,jl=m({},Zr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ld,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==Jr&&(Jr&&n.type==="mousemove"?(ad=n.screenX-Jr.screenX,rd=n.screenY-Jr.screenY):rd=ad=0,Jr=n),ad)},movementY:function(n){return"movementY"in n?n.movementY:rd}}),pg=Ze(jl),tA=m({},jl,{dataTransfer:0}),eA=Ze(tA),nA=m({},Zr,{relatedTarget:0}),od=Ze(nA),iA=m({},Ds,{animationName:0,elapsedTime:0,pseudoElement:0}),sA=Ze(iA),aA=m({},Ds,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),rA=Ze(aA),oA=m({},Ds,{data:0}),gg=Ze(oA),lA={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},cA={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},uA={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function dA(n){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(n):(n=uA[n])?!!i[n]:!1}function ld(){return dA}var hA=m({},Zr,{key:function(n){if(n.key){var i=lA[n.key]||n.key;if(i!=="Unidentified")return i}return n.type==="keypress"?(n=Rl(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?cA[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ld,charCode:function(n){return n.type==="keypress"?Rl(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?Rl(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),fA=Ze(hA),pA=m({},jl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),mg=Ze(pA),gA=m({},Zr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ld}),mA=Ze(gA),bA=m({},Ds,{propertyName:0,elapsedTime:0,pseudoElement:0}),yA=Ze(bA),xA=m({},jl,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),vA=Ze(xA),AA=m({},Ds,{newState:0,oldState:0}),wA=Ze(AA),SA=[9,13,27,32],cd=fi&&"CompositionEvent"in window,to=null;fi&&"documentMode"in document&&(to=document.documentMode);var EA=fi&&"TextEvent"in window&&!to,bg=fi&&(!cd||to&&8<to&&11>=to),yg=" ",xg=!1;function vg(n,i){switch(n){case"keyup":return SA.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Ag(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var ka=!1;function TA(n,i){switch(n){case"compositionend":return Ag(i);case"keypress":return i.which!==32?null:(xg=!0,yg);case"textInput":return n=i.data,n===yg&&xg?null:n;default:return null}}function CA(n,i){if(ka)return n==="compositionend"||!cd&&vg(n,i)?(n=hg(),Dl=sd=$i=null,ka=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return bg&&i.locale!=="ko"?null:i.data;default:return null}}var _A={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function wg(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i==="input"?!!_A[n.type]:i==="textarea"}function Sg(n,i,o,u){Ca?_a?_a.push(u):_a=[u]:Ca=u,i=Sc(i,"onChange"),0<i.length&&(o=new Ol("onChange","change",null,o,u),n.push({event:o,listeners:i}))}var eo=null,no=null;function kA(n){ab(n,0)}function Nl(n){var i=Wr(n);if(sg(i))return n}function Eg(n,i){if(n==="change")return i}var Tg=!1;if(fi){var ud;if(fi){var dd="oninput"in document;if(!dd){var Cg=document.createElement("div");Cg.setAttribute("oninput","return;"),dd=typeof Cg.oninput=="function"}ud=dd}else ud=!1;Tg=ud&&(!document.documentMode||9<document.documentMode)}function _g(){eo&&(eo.detachEvent("onpropertychange",kg),no=eo=null)}function kg(n){if(n.propertyName==="value"&&Nl(no)){var i=[];Sg(i,no,n,ed(n)),dg(kA,i)}}function MA(n,i,o){n==="focusin"?(_g(),eo=i,no=o,eo.attachEvent("onpropertychange",kg)):n==="focusout"&&_g()}function DA(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return Nl(no)}function RA(n,i){if(n==="click")return Nl(i)}function LA(n,i){if(n==="input"||n==="change")return Nl(i)}function OA(n,i){return n===i&&(n!==0||1/n===1/i)||n!==n&&i!==i}var dn=typeof Object.is=="function"?Object.is:OA;function io(n,i){if(dn(n,i))return!0;if(typeof n!="object"||n===null||typeof i!="object"||i===null)return!1;var o=Object.keys(n),u=Object.keys(i);if(o.length!==u.length)return!1;for(u=0;u<o.length;u++){var p=o[u];if(!Qe.call(i,p)||!dn(n[p],i[p]))return!1}return!0}function Mg(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function Dg(n,i){var o=Mg(n);n=0;for(var u;o;){if(o.nodeType===3){if(u=n+o.textContent.length,n<=i&&u>=i)return{node:o,offset:i-n};n=u}t:{for(;o;){if(o.nextSibling){o=o.nextSibling;break t}o=o.parentNode}o=void 0}o=Mg(o)}}function Rg(n,i){return n&&i?n===i?!0:n&&n.nodeType===3?!1:i&&i.nodeType===3?Rg(n,i.parentNode):"contains"in n?n.contains(i):n.compareDocumentPosition?!!(n.compareDocumentPosition(i)&16):!1:!1}function Lg(n){n=n!=null&&n.ownerDocument!=null&&n.ownerDocument.defaultView!=null?n.ownerDocument.defaultView:window;for(var i=kl(n.document);i instanceof n.HTMLIFrameElement;){try{var o=typeof i.contentWindow.location.href=="string"}catch{o=!1}if(o)n=i.contentWindow;else break;i=kl(n.document)}return i}function hd(n){var i=n&&n.nodeName&&n.nodeName.toLowerCase();return i&&(i==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||i==="textarea"||n.contentEditable==="true")}var jA=fi&&"documentMode"in document&&11>=document.documentMode,Ma=null,fd=null,so=null,pd=!1;function Og(n,i,o){var u=o.window===o?o.document:o.nodeType===9?o:o.ownerDocument;pd||Ma==null||Ma!==kl(u)||(u=Ma,"selectionStart"in u&&hd(u)?u={start:u.selectionStart,end:u.selectionEnd}:(u=(u.ownerDocument&&u.ownerDocument.defaultView||window).getSelection(),u={anchorNode:u.anchorNode,anchorOffset:u.anchorOffset,focusNode:u.focusNode,focusOffset:u.focusOffset}),so&&io(so,u)||(so=u,u=Sc(fd,"onSelect"),0<u.length&&(i=new Ol("onSelect","select",null,i,o),n.push({event:i,listeners:u}),i.target=Ma)))}function Rs(n,i){var o={};return o[n.toLowerCase()]=i.toLowerCase(),o["Webkit"+n]="webkit"+i,o["Moz"+n]="moz"+i,o}var Da={animationend:Rs("Animation","AnimationEnd"),animationiteration:Rs("Animation","AnimationIteration"),animationstart:Rs("Animation","AnimationStart"),transitionrun:Rs("Transition","TransitionRun"),transitionstart:Rs("Transition","TransitionStart"),transitioncancel:Rs("Transition","TransitionCancel"),transitionend:Rs("Transition","TransitionEnd")},gd={},jg={};fi&&(jg=document.createElement("div").style,"AnimationEvent"in window||(delete Da.animationend.animation,delete Da.animationiteration.animation,delete Da.animationstart.animation),"TransitionEvent"in window||delete Da.transitionend.transition);function Ls(n){if(gd[n])return gd[n];if(!Da[n])return n;var i=Da[n],o;for(o in i)if(i.hasOwnProperty(o)&&o in jg)return gd[n]=i[o];return n}var Ng=Ls("animationend"),Bg=Ls("animationiteration"),zg=Ls("animationstart"),NA=Ls("transitionrun"),BA=Ls("transitionstart"),zA=Ls("transitioncancel"),Pg=Ls("transitionend"),Ig=new Map,md="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");md.push("scrollEnd");function $n(n,i){Ig.set(n,i),Ms(i,[n])}var Bl=typeof reportError=="function"?reportError:function(n){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var i=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof n=="object"&&n!==null&&typeof n.message=="string"?String(n.message):String(n),error:n});if(!window.dispatchEvent(i))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",n);return}console.error(n)},_n=[],Ra=0,bd=0;function zl(){for(var n=Ra,i=bd=Ra=0;i<n;){var o=_n[i];_n[i++]=null;var u=_n[i];_n[i++]=null;var p=_n[i];_n[i++]=null;var b=_n[i];if(_n[i++]=null,u!==null&&p!==null){var A=u.pending;A===null?p.next=p:(p.next=A.next,A.next=p),u.pending=p}b!==0&&Fg(o,p,b)}}function Pl(n,i,o,u){_n[Ra++]=n,_n[Ra++]=i,_n[Ra++]=o,_n[Ra++]=u,bd|=u,n.lanes|=u,n=n.alternate,n!==null&&(n.lanes|=u)}function yd(n,i,o,u){return Pl(n,i,o,u),Il(n)}function Os(n,i){return Pl(n,null,null,i),Il(n)}function Fg(n,i,o){n.lanes|=o;var u=n.alternate;u!==null&&(u.lanes|=o);for(var p=!1,b=n.return;b!==null;)b.childLanes|=o,u=b.alternate,u!==null&&(u.childLanes|=o),b.tag===22&&(n=b.stateNode,n===null||n._visibility&1||(p=!0)),n=b,b=b.return;return n.tag===3?(b=n.stateNode,p&&i!==null&&(p=31-un(o),n=b.hiddenUpdates,u=n[p],u===null?n[p]=[i]:u.push(i),i.lane=o|536870912),b):null}function Il(n){if(50<_o)throw _o=0,_h=null,Error(s(185));for(var i=n.return;i!==null;)n=i,i=n.return;return n.tag===3?n.stateNode:null}var La={};function PA(n,i,o,u){this.tag=n,this.key=o,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=u,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function hn(n,i,o,u){return new PA(n,i,o,u)}function xd(n){return n=n.prototype,!(!n||!n.isReactComponent)}function pi(n,i){var o=n.alternate;return o===null?(o=hn(n.tag,i,n.key,n.mode),o.elementType=n.elementType,o.type=n.type,o.stateNode=n.stateNode,o.alternate=n,n.alternate=o):(o.pendingProps=i,o.type=n.type,o.flags=0,o.subtreeFlags=0,o.deletions=null),o.flags=n.flags&65011712,o.childLanes=n.childLanes,o.lanes=n.lanes,o.child=n.child,o.memoizedProps=n.memoizedProps,o.memoizedState=n.memoizedState,o.updateQueue=n.updateQueue,i=n.dependencies,o.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},o.sibling=n.sibling,o.index=n.index,o.ref=n.ref,o.refCleanup=n.refCleanup,o}function $g(n,i){n.flags&=65011714;var o=n.alternate;return o===null?(n.childLanes=0,n.lanes=i,n.child=null,n.subtreeFlags=0,n.memoizedProps=null,n.memoizedState=null,n.updateQueue=null,n.dependencies=null,n.stateNode=null):(n.childLanes=o.childLanes,n.lanes=o.lanes,n.child=o.child,n.subtreeFlags=0,n.deletions=null,n.memoizedProps=o.memoizedProps,n.memoizedState=o.memoizedState,n.updateQueue=o.updateQueue,n.type=o.type,i=o.dependencies,n.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext}),n}function Fl(n,i,o,u,p,b){var A=0;if(u=n,typeof n=="function")xd(n)&&(A=1);else if(typeof n=="string")A=Uw(n,o,tt.current)?26:n==="html"||n==="head"||n==="body"?27:5;else t:switch(n){case F:return n=hn(31,o,i,p),n.elementType=F,n.lanes=b,n;case S:return js(o.children,p,b,i);case C:A=8,p|=24;break;case T:return n=hn(12,o,i,p|2),n.elementType=T,n.lanes=b,n;case D:return n=hn(13,o,i,p),n.elementType=D,n.lanes=b,n;case L:return n=hn(19,o,i,p),n.elementType=L,n.lanes=b,n;default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case k:A=10;break t;case _:A=9;break t;case R:A=11;break t;case O:A=14;break t;case B:A=16,u=null;break t}A=29,o=Error(s(130,n===null?"null":typeof n,"")),u=null}return i=hn(A,o,i,p),i.elementType=n,i.type=u,i.lanes=b,i}function js(n,i,o,u){return n=hn(7,n,u,i),n.lanes=o,n}function vd(n,i,o){return n=hn(6,n,null,i),n.lanes=o,n}function Hg(n){var i=hn(18,null,null,0);return i.stateNode=n,i}function Ad(n,i,o){return i=hn(4,n.children!==null?n.children:[],n.key,i),i.lanes=o,i.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},i}var Ug=new WeakMap;function kn(n,i){if(typeof n=="object"&&n!==null){var o=Ug.get(n);return o!==void 0?o:(i={value:n,source:i,stack:Sn(i)},Ug.set(n,i),i)}return{value:n,source:i,stack:Sn(i)}}var Oa=[],ja=0,$l=null,ao=0,Mn=[],Dn=0,Hi=null,Qn=1,Kn="";function gi(n,i){Oa[ja++]=ao,Oa[ja++]=$l,$l=n,ao=i}function Gg(n,i,o){Mn[Dn++]=Qn,Mn[Dn++]=Kn,Mn[Dn++]=Hi,Hi=n;var u=Qn;n=Kn;var p=32-un(u)-1;u&=~(1<<p),o+=1;var b=32-un(i)+p;if(30<b){var A=p-p%5;b=(u&(1<<A)-1).toString(32),u>>=A,p-=A,Qn=1<<32-un(i)+p|o<<p|u,Kn=b+n}else Qn=1<<b|o<<p|u,Kn=n}function wd(n){n.return!==null&&(gi(n,1),Gg(n,1,0))}function Sd(n){for(;n===$l;)$l=Oa[--ja],Oa[ja]=null,ao=Oa[--ja],Oa[ja]=null;for(;n===Hi;)Hi=Mn[--Dn],Mn[Dn]=null,Kn=Mn[--Dn],Mn[Dn]=null,Qn=Mn[--Dn],Mn[Dn]=null}function Vg(n,i){Mn[Dn++]=Qn,Mn[Dn++]=Kn,Mn[Dn++]=Hi,Qn=i.id,Kn=i.overflow,Hi=n}var Be=null,se=null,$t=!1,Ui=null,Rn=!1,Ed=Error(s(519));function Gi(n){var i=Error(s(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw ro(kn(i,n)),Ed}function qg(n){var i=n.stateNode,o=n.type,u=n.memoizedProps;switch(i[Ne]=n,i[Ke]=u,o){case"dialog":zt("cancel",i),zt("close",i);break;case"iframe":case"object":case"embed":zt("load",i);break;case"video":case"audio":for(o=0;o<Mo.length;o++)zt(Mo[o],i);break;case"source":zt("error",i);break;case"img":case"image":case"link":zt("error",i),zt("load",i);break;case"details":zt("toggle",i);break;case"input":zt("invalid",i),ag(i,u.value,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name,!0);break;case"select":zt("invalid",i);break;case"textarea":zt("invalid",i),og(i,u.value,u.defaultValue,u.children)}o=u.children,typeof o!="string"&&typeof o!="number"&&typeof o!="bigint"||i.textContent===""+o||u.suppressHydrationWarning===!0||cb(i.textContent,o)?(u.popover!=null&&(zt("beforetoggle",i),zt("toggle",i)),u.onScroll!=null&&zt("scroll",i),u.onScrollEnd!=null&&zt("scrollend",i),u.onClick!=null&&(i.onclick=hi),i=!0):i=!1,i||Gi(n,!0)}function Yg(n){for(Be=n.return;Be;)switch(Be.tag){case 5:case 31:case 13:Rn=!1;return;case 27:case 3:Rn=!0;return;default:Be=Be.return}}function Na(n){if(n!==Be)return!1;if(!$t)return Yg(n),$t=!0,!1;var i=n.tag,o;if((o=i!==3&&i!==27)&&((o=i===5)&&(o=n.type,o=!(o!=="form"&&o!=="button")||Hh(n.type,n.memoizedProps)),o=!o),o&&se&&Gi(n),Yg(n),i===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(s(317));se=yb(n)}else if(i===31){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(s(317));se=yb(n)}else i===27?(i=se,ss(n.type)?(n=Yh,Yh=null,se=n):se=i):se=Be?On(n.stateNode.nextSibling):null;return!0}function Ns(){se=Be=null,$t=!1}function Td(){var n=Ui;return n!==null&&(nn===null?nn=n:nn.push.apply(nn,n),Ui=null),n}function ro(n){Ui===null?Ui=[n]:Ui.push(n)}var Cd=z(null),Bs=null,mi=null;function Vi(n,i,o){q(Cd,i._currentValue),i._currentValue=o}function bi(n){n._currentValue=Cd.current,H(Cd)}function _d(n,i,o){for(;n!==null;){var u=n.alternate;if((n.childLanes&i)!==i?(n.childLanes|=i,u!==null&&(u.childLanes|=i)):u!==null&&(u.childLanes&i)!==i&&(u.childLanes|=i),n===o)break;n=n.return}}function kd(n,i,o,u){var p=n.child;for(p!==null&&(p.return=n);p!==null;){var b=p.dependencies;if(b!==null){var A=p.child;b=b.firstContext;t:for(;b!==null;){var M=b;b=p;for(var N=0;N<i.length;N++)if(M.context===i[N]){b.lanes|=o,M=b.alternate,M!==null&&(M.lanes|=o),_d(b.return,o,n),u||(A=null);break t}b=M.next}}else if(p.tag===18){if(A=p.return,A===null)throw Error(s(341));A.lanes|=o,b=A.alternate,b!==null&&(b.lanes|=o),_d(A,o,n),A=null}else A=p.child;if(A!==null)A.return=p;else for(A=p;A!==null;){if(A===n){A=null;break}if(p=A.sibling,p!==null){p.return=A.return,A=p;break}A=A.return}p=A}}function Ba(n,i,o,u){n=null;for(var p=i,b=!1;p!==null;){if(!b){if((p.flags&524288)!==0)b=!0;else if((p.flags&262144)!==0)break}if(p.tag===10){var A=p.alternate;if(A===null)throw Error(s(387));if(A=A.memoizedProps,A!==null){var M=p.type;dn(p.pendingProps.value,A.value)||(n!==null?n.push(M):n=[M])}}else if(p===at.current){if(A=p.alternate,A===null)throw Error(s(387));A.memoizedState.memoizedState!==p.memoizedState.memoizedState&&(n!==null?n.push(jo):n=[jo])}p=p.return}n!==null&&kd(i,n,o,u),i.flags|=262144}function Hl(n){for(n=n.firstContext;n!==null;){if(!dn(n.context._currentValue,n.memoizedValue))return!0;n=n.next}return!1}function zs(n){Bs=n,mi=null,n=n.dependencies,n!==null&&(n.firstContext=null)}function ze(n){return Xg(Bs,n)}function Ul(n,i){return Bs===null&&zs(n),Xg(n,i)}function Xg(n,i){var o=i._currentValue;if(i={context:i,memoizedValue:o,next:null},mi===null){if(n===null)throw Error(s(308));mi=i,n.dependencies={lanes:0,firstContext:i},n.flags|=524288}else mi=mi.next=i;return o}var IA=typeof AbortController<"u"?AbortController:function(){var n=[],i=this.signal={aborted:!1,addEventListener:function(o,u){n.push(u)}};this.abort=function(){i.aborted=!0,n.forEach(function(o){return o()})}},FA=r.unstable_scheduleCallback,$A=r.unstable_NormalPriority,Ae={$$typeof:k,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Md(){return{controller:new IA,data:new Map,refCount:0}}function oo(n){n.refCount--,n.refCount===0&&FA($A,function(){n.controller.abort()})}var lo=null,Dd=0,za=0,Pa=null;function HA(n,i){if(lo===null){var o=lo=[];Dd=0,za=Oh(),Pa={status:"pending",value:void 0,then:function(u){o.push(u)}}}return Dd++,i.then(Wg,Wg),i}function Wg(){if(--Dd===0&&lo!==null){Pa!==null&&(Pa.status="fulfilled");var n=lo;lo=null,za=0,Pa=null;for(var i=0;i<n.length;i++)(0,n[i])()}}function UA(n,i){var o=[],u={status:"pending",value:null,reason:null,then:function(p){o.push(p)}};return n.then(function(){u.status="fulfilled",u.value=i;for(var p=0;p<o.length;p++)(0,o[p])(i)},function(p){for(u.status="rejected",u.reason=p,p=0;p<o.length;p++)(0,o[p])(void 0)}),u}var Qg=P.S;P.S=function(n,i){O0=Ue(),typeof i=="object"&&i!==null&&typeof i.then=="function"&&HA(n,i),Qg!==null&&Qg(n,i)};var Ps=z(null);function Rd(){var n=Ps.current;return n!==null?n:ee.pooledCache}function Gl(n,i){i===null?q(Ps,Ps.current):q(Ps,i.pool)}function Kg(){var n=Rd();return n===null?null:{parent:Ae._currentValue,pool:n}}var Ia=Error(s(460)),Ld=Error(s(474)),Vl=Error(s(542)),ql={then:function(){}};function Zg(n){return n=n.status,n==="fulfilled"||n==="rejected"}function Jg(n,i,o){switch(o=n[o],o===void 0?n.push(i):o!==i&&(i.then(hi,hi),i=o),i.status){case"fulfilled":return i.value;case"rejected":throw n=i.reason,em(n),n;default:if(typeof i.status=="string")i.then(hi,hi);else{if(n=ee,n!==null&&100<n.shellSuspendCounter)throw Error(s(482));n=i,n.status="pending",n.then(function(u){if(i.status==="pending"){var p=i;p.status="fulfilled",p.value=u}},function(u){if(i.status==="pending"){var p=i;p.status="rejected",p.reason=u}})}switch(i.status){case"fulfilled":return i.value;case"rejected":throw n=i.reason,em(n),n}throw Fs=i,Ia}}function Is(n){try{var i=n._init;return i(n._payload)}catch(o){throw o!==null&&typeof o=="object"&&typeof o.then=="function"?(Fs=o,Ia):o}}var Fs=null;function tm(){if(Fs===null)throw Error(s(459));var n=Fs;return Fs=null,n}function em(n){if(n===Ia||n===Vl)throw Error(s(483))}var Fa=null,co=0;function Yl(n){var i=co;return co+=1,Fa===null&&(Fa=[]),Jg(Fa,n,i)}function uo(n,i){i=i.props.ref,n.ref=i!==void 0?i:null}function Xl(n,i){throw i.$$typeof===x?Error(s(525)):(n=Object.prototype.toString.call(i),Error(s(31,n==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":n)))}function nm(n){function i($,I){if(n){var U=$.deletions;U===null?($.deletions=[I],$.flags|=16):U.push(I)}}function o($,I){if(!n)return null;for(;I!==null;)i($,I),I=I.sibling;return null}function u($){for(var I=new Map;$!==null;)$.key!==null?I.set($.key,$):I.set($.index,$),$=$.sibling;return I}function p($,I){return $=pi($,I),$.index=0,$.sibling=null,$}function b($,I,U){return $.index=U,n?(U=$.alternate,U!==null?(U=U.index,U<I?($.flags|=67108866,I):U):($.flags|=67108866,I)):($.flags|=1048576,I)}function A($){return n&&$.alternate===null&&($.flags|=67108866),$}function M($,I,U,nt){return I===null||I.tag!==6?(I=vd(U,$.mode,nt),I.return=$,I):(I=p(I,U),I.return=$,I)}function N($,I,U,nt){var wt=U.type;return wt===S?J($,I,U.props.children,nt,U.key):I!==null&&(I.elementType===wt||typeof wt=="object"&&wt!==null&&wt.$$typeof===B&&Is(wt)===I.type)?(I=p(I,U.props),uo(I,U),I.return=$,I):(I=Fl(U.type,U.key,U.props,null,$.mode,nt),uo(I,U),I.return=$,I)}function G($,I,U,nt){return I===null||I.tag!==4||I.stateNode.containerInfo!==U.containerInfo||I.stateNode.implementation!==U.implementation?(I=Ad(U,$.mode,nt),I.return=$,I):(I=p(I,U.children||[]),I.return=$,I)}function J($,I,U,nt,wt){return I===null||I.tag!==7?(I=js(U,$.mode,nt,wt),I.return=$,I):(I=p(I,U),I.return=$,I)}function it($,I,U){if(typeof I=="string"&&I!==""||typeof I=="number"||typeof I=="bigint")return I=vd(""+I,$.mode,U),I.return=$,I;if(typeof I=="object"&&I!==null){switch(I.$$typeof){case v:return U=Fl(I.type,I.key,I.props,null,$.mode,U),uo(U,I),U.return=$,U;case E:return I=Ad(I,$.mode,U),I.return=$,I;case B:return I=Is(I),it($,I,U)}if(ut(I)||rt(I))return I=js(I,$.mode,U,null),I.return=$,I;if(typeof I.then=="function")return it($,Yl(I),U);if(I.$$typeof===k)return it($,Ul($,I),U);Xl($,I)}return null}function Y($,I,U,nt){var wt=I!==null?I.key:null;if(typeof U=="string"&&U!==""||typeof U=="number"||typeof U=="bigint")return wt!==null?null:M($,I,""+U,nt);if(typeof U=="object"&&U!==null){switch(U.$$typeof){case v:return U.key===wt?N($,I,U,nt):null;case E:return U.key===wt?G($,I,U,nt):null;case B:return U=Is(U),Y($,I,U,nt)}if(ut(U)||rt(U))return wt!==null?null:J($,I,U,nt,null);if(typeof U.then=="function")return Y($,I,Yl(U),nt);if(U.$$typeof===k)return Y($,I,Ul($,U),nt);Xl($,U)}return null}function Q($,I,U,nt,wt){if(typeof nt=="string"&&nt!==""||typeof nt=="number"||typeof nt=="bigint")return $=$.get(U)||null,M(I,$,""+nt,wt);if(typeof nt=="object"&&nt!==null){switch(nt.$$typeof){case v:return $=$.get(nt.key===null?U:nt.key)||null,N(I,$,nt,wt);case E:return $=$.get(nt.key===null?U:nt.key)||null,G(I,$,nt,wt);case B:return nt=Is(nt),Q($,I,U,nt,wt)}if(ut(nt)||rt(nt))return $=$.get(U)||null,J(I,$,nt,wt,null);if(typeof nt.then=="function")return Q($,I,U,Yl(nt),wt);if(nt.$$typeof===k)return Q($,I,U,Ul(I,nt),wt);Xl(I,nt)}return null}function mt($,I,U,nt){for(var wt=null,Ut=null,vt=I,Ot=I=0,It=null;vt!==null&&Ot<U.length;Ot++){vt.index>Ot?(It=vt,vt=null):It=vt.sibling;var Gt=Y($,vt,U[Ot],nt);if(Gt===null){vt===null&&(vt=It);break}n&&vt&&Gt.alternate===null&&i($,vt),I=b(Gt,I,Ot),Ut===null?wt=Gt:Ut.sibling=Gt,Ut=Gt,vt=It}if(Ot===U.length)return o($,vt),$t&&gi($,Ot),wt;if(vt===null){for(;Ot<U.length;Ot++)vt=it($,U[Ot],nt),vt!==null&&(I=b(vt,I,Ot),Ut===null?wt=vt:Ut.sibling=vt,Ut=vt);return $t&&gi($,Ot),wt}for(vt=u(vt);Ot<U.length;Ot++)It=Q(vt,$,Ot,U[Ot],nt),It!==null&&(n&&It.alternate!==null&&vt.delete(It.key===null?Ot:It.key),I=b(It,I,Ot),Ut===null?wt=It:Ut.sibling=It,Ut=It);return n&&vt.forEach(function(cs){return i($,cs)}),$t&&gi($,Ot),wt}function Tt($,I,U,nt){if(U==null)throw Error(s(151));for(var wt=null,Ut=null,vt=I,Ot=I=0,It=null,Gt=U.next();vt!==null&&!Gt.done;Ot++,Gt=U.next()){vt.index>Ot?(It=vt,vt=null):It=vt.sibling;var cs=Y($,vt,Gt.value,nt);if(cs===null){vt===null&&(vt=It);break}n&&vt&&cs.alternate===null&&i($,vt),I=b(cs,I,Ot),Ut===null?wt=cs:Ut.sibling=cs,Ut=cs,vt=It}if(Gt.done)return o($,vt),$t&&gi($,Ot),wt;if(vt===null){for(;!Gt.done;Ot++,Gt=U.next())Gt=it($,Gt.value,nt),Gt!==null&&(I=b(Gt,I,Ot),Ut===null?wt=Gt:Ut.sibling=Gt,Ut=Gt);return $t&&gi($,Ot),wt}for(vt=u(vt);!Gt.done;Ot++,Gt=U.next())Gt=Q(vt,$,Ot,Gt.value,nt),Gt!==null&&(n&&Gt.alternate!==null&&vt.delete(Gt.key===null?Ot:Gt.key),I=b(Gt,I,Ot),Ut===null?wt=Gt:Ut.sibling=Gt,Ut=Gt);return n&&vt.forEach(function(tS){return i($,tS)}),$t&&gi($,Ot),wt}function Jt($,I,U,nt){if(typeof U=="object"&&U!==null&&U.type===S&&U.key===null&&(U=U.props.children),typeof U=="object"&&U!==null){switch(U.$$typeof){case v:t:{for(var wt=U.key;I!==null;){if(I.key===wt){if(wt=U.type,wt===S){if(I.tag===7){o($,I.sibling),nt=p(I,U.props.children),nt.return=$,$=nt;break t}}else if(I.elementType===wt||typeof wt=="object"&&wt!==null&&wt.$$typeof===B&&Is(wt)===I.type){o($,I.sibling),nt=p(I,U.props),uo(nt,U),nt.return=$,$=nt;break t}o($,I);break}else i($,I);I=I.sibling}U.type===S?(nt=js(U.props.children,$.mode,nt,U.key),nt.return=$,$=nt):(nt=Fl(U.type,U.key,U.props,null,$.mode,nt),uo(nt,U),nt.return=$,$=nt)}return A($);case E:t:{for(wt=U.key;I!==null;){if(I.key===wt)if(I.tag===4&&I.stateNode.containerInfo===U.containerInfo&&I.stateNode.implementation===U.implementation){o($,I.sibling),nt=p(I,U.children||[]),nt.return=$,$=nt;break t}else{o($,I);break}else i($,I);I=I.sibling}nt=Ad(U,$.mode,nt),nt.return=$,$=nt}return A($);case B:return U=Is(U),Jt($,I,U,nt)}if(ut(U))return mt($,I,U,nt);if(rt(U)){if(wt=rt(U),typeof wt!="function")throw Error(s(150));return U=wt.call(U),Tt($,I,U,nt)}if(typeof U.then=="function")return Jt($,I,Yl(U),nt);if(U.$$typeof===k)return Jt($,I,Ul($,U),nt);Xl($,U)}return typeof U=="string"&&U!==""||typeof U=="number"||typeof U=="bigint"?(U=""+U,I!==null&&I.tag===6?(o($,I.sibling),nt=p(I,U),nt.return=$,$=nt):(o($,I),nt=vd(U,$.mode,nt),nt.return=$,$=nt),A($)):o($,I)}return function($,I,U,nt){try{co=0;var wt=Jt($,I,U,nt);return Fa=null,wt}catch(vt){if(vt===Ia||vt===Vl)throw vt;var Ut=hn(29,vt,null,$.mode);return Ut.lanes=nt,Ut.return=$,Ut}}}var $s=nm(!0),im=nm(!1),qi=!1;function Od(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function jd(n,i){n=n.updateQueue,i.updateQueue===n&&(i.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,callbacks:null})}function Yi(n){return{lane:n,tag:0,payload:null,callback:null,next:null}}function Xi(n,i,o){var u=n.updateQueue;if(u===null)return null;if(u=u.shared,(qt&2)!==0){var p=u.pending;return p===null?i.next=i:(i.next=p.next,p.next=i),u.pending=i,i=Il(n),Fg(n,null,o),i}return Pl(n,u,i,o),Il(n)}function ho(n,i,o){if(i=i.updateQueue,i!==null&&(i=i.shared,(o&4194048)!==0)){var u=i.lanes;u&=n.pendingLanes,o|=u,i.lanes=o,Xp(n,o)}}function Nd(n,i){var o=n.updateQueue,u=n.alternate;if(u!==null&&(u=u.updateQueue,o===u)){var p=null,b=null;if(o=o.firstBaseUpdate,o!==null){do{var A={lane:o.lane,tag:o.tag,payload:o.payload,callback:null,next:null};b===null?p=b=A:b=b.next=A,o=o.next}while(o!==null);b===null?p=b=i:b=b.next=i}else p=b=i;o={baseState:u.baseState,firstBaseUpdate:p,lastBaseUpdate:b,shared:u.shared,callbacks:u.callbacks},n.updateQueue=o;return}n=o.lastBaseUpdate,n===null?o.firstBaseUpdate=i:n.next=i,o.lastBaseUpdate=i}var Bd=!1;function fo(){if(Bd){var n=Pa;if(n!==null)throw n}}function po(n,i,o,u){Bd=!1;var p=n.updateQueue;qi=!1;var b=p.firstBaseUpdate,A=p.lastBaseUpdate,M=p.shared.pending;if(M!==null){p.shared.pending=null;var N=M,G=N.next;N.next=null,A===null?b=G:A.next=G,A=N;var J=n.alternate;J!==null&&(J=J.updateQueue,M=J.lastBaseUpdate,M!==A&&(M===null?J.firstBaseUpdate=G:M.next=G,J.lastBaseUpdate=N))}if(b!==null){var it=p.baseState;A=0,J=G=N=null,M=b;do{var Y=M.lane&-536870913,Q=Y!==M.lane;if(Q?(Pt&Y)===Y:(u&Y)===Y){Y!==0&&Y===za&&(Bd=!0),J!==null&&(J=J.next={lane:0,tag:M.tag,payload:M.payload,callback:null,next:null});t:{var mt=n,Tt=M;Y=i;var Jt=o;switch(Tt.tag){case 1:if(mt=Tt.payload,typeof mt=="function"){it=mt.call(Jt,it,Y);break t}it=mt;break t;case 3:mt.flags=mt.flags&-65537|128;case 0:if(mt=Tt.payload,Y=typeof mt=="function"?mt.call(Jt,it,Y):mt,Y==null)break t;it=m({},it,Y);break t;case 2:qi=!0}}Y=M.callback,Y!==null&&(n.flags|=64,Q&&(n.flags|=8192),Q=p.callbacks,Q===null?p.callbacks=[Y]:Q.push(Y))}else Q={lane:Y,tag:M.tag,payload:M.payload,callback:M.callback,next:null},J===null?(G=J=Q,N=it):J=J.next=Q,A|=Y;if(M=M.next,M===null){if(M=p.shared.pending,M===null)break;Q=M,M=Q.next,Q.next=null,p.lastBaseUpdate=Q,p.shared.pending=null}}while(!0);J===null&&(N=it),p.baseState=N,p.firstBaseUpdate=G,p.lastBaseUpdate=J,b===null&&(p.shared.lanes=0),Ji|=A,n.lanes=A,n.memoizedState=it}}function sm(n,i){if(typeof n!="function")throw Error(s(191,n));n.call(i)}function am(n,i){var o=n.callbacks;if(o!==null)for(n.callbacks=null,n=0;n<o.length;n++)sm(o[n],i)}var $a=z(null),Wl=z(0);function rm(n,i){n=Ci,q(Wl,n),q($a,i),Ci=n|i.baseLanes}function zd(){q(Wl,Ci),q($a,$a.current)}function Pd(){Ci=Wl.current,H($a),H(Wl)}var fn=z(null),Ln=null;function Wi(n){var i=n.alternate;q(be,be.current&1),q(fn,n),Ln===null&&(i===null||$a.current!==null||i.memoizedState!==null)&&(Ln=n)}function Id(n){q(be,be.current),q(fn,n),Ln===null&&(Ln=n)}function om(n){n.tag===22?(q(be,be.current),q(fn,n),Ln===null&&(Ln=n)):Qi()}function Qi(){q(be,be.current),q(fn,fn.current)}function pn(n){H(fn),Ln===n&&(Ln=null),H(be)}var be=z(0);function Ql(n){for(var i=n;i!==null;){if(i.tag===13){var o=i.memoizedState;if(o!==null&&(o=o.dehydrated,o===null||Vh(o)||qh(o)))return i}else if(i.tag===19&&(i.memoizedProps.revealOrder==="forwards"||i.memoizedProps.revealOrder==="backwards"||i.memoizedProps.revealOrder==="unstable_legacy-backwards"||i.memoizedProps.revealOrder==="together")){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var yi=0,Lt=null,Kt=null,we=null,Kl=!1,Ha=!1,Hs=!1,Zl=0,go=0,Ua=null,GA=0;function pe(){throw Error(s(321))}function Fd(n,i){if(i===null)return!1;for(var o=0;o<i.length&&o<n.length;o++)if(!dn(n[o],i[o]))return!1;return!0}function $d(n,i,o,u,p,b){return yi=b,Lt=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,P.H=n===null||n.memoizedState===null?Gm:nh,Hs=!1,b=o(u,p),Hs=!1,Ha&&(b=cm(i,o,u,p)),lm(n),b}function lm(n){P.H=yo;var i=Kt!==null&&Kt.next!==null;if(yi=0,we=Kt=Lt=null,Kl=!1,go=0,Ua=null,i)throw Error(s(300));n===null||Se||(n=n.dependencies,n!==null&&Hl(n)&&(Se=!0))}function cm(n,i,o,u){Lt=n;var p=0;do{if(Ha&&(Ua=null),go=0,Ha=!1,25<=p)throw Error(s(301));if(p+=1,we=Kt=null,n.updateQueue!=null){var b=n.updateQueue;b.lastEffect=null,b.events=null,b.stores=null,b.memoCache!=null&&(b.memoCache.index=0)}P.H=Vm,b=i(o,u)}while(Ha);return b}function VA(){var n=P.H,i=n.useState()[0];return i=typeof i.then=="function"?mo(i):i,n=n.useState()[0],(Kt!==null?Kt.memoizedState:null)!==n&&(Lt.flags|=1024),i}function Hd(){var n=Zl!==0;return Zl=0,n}function Ud(n,i,o){i.updateQueue=n.updateQueue,i.flags&=-2053,n.lanes&=~o}function Gd(n){if(Kl){for(n=n.memoizedState;n!==null;){var i=n.queue;i!==null&&(i.pending=null),n=n.next}Kl=!1}yi=0,we=Kt=Lt=null,Ha=!1,go=Zl=0,Ua=null}function Ye(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return we===null?Lt.memoizedState=we=n:we=we.next=n,we}function ye(){if(Kt===null){var n=Lt.alternate;n=n!==null?n.memoizedState:null}else n=Kt.next;var i=we===null?Lt.memoizedState:we.next;if(i!==null)we=i,Kt=n;else{if(n===null)throw Lt.alternate===null?Error(s(467)):Error(s(310));Kt=n,n={memoizedState:Kt.memoizedState,baseState:Kt.baseState,baseQueue:Kt.baseQueue,queue:Kt.queue,next:null},we===null?Lt.memoizedState=we=n:we=we.next=n}return we}function Jl(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function mo(n){var i=go;return go+=1,Ua===null&&(Ua=[]),n=Jg(Ua,n,i),i=Lt,(we===null?i.memoizedState:we.next)===null&&(i=i.alternate,P.H=i===null||i.memoizedState===null?Gm:nh),n}function tc(n){if(n!==null&&typeof n=="object"){if(typeof n.then=="function")return mo(n);if(n.$$typeof===k)return ze(n)}throw Error(s(438,String(n)))}function Vd(n){var i=null,o=Lt.updateQueue;if(o!==null&&(i=o.memoCache),i==null){var u=Lt.alternate;u!==null&&(u=u.updateQueue,u!==null&&(u=u.memoCache,u!=null&&(i={data:u.data.map(function(p){return p.slice()}),index:0})))}if(i==null&&(i={data:[],index:0}),o===null&&(o=Jl(),Lt.updateQueue=o),o.memoCache=i,o=i.data[i.index],o===void 0)for(o=i.data[i.index]=Array(n),u=0;u<n;u++)o[u]=W;return i.index++,o}function xi(n,i){return typeof i=="function"?i(n):i}function ec(n){var i=ye();return qd(i,Kt,n)}function qd(n,i,o){var u=n.queue;if(u===null)throw Error(s(311));u.lastRenderedReducer=o;var p=n.baseQueue,b=u.pending;if(b!==null){if(p!==null){var A=p.next;p.next=b.next,b.next=A}i.baseQueue=p=b,u.pending=null}if(b=n.baseState,p===null)n.memoizedState=b;else{i=p.next;var M=A=null,N=null,G=i,J=!1;do{var it=G.lane&-536870913;if(it!==G.lane?(Pt&it)===it:(yi&it)===it){var Y=G.revertLane;if(Y===0)N!==null&&(N=N.next={lane:0,revertLane:0,gesture:null,action:G.action,hasEagerState:G.hasEagerState,eagerState:G.eagerState,next:null}),it===za&&(J=!0);else if((yi&Y)===Y){G=G.next,Y===za&&(J=!0);continue}else it={lane:0,revertLane:G.revertLane,gesture:null,action:G.action,hasEagerState:G.hasEagerState,eagerState:G.eagerState,next:null},N===null?(M=N=it,A=b):N=N.next=it,Lt.lanes|=Y,Ji|=Y;it=G.action,Hs&&o(b,it),b=G.hasEagerState?G.eagerState:o(b,it)}else Y={lane:it,revertLane:G.revertLane,gesture:G.gesture,action:G.action,hasEagerState:G.hasEagerState,eagerState:G.eagerState,next:null},N===null?(M=N=Y,A=b):N=N.next=Y,Lt.lanes|=it,Ji|=it;G=G.next}while(G!==null&&G!==i);if(N===null?A=b:N.next=M,!dn(b,n.memoizedState)&&(Se=!0,J&&(o=Pa,o!==null)))throw o;n.memoizedState=b,n.baseState=A,n.baseQueue=N,u.lastRenderedState=b}return p===null&&(u.lanes=0),[n.memoizedState,u.dispatch]}function Yd(n){var i=ye(),o=i.queue;if(o===null)throw Error(s(311));o.lastRenderedReducer=n;var u=o.dispatch,p=o.pending,b=i.memoizedState;if(p!==null){o.pending=null;var A=p=p.next;do b=n(b,A.action),A=A.next;while(A!==p);dn(b,i.memoizedState)||(Se=!0),i.memoizedState=b,i.baseQueue===null&&(i.baseState=b),o.lastRenderedState=b}return[b,u]}function um(n,i,o){var u=Lt,p=ye(),b=$t;if(b){if(o===void 0)throw Error(s(407));o=o()}else o=i();var A=!dn((Kt||p).memoizedState,o);if(A&&(p.memoizedState=o,Se=!0),p=p.queue,Qd(fm.bind(null,u,p,n),[n]),p.getSnapshot!==i||A||we!==null&&we.memoizedState.tag&1){if(u.flags|=2048,Ga(9,{destroy:void 0},hm.bind(null,u,p,o,i),null),ee===null)throw Error(s(349));b||(yi&127)!==0||dm(u,i,o)}return o}function dm(n,i,o){n.flags|=16384,n={getSnapshot:i,value:o},i=Lt.updateQueue,i===null?(i=Jl(),Lt.updateQueue=i,i.stores=[n]):(o=i.stores,o===null?i.stores=[n]:o.push(n))}function hm(n,i,o,u){i.value=o,i.getSnapshot=u,pm(i)&&gm(n)}function fm(n,i,o){return o(function(){pm(i)&&gm(n)})}function pm(n){var i=n.getSnapshot;n=n.value;try{var o=i();return!dn(n,o)}catch{return!0}}function gm(n){var i=Os(n,2);i!==null&&sn(i,n,2)}function Xd(n){var i=Ye();if(typeof n=="function"){var o=n;if(n=o(),Hs){Ii(!0);try{o()}finally{Ii(!1)}}}return i.memoizedState=i.baseState=n,i.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:xi,lastRenderedState:n},i}function mm(n,i,o,u){return n.baseState=o,qd(n,Kt,typeof u=="function"?u:xi)}function qA(n,i,o,u,p){if(sc(n))throw Error(s(485));if(n=i.action,n!==null){var b={payload:p,action:n,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(A){b.listeners.push(A)}};P.T!==null?o(!0):b.isTransition=!1,u(b),o=i.pending,o===null?(b.next=i.pending=b,bm(i,b)):(b.next=o.next,i.pending=o.next=b)}}function bm(n,i){var o=i.action,u=i.payload,p=n.state;if(i.isTransition){var b=P.T,A={};P.T=A;try{var M=o(p,u),N=P.S;N!==null&&N(A,M),ym(n,i,M)}catch(G){Wd(n,i,G)}finally{b!==null&&A.types!==null&&(b.types=A.types),P.T=b}}else try{b=o(p,u),ym(n,i,b)}catch(G){Wd(n,i,G)}}function ym(n,i,o){o!==null&&typeof o=="object"&&typeof o.then=="function"?o.then(function(u){xm(n,i,u)},function(u){return Wd(n,i,u)}):xm(n,i,o)}function xm(n,i,o){i.status="fulfilled",i.value=o,vm(i),n.state=o,i=n.pending,i!==null&&(o=i.next,o===i?n.pending=null:(o=o.next,i.next=o,bm(n,o)))}function Wd(n,i,o){var u=n.pending;if(n.pending=null,u!==null){u=u.next;do i.status="rejected",i.reason=o,vm(i),i=i.next;while(i!==u)}n.action=null}function vm(n){n=n.listeners;for(var i=0;i<n.length;i++)(0,n[i])()}function Am(n,i){return i}function wm(n,i){if($t){var o=ee.formState;if(o!==null){t:{var u=Lt;if($t){if(se){e:{for(var p=se,b=Rn;p.nodeType!==8;){if(!b){p=null;break e}if(p=On(p.nextSibling),p===null){p=null;break e}}b=p.data,p=b==="F!"||b==="F"?p:null}if(p){se=On(p.nextSibling),u=p.data==="F!";break t}}Gi(u)}u=!1}u&&(i=o[0])}}return o=Ye(),o.memoizedState=o.baseState=i,u={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Am,lastRenderedState:i},o.queue=u,o=$m.bind(null,Lt,u),u.dispatch=o,u=Xd(!1),b=eh.bind(null,Lt,!1,u.queue),u=Ye(),p={state:i,dispatch:null,action:n,pending:null},u.queue=p,o=qA.bind(null,Lt,p,b,o),p.dispatch=o,u.memoizedState=n,[i,o,!1]}function Sm(n){var i=ye();return Em(i,Kt,n)}function Em(n,i,o){if(i=qd(n,i,Am)[0],n=ec(xi)[0],typeof i=="object"&&i!==null&&typeof i.then=="function")try{var u=mo(i)}catch(A){throw A===Ia?Vl:A}else u=i;i=ye();var p=i.queue,b=p.dispatch;return o!==i.memoizedState&&(Lt.flags|=2048,Ga(9,{destroy:void 0},YA.bind(null,p,o),null)),[u,b,n]}function YA(n,i){n.action=i}function Tm(n){var i=ye(),o=Kt;if(o!==null)return Em(i,o,n);ye(),i=i.memoizedState,o=ye();var u=o.queue.dispatch;return o.memoizedState=n,[i,u,!1]}function Ga(n,i,o,u){return n={tag:n,create:o,deps:u,inst:i,next:null},i=Lt.updateQueue,i===null&&(i=Jl(),Lt.updateQueue=i),o=i.lastEffect,o===null?i.lastEffect=n.next=n:(u=o.next,o.next=n,n.next=u,i.lastEffect=n),n}function Cm(){return ye().memoizedState}function nc(n,i,o,u){var p=Ye();Lt.flags|=n,p.memoizedState=Ga(1|i,{destroy:void 0},o,u===void 0?null:u)}function ic(n,i,o,u){var p=ye();u=u===void 0?null:u;var b=p.memoizedState.inst;Kt!==null&&u!==null&&Fd(u,Kt.memoizedState.deps)?p.memoizedState=Ga(i,b,o,u):(Lt.flags|=n,p.memoizedState=Ga(1|i,b,o,u))}function _m(n,i){nc(8390656,8,n,i)}function Qd(n,i){ic(2048,8,n,i)}function XA(n){Lt.flags|=4;var i=Lt.updateQueue;if(i===null)i=Jl(),Lt.updateQueue=i,i.events=[n];else{var o=i.events;o===null?i.events=[n]:o.push(n)}}function km(n){var i=ye().memoizedState;return XA({ref:i,nextImpl:n}),function(){if((qt&2)!==0)throw Error(s(440));return i.impl.apply(void 0,arguments)}}function Mm(n,i){return ic(4,2,n,i)}function Dm(n,i){return ic(4,4,n,i)}function Rm(n,i){if(typeof i=="function"){n=n();var o=i(n);return function(){typeof o=="function"?o():i(null)}}if(i!=null)return n=n(),i.current=n,function(){i.current=null}}function Lm(n,i,o){o=o!=null?o.concat([n]):null,ic(4,4,Rm.bind(null,i,n),o)}function Kd(){}function Om(n,i){var o=ye();i=i===void 0?null:i;var u=o.memoizedState;return i!==null&&Fd(i,u[1])?u[0]:(o.memoizedState=[n,i],n)}function jm(n,i){var o=ye();i=i===void 0?null:i;var u=o.memoizedState;if(i!==null&&Fd(i,u[1]))return u[0];if(u=n(),Hs){Ii(!0);try{n()}finally{Ii(!1)}}return o.memoizedState=[u,i],u}function Zd(n,i,o){return o===void 0||(yi&1073741824)!==0&&(Pt&261930)===0?n.memoizedState=i:(n.memoizedState=o,n=N0(),Lt.lanes|=n,Ji|=n,o)}function Nm(n,i,o,u){return dn(o,i)?o:$a.current!==null?(n=Zd(n,o,u),dn(n,i)||(Se=!0),n):(yi&42)===0||(yi&1073741824)!==0&&(Pt&261930)===0?(Se=!0,n.memoizedState=o):(n=N0(),Lt.lanes|=n,Ji|=n,i)}function Bm(n,i,o,u,p){var b=V.p;V.p=b!==0&&8>b?b:8;var A=P.T,M={};P.T=M,eh(n,!1,i,o);try{var N=p(),G=P.S;if(G!==null&&G(M,N),N!==null&&typeof N=="object"&&typeof N.then=="function"){var J=UA(N,u);bo(n,i,J,bn(n))}else bo(n,i,u,bn(n))}catch(it){bo(n,i,{then:function(){},status:"rejected",reason:it},bn())}finally{V.p=b,A!==null&&M.types!==null&&(A.types=M.types),P.T=A}}function WA(){}function Jd(n,i,o,u){if(n.tag!==5)throw Error(s(476));var p=zm(n).queue;Bm(n,p,i,K,o===null?WA:function(){return Pm(n),o(u)})}function zm(n){var i=n.memoizedState;if(i!==null)return i;i={memoizedState:K,baseState:K,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:xi,lastRenderedState:K},next:null};var o={};return i.next={memoizedState:o,baseState:o,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:xi,lastRenderedState:o},next:null},n.memoizedState=i,n=n.alternate,n!==null&&(n.memoizedState=i),i}function Pm(n){var i=zm(n);i.next===null&&(i=n.alternate.memoizedState),bo(n,i.next.queue,{},bn())}function th(){return ze(jo)}function Im(){return ye().memoizedState}function Fm(){return ye().memoizedState}function QA(n){for(var i=n.return;i!==null;){switch(i.tag){case 24:case 3:var o=bn();n=Yi(o);var u=Xi(i,n,o);u!==null&&(sn(u,i,o),ho(u,i,o)),i={cache:Md()},n.payload=i;return}i=i.return}}function KA(n,i,o){var u=bn();o={lane:u,revertLane:0,gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},sc(n)?Hm(i,o):(o=yd(n,i,o,u),o!==null&&(sn(o,n,u),Um(o,i,u)))}function $m(n,i,o){var u=bn();bo(n,i,o,u)}function bo(n,i,o,u){var p={lane:u,revertLane:0,gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null};if(sc(n))Hm(i,p);else{var b=n.alternate;if(n.lanes===0&&(b===null||b.lanes===0)&&(b=i.lastRenderedReducer,b!==null))try{var A=i.lastRenderedState,M=b(A,o);if(p.hasEagerState=!0,p.eagerState=M,dn(M,A))return Pl(n,i,p,0),ee===null&&zl(),!1}catch{}if(o=yd(n,i,p,u),o!==null)return sn(o,n,u),Um(o,i,u),!0}return!1}function eh(n,i,o,u){if(u={lane:2,revertLane:Oh(),gesture:null,action:u,hasEagerState:!1,eagerState:null,next:null},sc(n)){if(i)throw Error(s(479))}else i=yd(n,o,u,2),i!==null&&sn(i,n,2)}function sc(n){var i=n.alternate;return n===Lt||i!==null&&i===Lt}function Hm(n,i){Ha=Kl=!0;var o=n.pending;o===null?i.next=i:(i.next=o.next,o.next=i),n.pending=i}function Um(n,i,o){if((o&4194048)!==0){var u=i.lanes;u&=n.pendingLanes,o|=u,i.lanes=o,Xp(n,o)}}var yo={readContext:ze,use:tc,useCallback:pe,useContext:pe,useEffect:pe,useImperativeHandle:pe,useLayoutEffect:pe,useInsertionEffect:pe,useMemo:pe,useReducer:pe,useRef:pe,useState:pe,useDebugValue:pe,useDeferredValue:pe,useTransition:pe,useSyncExternalStore:pe,useId:pe,useHostTransitionStatus:pe,useFormState:pe,useActionState:pe,useOptimistic:pe,useMemoCache:pe,useCacheRefresh:pe};yo.useEffectEvent=pe;var Gm={readContext:ze,use:tc,useCallback:function(n,i){return Ye().memoizedState=[n,i===void 0?null:i],n},useContext:ze,useEffect:_m,useImperativeHandle:function(n,i,o){o=o!=null?o.concat([n]):null,nc(4194308,4,Rm.bind(null,i,n),o)},useLayoutEffect:function(n,i){return nc(4194308,4,n,i)},useInsertionEffect:function(n,i){nc(4,2,n,i)},useMemo:function(n,i){var o=Ye();i=i===void 0?null:i;var u=n();if(Hs){Ii(!0);try{n()}finally{Ii(!1)}}return o.memoizedState=[u,i],u},useReducer:function(n,i,o){var u=Ye();if(o!==void 0){var p=o(i);if(Hs){Ii(!0);try{o(i)}finally{Ii(!1)}}}else p=i;return u.memoizedState=u.baseState=p,n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:p},u.queue=n,n=n.dispatch=KA.bind(null,Lt,n),[u.memoizedState,n]},useRef:function(n){var i=Ye();return n={current:n},i.memoizedState=n},useState:function(n){n=Xd(n);var i=n.queue,o=$m.bind(null,Lt,i);return i.dispatch=o,[n.memoizedState,o]},useDebugValue:Kd,useDeferredValue:function(n,i){var o=Ye();return Zd(o,n,i)},useTransition:function(){var n=Xd(!1);return n=Bm.bind(null,Lt,n.queue,!0,!1),Ye().memoizedState=n,[!1,n]},useSyncExternalStore:function(n,i,o){var u=Lt,p=Ye();if($t){if(o===void 0)throw Error(s(407));o=o()}else{if(o=i(),ee===null)throw Error(s(349));(Pt&127)!==0||dm(u,i,o)}p.memoizedState=o;var b={value:o,getSnapshot:i};return p.queue=b,_m(fm.bind(null,u,b,n),[n]),u.flags|=2048,Ga(9,{destroy:void 0},hm.bind(null,u,b,o,i),null),o},useId:function(){var n=Ye(),i=ee.identifierPrefix;if($t){var o=Kn,u=Qn;o=(u&~(1<<32-un(u)-1)).toString(32)+o,i="_"+i+"R_"+o,o=Zl++,0<o&&(i+="H"+o.toString(32)),i+="_"}else o=GA++,i="_"+i+"r_"+o.toString(32)+"_";return n.memoizedState=i},useHostTransitionStatus:th,useFormState:wm,useActionState:wm,useOptimistic:function(n){var i=Ye();i.memoizedState=i.baseState=n;var o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return i.queue=o,i=eh.bind(null,Lt,!0,o),o.dispatch=i,[n,i]},useMemoCache:Vd,useCacheRefresh:function(){return Ye().memoizedState=QA.bind(null,Lt)},useEffectEvent:function(n){var i=Ye(),o={impl:n};return i.memoizedState=o,function(){if((qt&2)!==0)throw Error(s(440));return o.impl.apply(void 0,arguments)}}},nh={readContext:ze,use:tc,useCallback:Om,useContext:ze,useEffect:Qd,useImperativeHandle:Lm,useInsertionEffect:Mm,useLayoutEffect:Dm,useMemo:jm,useReducer:ec,useRef:Cm,useState:function(){return ec(xi)},useDebugValue:Kd,useDeferredValue:function(n,i){var o=ye();return Nm(o,Kt.memoizedState,n,i)},useTransition:function(){var n=ec(xi)[0],i=ye().memoizedState;return[typeof n=="boolean"?n:mo(n),i]},useSyncExternalStore:um,useId:Im,useHostTransitionStatus:th,useFormState:Sm,useActionState:Sm,useOptimistic:function(n,i){var o=ye();return mm(o,Kt,n,i)},useMemoCache:Vd,useCacheRefresh:Fm};nh.useEffectEvent=km;var Vm={readContext:ze,use:tc,useCallback:Om,useContext:ze,useEffect:Qd,useImperativeHandle:Lm,useInsertionEffect:Mm,useLayoutEffect:Dm,useMemo:jm,useReducer:Yd,useRef:Cm,useState:function(){return Yd(xi)},useDebugValue:Kd,useDeferredValue:function(n,i){var o=ye();return Kt===null?Zd(o,n,i):Nm(o,Kt.memoizedState,n,i)},useTransition:function(){var n=Yd(xi)[0],i=ye().memoizedState;return[typeof n=="boolean"?n:mo(n),i]},useSyncExternalStore:um,useId:Im,useHostTransitionStatus:th,useFormState:Tm,useActionState:Tm,useOptimistic:function(n,i){var o=ye();return Kt!==null?mm(o,Kt,n,i):(o.baseState=n,[n,o.queue.dispatch])},useMemoCache:Vd,useCacheRefresh:Fm};Vm.useEffectEvent=km;function ih(n,i,o,u){i=n.memoizedState,o=o(u,i),o=o==null?i:m({},i,o),n.memoizedState=o,n.lanes===0&&(n.updateQueue.baseState=o)}var sh={enqueueSetState:function(n,i,o){n=n._reactInternals;var u=bn(),p=Yi(u);p.payload=i,o!=null&&(p.callback=o),i=Xi(n,p,u),i!==null&&(sn(i,n,u),ho(i,n,u))},enqueueReplaceState:function(n,i,o){n=n._reactInternals;var u=bn(),p=Yi(u);p.tag=1,p.payload=i,o!=null&&(p.callback=o),i=Xi(n,p,u),i!==null&&(sn(i,n,u),ho(i,n,u))},enqueueForceUpdate:function(n,i){n=n._reactInternals;var o=bn(),u=Yi(o);u.tag=2,i!=null&&(u.callback=i),i=Xi(n,u,o),i!==null&&(sn(i,n,o),ho(i,n,o))}};function qm(n,i,o,u,p,b,A){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(u,b,A):i.prototype&&i.prototype.isPureReactComponent?!io(o,u)||!io(p,b):!0}function Ym(n,i,o,u){n=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(o,u),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(o,u),i.state!==n&&sh.enqueueReplaceState(i,i.state,null)}function Us(n,i){var o=i;if("ref"in i){o={};for(var u in i)u!=="ref"&&(o[u]=i[u])}if(n=n.defaultProps){o===i&&(o=m({},o));for(var p in n)o[p]===void 0&&(o[p]=n[p])}return o}function Xm(n){Bl(n)}function Wm(n){console.error(n)}function Qm(n){Bl(n)}function ac(n,i){try{var o=n.onUncaughtError;o(i.value,{componentStack:i.stack})}catch(u){setTimeout(function(){throw u})}}function Km(n,i,o){try{var u=n.onCaughtError;u(o.value,{componentStack:o.stack,errorBoundary:i.tag===1?i.stateNode:null})}catch(p){setTimeout(function(){throw p})}}function ah(n,i,o){return o=Yi(o),o.tag=3,o.payload={element:null},o.callback=function(){ac(n,i)},o}function Zm(n){return n=Yi(n),n.tag=3,n}function Jm(n,i,o,u){var p=o.type.getDerivedStateFromError;if(typeof p=="function"){var b=u.value;n.payload=function(){return p(b)},n.callback=function(){Km(i,o,u)}}var A=o.stateNode;A!==null&&typeof A.componentDidCatch=="function"&&(n.callback=function(){Km(i,o,u),typeof p!="function"&&(ts===null?ts=new Set([this]):ts.add(this));var M=u.stack;this.componentDidCatch(u.value,{componentStack:M!==null?M:""})})}function ZA(n,i,o,u,p){if(o.flags|=32768,u!==null&&typeof u=="object"&&typeof u.then=="function"){if(i=o.alternate,i!==null&&Ba(i,o,p,!0),o=fn.current,o!==null){switch(o.tag){case 31:case 13:return Ln===null?bc():o.alternate===null&&ge===0&&(ge=3),o.flags&=-257,o.flags|=65536,o.lanes=p,u===ql?o.flags|=16384:(i=o.updateQueue,i===null?o.updateQueue=new Set([u]):i.add(u),Dh(n,u,p)),!1;case 22:return o.flags|=65536,u===ql?o.flags|=16384:(i=o.updateQueue,i===null?(i={transitions:null,markerInstances:null,retryQueue:new Set([u])},o.updateQueue=i):(o=i.retryQueue,o===null?i.retryQueue=new Set([u]):o.add(u)),Dh(n,u,p)),!1}throw Error(s(435,o.tag))}return Dh(n,u,p),bc(),!1}if($t)return i=fn.current,i!==null?((i.flags&65536)===0&&(i.flags|=256),i.flags|=65536,i.lanes=p,u!==Ed&&(n=Error(s(422),{cause:u}),ro(kn(n,o)))):(u!==Ed&&(i=Error(s(423),{cause:u}),ro(kn(i,o))),n=n.current.alternate,n.flags|=65536,p&=-p,n.lanes|=p,u=kn(u,o),p=ah(n.stateNode,u,p),Nd(n,p),ge!==4&&(ge=2)),!1;var b=Error(s(520),{cause:u});if(b=kn(b,o),Co===null?Co=[b]:Co.push(b),ge!==4&&(ge=2),i===null)return!0;u=kn(u,o),o=i;do{switch(o.tag){case 3:return o.flags|=65536,n=p&-p,o.lanes|=n,n=ah(o.stateNode,u,n),Nd(o,n),!1;case 1:if(i=o.type,b=o.stateNode,(o.flags&128)===0&&(typeof i.getDerivedStateFromError=="function"||b!==null&&typeof b.componentDidCatch=="function"&&(ts===null||!ts.has(b))))return o.flags|=65536,p&=-p,o.lanes|=p,p=Zm(p),Jm(p,n,o,u),Nd(o,p),!1}o=o.return}while(o!==null);return!1}var rh=Error(s(461)),Se=!1;function Pe(n,i,o,u){i.child=n===null?im(i,null,o,u):$s(i,n.child,o,u)}function t0(n,i,o,u,p){o=o.render;var b=i.ref;if("ref"in u){var A={};for(var M in u)M!=="ref"&&(A[M]=u[M])}else A=u;return zs(i),u=$d(n,i,o,A,b,p),M=Hd(),n!==null&&!Se?(Ud(n,i,p),vi(n,i,p)):($t&&M&&wd(i),i.flags|=1,Pe(n,i,u,p),i.child)}function e0(n,i,o,u,p){if(n===null){var b=o.type;return typeof b=="function"&&!xd(b)&&b.defaultProps===void 0&&o.compare===null?(i.tag=15,i.type=b,n0(n,i,b,u,p)):(n=Fl(o.type,null,u,i,i.mode,p),n.ref=i.ref,n.return=i,i.child=n)}if(b=n.child,!ph(n,p)){var A=b.memoizedProps;if(o=o.compare,o=o!==null?o:io,o(A,u)&&n.ref===i.ref)return vi(n,i,p)}return i.flags|=1,n=pi(b,u),n.ref=i.ref,n.return=i,i.child=n}function n0(n,i,o,u,p){if(n!==null){var b=n.memoizedProps;if(io(b,u)&&n.ref===i.ref)if(Se=!1,i.pendingProps=u=b,ph(n,p))(n.flags&131072)!==0&&(Se=!0);else return i.lanes=n.lanes,vi(n,i,p)}return oh(n,i,o,u,p)}function i0(n,i,o,u){var p=u.children,b=n!==null?n.memoizedState:null;if(n===null&&i.stateNode===null&&(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),u.mode==="hidden"){if((i.flags&128)!==0){if(b=b!==null?b.baseLanes|o:o,n!==null){for(u=i.child=n.child,p=0;u!==null;)p=p|u.lanes|u.childLanes,u=u.sibling;u=p&~b}else u=0,i.child=null;return s0(n,i,b,o,u)}if((o&536870912)!==0)i.memoizedState={baseLanes:0,cachePool:null},n!==null&&Gl(i,b!==null?b.cachePool:null),b!==null?rm(i,b):zd(),om(i);else return u=i.lanes=536870912,s0(n,i,b!==null?b.baseLanes|o:o,o,u)}else b!==null?(Gl(i,b.cachePool),rm(i,b),Qi(),i.memoizedState=null):(n!==null&&Gl(i,null),zd(),Qi());return Pe(n,i,p,o),i.child}function xo(n,i){return n!==null&&n.tag===22||i.stateNode!==null||(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.sibling}function s0(n,i,o,u,p){var b=Rd();return b=b===null?null:{parent:Ae._currentValue,pool:b},i.memoizedState={baseLanes:o,cachePool:b},n!==null&&Gl(i,null),zd(),om(i),n!==null&&Ba(n,i,u,!0),i.childLanes=p,null}function rc(n,i){return i=lc({mode:i.mode,children:i.children},n.mode),i.ref=n.ref,n.child=i,i.return=n,i}function a0(n,i,o){return $s(i,n.child,null,o),n=rc(i,i.pendingProps),n.flags|=2,pn(i),i.memoizedState=null,n}function JA(n,i,o){var u=i.pendingProps,p=(i.flags&128)!==0;if(i.flags&=-129,n===null){if($t){if(u.mode==="hidden")return n=rc(i,u),i.lanes=536870912,xo(null,n);if(Id(i),(n=se)?(n=bb(n,Rn),n=n!==null&&n.data==="&"?n:null,n!==null&&(i.memoizedState={dehydrated:n,treeContext:Hi!==null?{id:Qn,overflow:Kn}:null,retryLane:536870912,hydrationErrors:null},o=Hg(n),o.return=i,i.child=o,Be=i,se=null)):n=null,n===null)throw Gi(i);return i.lanes=536870912,null}return rc(i,u)}var b=n.memoizedState;if(b!==null){var A=b.dehydrated;if(Id(i),p)if(i.flags&256)i.flags&=-257,i=a0(n,i,o);else if(i.memoizedState!==null)i.child=n.child,i.flags|=128,i=null;else throw Error(s(558));else if(Se||Ba(n,i,o,!1),p=(o&n.childLanes)!==0,Se||p){if(u=ee,u!==null&&(A=Wp(u,o),A!==0&&A!==b.retryLane))throw b.retryLane=A,Os(n,A),sn(u,n,A),rh;bc(),i=a0(n,i,o)}else n=b.treeContext,se=On(A.nextSibling),Be=i,$t=!0,Ui=null,Rn=!1,n!==null&&Vg(i,n),i=rc(i,u),i.flags|=4096;return i}return n=pi(n.child,{mode:u.mode,children:u.children}),n.ref=i.ref,i.child=n,n.return=i,n}function oc(n,i){var o=i.ref;if(o===null)n!==null&&n.ref!==null&&(i.flags|=4194816);else{if(typeof o!="function"&&typeof o!="object")throw Error(s(284));(n===null||n.ref!==o)&&(i.flags|=4194816)}}function oh(n,i,o,u,p){return zs(i),o=$d(n,i,o,u,void 0,p),u=Hd(),n!==null&&!Se?(Ud(n,i,p),vi(n,i,p)):($t&&u&&wd(i),i.flags|=1,Pe(n,i,o,p),i.child)}function r0(n,i,o,u,p,b){return zs(i),i.updateQueue=null,o=cm(i,u,o,p),lm(n),u=Hd(),n!==null&&!Se?(Ud(n,i,b),vi(n,i,b)):($t&&u&&wd(i),i.flags|=1,Pe(n,i,o,b),i.child)}function o0(n,i,o,u,p){if(zs(i),i.stateNode===null){var b=La,A=o.contextType;typeof A=="object"&&A!==null&&(b=ze(A)),b=new o(u,b),i.memoizedState=b.state!==null&&b.state!==void 0?b.state:null,b.updater=sh,i.stateNode=b,b._reactInternals=i,b=i.stateNode,b.props=u,b.state=i.memoizedState,b.refs={},Od(i),A=o.contextType,b.context=typeof A=="object"&&A!==null?ze(A):La,b.state=i.memoizedState,A=o.getDerivedStateFromProps,typeof A=="function"&&(ih(i,o,A,u),b.state=i.memoizedState),typeof o.getDerivedStateFromProps=="function"||typeof b.getSnapshotBeforeUpdate=="function"||typeof b.UNSAFE_componentWillMount!="function"&&typeof b.componentWillMount!="function"||(A=b.state,typeof b.componentWillMount=="function"&&b.componentWillMount(),typeof b.UNSAFE_componentWillMount=="function"&&b.UNSAFE_componentWillMount(),A!==b.state&&sh.enqueueReplaceState(b,b.state,null),po(i,u,b,p),fo(),b.state=i.memoizedState),typeof b.componentDidMount=="function"&&(i.flags|=4194308),u=!0}else if(n===null){b=i.stateNode;var M=i.memoizedProps,N=Us(o,M);b.props=N;var G=b.context,J=o.contextType;A=La,typeof J=="object"&&J!==null&&(A=ze(J));var it=o.getDerivedStateFromProps;J=typeof it=="function"||typeof b.getSnapshotBeforeUpdate=="function",M=i.pendingProps!==M,J||typeof b.UNSAFE_componentWillReceiveProps!="function"&&typeof b.componentWillReceiveProps!="function"||(M||G!==A)&&Ym(i,b,u,A),qi=!1;var Y=i.memoizedState;b.state=Y,po(i,u,b,p),fo(),G=i.memoizedState,M||Y!==G||qi?(typeof it=="function"&&(ih(i,o,it,u),G=i.memoizedState),(N=qi||qm(i,o,N,u,Y,G,A))?(J||typeof b.UNSAFE_componentWillMount!="function"&&typeof b.componentWillMount!="function"||(typeof b.componentWillMount=="function"&&b.componentWillMount(),typeof b.UNSAFE_componentWillMount=="function"&&b.UNSAFE_componentWillMount()),typeof b.componentDidMount=="function"&&(i.flags|=4194308)):(typeof b.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=u,i.memoizedState=G),b.props=u,b.state=G,b.context=A,u=N):(typeof b.componentDidMount=="function"&&(i.flags|=4194308),u=!1)}else{b=i.stateNode,jd(n,i),A=i.memoizedProps,J=Us(o,A),b.props=J,it=i.pendingProps,Y=b.context,G=o.contextType,N=La,typeof G=="object"&&G!==null&&(N=ze(G)),M=o.getDerivedStateFromProps,(G=typeof M=="function"||typeof b.getSnapshotBeforeUpdate=="function")||typeof b.UNSAFE_componentWillReceiveProps!="function"&&typeof b.componentWillReceiveProps!="function"||(A!==it||Y!==N)&&Ym(i,b,u,N),qi=!1,Y=i.memoizedState,b.state=Y,po(i,u,b,p),fo();var Q=i.memoizedState;A!==it||Y!==Q||qi||n!==null&&n.dependencies!==null&&Hl(n.dependencies)?(typeof M=="function"&&(ih(i,o,M,u),Q=i.memoizedState),(J=qi||qm(i,o,J,u,Y,Q,N)||n!==null&&n.dependencies!==null&&Hl(n.dependencies))?(G||typeof b.UNSAFE_componentWillUpdate!="function"&&typeof b.componentWillUpdate!="function"||(typeof b.componentWillUpdate=="function"&&b.componentWillUpdate(u,Q,N),typeof b.UNSAFE_componentWillUpdate=="function"&&b.UNSAFE_componentWillUpdate(u,Q,N)),typeof b.componentDidUpdate=="function"&&(i.flags|=4),typeof b.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof b.componentDidUpdate!="function"||A===n.memoizedProps&&Y===n.memoizedState||(i.flags|=4),typeof b.getSnapshotBeforeUpdate!="function"||A===n.memoizedProps&&Y===n.memoizedState||(i.flags|=1024),i.memoizedProps=u,i.memoizedState=Q),b.props=u,b.state=Q,b.context=N,u=J):(typeof b.componentDidUpdate!="function"||A===n.memoizedProps&&Y===n.memoizedState||(i.flags|=4),typeof b.getSnapshotBeforeUpdate!="function"||A===n.memoizedProps&&Y===n.memoizedState||(i.flags|=1024),u=!1)}return b=u,oc(n,i),u=(i.flags&128)!==0,b||u?(b=i.stateNode,o=u&&typeof o.getDerivedStateFromError!="function"?null:b.render(),i.flags|=1,n!==null&&u?(i.child=$s(i,n.child,null,p),i.child=$s(i,null,o,p)):Pe(n,i,o,p),i.memoizedState=b.state,n=i.child):n=vi(n,i,p),n}function l0(n,i,o,u){return Ns(),i.flags|=256,Pe(n,i,o,u),i.child}var lh={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function ch(n){return{baseLanes:n,cachePool:Kg()}}function uh(n,i,o){return n=n!==null?n.childLanes&~o:0,i&&(n|=mn),n}function c0(n,i,o){var u=i.pendingProps,p=!1,b=(i.flags&128)!==0,A;if((A=b)||(A=n!==null&&n.memoizedState===null?!1:(be.current&2)!==0),A&&(p=!0,i.flags&=-129),A=(i.flags&32)!==0,i.flags&=-33,n===null){if($t){if(p?Wi(i):Qi(),(n=se)?(n=bb(n,Rn),n=n!==null&&n.data!=="&"?n:null,n!==null&&(i.memoizedState={dehydrated:n,treeContext:Hi!==null?{id:Qn,overflow:Kn}:null,retryLane:536870912,hydrationErrors:null},o=Hg(n),o.return=i,i.child=o,Be=i,se=null)):n=null,n===null)throw Gi(i);return qh(n)?i.lanes=32:i.lanes=536870912,null}var M=u.children;return u=u.fallback,p?(Qi(),p=i.mode,M=lc({mode:"hidden",children:M},p),u=js(u,p,o,null),M.return=i,u.return=i,M.sibling=u,i.child=M,u=i.child,u.memoizedState=ch(o),u.childLanes=uh(n,A,o),i.memoizedState=lh,xo(null,u)):(Wi(i),dh(i,M))}var N=n.memoizedState;if(N!==null&&(M=N.dehydrated,M!==null)){if(b)i.flags&256?(Wi(i),i.flags&=-257,i=hh(n,i,o)):i.memoizedState!==null?(Qi(),i.child=n.child,i.flags|=128,i=null):(Qi(),M=u.fallback,p=i.mode,u=lc({mode:"visible",children:u.children},p),M=js(M,p,o,null),M.flags|=2,u.return=i,M.return=i,u.sibling=M,i.child=u,$s(i,n.child,null,o),u=i.child,u.memoizedState=ch(o),u.childLanes=uh(n,A,o),i.memoizedState=lh,i=xo(null,u));else if(Wi(i),qh(M)){if(A=M.nextSibling&&M.nextSibling.dataset,A)var G=A.dgst;A=G,u=Error(s(419)),u.stack="",u.digest=A,ro({value:u,source:null,stack:null}),i=hh(n,i,o)}else if(Se||Ba(n,i,o,!1),A=(o&n.childLanes)!==0,Se||A){if(A=ee,A!==null&&(u=Wp(A,o),u!==0&&u!==N.retryLane))throw N.retryLane=u,Os(n,u),sn(A,n,u),rh;Vh(M)||bc(),i=hh(n,i,o)}else Vh(M)?(i.flags|=192,i.child=n.child,i=null):(n=N.treeContext,se=On(M.nextSibling),Be=i,$t=!0,Ui=null,Rn=!1,n!==null&&Vg(i,n),i=dh(i,u.children),i.flags|=4096);return i}return p?(Qi(),M=u.fallback,p=i.mode,N=n.child,G=N.sibling,u=pi(N,{mode:"hidden",children:u.children}),u.subtreeFlags=N.subtreeFlags&65011712,G!==null?M=pi(G,M):(M=js(M,p,o,null),M.flags|=2),M.return=i,u.return=i,u.sibling=M,i.child=u,xo(null,u),u=i.child,M=n.child.memoizedState,M===null?M=ch(o):(p=M.cachePool,p!==null?(N=Ae._currentValue,p=p.parent!==N?{parent:N,pool:N}:p):p=Kg(),M={baseLanes:M.baseLanes|o,cachePool:p}),u.memoizedState=M,u.childLanes=uh(n,A,o),i.memoizedState=lh,xo(n.child,u)):(Wi(i),o=n.child,n=o.sibling,o=pi(o,{mode:"visible",children:u.children}),o.return=i,o.sibling=null,n!==null&&(A=i.deletions,A===null?(i.deletions=[n],i.flags|=16):A.push(n)),i.child=o,i.memoizedState=null,o)}function dh(n,i){return i=lc({mode:"visible",children:i},n.mode),i.return=n,n.child=i}function lc(n,i){return n=hn(22,n,null,i),n.lanes=0,n}function hh(n,i,o){return $s(i,n.child,null,o),n=dh(i,i.pendingProps.children),n.flags|=2,i.memoizedState=null,n}function u0(n,i,o){n.lanes|=i;var u=n.alternate;u!==null&&(u.lanes|=i),_d(n.return,i,o)}function fh(n,i,o,u,p,b){var A=n.memoizedState;A===null?n.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:u,tail:o,tailMode:p,treeForkCount:b}:(A.isBackwards=i,A.rendering=null,A.renderingStartTime=0,A.last=u,A.tail=o,A.tailMode=p,A.treeForkCount=b)}function d0(n,i,o){var u=i.pendingProps,p=u.revealOrder,b=u.tail;u=u.children;var A=be.current,M=(A&2)!==0;if(M?(A=A&1|2,i.flags|=128):A&=1,q(be,A),Pe(n,i,u,o),u=$t?ao:0,!M&&n!==null&&(n.flags&128)!==0)t:for(n=i.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&u0(n,o,i);else if(n.tag===19)u0(n,o,i);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===i)break t;for(;n.sibling===null;){if(n.return===null||n.return===i)break t;n=n.return}n.sibling.return=n.return,n=n.sibling}switch(p){case"forwards":for(o=i.child,p=null;o!==null;)n=o.alternate,n!==null&&Ql(n)===null&&(p=o),o=o.sibling;o=p,o===null?(p=i.child,i.child=null):(p=o.sibling,o.sibling=null),fh(i,!1,p,o,b,u);break;case"backwards":case"unstable_legacy-backwards":for(o=null,p=i.child,i.child=null;p!==null;){if(n=p.alternate,n!==null&&Ql(n)===null){i.child=p;break}n=p.sibling,p.sibling=o,o=p,p=n}fh(i,!0,o,null,b,u);break;case"together":fh(i,!1,null,null,void 0,u);break;default:i.memoizedState=null}return i.child}function vi(n,i,o){if(n!==null&&(i.dependencies=n.dependencies),Ji|=i.lanes,(o&i.childLanes)===0)if(n!==null){if(Ba(n,i,o,!1),(o&i.childLanes)===0)return null}else return null;if(n!==null&&i.child!==n.child)throw Error(s(153));if(i.child!==null){for(n=i.child,o=pi(n,n.pendingProps),i.child=o,o.return=i;n.sibling!==null;)n=n.sibling,o=o.sibling=pi(n,n.pendingProps),o.return=i;o.sibling=null}return i.child}function ph(n,i){return(n.lanes&i)!==0?!0:(n=n.dependencies,!!(n!==null&&Hl(n)))}function tw(n,i,o){switch(i.tag){case 3:kt(i,i.stateNode.containerInfo),Vi(i,Ae,n.memoizedState.cache),Ns();break;case 27:case 5:xt(i);break;case 4:kt(i,i.stateNode.containerInfo);break;case 10:Vi(i,i.type,i.memoizedProps.value);break;case 31:if(i.memoizedState!==null)return i.flags|=128,Id(i),null;break;case 13:var u=i.memoizedState;if(u!==null)return u.dehydrated!==null?(Wi(i),i.flags|=128,null):(o&i.child.childLanes)!==0?c0(n,i,o):(Wi(i),n=vi(n,i,o),n!==null?n.sibling:null);Wi(i);break;case 19:var p=(n.flags&128)!==0;if(u=(o&i.childLanes)!==0,u||(Ba(n,i,o,!1),u=(o&i.childLanes)!==0),p){if(u)return d0(n,i,o);i.flags|=128}if(p=i.memoizedState,p!==null&&(p.rendering=null,p.tail=null,p.lastEffect=null),q(be,be.current),u)break;return null;case 22:return i.lanes=0,i0(n,i,o,i.pendingProps);case 24:Vi(i,Ae,n.memoizedState.cache)}return vi(n,i,o)}function h0(n,i,o){if(n!==null)if(n.memoizedProps!==i.pendingProps)Se=!0;else{if(!ph(n,o)&&(i.flags&128)===0)return Se=!1,tw(n,i,o);Se=(n.flags&131072)!==0}else Se=!1,$t&&(i.flags&1048576)!==0&&Gg(i,ao,i.index);switch(i.lanes=0,i.tag){case 16:t:{var u=i.pendingProps;if(n=Is(i.elementType),i.type=n,typeof n=="function")xd(n)?(u=Us(n,u),i.tag=1,i=o0(null,i,n,u,o)):(i.tag=0,i=oh(null,i,n,u,o));else{if(n!=null){var p=n.$$typeof;if(p===R){i.tag=11,i=t0(null,i,n,u,o);break t}else if(p===O){i.tag=14,i=e0(null,i,n,u,o);break t}}throw i=lt(n)||n,Error(s(306,i,""))}}return i;case 0:return oh(n,i,i.type,i.pendingProps,o);case 1:return u=i.type,p=Us(u,i.pendingProps),o0(n,i,u,p,o);case 3:t:{if(kt(i,i.stateNode.containerInfo),n===null)throw Error(s(387));u=i.pendingProps;var b=i.memoizedState;p=b.element,jd(n,i),po(i,u,null,o);var A=i.memoizedState;if(u=A.cache,Vi(i,Ae,u),u!==b.cache&&kd(i,[Ae],o,!0),fo(),u=A.element,b.isDehydrated)if(b={element:u,isDehydrated:!1,cache:A.cache},i.updateQueue.baseState=b,i.memoizedState=b,i.flags&256){i=l0(n,i,u,o);break t}else if(u!==p){p=kn(Error(s(424)),i),ro(p),i=l0(n,i,u,o);break t}else for(n=i.stateNode.containerInfo,n.nodeType===9?n=n.body:n=n.nodeName==="HTML"?n.ownerDocument.body:n,se=On(n.firstChild),Be=i,$t=!0,Ui=null,Rn=!0,o=im(i,null,u,o),i.child=o;o;)o.flags=o.flags&-3|4096,o=o.sibling;else{if(Ns(),u===p){i=vi(n,i,o);break t}Pe(n,i,u,o)}i=i.child}return i;case 26:return oc(n,i),n===null?(o=Sb(i.type,null,i.pendingProps,null))?i.memoizedState=o:$t||(o=i.type,n=i.pendingProps,u=Ec(ot.current).createElement(o),u[Ne]=i,u[Ke]=n,Ie(u,o,n),Me(u),i.stateNode=u):i.memoizedState=Sb(i.type,n.memoizedProps,i.pendingProps,n.memoizedState),null;case 27:return xt(i),n===null&&$t&&(u=i.stateNode=vb(i.type,i.pendingProps,ot.current),Be=i,Rn=!0,p=se,ss(i.type)?(Yh=p,se=On(u.firstChild)):se=p),Pe(n,i,i.pendingProps.children,o),oc(n,i),n===null&&(i.flags|=4194304),i.child;case 5:return n===null&&$t&&((p=u=se)&&(u=Dw(u,i.type,i.pendingProps,Rn),u!==null?(i.stateNode=u,Be=i,se=On(u.firstChild),Rn=!1,p=!0):p=!1),p||Gi(i)),xt(i),p=i.type,b=i.pendingProps,A=n!==null?n.memoizedProps:null,u=b.children,Hh(p,b)?u=null:A!==null&&Hh(p,A)&&(i.flags|=32),i.memoizedState!==null&&(p=$d(n,i,VA,null,null,o),jo._currentValue=p),oc(n,i),Pe(n,i,u,o),i.child;case 6:return n===null&&$t&&((n=o=se)&&(o=Rw(o,i.pendingProps,Rn),o!==null?(i.stateNode=o,Be=i,se=null,n=!0):n=!1),n||Gi(i)),null;case 13:return c0(n,i,o);case 4:return kt(i,i.stateNode.containerInfo),u=i.pendingProps,n===null?i.child=$s(i,null,u,o):Pe(n,i,u,o),i.child;case 11:return t0(n,i,i.type,i.pendingProps,o);case 7:return Pe(n,i,i.pendingProps,o),i.child;case 8:return Pe(n,i,i.pendingProps.children,o),i.child;case 12:return Pe(n,i,i.pendingProps.children,o),i.child;case 10:return u=i.pendingProps,Vi(i,i.type,u.value),Pe(n,i,u.children,o),i.child;case 9:return p=i.type._context,u=i.pendingProps.children,zs(i),p=ze(p),u=u(p),i.flags|=1,Pe(n,i,u,o),i.child;case 14:return e0(n,i,i.type,i.pendingProps,o);case 15:return n0(n,i,i.type,i.pendingProps,o);case 19:return d0(n,i,o);case 31:return JA(n,i,o);case 22:return i0(n,i,o,i.pendingProps);case 24:return zs(i),u=ze(Ae),n===null?(p=Rd(),p===null&&(p=ee,b=Md(),p.pooledCache=b,b.refCount++,b!==null&&(p.pooledCacheLanes|=o),p=b),i.memoizedState={parent:u,cache:p},Od(i),Vi(i,Ae,p)):((n.lanes&o)!==0&&(jd(n,i),po(i,null,null,o),fo()),p=n.memoizedState,b=i.memoizedState,p.parent!==u?(p={parent:u,cache:u},i.memoizedState=p,i.lanes===0&&(i.memoizedState=i.updateQueue.baseState=p),Vi(i,Ae,u)):(u=b.cache,Vi(i,Ae,u),u!==p.cache&&kd(i,[Ae],o,!0))),Pe(n,i,i.pendingProps.children,o),i.child;case 29:throw i.pendingProps}throw Error(s(156,i.tag))}function Ai(n){n.flags|=4}function gh(n,i,o,u,p){if((i=(n.mode&32)!==0)&&(i=!1),i){if(n.flags|=16777216,(p&335544128)===p)if(n.stateNode.complete)n.flags|=8192;else if(I0())n.flags|=8192;else throw Fs=ql,Ld}else n.flags&=-16777217}function f0(n,i){if(i.type!=="stylesheet"||(i.state.loading&4)!==0)n.flags&=-16777217;else if(n.flags|=16777216,!kb(i))if(I0())n.flags|=8192;else throw Fs=ql,Ld}function cc(n,i){i!==null&&(n.flags|=4),n.flags&16384&&(i=n.tag!==22?qp():536870912,n.lanes|=i,Xa|=i)}function vo(n,i){if(!$t)switch(n.tailMode){case"hidden":i=n.tail;for(var o=null;i!==null;)i.alternate!==null&&(o=i),i=i.sibling;o===null?n.tail=null:o.sibling=null;break;case"collapsed":o=n.tail;for(var u=null;o!==null;)o.alternate!==null&&(u=o),o=o.sibling;u===null?i||n.tail===null?n.tail=null:n.tail.sibling=null:u.sibling=null}}function ae(n){var i=n.alternate!==null&&n.alternate.child===n.child,o=0,u=0;if(i)for(var p=n.child;p!==null;)o|=p.lanes|p.childLanes,u|=p.subtreeFlags&65011712,u|=p.flags&65011712,p.return=n,p=p.sibling;else for(p=n.child;p!==null;)o|=p.lanes|p.childLanes,u|=p.subtreeFlags,u|=p.flags,p.return=n,p=p.sibling;return n.subtreeFlags|=u,n.childLanes=o,i}function ew(n,i,o){var u=i.pendingProps;switch(Sd(i),i.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return ae(i),null;case 1:return ae(i),null;case 3:return o=i.stateNode,u=null,n!==null&&(u=n.memoizedState.cache),i.memoizedState.cache!==u&&(i.flags|=2048),bi(Ae),et(),o.pendingContext&&(o.context=o.pendingContext,o.pendingContext=null),(n===null||n.child===null)&&(Na(i)?Ai(i):n===null||n.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,Td())),ae(i),null;case 26:var p=i.type,b=i.memoizedState;return n===null?(Ai(i),b!==null?(ae(i),f0(i,b)):(ae(i),gh(i,p,null,u,o))):b?b!==n.memoizedState?(Ai(i),ae(i),f0(i,b)):(ae(i),i.flags&=-16777217):(n=n.memoizedProps,n!==u&&Ai(i),ae(i),gh(i,p,n,u,o)),null;case 27:if(ht(i),o=ot.current,p=i.type,n!==null&&i.stateNode!=null)n.memoizedProps!==u&&Ai(i);else{if(!u){if(i.stateNode===null)throw Error(s(166));return ae(i),null}n=tt.current,Na(i)?qg(i):(n=vb(p,u,o),i.stateNode=n,Ai(i))}return ae(i),null;case 5:if(ht(i),p=i.type,n!==null&&i.stateNode!=null)n.memoizedProps!==u&&Ai(i);else{if(!u){if(i.stateNode===null)throw Error(s(166));return ae(i),null}if(b=tt.current,Na(i))qg(i);else{var A=Ec(ot.current);switch(b){case 1:b=A.createElementNS("http://www.w3.org/2000/svg",p);break;case 2:b=A.createElementNS("http://www.w3.org/1998/Math/MathML",p);break;default:switch(p){case"svg":b=A.createElementNS("http://www.w3.org/2000/svg",p);break;case"math":b=A.createElementNS("http://www.w3.org/1998/Math/MathML",p);break;case"script":b=A.createElement("div"),b.innerHTML="<script><\/script>",b=b.removeChild(b.firstChild);break;case"select":b=typeof u.is=="string"?A.createElement("select",{is:u.is}):A.createElement("select"),u.multiple?b.multiple=!0:u.size&&(b.size=u.size);break;default:b=typeof u.is=="string"?A.createElement(p,{is:u.is}):A.createElement(p)}}b[Ne]=i,b[Ke]=u;t:for(A=i.child;A!==null;){if(A.tag===5||A.tag===6)b.appendChild(A.stateNode);else if(A.tag!==4&&A.tag!==27&&A.child!==null){A.child.return=A,A=A.child;continue}if(A===i)break t;for(;A.sibling===null;){if(A.return===null||A.return===i)break t;A=A.return}A.sibling.return=A.return,A=A.sibling}i.stateNode=b;t:switch(Ie(b,p,u),p){case"button":case"input":case"select":case"textarea":u=!!u.autoFocus;break t;case"img":u=!0;break t;default:u=!1}u&&Ai(i)}}return ae(i),gh(i,i.type,n===null?null:n.memoizedProps,i.pendingProps,o),null;case 6:if(n&&i.stateNode!=null)n.memoizedProps!==u&&Ai(i);else{if(typeof u!="string"&&i.stateNode===null)throw Error(s(166));if(n=ot.current,Na(i)){if(n=i.stateNode,o=i.memoizedProps,u=null,p=Be,p!==null)switch(p.tag){case 27:case 5:u=p.memoizedProps}n[Ne]=i,n=!!(n.nodeValue===o||u!==null&&u.suppressHydrationWarning===!0||cb(n.nodeValue,o)),n||Gi(i,!0)}else n=Ec(n).createTextNode(u),n[Ne]=i,i.stateNode=n}return ae(i),null;case 31:if(o=i.memoizedState,n===null||n.memoizedState!==null){if(u=Na(i),o!==null){if(n===null){if(!u)throw Error(s(318));if(n=i.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(s(557));n[Ne]=i}else Ns(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;ae(i),n=!1}else o=Td(),n!==null&&n.memoizedState!==null&&(n.memoizedState.hydrationErrors=o),n=!0;if(!n)return i.flags&256?(pn(i),i):(pn(i),null);if((i.flags&128)!==0)throw Error(s(558))}return ae(i),null;case 13:if(u=i.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(p=Na(i),u!==null&&u.dehydrated!==null){if(n===null){if(!p)throw Error(s(318));if(p=i.memoizedState,p=p!==null?p.dehydrated:null,!p)throw Error(s(317));p[Ne]=i}else Ns(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;ae(i),p=!1}else p=Td(),n!==null&&n.memoizedState!==null&&(n.memoizedState.hydrationErrors=p),p=!0;if(!p)return i.flags&256?(pn(i),i):(pn(i),null)}return pn(i),(i.flags&128)!==0?(i.lanes=o,i):(o=u!==null,n=n!==null&&n.memoizedState!==null,o&&(u=i.child,p=null,u.alternate!==null&&u.alternate.memoizedState!==null&&u.alternate.memoizedState.cachePool!==null&&(p=u.alternate.memoizedState.cachePool.pool),b=null,u.memoizedState!==null&&u.memoizedState.cachePool!==null&&(b=u.memoizedState.cachePool.pool),b!==p&&(u.flags|=2048)),o!==n&&o&&(i.child.flags|=8192),cc(i,i.updateQueue),ae(i),null);case 4:return et(),n===null&&zh(i.stateNode.containerInfo),ae(i),null;case 10:return bi(i.type),ae(i),null;case 19:if(H(be),u=i.memoizedState,u===null)return ae(i),null;if(p=(i.flags&128)!==0,b=u.rendering,b===null)if(p)vo(u,!1);else{if(ge!==0||n!==null&&(n.flags&128)!==0)for(n=i.child;n!==null;){if(b=Ql(n),b!==null){for(i.flags|=128,vo(u,!1),n=b.updateQueue,i.updateQueue=n,cc(i,n),i.subtreeFlags=0,n=o,o=i.child;o!==null;)$g(o,n),o=o.sibling;return q(be,be.current&1|2),$t&&gi(i,u.treeForkCount),i.child}n=n.sibling}u.tail!==null&&Ue()>pc&&(i.flags|=128,p=!0,vo(u,!1),i.lanes=4194304)}else{if(!p)if(n=Ql(b),n!==null){if(i.flags|=128,p=!0,n=n.updateQueue,i.updateQueue=n,cc(i,n),vo(u,!0),u.tail===null&&u.tailMode==="hidden"&&!b.alternate&&!$t)return ae(i),null}else 2*Ue()-u.renderingStartTime>pc&&o!==536870912&&(i.flags|=128,p=!0,vo(u,!1),i.lanes=4194304);u.isBackwards?(b.sibling=i.child,i.child=b):(n=u.last,n!==null?n.sibling=b:i.child=b,u.last=b)}return u.tail!==null?(n=u.tail,u.rendering=n,u.tail=n.sibling,u.renderingStartTime=Ue(),n.sibling=null,o=be.current,q(be,p?o&1|2:o&1),$t&&gi(i,u.treeForkCount),n):(ae(i),null);case 22:case 23:return pn(i),Pd(),u=i.memoizedState!==null,n!==null?n.memoizedState!==null!==u&&(i.flags|=8192):u&&(i.flags|=8192),u?(o&536870912)!==0&&(i.flags&128)===0&&(ae(i),i.subtreeFlags&6&&(i.flags|=8192)):ae(i),o=i.updateQueue,o!==null&&cc(i,o.retryQueue),o=null,n!==null&&n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),u=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(u=i.memoizedState.cachePool.pool),u!==o&&(i.flags|=2048),n!==null&&H(Ps),null;case 24:return o=null,n!==null&&(o=n.memoizedState.cache),i.memoizedState.cache!==o&&(i.flags|=2048),bi(Ae),ae(i),null;case 25:return null;case 30:return null}throw Error(s(156,i.tag))}function nw(n,i){switch(Sd(i),i.tag){case 1:return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 3:return bi(Ae),et(),n=i.flags,(n&65536)!==0&&(n&128)===0?(i.flags=n&-65537|128,i):null;case 26:case 27:case 5:return ht(i),null;case 31:if(i.memoizedState!==null){if(pn(i),i.alternate===null)throw Error(s(340));Ns()}return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 13:if(pn(i),n=i.memoizedState,n!==null&&n.dehydrated!==null){if(i.alternate===null)throw Error(s(340));Ns()}return n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 19:return H(be),null;case 4:return et(),null;case 10:return bi(i.type),null;case 22:case 23:return pn(i),Pd(),n!==null&&H(Ps),n=i.flags,n&65536?(i.flags=n&-65537|128,i):null;case 24:return bi(Ae),null;case 25:return null;default:return null}}function p0(n,i){switch(Sd(i),i.tag){case 3:bi(Ae),et();break;case 26:case 27:case 5:ht(i);break;case 4:et();break;case 31:i.memoizedState!==null&&pn(i);break;case 13:pn(i);break;case 19:H(be);break;case 10:bi(i.type);break;case 22:case 23:pn(i),Pd(),n!==null&&H(Ps);break;case 24:bi(Ae)}}function Ao(n,i){try{var o=i.updateQueue,u=o!==null?o.lastEffect:null;if(u!==null){var p=u.next;o=p;do{if((o.tag&n)===n){u=void 0;var b=o.create,A=o.inst;u=b(),A.destroy=u}o=o.next}while(o!==p)}}catch(M){Qt(i,i.return,M)}}function Ki(n,i,o){try{var u=i.updateQueue,p=u!==null?u.lastEffect:null;if(p!==null){var b=p.next;u=b;do{if((u.tag&n)===n){var A=u.inst,M=A.destroy;if(M!==void 0){A.destroy=void 0,p=i;var N=o,G=M;try{G()}catch(J){Qt(p,N,J)}}}u=u.next}while(u!==b)}}catch(J){Qt(i,i.return,J)}}function g0(n){var i=n.updateQueue;if(i!==null){var o=n.stateNode;try{am(i,o)}catch(u){Qt(n,n.return,u)}}}function m0(n,i,o){o.props=Us(n.type,n.memoizedProps),o.state=n.memoizedState;try{o.componentWillUnmount()}catch(u){Qt(n,i,u)}}function wo(n,i){try{var o=n.ref;if(o!==null){switch(n.tag){case 26:case 27:case 5:var u=n.stateNode;break;case 30:u=n.stateNode;break;default:u=n.stateNode}typeof o=="function"?n.refCleanup=o(u):o.current=u}}catch(p){Qt(n,i,p)}}function Zn(n,i){var o=n.ref,u=n.refCleanup;if(o!==null)if(typeof u=="function")try{u()}catch(p){Qt(n,i,p)}finally{n.refCleanup=null,n=n.alternate,n!=null&&(n.refCleanup=null)}else if(typeof o=="function")try{o(null)}catch(p){Qt(n,i,p)}else o.current=null}function b0(n){var i=n.type,o=n.memoizedProps,u=n.stateNode;try{t:switch(i){case"button":case"input":case"select":case"textarea":o.autoFocus&&u.focus();break t;case"img":o.src?u.src=o.src:o.srcSet&&(u.srcset=o.srcSet)}}catch(p){Qt(n,n.return,p)}}function mh(n,i,o){try{var u=n.stateNode;Ew(u,n.type,o,i),u[Ke]=i}catch(p){Qt(n,n.return,p)}}function y0(n){return n.tag===5||n.tag===3||n.tag===26||n.tag===27&&ss(n.type)||n.tag===4}function bh(n){t:for(;;){for(;n.sibling===null;){if(n.return===null||y0(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.tag===27&&ss(n.type)||n.flags&2||n.child===null||n.tag===4)continue t;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function yh(n,i,o){var u=n.tag;if(u===5||u===6)n=n.stateNode,i?(o.nodeType===9?o.body:o.nodeName==="HTML"?o.ownerDocument.body:o).insertBefore(n,i):(i=o.nodeType===9?o.body:o.nodeName==="HTML"?o.ownerDocument.body:o,i.appendChild(n),o=o._reactRootContainer,o!=null||i.onclick!==null||(i.onclick=hi));else if(u!==4&&(u===27&&ss(n.type)&&(o=n.stateNode,i=null),n=n.child,n!==null))for(yh(n,i,o),n=n.sibling;n!==null;)yh(n,i,o),n=n.sibling}function uc(n,i,o){var u=n.tag;if(u===5||u===6)n=n.stateNode,i?o.insertBefore(n,i):o.appendChild(n);else if(u!==4&&(u===27&&ss(n.type)&&(o=n.stateNode),n=n.child,n!==null))for(uc(n,i,o),n=n.sibling;n!==null;)uc(n,i,o),n=n.sibling}function x0(n){var i=n.stateNode,o=n.memoizedProps;try{for(var u=n.type,p=i.attributes;p.length;)i.removeAttributeNode(p[0]);Ie(i,u,o),i[Ne]=n,i[Ke]=o}catch(b){Qt(n,n.return,b)}}var wi=!1,Ee=!1,xh=!1,v0=typeof WeakSet=="function"?WeakSet:Set,De=null;function iw(n,i){if(n=n.containerInfo,Fh=Rc,n=Lg(n),hd(n)){if("selectionStart"in n)var o={start:n.selectionStart,end:n.selectionEnd};else t:{o=(o=n.ownerDocument)&&o.defaultView||window;var u=o.getSelection&&o.getSelection();if(u&&u.rangeCount!==0){o=u.anchorNode;var p=u.anchorOffset,b=u.focusNode;u=u.focusOffset;try{o.nodeType,b.nodeType}catch{o=null;break t}var A=0,M=-1,N=-1,G=0,J=0,it=n,Y=null;e:for(;;){for(var Q;it!==o||p!==0&&it.nodeType!==3||(M=A+p),it!==b||u!==0&&it.nodeType!==3||(N=A+u),it.nodeType===3&&(A+=it.nodeValue.length),(Q=it.firstChild)!==null;)Y=it,it=Q;for(;;){if(it===n)break e;if(Y===o&&++G===p&&(M=A),Y===b&&++J===u&&(N=A),(Q=it.nextSibling)!==null)break;it=Y,Y=it.parentNode}it=Q}o=M===-1||N===-1?null:{start:M,end:N}}else o=null}o=o||{start:0,end:0}}else o=null;for($h={focusedElem:n,selectionRange:o},Rc=!1,De=i;De!==null;)if(i=De,n=i.child,(i.subtreeFlags&1028)!==0&&n!==null)n.return=i,De=n;else for(;De!==null;){switch(i=De,b=i.alternate,n=i.flags,i.tag){case 0:if((n&4)!==0&&(n=i.updateQueue,n=n!==null?n.events:null,n!==null))for(o=0;o<n.length;o++)p=n[o],p.ref.impl=p.nextImpl;break;case 11:case 15:break;case 1:if((n&1024)!==0&&b!==null){n=void 0,o=i,p=b.memoizedProps,b=b.memoizedState,u=o.stateNode;try{var mt=Us(o.type,p);n=u.getSnapshotBeforeUpdate(mt,b),u.__reactInternalSnapshotBeforeUpdate=n}catch(Tt){Qt(o,o.return,Tt)}}break;case 3:if((n&1024)!==0){if(n=i.stateNode.containerInfo,o=n.nodeType,o===9)Gh(n);else if(o===1)switch(n.nodeName){case"HEAD":case"HTML":case"BODY":Gh(n);break;default:n.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((n&1024)!==0)throw Error(s(163))}if(n=i.sibling,n!==null){n.return=i.return,De=n;break}De=i.return}}function A0(n,i,o){var u=o.flags;switch(o.tag){case 0:case 11:case 15:Ei(n,o),u&4&&Ao(5,o);break;case 1:if(Ei(n,o),u&4)if(n=o.stateNode,i===null)try{n.componentDidMount()}catch(A){Qt(o,o.return,A)}else{var p=Us(o.type,i.memoizedProps);i=i.memoizedState;try{n.componentDidUpdate(p,i,n.__reactInternalSnapshotBeforeUpdate)}catch(A){Qt(o,o.return,A)}}u&64&&g0(o),u&512&&wo(o,o.return);break;case 3:if(Ei(n,o),u&64&&(n=o.updateQueue,n!==null)){if(i=null,o.child!==null)switch(o.child.tag){case 27:case 5:i=o.child.stateNode;break;case 1:i=o.child.stateNode}try{am(n,i)}catch(A){Qt(o,o.return,A)}}break;case 27:i===null&&u&4&&x0(o);case 26:case 5:Ei(n,o),i===null&&u&4&&b0(o),u&512&&wo(o,o.return);break;case 12:Ei(n,o);break;case 31:Ei(n,o),u&4&&E0(n,o);break;case 13:Ei(n,o),u&4&&T0(n,o),u&64&&(n=o.memoizedState,n!==null&&(n=n.dehydrated,n!==null&&(o=hw.bind(null,o),Lw(n,o))));break;case 22:if(u=o.memoizedState!==null||wi,!u){i=i!==null&&i.memoizedState!==null||Ee,p=wi;var b=Ee;wi=u,(Ee=i)&&!b?Ti(n,o,(o.subtreeFlags&8772)!==0):Ei(n,o),wi=p,Ee=b}break;case 30:break;default:Ei(n,o)}}function w0(n){var i=n.alternate;i!==null&&(n.alternate=null,w0(i)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(i=n.stateNode,i!==null&&Wu(i)),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}var oe=null,Je=!1;function Si(n,i,o){for(o=o.child;o!==null;)S0(n,i,o),o=o.sibling}function S0(n,i,o){if(cn&&typeof cn.onCommitFiberUnmount=="function")try{cn.onCommitFiberUnmount(Vr,o)}catch{}switch(o.tag){case 26:Ee||Zn(o,i),Si(n,i,o),o.memoizedState?o.memoizedState.count--:o.stateNode&&(o=o.stateNode,o.parentNode.removeChild(o));break;case 27:Ee||Zn(o,i);var u=oe,p=Je;ss(o.type)&&(oe=o.stateNode,Je=!1),Si(n,i,o),Ro(o.stateNode),oe=u,Je=p;break;case 5:Ee||Zn(o,i);case 6:if(u=oe,p=Je,oe=null,Si(n,i,o),oe=u,Je=p,oe!==null)if(Je)try{(oe.nodeType===9?oe.body:oe.nodeName==="HTML"?oe.ownerDocument.body:oe).removeChild(o.stateNode)}catch(b){Qt(o,i,b)}else try{oe.removeChild(o.stateNode)}catch(b){Qt(o,i,b)}break;case 18:oe!==null&&(Je?(n=oe,gb(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,o.stateNode),nr(n)):gb(oe,o.stateNode));break;case 4:u=oe,p=Je,oe=o.stateNode.containerInfo,Je=!0,Si(n,i,o),oe=u,Je=p;break;case 0:case 11:case 14:case 15:Ki(2,o,i),Ee||Ki(4,o,i),Si(n,i,o);break;case 1:Ee||(Zn(o,i),u=o.stateNode,typeof u.componentWillUnmount=="function"&&m0(o,i,u)),Si(n,i,o);break;case 21:Si(n,i,o);break;case 22:Ee=(u=Ee)||o.memoizedState!==null,Si(n,i,o),Ee=u;break;default:Si(n,i,o)}}function E0(n,i){if(i.memoizedState===null&&(n=i.alternate,n!==null&&(n=n.memoizedState,n!==null))){n=n.dehydrated;try{nr(n)}catch(o){Qt(i,i.return,o)}}}function T0(n,i){if(i.memoizedState===null&&(n=i.alternate,n!==null&&(n=n.memoizedState,n!==null&&(n=n.dehydrated,n!==null))))try{nr(n)}catch(o){Qt(i,i.return,o)}}function sw(n){switch(n.tag){case 31:case 13:case 19:var i=n.stateNode;return i===null&&(i=n.stateNode=new v0),i;case 22:return n=n.stateNode,i=n._retryCache,i===null&&(i=n._retryCache=new v0),i;default:throw Error(s(435,n.tag))}}function dc(n,i){var o=sw(n);i.forEach(function(u){if(!o.has(u)){o.add(u);var p=fw.bind(null,n,u);u.then(p,p)}})}function tn(n,i){var o=i.deletions;if(o!==null)for(var u=0;u<o.length;u++){var p=o[u],b=n,A=i,M=A;t:for(;M!==null;){switch(M.tag){case 27:if(ss(M.type)){oe=M.stateNode,Je=!1;break t}break;case 5:oe=M.stateNode,Je=!1;break t;case 3:case 4:oe=M.stateNode.containerInfo,Je=!0;break t}M=M.return}if(oe===null)throw Error(s(160));S0(b,A,p),oe=null,Je=!1,b=p.alternate,b!==null&&(b.return=null),p.return=null}if(i.subtreeFlags&13886)for(i=i.child;i!==null;)C0(i,n),i=i.sibling}var Hn=null;function C0(n,i){var o=n.alternate,u=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:tn(i,n),en(n),u&4&&(Ki(3,n,n.return),Ao(3,n),Ki(5,n,n.return));break;case 1:tn(i,n),en(n),u&512&&(Ee||o===null||Zn(o,o.return)),u&64&&wi&&(n=n.updateQueue,n!==null&&(u=n.callbacks,u!==null&&(o=n.shared.hiddenCallbacks,n.shared.hiddenCallbacks=o===null?u:o.concat(u))));break;case 26:var p=Hn;if(tn(i,n),en(n),u&512&&(Ee||o===null||Zn(o,o.return)),u&4){var b=o!==null?o.memoizedState:null;if(u=n.memoizedState,o===null)if(u===null)if(n.stateNode===null){t:{u=n.type,o=n.memoizedProps,p=p.ownerDocument||p;e:switch(u){case"title":b=p.getElementsByTagName("title")[0],(!b||b[Xr]||b[Ne]||b.namespaceURI==="http://www.w3.org/2000/svg"||b.hasAttribute("itemprop"))&&(b=p.createElement(u),p.head.insertBefore(b,p.querySelector("head > title"))),Ie(b,u,o),b[Ne]=n,Me(b),u=b;break t;case"link":var A=Cb("link","href",p).get(u+(o.href||""));if(A){for(var M=0;M<A.length;M++)if(b=A[M],b.getAttribute("href")===(o.href==null||o.href===""?null:o.href)&&b.getAttribute("rel")===(o.rel==null?null:o.rel)&&b.getAttribute("title")===(o.title==null?null:o.title)&&b.getAttribute("crossorigin")===(o.crossOrigin==null?null:o.crossOrigin)){A.splice(M,1);break e}}b=p.createElement(u),Ie(b,u,o),p.head.appendChild(b);break;case"meta":if(A=Cb("meta","content",p).get(u+(o.content||""))){for(M=0;M<A.length;M++)if(b=A[M],b.getAttribute("content")===(o.content==null?null:""+o.content)&&b.getAttribute("name")===(o.name==null?null:o.name)&&b.getAttribute("property")===(o.property==null?null:o.property)&&b.getAttribute("http-equiv")===(o.httpEquiv==null?null:o.httpEquiv)&&b.getAttribute("charset")===(o.charSet==null?null:o.charSet)){A.splice(M,1);break e}}b=p.createElement(u),Ie(b,u,o),p.head.appendChild(b);break;default:throw Error(s(468,u))}b[Ne]=n,Me(b),u=b}n.stateNode=u}else _b(p,n.type,n.stateNode);else n.stateNode=Tb(p,u,n.memoizedProps);else b!==u?(b===null?o.stateNode!==null&&(o=o.stateNode,o.parentNode.removeChild(o)):b.count--,u===null?_b(p,n.type,n.stateNode):Tb(p,u,n.memoizedProps)):u===null&&n.stateNode!==null&&mh(n,n.memoizedProps,o.memoizedProps)}break;case 27:tn(i,n),en(n),u&512&&(Ee||o===null||Zn(o,o.return)),o!==null&&u&4&&mh(n,n.memoizedProps,o.memoizedProps);break;case 5:if(tn(i,n),en(n),u&512&&(Ee||o===null||Zn(o,o.return)),n.flags&32){p=n.stateNode;try{Ta(p,"")}catch(mt){Qt(n,n.return,mt)}}u&4&&n.stateNode!=null&&(p=n.memoizedProps,mh(n,p,o!==null?o.memoizedProps:p)),u&1024&&(xh=!0);break;case 6:if(tn(i,n),en(n),u&4){if(n.stateNode===null)throw Error(s(162));u=n.memoizedProps,o=n.stateNode;try{o.nodeValue=u}catch(mt){Qt(n,n.return,mt)}}break;case 3:if(_c=null,p=Hn,Hn=Tc(i.containerInfo),tn(i,n),Hn=p,en(n),u&4&&o!==null&&o.memoizedState.isDehydrated)try{nr(i.containerInfo)}catch(mt){Qt(n,n.return,mt)}xh&&(xh=!1,_0(n));break;case 4:u=Hn,Hn=Tc(n.stateNode.containerInfo),tn(i,n),en(n),Hn=u;break;case 12:tn(i,n),en(n);break;case 31:tn(i,n),en(n),u&4&&(u=n.updateQueue,u!==null&&(n.updateQueue=null,dc(n,u)));break;case 13:tn(i,n),en(n),n.child.flags&8192&&n.memoizedState!==null!=(o!==null&&o.memoizedState!==null)&&(fc=Ue()),u&4&&(u=n.updateQueue,u!==null&&(n.updateQueue=null,dc(n,u)));break;case 22:p=n.memoizedState!==null;var N=o!==null&&o.memoizedState!==null,G=wi,J=Ee;if(wi=G||p,Ee=J||N,tn(i,n),Ee=J,wi=G,en(n),u&8192)t:for(i=n.stateNode,i._visibility=p?i._visibility&-2:i._visibility|1,p&&(o===null||N||wi||Ee||Gs(n)),o=null,i=n;;){if(i.tag===5||i.tag===26){if(o===null){N=o=i;try{if(b=N.stateNode,p)A=b.style,typeof A.setProperty=="function"?A.setProperty("display","none","important"):A.display="none";else{M=N.stateNode;var it=N.memoizedProps.style,Y=it!=null&&it.hasOwnProperty("display")?it.display:null;M.style.display=Y==null||typeof Y=="boolean"?"":(""+Y).trim()}}catch(mt){Qt(N,N.return,mt)}}}else if(i.tag===6){if(o===null){N=i;try{N.stateNode.nodeValue=p?"":N.memoizedProps}catch(mt){Qt(N,N.return,mt)}}}else if(i.tag===18){if(o===null){N=i;try{var Q=N.stateNode;p?mb(Q,!0):mb(N.stateNode,!1)}catch(mt){Qt(N,N.return,mt)}}}else if((i.tag!==22&&i.tag!==23||i.memoizedState===null||i===n)&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===n)break t;for(;i.sibling===null;){if(i.return===null||i.return===n)break t;o===i&&(o=null),i=i.return}o===i&&(o=null),i.sibling.return=i.return,i=i.sibling}u&4&&(u=n.updateQueue,u!==null&&(o=u.retryQueue,o!==null&&(u.retryQueue=null,dc(n,o))));break;case 19:tn(i,n),en(n),u&4&&(u=n.updateQueue,u!==null&&(n.updateQueue=null,dc(n,u)));break;case 30:break;case 21:break;default:tn(i,n),en(n)}}function en(n){var i=n.flags;if(i&2){try{for(var o,u=n.return;u!==null;){if(y0(u)){o=u;break}u=u.return}if(o==null)throw Error(s(160));switch(o.tag){case 27:var p=o.stateNode,b=bh(n);uc(n,b,p);break;case 5:var A=o.stateNode;o.flags&32&&(Ta(A,""),o.flags&=-33);var M=bh(n);uc(n,M,A);break;case 3:case 4:var N=o.stateNode.containerInfo,G=bh(n);yh(n,G,N);break;default:throw Error(s(161))}}catch(J){Qt(n,n.return,J)}n.flags&=-3}i&4096&&(n.flags&=-4097)}function _0(n){if(n.subtreeFlags&1024)for(n=n.child;n!==null;){var i=n;_0(i),i.tag===5&&i.flags&1024&&i.stateNode.reset(),n=n.sibling}}function Ei(n,i){if(i.subtreeFlags&8772)for(i=i.child;i!==null;)A0(n,i.alternate,i),i=i.sibling}function Gs(n){for(n=n.child;n!==null;){var i=n;switch(i.tag){case 0:case 11:case 14:case 15:Ki(4,i,i.return),Gs(i);break;case 1:Zn(i,i.return);var o=i.stateNode;typeof o.componentWillUnmount=="function"&&m0(i,i.return,o),Gs(i);break;case 27:Ro(i.stateNode);case 26:case 5:Zn(i,i.return),Gs(i);break;case 22:i.memoizedState===null&&Gs(i);break;case 30:Gs(i);break;default:Gs(i)}n=n.sibling}}function Ti(n,i,o){for(o=o&&(i.subtreeFlags&8772)!==0,i=i.child;i!==null;){var u=i.alternate,p=n,b=i,A=b.flags;switch(b.tag){case 0:case 11:case 15:Ti(p,b,o),Ao(4,b);break;case 1:if(Ti(p,b,o),u=b,p=u.stateNode,typeof p.componentDidMount=="function")try{p.componentDidMount()}catch(G){Qt(u,u.return,G)}if(u=b,p=u.updateQueue,p!==null){var M=u.stateNode;try{var N=p.shared.hiddenCallbacks;if(N!==null)for(p.shared.hiddenCallbacks=null,p=0;p<N.length;p++)sm(N[p],M)}catch(G){Qt(u,u.return,G)}}o&&A&64&&g0(b),wo(b,b.return);break;case 27:x0(b);case 26:case 5:Ti(p,b,o),o&&u===null&&A&4&&b0(b),wo(b,b.return);break;case 12:Ti(p,b,o);break;case 31:Ti(p,b,o),o&&A&4&&E0(p,b);break;case 13:Ti(p,b,o),o&&A&4&&T0(p,b);break;case 22:b.memoizedState===null&&Ti(p,b,o),wo(b,b.return);break;case 30:break;default:Ti(p,b,o)}i=i.sibling}}function vh(n,i){var o=null;n!==null&&n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),n=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(n=i.memoizedState.cachePool.pool),n!==o&&(n!=null&&n.refCount++,o!=null&&oo(o))}function Ah(n,i){n=null,i.alternate!==null&&(n=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==n&&(i.refCount++,n!=null&&oo(n))}function Un(n,i,o,u){if(i.subtreeFlags&10256)for(i=i.child;i!==null;)k0(n,i,o,u),i=i.sibling}function k0(n,i,o,u){var p=i.flags;switch(i.tag){case 0:case 11:case 15:Un(n,i,o,u),p&2048&&Ao(9,i);break;case 1:Un(n,i,o,u);break;case 3:Un(n,i,o,u),p&2048&&(n=null,i.alternate!==null&&(n=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==n&&(i.refCount++,n!=null&&oo(n)));break;case 12:if(p&2048){Un(n,i,o,u),n=i.stateNode;try{var b=i.memoizedProps,A=b.id,M=b.onPostCommit;typeof M=="function"&&M(A,i.alternate===null?"mount":"update",n.passiveEffectDuration,-0)}catch(N){Qt(i,i.return,N)}}else Un(n,i,o,u);break;case 31:Un(n,i,o,u);break;case 13:Un(n,i,o,u);break;case 23:break;case 22:b=i.stateNode,A=i.alternate,i.memoizedState!==null?b._visibility&2?Un(n,i,o,u):So(n,i):b._visibility&2?Un(n,i,o,u):(b._visibility|=2,Va(n,i,o,u,(i.subtreeFlags&10256)!==0||!1)),p&2048&&vh(A,i);break;case 24:Un(n,i,o,u),p&2048&&Ah(i.alternate,i);break;default:Un(n,i,o,u)}}function Va(n,i,o,u,p){for(p=p&&((i.subtreeFlags&10256)!==0||!1),i=i.child;i!==null;){var b=n,A=i,M=o,N=u,G=A.flags;switch(A.tag){case 0:case 11:case 15:Va(b,A,M,N,p),Ao(8,A);break;case 23:break;case 22:var J=A.stateNode;A.memoizedState!==null?J._visibility&2?Va(b,A,M,N,p):So(b,A):(J._visibility|=2,Va(b,A,M,N,p)),p&&G&2048&&vh(A.alternate,A);break;case 24:Va(b,A,M,N,p),p&&G&2048&&Ah(A.alternate,A);break;default:Va(b,A,M,N,p)}i=i.sibling}}function So(n,i){if(i.subtreeFlags&10256)for(i=i.child;i!==null;){var o=n,u=i,p=u.flags;switch(u.tag){case 22:So(o,u),p&2048&&vh(u.alternate,u);break;case 24:So(o,u),p&2048&&Ah(u.alternate,u);break;default:So(o,u)}i=i.sibling}}var Eo=8192;function qa(n,i,o){if(n.subtreeFlags&Eo)for(n=n.child;n!==null;)M0(n,i,o),n=n.sibling}function M0(n,i,o){switch(n.tag){case 26:qa(n,i,o),n.flags&Eo&&n.memoizedState!==null&&Gw(o,Hn,n.memoizedState,n.memoizedProps);break;case 5:qa(n,i,o);break;case 3:case 4:var u=Hn;Hn=Tc(n.stateNode.containerInfo),qa(n,i,o),Hn=u;break;case 22:n.memoizedState===null&&(u=n.alternate,u!==null&&u.memoizedState!==null?(u=Eo,Eo=16777216,qa(n,i,o),Eo=u):qa(n,i,o));break;default:qa(n,i,o)}}function D0(n){var i=n.alternate;if(i!==null&&(n=i.child,n!==null)){i.child=null;do i=n.sibling,n.sibling=null,n=i;while(n!==null)}}function To(n){var i=n.deletions;if((n.flags&16)!==0){if(i!==null)for(var o=0;o<i.length;o++){var u=i[o];De=u,L0(u,n)}D0(n)}if(n.subtreeFlags&10256)for(n=n.child;n!==null;)R0(n),n=n.sibling}function R0(n){switch(n.tag){case 0:case 11:case 15:To(n),n.flags&2048&&Ki(9,n,n.return);break;case 3:To(n);break;case 12:To(n);break;case 22:var i=n.stateNode;n.memoizedState!==null&&i._visibility&2&&(n.return===null||n.return.tag!==13)?(i._visibility&=-3,hc(n)):To(n);break;default:To(n)}}function hc(n){var i=n.deletions;if((n.flags&16)!==0){if(i!==null)for(var o=0;o<i.length;o++){var u=i[o];De=u,L0(u,n)}D0(n)}for(n=n.child;n!==null;){switch(i=n,i.tag){case 0:case 11:case 15:Ki(8,i,i.return),hc(i);break;case 22:o=i.stateNode,o._visibility&2&&(o._visibility&=-3,hc(i));break;default:hc(i)}n=n.sibling}}function L0(n,i){for(;De!==null;){var o=De;switch(o.tag){case 0:case 11:case 15:Ki(8,o,i);break;case 23:case 22:if(o.memoizedState!==null&&o.memoizedState.cachePool!==null){var u=o.memoizedState.cachePool.pool;u!=null&&u.refCount++}break;case 24:oo(o.memoizedState.cache)}if(u=o.child,u!==null)u.return=o,De=u;else t:for(o=n;De!==null;){u=De;var p=u.sibling,b=u.return;if(w0(u),u===o){De=null;break t}if(p!==null){p.return=b,De=p;break t}De=b}}}var aw={getCacheForType:function(n){var i=ze(Ae),o=i.data.get(n);return o===void 0&&(o=n(),i.data.set(n,o)),o},cacheSignal:function(){return ze(Ae).controller.signal}},rw=typeof WeakMap=="function"?WeakMap:Map,qt=0,ee=null,Bt=null,Pt=0,Wt=0,gn=null,Zi=!1,Ya=!1,wh=!1,Ci=0,ge=0,Ji=0,Vs=0,Sh=0,mn=0,Xa=0,Co=null,nn=null,Eh=!1,fc=0,O0=0,pc=1/0,gc=null,ts=null,_e=0,es=null,Wa=null,_i=0,Th=0,Ch=null,j0=null,_o=0,_h=null;function bn(){return(qt&2)!==0&&Pt!==0?Pt&-Pt:P.T!==null?Oh():Qp()}function N0(){if(mn===0)if((Pt&536870912)===0||$t){var n=Sl;Sl<<=1,(Sl&3932160)===0&&(Sl=262144),mn=n}else mn=536870912;return n=fn.current,n!==null&&(n.flags|=32),mn}function sn(n,i,o){(n===ee&&(Wt===2||Wt===9)||n.cancelPendingCommit!==null)&&(Qa(n,0),ns(n,Pt,mn,!1)),Yr(n,o),((qt&2)===0||n!==ee)&&(n===ee&&((qt&2)===0&&(Vs|=o),ge===4&&ns(n,Pt,mn,!1)),Jn(n))}function B0(n,i,o){if((qt&6)!==0)throw Error(s(327));var u=!o&&(i&127)===0&&(i&n.expiredLanes)===0||qr(n,i),p=u?cw(n,i):Mh(n,i,!0),b=u;do{if(p===0){Ya&&!u&&ns(n,i,0,!1);break}else{if(o=n.current.alternate,b&&!ow(o)){p=Mh(n,i,!1),b=!1;continue}if(p===2){if(b=i,n.errorRecoveryDisabledLanes&b)var A=0;else A=n.pendingLanes&-536870913,A=A!==0?A:A&536870912?536870912:0;if(A!==0){i=A;t:{var M=n;p=Co;var N=M.current.memoizedState.isDehydrated;if(N&&(Qa(M,A).flags|=256),A=Mh(M,A,!1),A!==2){if(wh&&!N){M.errorRecoveryDisabledLanes|=b,Vs|=b,p=4;break t}b=nn,nn=p,b!==null&&(nn===null?nn=b:nn.push.apply(nn,b))}p=A}if(b=!1,p!==2)continue}}if(p===1){Qa(n,0),ns(n,i,0,!0);break}t:{switch(u=n,b=p,b){case 0:case 1:throw Error(s(345));case 4:if((i&4194048)!==i)break;case 6:ns(u,i,mn,!Zi);break t;case 2:nn=null;break;case 3:case 5:break;default:throw Error(s(329))}if((i&62914560)===i&&(p=fc+300-Ue(),10<p)){if(ns(u,i,mn,!Zi),Tl(u,0,!0)!==0)break t;_i=i,u.timeoutHandle=fb(z0.bind(null,u,o,nn,gc,Eh,i,mn,Vs,Xa,Zi,b,"Throttled",-0,0),p);break t}z0(u,o,nn,gc,Eh,i,mn,Vs,Xa,Zi,b,null,-0,0)}}break}while(!0);Jn(n)}function z0(n,i,o,u,p,b,A,M,N,G,J,it,Y,Q){if(n.timeoutHandle=-1,it=i.subtreeFlags,it&8192||(it&16785408)===16785408){it={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:hi},M0(i,b,it);var mt=(b&62914560)===b?fc-Ue():(b&4194048)===b?O0-Ue():0;if(mt=Vw(it,mt),mt!==null){_i=b,n.cancelPendingCommit=mt(V0.bind(null,n,i,b,o,u,p,A,M,N,J,it,null,Y,Q)),ns(n,b,A,!G);return}}V0(n,i,b,o,u,p,A,M,N)}function ow(n){for(var i=n;;){var o=i.tag;if((o===0||o===11||o===15)&&i.flags&16384&&(o=i.updateQueue,o!==null&&(o=o.stores,o!==null)))for(var u=0;u<o.length;u++){var p=o[u],b=p.getSnapshot;p=p.value;try{if(!dn(b(),p))return!1}catch{return!1}}if(o=i.child,i.subtreeFlags&16384&&o!==null)o.return=i,i=o;else{if(i===n)break;for(;i.sibling===null;){if(i.return===null||i.return===n)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function ns(n,i,o,u){i&=~Sh,i&=~Vs,n.suspendedLanes|=i,n.pingedLanes&=~i,u&&(n.warmLanes|=i),u=n.expirationTimes;for(var p=i;0<p;){var b=31-un(p),A=1<<b;u[b]=-1,p&=~A}o!==0&&Yp(n,o,i)}function mc(){return(qt&6)===0?(ko(0),!1):!0}function kh(){if(Bt!==null){if(Wt===0)var n=Bt.return;else n=Bt,mi=Bs=null,Gd(n),Fa=null,co=0,n=Bt;for(;n!==null;)p0(n.alternate,n),n=n.return;Bt=null}}function Qa(n,i){var o=n.timeoutHandle;o!==-1&&(n.timeoutHandle=-1,_w(o)),o=n.cancelPendingCommit,o!==null&&(n.cancelPendingCommit=null,o()),_i=0,kh(),ee=n,Bt=o=pi(n.current,null),Pt=i,Wt=0,gn=null,Zi=!1,Ya=qr(n,i),wh=!1,Xa=mn=Sh=Vs=Ji=ge=0,nn=Co=null,Eh=!1,(i&8)!==0&&(i|=i&32);var u=n.entangledLanes;if(u!==0)for(n=n.entanglements,u&=i;0<u;){var p=31-un(u),b=1<<p;i|=n[p],u&=~b}return Ci=i,zl(),o}function P0(n,i){Lt=null,P.H=yo,i===Ia||i===Vl?(i=tm(),Wt=3):i===Ld?(i=tm(),Wt=4):Wt=i===rh?8:i!==null&&typeof i=="object"&&typeof i.then=="function"?6:1,gn=i,Bt===null&&(ge=1,ac(n,kn(i,n.current)))}function I0(){var n=fn.current;return n===null?!0:(Pt&4194048)===Pt?Ln===null:(Pt&62914560)===Pt||(Pt&536870912)!==0?n===Ln:!1}function F0(){var n=P.H;return P.H=yo,n===null?yo:n}function $0(){var n=P.A;return P.A=aw,n}function bc(){ge=4,Zi||(Pt&4194048)!==Pt&&fn.current!==null||(Ya=!0),(Ji&134217727)===0&&(Vs&134217727)===0||ee===null||ns(ee,Pt,mn,!1)}function Mh(n,i,o){var u=qt;qt|=2;var p=F0(),b=$0();(ee!==n||Pt!==i)&&(gc=null,Qa(n,i)),i=!1;var A=ge;t:do try{if(Wt!==0&&Bt!==null){var M=Bt,N=gn;switch(Wt){case 8:kh(),A=6;break t;case 3:case 2:case 9:case 6:fn.current===null&&(i=!0);var G=Wt;if(Wt=0,gn=null,Ka(n,M,N,G),o&&Ya){A=0;break t}break;default:G=Wt,Wt=0,gn=null,Ka(n,M,N,G)}}lw(),A=ge;break}catch(J){P0(n,J)}while(!0);return i&&n.shellSuspendCounter++,mi=Bs=null,qt=u,P.H=p,P.A=b,Bt===null&&(ee=null,Pt=0,zl()),A}function lw(){for(;Bt!==null;)H0(Bt)}function cw(n,i){var o=qt;qt|=2;var u=F0(),p=$0();ee!==n||Pt!==i?(gc=null,pc=Ue()+500,Qa(n,i)):Ya=qr(n,i);t:do try{if(Wt!==0&&Bt!==null){i=Bt;var b=gn;e:switch(Wt){case 1:Wt=0,gn=null,Ka(n,i,b,1);break;case 2:case 9:if(Zg(b)){Wt=0,gn=null,U0(i);break}i=function(){Wt!==2&&Wt!==9||ee!==n||(Wt=7),Jn(n)},b.then(i,i);break t;case 3:Wt=7;break t;case 4:Wt=5;break t;case 7:Zg(b)?(Wt=0,gn=null,U0(i)):(Wt=0,gn=null,Ka(n,i,b,7));break;case 5:var A=null;switch(Bt.tag){case 26:A=Bt.memoizedState;case 5:case 27:var M=Bt;if(A?kb(A):M.stateNode.complete){Wt=0,gn=null;var N=M.sibling;if(N!==null)Bt=N;else{var G=M.return;G!==null?(Bt=G,yc(G)):Bt=null}break e}}Wt=0,gn=null,Ka(n,i,b,5);break;case 6:Wt=0,gn=null,Ka(n,i,b,6);break;case 8:kh(),ge=6;break t;default:throw Error(s(462))}}uw();break}catch(J){P0(n,J)}while(!0);return mi=Bs=null,P.H=u,P.A=p,qt=o,Bt!==null?0:(ee=null,Pt=0,zl(),ge)}function uw(){for(;Bt!==null&&!En();)H0(Bt)}function H0(n){var i=h0(n.alternate,n,Ci);n.memoizedProps=n.pendingProps,i===null?yc(n):Bt=i}function U0(n){var i=n,o=i.alternate;switch(i.tag){case 15:case 0:i=r0(o,i,i.pendingProps,i.type,void 0,Pt);break;case 11:i=r0(o,i,i.pendingProps,i.type.render,i.ref,Pt);break;case 5:Gd(i);default:p0(o,i),i=Bt=$g(i,Ci),i=h0(o,i,Ci)}n.memoizedProps=n.pendingProps,i===null?yc(n):Bt=i}function Ka(n,i,o,u){mi=Bs=null,Gd(i),Fa=null,co=0;var p=i.return;try{if(ZA(n,p,i,o,Pt)){ge=1,ac(n,kn(o,n.current)),Bt=null;return}}catch(b){if(p!==null)throw Bt=p,b;ge=1,ac(n,kn(o,n.current)),Bt=null;return}i.flags&32768?($t||u===1?n=!0:Ya||(Pt&536870912)!==0?n=!1:(Zi=n=!0,(u===2||u===9||u===3||u===6)&&(u=fn.current,u!==null&&u.tag===13&&(u.flags|=16384))),G0(i,n)):yc(i)}function yc(n){var i=n;do{if((i.flags&32768)!==0){G0(i,Zi);return}n=i.return;var o=ew(i.alternate,i,Ci);if(o!==null){Bt=o;return}if(i=i.sibling,i!==null){Bt=i;return}Bt=i=n}while(i!==null);ge===0&&(ge=5)}function G0(n,i){do{var o=nw(n.alternate,n);if(o!==null){o.flags&=32767,Bt=o;return}if(o=n.return,o!==null&&(o.flags|=32768,o.subtreeFlags=0,o.deletions=null),!i&&(n=n.sibling,n!==null)){Bt=n;return}Bt=n=o}while(n!==null);ge=6,Bt=null}function V0(n,i,o,u,p,b,A,M,N){n.cancelPendingCommit=null;do xc();while(_e!==0);if((qt&6)!==0)throw Error(s(327));if(i!==null){if(i===n.current)throw Error(s(177));if(b=i.lanes|i.childLanes,b|=bd,U1(n,o,b,A,M,N),n===ee&&(Bt=ee=null,Pt=0),Wa=i,es=n,_i=o,Th=b,Ch=p,j0=u,(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?(n.callbackNode=null,n.callbackPriority=0,pw(ln,function(){return Q0(),null})):(n.callbackNode=null,n.callbackPriority=0),u=(i.flags&13878)!==0,(i.subtreeFlags&13878)!==0||u){u=P.T,P.T=null,p=V.p,V.p=2,A=qt,qt|=4;try{iw(n,i,o)}finally{qt=A,V.p=p,P.T=u}}_e=1,q0(),Y0(),X0()}}function q0(){if(_e===1){_e=0;var n=es,i=Wa,o=(i.flags&13878)!==0;if((i.subtreeFlags&13878)!==0||o){o=P.T,P.T=null;var u=V.p;V.p=2;var p=qt;qt|=4;try{C0(i,n);var b=$h,A=Lg(n.containerInfo),M=b.focusedElem,N=b.selectionRange;if(A!==M&&M&&M.ownerDocument&&Rg(M.ownerDocument.documentElement,M)){if(N!==null&&hd(M)){var G=N.start,J=N.end;if(J===void 0&&(J=G),"selectionStart"in M)M.selectionStart=G,M.selectionEnd=Math.min(J,M.value.length);else{var it=M.ownerDocument||document,Y=it&&it.defaultView||window;if(Y.getSelection){var Q=Y.getSelection(),mt=M.textContent.length,Tt=Math.min(N.start,mt),Jt=N.end===void 0?Tt:Math.min(N.end,mt);!Q.extend&&Tt>Jt&&(A=Jt,Jt=Tt,Tt=A);var $=Dg(M,Tt),I=Dg(M,Jt);if($&&I&&(Q.rangeCount!==1||Q.anchorNode!==$.node||Q.anchorOffset!==$.offset||Q.focusNode!==I.node||Q.focusOffset!==I.offset)){var U=it.createRange();U.setStart($.node,$.offset),Q.removeAllRanges(),Tt>Jt?(Q.addRange(U),Q.extend(I.node,I.offset)):(U.setEnd(I.node,I.offset),Q.addRange(U))}}}}for(it=[],Q=M;Q=Q.parentNode;)Q.nodeType===1&&it.push({element:Q,left:Q.scrollLeft,top:Q.scrollTop});for(typeof M.focus=="function"&&M.focus(),M=0;M<it.length;M++){var nt=it[M];nt.element.scrollLeft=nt.left,nt.element.scrollTop=nt.top}}Rc=!!Fh,$h=Fh=null}finally{qt=p,V.p=u,P.T=o}}n.current=i,_e=2}}function Y0(){if(_e===2){_e=0;var n=es,i=Wa,o=(i.flags&8772)!==0;if((i.subtreeFlags&8772)!==0||o){o=P.T,P.T=null;var u=V.p;V.p=2;var p=qt;qt|=4;try{A0(n,i.alternate,i)}finally{qt=p,V.p=u,P.T=o}}_e=3}}function X0(){if(_e===4||_e===3){_e=0,ya();var n=es,i=Wa,o=_i,u=j0;(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?_e=5:(_e=0,Wa=es=null,W0(n,n.pendingLanes));var p=n.pendingLanes;if(p===0&&(ts=null),Yu(o),i=i.stateNode,cn&&typeof cn.onCommitFiberRoot=="function")try{cn.onCommitFiberRoot(Vr,i,void 0,(i.current.flags&128)===128)}catch{}if(u!==null){i=P.T,p=V.p,V.p=2,P.T=null;try{for(var b=n.onRecoverableError,A=0;A<u.length;A++){var M=u[A];b(M.value,{componentStack:M.stack})}}finally{P.T=i,V.p=p}}(_i&3)!==0&&xc(),Jn(n),p=n.pendingLanes,(o&261930)!==0&&(p&42)!==0?n===_h?_o++:(_o=0,_h=n):_o=0,ko(0)}}function W0(n,i){(n.pooledCacheLanes&=i)===0&&(i=n.pooledCache,i!=null&&(n.pooledCache=null,oo(i)))}function xc(){return q0(),Y0(),X0(),Q0()}function Q0(){if(_e!==5)return!1;var n=es,i=Th;Th=0;var o=Yu(_i),u=P.T,p=V.p;try{V.p=32>o?32:o,P.T=null,o=Ch,Ch=null;var b=es,A=_i;if(_e=0,Wa=es=null,_i=0,(qt&6)!==0)throw Error(s(331));var M=qt;if(qt|=4,R0(b.current),k0(b,b.current,A,o),qt=M,ko(0,!1),cn&&typeof cn.onPostCommitFiberRoot=="function")try{cn.onPostCommitFiberRoot(Vr,b)}catch{}return!0}finally{V.p=p,P.T=u,W0(n,i)}}function K0(n,i,o){i=kn(o,i),i=ah(n.stateNode,i,2),n=Xi(n,i,2),n!==null&&(Yr(n,2),Jn(n))}function Qt(n,i,o){if(n.tag===3)K0(n,n,o);else for(;i!==null;){if(i.tag===3){K0(i,n,o);break}else if(i.tag===1){var u=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof u.componentDidCatch=="function"&&(ts===null||!ts.has(u))){n=kn(o,n),o=Zm(2),u=Xi(i,o,2),u!==null&&(Jm(o,u,i,n),Yr(u,2),Jn(u));break}}i=i.return}}function Dh(n,i,o){var u=n.pingCache;if(u===null){u=n.pingCache=new rw;var p=new Set;u.set(i,p)}else p=u.get(i),p===void 0&&(p=new Set,u.set(i,p));p.has(o)||(wh=!0,p.add(o),n=dw.bind(null,n,i,o),i.then(n,n))}function dw(n,i,o){var u=n.pingCache;u!==null&&u.delete(i),n.pingedLanes|=n.suspendedLanes&o,n.warmLanes&=~o,ee===n&&(Pt&o)===o&&(ge===4||ge===3&&(Pt&62914560)===Pt&&300>Ue()-fc?(qt&2)===0&&Qa(n,0):Sh|=o,Xa===Pt&&(Xa=0)),Jn(n)}function Z0(n,i){i===0&&(i=qp()),n=Os(n,i),n!==null&&(Yr(n,i),Jn(n))}function hw(n){var i=n.memoizedState,o=0;i!==null&&(o=i.retryLane),Z0(n,o)}function fw(n,i){var o=0;switch(n.tag){case 31:case 13:var u=n.stateNode,p=n.memoizedState;p!==null&&(o=p.retryLane);break;case 19:u=n.stateNode;break;case 22:u=n.stateNode._retryCache;break;default:throw Error(s(314))}u!==null&&u.delete(i),Z0(n,o)}function pw(n,i){return In(n,i)}var vc=null,Za=null,Rh=!1,Ac=!1,Lh=!1,is=0;function Jn(n){n!==Za&&n.next===null&&(Za===null?vc=Za=n:Za=Za.next=n),Ac=!0,Rh||(Rh=!0,mw())}function ko(n,i){if(!Lh&&Ac){Lh=!0;do for(var o=!1,u=vc;u!==null;){if(n!==0){var p=u.pendingLanes;if(p===0)var b=0;else{var A=u.suspendedLanes,M=u.pingedLanes;b=(1<<31-un(42|n)+1)-1,b&=p&~(A&~M),b=b&201326741?b&201326741|1:b?b|2:0}b!==0&&(o=!0,nb(u,b))}else b=Pt,b=Tl(u,u===ee?b:0,u.cancelPendingCommit!==null||u.timeoutHandle!==-1),(b&3)===0||qr(u,b)||(o=!0,nb(u,b));u=u.next}while(o);Lh=!1}}function gw(){J0()}function J0(){Ac=Rh=!1;var n=0;is!==0&&Cw()&&(n=is);for(var i=Ue(),o=null,u=vc;u!==null;){var p=u.next,b=tb(u,i);b===0?(u.next=null,o===null?vc=p:o.next=p,p===null&&(Za=o)):(o=u,(n!==0||(b&3)!==0)&&(Ac=!0)),u=p}_e!==0&&_e!==5||ko(n),is!==0&&(is=0)}function tb(n,i){for(var o=n.suspendedLanes,u=n.pingedLanes,p=n.expirationTimes,b=n.pendingLanes&-62914561;0<b;){var A=31-un(b),M=1<<A,N=p[A];N===-1?((M&o)===0||(M&u)!==0)&&(p[A]=H1(M,i)):N<=i&&(n.expiredLanes|=M),b&=~M}if(i=ee,o=Pt,o=Tl(n,n===i?o:0,n.cancelPendingCommit!==null||n.timeoutHandle!==-1),u=n.callbackNode,o===0||n===i&&(Wt===2||Wt===9)||n.cancelPendingCommit!==null)return u!==null&&u!==null&&ui(u),n.callbackNode=null,n.callbackPriority=0;if((o&3)===0||qr(n,o)){if(i=o&-o,i===n.callbackPriority)return i;switch(u!==null&&ui(u),Yu(o)){case 2:case 8:o=Al;break;case 32:o=ln;break;case 268435456:o=Fn;break;default:o=ln}return u=eb.bind(null,n),o=In(o,u),n.callbackPriority=i,n.callbackNode=o,i}return u!==null&&u!==null&&ui(u),n.callbackPriority=2,n.callbackNode=null,2}function eb(n,i){if(_e!==0&&_e!==5)return n.callbackNode=null,n.callbackPriority=0,null;var o=n.callbackNode;if(xc()&&n.callbackNode!==o)return null;var u=Pt;return u=Tl(n,n===ee?u:0,n.cancelPendingCommit!==null||n.timeoutHandle!==-1),u===0?null:(B0(n,u,i),tb(n,Ue()),n.callbackNode!=null&&n.callbackNode===o?eb.bind(null,n):null)}function nb(n,i){if(xc())return null;B0(n,i,!0)}function mw(){kw(function(){(qt&6)!==0?In(vl,gw):J0()})}function Oh(){if(is===0){var n=za;n===0&&(n=wl,wl<<=1,(wl&261888)===0&&(wl=256)),is=n}return is}function ib(n){return n==null||typeof n=="symbol"||typeof n=="boolean"?null:typeof n=="function"?n:Ml(""+n)}function sb(n,i){var o=i.ownerDocument.createElement("input");return o.name=i.name,o.value=i.value,n.id&&o.setAttribute("form",n.id),i.parentNode.insertBefore(o,i),n=new FormData(n),o.parentNode.removeChild(o),n}function bw(n,i,o,u,p){if(i==="submit"&&o&&o.stateNode===p){var b=ib((p[Ke]||null).action),A=u.submitter;A&&(i=(i=A[Ke]||null)?ib(i.formAction):A.getAttribute("formAction"),i!==null&&(b=i,A=null));var M=new Ol("action","action",null,u,p);n.push({event:M,listeners:[{instance:null,listener:function(){if(u.defaultPrevented){if(is!==0){var N=A?sb(p,A):new FormData(p);Jd(o,{pending:!0,data:N,method:p.method,action:b},null,N)}}else typeof b=="function"&&(M.preventDefault(),N=A?sb(p,A):new FormData(p),Jd(o,{pending:!0,data:N,method:p.method,action:b},b,N))},currentTarget:p}]})}}for(var jh=0;jh<md.length;jh++){var Nh=md[jh],yw=Nh.toLowerCase(),xw=Nh[0].toUpperCase()+Nh.slice(1);$n(yw,"on"+xw)}$n(Ng,"onAnimationEnd"),$n(Bg,"onAnimationIteration"),$n(zg,"onAnimationStart"),$n("dblclick","onDoubleClick"),$n("focusin","onFocus"),$n("focusout","onBlur"),$n(NA,"onTransitionRun"),$n(BA,"onTransitionStart"),$n(zA,"onTransitionCancel"),$n(Pg,"onTransitionEnd"),Sa("onMouseEnter",["mouseout","mouseover"]),Sa("onMouseLeave",["mouseout","mouseover"]),Sa("onPointerEnter",["pointerout","pointerover"]),Sa("onPointerLeave",["pointerout","pointerover"]),Ms("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Ms("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Ms("onBeforeInput",["compositionend","keypress","textInput","paste"]),Ms("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Ms("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Ms("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Mo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),vw=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Mo));function ab(n,i){i=(i&4)!==0;for(var o=0;o<n.length;o++){var u=n[o],p=u.event;u=u.listeners;t:{var b=void 0;if(i)for(var A=u.length-1;0<=A;A--){var M=u[A],N=M.instance,G=M.currentTarget;if(M=M.listener,N!==b&&p.isPropagationStopped())break t;b=M,p.currentTarget=G;try{b(p)}catch(J){Bl(J)}p.currentTarget=null,b=N}else for(A=0;A<u.length;A++){if(M=u[A],N=M.instance,G=M.currentTarget,M=M.listener,N!==b&&p.isPropagationStopped())break t;b=M,p.currentTarget=G;try{b(p)}catch(J){Bl(J)}p.currentTarget=null,b=N}}}}function zt(n,i){var o=i[Xu];o===void 0&&(o=i[Xu]=new Set);var u=n+"__bubble";o.has(u)||(rb(i,n,2,!1),o.add(u))}function Bh(n,i,o){var u=0;i&&(u|=4),rb(o,n,u,i)}var wc="_reactListening"+Math.random().toString(36).slice(2);function zh(n){if(!n[wc]){n[wc]=!0,Jp.forEach(function(o){o!=="selectionchange"&&(vw.has(o)||Bh(o,!1,n),Bh(o,!0,n))});var i=n.nodeType===9?n:n.ownerDocument;i===null||i[wc]||(i[wc]=!0,Bh("selectionchange",!1,i))}}function rb(n,i,o,u){switch(Nb(i)){case 2:var p=Xw;break;case 8:p=Ww;break;default:p=Zh}o=p.bind(null,i,o,n),p=void 0,!id||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(p=!0),u?p!==void 0?n.addEventListener(i,o,{capture:!0,passive:p}):n.addEventListener(i,o,!0):p!==void 0?n.addEventListener(i,o,{passive:p}):n.addEventListener(i,o,!1)}function Ph(n,i,o,u,p){var b=u;if((i&1)===0&&(i&2)===0&&u!==null)t:for(;;){if(u===null)return;var A=u.tag;if(A===3||A===4){var M=u.stateNode.containerInfo;if(M===p)break;if(A===4)for(A=u.return;A!==null;){var N=A.tag;if((N===3||N===4)&&A.stateNode.containerInfo===p)return;A=A.return}for(;M!==null;){if(A=va(M),A===null)return;if(N=A.tag,N===5||N===6||N===26||N===27){u=b=A;continue t}M=M.parentNode}}u=u.return}dg(function(){var G=b,J=ed(o),it=[];t:{var Y=Ig.get(n);if(Y!==void 0){var Q=Ol,mt=n;switch(n){case"keypress":if(Rl(o)===0)break t;case"keydown":case"keyup":Q=fA;break;case"focusin":mt="focus",Q=od;break;case"focusout":mt="blur",Q=od;break;case"beforeblur":case"afterblur":Q=od;break;case"click":if(o.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":Q=pg;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":Q=eA;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":Q=mA;break;case Ng:case Bg:case zg:Q=sA;break;case Pg:Q=yA;break;case"scroll":case"scrollend":Q=J1;break;case"wheel":Q=vA;break;case"copy":case"cut":case"paste":Q=rA;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":Q=mg;break;case"toggle":case"beforetoggle":Q=wA}var Tt=(i&4)!==0,Jt=!Tt&&(n==="scroll"||n==="scrollend"),$=Tt?Y!==null?Y+"Capture":null:Y;Tt=[];for(var I=G,U;I!==null;){var nt=I;if(U=nt.stateNode,nt=nt.tag,nt!==5&&nt!==26&&nt!==27||U===null||$===null||(nt=Qr(I,$),nt!=null&&Tt.push(Do(I,nt,U))),Jt)break;I=I.return}0<Tt.length&&(Y=new Q(Y,mt,null,o,J),it.push({event:Y,listeners:Tt}))}}if((i&7)===0){t:{if(Y=n==="mouseover"||n==="pointerover",Q=n==="mouseout"||n==="pointerout",Y&&o!==td&&(mt=o.relatedTarget||o.fromElement)&&(va(mt)||mt[xa]))break t;if((Q||Y)&&(Y=J.window===J?J:(Y=J.ownerDocument)?Y.defaultView||Y.parentWindow:window,Q?(mt=o.relatedTarget||o.toElement,Q=G,mt=mt?va(mt):null,mt!==null&&(Jt=l(mt),Tt=mt.tag,mt!==Jt||Tt!==5&&Tt!==27&&Tt!==6)&&(mt=null)):(Q=null,mt=G),Q!==mt)){if(Tt=pg,nt="onMouseLeave",$="onMouseEnter",I="mouse",(n==="pointerout"||n==="pointerover")&&(Tt=mg,nt="onPointerLeave",$="onPointerEnter",I="pointer"),Jt=Q==null?Y:Wr(Q),U=mt==null?Y:Wr(mt),Y=new Tt(nt,I+"leave",Q,o,J),Y.target=Jt,Y.relatedTarget=U,nt=null,va(J)===G&&(Tt=new Tt($,I+"enter",mt,o,J),Tt.target=U,Tt.relatedTarget=Jt,nt=Tt),Jt=nt,Q&&mt)e:{for(Tt=Aw,$=Q,I=mt,U=0,nt=$;nt;nt=Tt(nt))U++;nt=0;for(var wt=I;wt;wt=Tt(wt))nt++;for(;0<U-nt;)$=Tt($),U--;for(;0<nt-U;)I=Tt(I),nt--;for(;U--;){if($===I||I!==null&&$===I.alternate){Tt=$;break e}$=Tt($),I=Tt(I)}Tt=null}else Tt=null;Q!==null&&ob(it,Y,Q,Tt,!1),mt!==null&&Jt!==null&&ob(it,Jt,mt,Tt,!0)}}t:{if(Y=G?Wr(G):window,Q=Y.nodeName&&Y.nodeName.toLowerCase(),Q==="select"||Q==="input"&&Y.type==="file")var Ut=Eg;else if(wg(Y))if(Tg)Ut=LA;else{Ut=DA;var vt=MA}else Q=Y.nodeName,!Q||Q.toLowerCase()!=="input"||Y.type!=="checkbox"&&Y.type!=="radio"?G&&Ju(G.elementType)&&(Ut=Eg):Ut=RA;if(Ut&&(Ut=Ut(n,G))){Sg(it,Ut,o,J);break t}vt&&vt(n,Y,G),n==="focusout"&&G&&Y.type==="number"&&G.memoizedProps.value!=null&&Zu(Y,"number",Y.value)}switch(vt=G?Wr(G):window,n){case"focusin":(wg(vt)||vt.contentEditable==="true")&&(Ma=vt,fd=G,so=null);break;case"focusout":so=fd=Ma=null;break;case"mousedown":pd=!0;break;case"contextmenu":case"mouseup":case"dragend":pd=!1,Og(it,o,J);break;case"selectionchange":if(jA)break;case"keydown":case"keyup":Og(it,o,J)}var Ot;if(cd)t:{switch(n){case"compositionstart":var It="onCompositionStart";break t;case"compositionend":It="onCompositionEnd";break t;case"compositionupdate":It="onCompositionUpdate";break t}It=void 0}else ka?vg(n,o)&&(It="onCompositionEnd"):n==="keydown"&&o.keyCode===229&&(It="onCompositionStart");It&&(bg&&o.locale!=="ko"&&(ka||It!=="onCompositionStart"?It==="onCompositionEnd"&&ka&&(Ot=hg()):($i=J,sd="value"in $i?$i.value:$i.textContent,ka=!0)),vt=Sc(G,It),0<vt.length&&(It=new gg(It,n,null,o,J),it.push({event:It,listeners:vt}),Ot?It.data=Ot:(Ot=Ag(o),Ot!==null&&(It.data=Ot)))),(Ot=EA?TA(n,o):CA(n,o))&&(It=Sc(G,"onBeforeInput"),0<It.length&&(vt=new gg("onBeforeInput","beforeinput",null,o,J),it.push({event:vt,listeners:It}),vt.data=Ot)),bw(it,n,G,o,J)}ab(it,i)})}function Do(n,i,o){return{instance:n,listener:i,currentTarget:o}}function Sc(n,i){for(var o=i+"Capture",u=[];n!==null;){var p=n,b=p.stateNode;if(p=p.tag,p!==5&&p!==26&&p!==27||b===null||(p=Qr(n,o),p!=null&&u.unshift(Do(n,p,b)),p=Qr(n,i),p!=null&&u.push(Do(n,p,b))),n.tag===3)return u;n=n.return}return[]}function Aw(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5&&n.tag!==27);return n||null}function ob(n,i,o,u,p){for(var b=i._reactName,A=[];o!==null&&o!==u;){var M=o,N=M.alternate,G=M.stateNode;if(M=M.tag,N!==null&&N===u)break;M!==5&&M!==26&&M!==27||G===null||(N=G,p?(G=Qr(o,b),G!=null&&A.unshift(Do(o,G,N))):p||(G=Qr(o,b),G!=null&&A.push(Do(o,G,N)))),o=o.return}A.length!==0&&n.push({event:i,listeners:A})}var ww=/\r\n?/g,Sw=/\u0000|\uFFFD/g;function lb(n){return(typeof n=="string"?n:""+n).replace(ww,`
`).replace(Sw,"")}function cb(n,i){return i=lb(i),lb(n)===i}function Zt(n,i,o,u,p,b){switch(o){case"children":typeof u=="string"?i==="body"||i==="textarea"&&u===""||Ta(n,u):(typeof u=="number"||typeof u=="bigint")&&i!=="body"&&Ta(n,""+u);break;case"className":_l(n,"class",u);break;case"tabIndex":_l(n,"tabindex",u);break;case"dir":case"role":case"viewBox":case"width":case"height":_l(n,o,u);break;case"style":cg(n,u,b);break;case"data":if(i!=="object"){_l(n,"data",u);break}case"src":case"href":if(u===""&&(i!=="a"||o!=="href")){n.removeAttribute(o);break}if(u==null||typeof u=="function"||typeof u=="symbol"||typeof u=="boolean"){n.removeAttribute(o);break}u=Ml(""+u),n.setAttribute(o,u);break;case"action":case"formAction":if(typeof u=="function"){n.setAttribute(o,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof b=="function"&&(o==="formAction"?(i!=="input"&&Zt(n,i,"name",p.name,p,null),Zt(n,i,"formEncType",p.formEncType,p,null),Zt(n,i,"formMethod",p.formMethod,p,null),Zt(n,i,"formTarget",p.formTarget,p,null)):(Zt(n,i,"encType",p.encType,p,null),Zt(n,i,"method",p.method,p,null),Zt(n,i,"target",p.target,p,null)));if(u==null||typeof u=="symbol"||typeof u=="boolean"){n.removeAttribute(o);break}u=Ml(""+u),n.setAttribute(o,u);break;case"onClick":u!=null&&(n.onclick=hi);break;case"onScroll":u!=null&&zt("scroll",n);break;case"onScrollEnd":u!=null&&zt("scrollend",n);break;case"dangerouslySetInnerHTML":if(u!=null){if(typeof u!="object"||!("__html"in u))throw Error(s(61));if(o=u.__html,o!=null){if(p.children!=null)throw Error(s(60));n.innerHTML=o}}break;case"multiple":n.multiple=u&&typeof u!="function"&&typeof u!="symbol";break;case"muted":n.muted=u&&typeof u!="function"&&typeof u!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(u==null||typeof u=="function"||typeof u=="boolean"||typeof u=="symbol"){n.removeAttribute("xlink:href");break}o=Ml(""+u),n.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",o);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":u!=null&&typeof u!="function"&&typeof u!="symbol"?n.setAttribute(o,""+u):n.removeAttribute(o);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":u&&typeof u!="function"&&typeof u!="symbol"?n.setAttribute(o,""):n.removeAttribute(o);break;case"capture":case"download":u===!0?n.setAttribute(o,""):u!==!1&&u!=null&&typeof u!="function"&&typeof u!="symbol"?n.setAttribute(o,u):n.removeAttribute(o);break;case"cols":case"rows":case"size":case"span":u!=null&&typeof u!="function"&&typeof u!="symbol"&&!isNaN(u)&&1<=u?n.setAttribute(o,u):n.removeAttribute(o);break;case"rowSpan":case"start":u==null||typeof u=="function"||typeof u=="symbol"||isNaN(u)?n.removeAttribute(o):n.setAttribute(o,u);break;case"popover":zt("beforetoggle",n),zt("toggle",n),Cl(n,"popover",u);break;case"xlinkActuate":di(n,"http://www.w3.org/1999/xlink","xlink:actuate",u);break;case"xlinkArcrole":di(n,"http://www.w3.org/1999/xlink","xlink:arcrole",u);break;case"xlinkRole":di(n,"http://www.w3.org/1999/xlink","xlink:role",u);break;case"xlinkShow":di(n,"http://www.w3.org/1999/xlink","xlink:show",u);break;case"xlinkTitle":di(n,"http://www.w3.org/1999/xlink","xlink:title",u);break;case"xlinkType":di(n,"http://www.w3.org/1999/xlink","xlink:type",u);break;case"xmlBase":di(n,"http://www.w3.org/XML/1998/namespace","xml:base",u);break;case"xmlLang":di(n,"http://www.w3.org/XML/1998/namespace","xml:lang",u);break;case"xmlSpace":di(n,"http://www.w3.org/XML/1998/namespace","xml:space",u);break;case"is":Cl(n,"is",u);break;case"innerText":case"textContent":break;default:(!(2<o.length)||o[0]!=="o"&&o[0]!=="O"||o[1]!=="n"&&o[1]!=="N")&&(o=K1.get(o)||o,Cl(n,o,u))}}function Ih(n,i,o,u,p,b){switch(o){case"style":cg(n,u,b);break;case"dangerouslySetInnerHTML":if(u!=null){if(typeof u!="object"||!("__html"in u))throw Error(s(61));if(o=u.__html,o!=null){if(p.children!=null)throw Error(s(60));n.innerHTML=o}}break;case"children":typeof u=="string"?Ta(n,u):(typeof u=="number"||typeof u=="bigint")&&Ta(n,""+u);break;case"onScroll":u!=null&&zt("scroll",n);break;case"onScrollEnd":u!=null&&zt("scrollend",n);break;case"onClick":u!=null&&(n.onclick=hi);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!tg.hasOwnProperty(o))t:{if(o[0]==="o"&&o[1]==="n"&&(p=o.endsWith("Capture"),i=o.slice(2,p?o.length-7:void 0),b=n[Ke]||null,b=b!=null?b[o]:null,typeof b=="function"&&n.removeEventListener(i,b,p),typeof u=="function")){typeof b!="function"&&b!==null&&(o in n?n[o]=null:n.hasAttribute(o)&&n.removeAttribute(o)),n.addEventListener(i,u,p);break t}o in n?n[o]=u:u===!0?n.setAttribute(o,""):Cl(n,o,u)}}}function Ie(n,i,o){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":zt("error",n),zt("load",n);var u=!1,p=!1,b;for(b in o)if(o.hasOwnProperty(b)){var A=o[b];if(A!=null)switch(b){case"src":u=!0;break;case"srcSet":p=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(s(137,i));default:Zt(n,i,b,A,o,null)}}p&&Zt(n,i,"srcSet",o.srcSet,o,null),u&&Zt(n,i,"src",o.src,o,null);return;case"input":zt("invalid",n);var M=b=A=p=null,N=null,G=null;for(u in o)if(o.hasOwnProperty(u)){var J=o[u];if(J!=null)switch(u){case"name":p=J;break;case"type":A=J;break;case"checked":N=J;break;case"defaultChecked":G=J;break;case"value":b=J;break;case"defaultValue":M=J;break;case"children":case"dangerouslySetInnerHTML":if(J!=null)throw Error(s(137,i));break;default:Zt(n,i,u,J,o,null)}}ag(n,b,M,N,G,A,p,!1);return;case"select":zt("invalid",n),u=A=b=null;for(p in o)if(o.hasOwnProperty(p)&&(M=o[p],M!=null))switch(p){case"value":b=M;break;case"defaultValue":A=M;break;case"multiple":u=M;default:Zt(n,i,p,M,o,null)}i=b,o=A,n.multiple=!!u,i!=null?Ea(n,!!u,i,!1):o!=null&&Ea(n,!!u,o,!0);return;case"textarea":zt("invalid",n),b=p=u=null;for(A in o)if(o.hasOwnProperty(A)&&(M=o[A],M!=null))switch(A){case"value":u=M;break;case"defaultValue":p=M;break;case"children":b=M;break;case"dangerouslySetInnerHTML":if(M!=null)throw Error(s(91));break;default:Zt(n,i,A,M,o,null)}og(n,u,p,b);return;case"option":for(N in o)o.hasOwnProperty(N)&&(u=o[N],u!=null)&&(N==="selected"?n.selected=u&&typeof u!="function"&&typeof u!="symbol":Zt(n,i,N,u,o,null));return;case"dialog":zt("beforetoggle",n),zt("toggle",n),zt("cancel",n),zt("close",n);break;case"iframe":case"object":zt("load",n);break;case"video":case"audio":for(u=0;u<Mo.length;u++)zt(Mo[u],n);break;case"image":zt("error",n),zt("load",n);break;case"details":zt("toggle",n);break;case"embed":case"source":case"link":zt("error",n),zt("load",n);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(G in o)if(o.hasOwnProperty(G)&&(u=o[G],u!=null))switch(G){case"children":case"dangerouslySetInnerHTML":throw Error(s(137,i));default:Zt(n,i,G,u,o,null)}return;default:if(Ju(i)){for(J in o)o.hasOwnProperty(J)&&(u=o[J],u!==void 0&&Ih(n,i,J,u,o,void 0));return}}for(M in o)o.hasOwnProperty(M)&&(u=o[M],u!=null&&Zt(n,i,M,u,o,null))}function Ew(n,i,o,u){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var p=null,b=null,A=null,M=null,N=null,G=null,J=null;for(Q in o){var it=o[Q];if(o.hasOwnProperty(Q)&&it!=null)switch(Q){case"checked":break;case"value":break;case"defaultValue":N=it;default:u.hasOwnProperty(Q)||Zt(n,i,Q,null,u,it)}}for(var Y in u){var Q=u[Y];if(it=o[Y],u.hasOwnProperty(Y)&&(Q!=null||it!=null))switch(Y){case"type":b=Q;break;case"name":p=Q;break;case"checked":G=Q;break;case"defaultChecked":J=Q;break;case"value":A=Q;break;case"defaultValue":M=Q;break;case"children":case"dangerouslySetInnerHTML":if(Q!=null)throw Error(s(137,i));break;default:Q!==it&&Zt(n,i,Y,Q,u,it)}}Ku(n,A,M,N,G,J,b,p);return;case"select":Q=A=M=Y=null;for(b in o)if(N=o[b],o.hasOwnProperty(b)&&N!=null)switch(b){case"value":break;case"multiple":Q=N;default:u.hasOwnProperty(b)||Zt(n,i,b,null,u,N)}for(p in u)if(b=u[p],N=o[p],u.hasOwnProperty(p)&&(b!=null||N!=null))switch(p){case"value":Y=b;break;case"defaultValue":M=b;break;case"multiple":A=b;default:b!==N&&Zt(n,i,p,b,u,N)}i=M,o=A,u=Q,Y!=null?Ea(n,!!o,Y,!1):!!u!=!!o&&(i!=null?Ea(n,!!o,i,!0):Ea(n,!!o,o?[]:"",!1));return;case"textarea":Q=Y=null;for(M in o)if(p=o[M],o.hasOwnProperty(M)&&p!=null&&!u.hasOwnProperty(M))switch(M){case"value":break;case"children":break;default:Zt(n,i,M,null,u,p)}for(A in u)if(p=u[A],b=o[A],u.hasOwnProperty(A)&&(p!=null||b!=null))switch(A){case"value":Y=p;break;case"defaultValue":Q=p;break;case"children":break;case"dangerouslySetInnerHTML":if(p!=null)throw Error(s(91));break;default:p!==b&&Zt(n,i,A,p,u,b)}rg(n,Y,Q);return;case"option":for(var mt in o)Y=o[mt],o.hasOwnProperty(mt)&&Y!=null&&!u.hasOwnProperty(mt)&&(mt==="selected"?n.selected=!1:Zt(n,i,mt,null,u,Y));for(N in u)Y=u[N],Q=o[N],u.hasOwnProperty(N)&&Y!==Q&&(Y!=null||Q!=null)&&(N==="selected"?n.selected=Y&&typeof Y!="function"&&typeof Y!="symbol":Zt(n,i,N,Y,u,Q));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var Tt in o)Y=o[Tt],o.hasOwnProperty(Tt)&&Y!=null&&!u.hasOwnProperty(Tt)&&Zt(n,i,Tt,null,u,Y);for(G in u)if(Y=u[G],Q=o[G],u.hasOwnProperty(G)&&Y!==Q&&(Y!=null||Q!=null))switch(G){case"children":case"dangerouslySetInnerHTML":if(Y!=null)throw Error(s(137,i));break;default:Zt(n,i,G,Y,u,Q)}return;default:if(Ju(i)){for(var Jt in o)Y=o[Jt],o.hasOwnProperty(Jt)&&Y!==void 0&&!u.hasOwnProperty(Jt)&&Ih(n,i,Jt,void 0,u,Y);for(J in u)Y=u[J],Q=o[J],!u.hasOwnProperty(J)||Y===Q||Y===void 0&&Q===void 0||Ih(n,i,J,Y,u,Q);return}}for(var $ in o)Y=o[$],o.hasOwnProperty($)&&Y!=null&&!u.hasOwnProperty($)&&Zt(n,i,$,null,u,Y);for(it in u)Y=u[it],Q=o[it],!u.hasOwnProperty(it)||Y===Q||Y==null&&Q==null||Zt(n,i,it,Y,u,Q)}function ub(n){switch(n){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function Tw(){if(typeof performance.getEntriesByType=="function"){for(var n=0,i=0,o=performance.getEntriesByType("resource"),u=0;u<o.length;u++){var p=o[u],b=p.transferSize,A=p.initiatorType,M=p.duration;if(b&&M&&ub(A)){for(A=0,M=p.responseEnd,u+=1;u<o.length;u++){var N=o[u],G=N.startTime;if(G>M)break;var J=N.transferSize,it=N.initiatorType;J&&ub(it)&&(N=N.responseEnd,A+=J*(N<M?1:(M-G)/(N-G)))}if(--u,i+=8*(b+A)/(p.duration/1e3),n++,10<n)break}}if(0<n)return i/n/1e6}return navigator.connection&&(n=navigator.connection.downlink,typeof n=="number")?n:5}var Fh=null,$h=null;function Ec(n){return n.nodeType===9?n:n.ownerDocument}function db(n){switch(n){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function hb(n,i){if(n===0)switch(i){case"svg":return 1;case"math":return 2;default:return 0}return n===1&&i==="foreignObject"?0:n}function Hh(n,i){return n==="textarea"||n==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.children=="bigint"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Uh=null;function Cw(){var n=window.event;return n&&n.type==="popstate"?n===Uh?!1:(Uh=n,!0):(Uh=null,!1)}var fb=typeof setTimeout=="function"?setTimeout:void 0,_w=typeof clearTimeout=="function"?clearTimeout:void 0,pb=typeof Promise=="function"?Promise:void 0,kw=typeof queueMicrotask=="function"?queueMicrotask:typeof pb<"u"?function(n){return pb.resolve(null).then(n).catch(Mw)}:fb;function Mw(n){setTimeout(function(){throw n})}function ss(n){return n==="head"}function gb(n,i){var o=i,u=0;do{var p=o.nextSibling;if(n.removeChild(o),p&&p.nodeType===8)if(o=p.data,o==="/$"||o==="/&"){if(u===0){n.removeChild(p),nr(i);return}u--}else if(o==="$"||o==="$?"||o==="$~"||o==="$!"||o==="&")u++;else if(o==="html")Ro(n.ownerDocument.documentElement);else if(o==="head"){o=n.ownerDocument.head,Ro(o);for(var b=o.firstChild;b;){var A=b.nextSibling,M=b.nodeName;b[Xr]||M==="SCRIPT"||M==="STYLE"||M==="LINK"&&b.rel.toLowerCase()==="stylesheet"||o.removeChild(b),b=A}}else o==="body"&&Ro(n.ownerDocument.body);o=p}while(o);nr(i)}function mb(n,i){var o=n;n=0;do{var u=o.nextSibling;if(o.nodeType===1?i?(o._stashedDisplay=o.style.display,o.style.display="none"):(o.style.display=o._stashedDisplay||"",o.getAttribute("style")===""&&o.removeAttribute("style")):o.nodeType===3&&(i?(o._stashedText=o.nodeValue,o.nodeValue=""):o.nodeValue=o._stashedText||""),u&&u.nodeType===8)if(o=u.data,o==="/$"){if(n===0)break;n--}else o!=="$"&&o!=="$?"&&o!=="$~"&&o!=="$!"||n++;o=u}while(o)}function Gh(n){var i=n.firstChild;for(i&&i.nodeType===10&&(i=i.nextSibling);i;){var o=i;switch(i=i.nextSibling,o.nodeName){case"HTML":case"HEAD":case"BODY":Gh(o),Wu(o);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(o.rel.toLowerCase()==="stylesheet")continue}n.removeChild(o)}}function Dw(n,i,o,u){for(;n.nodeType===1;){var p=o;if(n.nodeName.toLowerCase()!==i.toLowerCase()){if(!u&&(n.nodeName!=="INPUT"||n.type!=="hidden"))break}else if(u){if(!n[Xr])switch(i){case"meta":if(!n.hasAttribute("itemprop"))break;return n;case"link":if(b=n.getAttribute("rel"),b==="stylesheet"&&n.hasAttribute("data-precedence"))break;if(b!==p.rel||n.getAttribute("href")!==(p.href==null||p.href===""?null:p.href)||n.getAttribute("crossorigin")!==(p.crossOrigin==null?null:p.crossOrigin)||n.getAttribute("title")!==(p.title==null?null:p.title))break;return n;case"style":if(n.hasAttribute("data-precedence"))break;return n;case"script":if(b=n.getAttribute("src"),(b!==(p.src==null?null:p.src)||n.getAttribute("type")!==(p.type==null?null:p.type)||n.getAttribute("crossorigin")!==(p.crossOrigin==null?null:p.crossOrigin))&&b&&n.hasAttribute("async")&&!n.hasAttribute("itemprop"))break;return n;default:return n}}else if(i==="input"&&n.type==="hidden"){var b=p.name==null?null:""+p.name;if(p.type==="hidden"&&n.getAttribute("name")===b)return n}else return n;if(n=On(n.nextSibling),n===null)break}return null}function Rw(n,i,o){if(i==="")return null;for(;n.nodeType!==3;)if((n.nodeType!==1||n.nodeName!=="INPUT"||n.type!=="hidden")&&!o||(n=On(n.nextSibling),n===null))return null;return n}function bb(n,i){for(;n.nodeType!==8;)if((n.nodeType!==1||n.nodeName!=="INPUT"||n.type!=="hidden")&&!i||(n=On(n.nextSibling),n===null))return null;return n}function Vh(n){return n.data==="$?"||n.data==="$~"}function qh(n){return n.data==="$!"||n.data==="$?"&&n.ownerDocument.readyState!=="loading"}function Lw(n,i){var o=n.ownerDocument;if(n.data==="$~")n._reactRetry=i;else if(n.data!=="$?"||o.readyState!=="loading")i();else{var u=function(){i(),o.removeEventListener("DOMContentLoaded",u)};o.addEventListener("DOMContentLoaded",u),n._reactRetry=u}}function On(n){for(;n!=null;n=n.nextSibling){var i=n.nodeType;if(i===1||i===3)break;if(i===8){if(i=n.data,i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"||i==="F!"||i==="F")break;if(i==="/$"||i==="/&")return null}}return n}var Yh=null;function yb(n){n=n.nextSibling;for(var i=0;n;){if(n.nodeType===8){var o=n.data;if(o==="/$"||o==="/&"){if(i===0)return On(n.nextSibling);i--}else o!=="$"&&o!=="$!"&&o!=="$?"&&o!=="$~"&&o!=="&"||i++}n=n.nextSibling}return null}function xb(n){n=n.previousSibling;for(var i=0;n;){if(n.nodeType===8){var o=n.data;if(o==="$"||o==="$!"||o==="$?"||o==="$~"||o==="&"){if(i===0)return n;i--}else o!=="/$"&&o!=="/&"||i++}n=n.previousSibling}return null}function vb(n,i,o){switch(i=Ec(o),n){case"html":if(n=i.documentElement,!n)throw Error(s(452));return n;case"head":if(n=i.head,!n)throw Error(s(453));return n;case"body":if(n=i.body,!n)throw Error(s(454));return n;default:throw Error(s(451))}}function Ro(n){for(var i=n.attributes;i.length;)n.removeAttributeNode(i[0]);Wu(n)}var jn=new Map,Ab=new Set;function Tc(n){return typeof n.getRootNode=="function"?n.getRootNode():n.nodeType===9?n:n.ownerDocument}var ki=V.d;V.d={f:Ow,r:jw,D:Nw,C:Bw,L:zw,m:Pw,X:Fw,S:Iw,M:$w};function Ow(){var n=ki.f(),i=mc();return n||i}function jw(n){var i=Aa(n);i!==null&&i.tag===5&&i.type==="form"?Pm(i):ki.r(n)}var Ja=typeof document>"u"?null:document;function wb(n,i,o){var u=Ja;if(u&&typeof i=="string"&&i){var p=Cn(i);p='link[rel="'+n+'"][href="'+p+'"]',typeof o=="string"&&(p+='[crossorigin="'+o+'"]'),Ab.has(p)||(Ab.add(p),n={rel:n,crossOrigin:o,href:i},u.querySelector(p)===null&&(i=u.createElement("link"),Ie(i,"link",n),Me(i),u.head.appendChild(i)))}}function Nw(n){ki.D(n),wb("dns-prefetch",n,null)}function Bw(n,i){ki.C(n,i),wb("preconnect",n,i)}function zw(n,i,o){ki.L(n,i,o);var u=Ja;if(u&&n&&i){var p='link[rel="preload"][as="'+Cn(i)+'"]';i==="image"&&o&&o.imageSrcSet?(p+='[imagesrcset="'+Cn(o.imageSrcSet)+'"]',typeof o.imageSizes=="string"&&(p+='[imagesizes="'+Cn(o.imageSizes)+'"]')):p+='[href="'+Cn(n)+'"]';var b=p;switch(i){case"style":b=tr(n);break;case"script":b=er(n)}jn.has(b)||(n=m({rel:"preload",href:i==="image"&&o&&o.imageSrcSet?void 0:n,as:i},o),jn.set(b,n),u.querySelector(p)!==null||i==="style"&&u.querySelector(Lo(b))||i==="script"&&u.querySelector(Oo(b))||(i=u.createElement("link"),Ie(i,"link",n),Me(i),u.head.appendChild(i)))}}function Pw(n,i){ki.m(n,i);var o=Ja;if(o&&n){var u=i&&typeof i.as=="string"?i.as:"script",p='link[rel="modulepreload"][as="'+Cn(u)+'"][href="'+Cn(n)+'"]',b=p;switch(u){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":b=er(n)}if(!jn.has(b)&&(n=m({rel:"modulepreload",href:n},i),jn.set(b,n),o.querySelector(p)===null)){switch(u){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(o.querySelector(Oo(b)))return}u=o.createElement("link"),Ie(u,"link",n),Me(u),o.head.appendChild(u)}}}function Iw(n,i,o){ki.S(n,i,o);var u=Ja;if(u&&n){var p=wa(u).hoistableStyles,b=tr(n);i=i||"default";var A=p.get(b);if(!A){var M={loading:0,preload:null};if(A=u.querySelector(Lo(b)))M.loading=5;else{n=m({rel:"stylesheet",href:n,"data-precedence":i},o),(o=jn.get(b))&&Xh(n,o);var N=A=u.createElement("link");Me(N),Ie(N,"link",n),N._p=new Promise(function(G,J){N.onload=G,N.onerror=J}),N.addEventListener("load",function(){M.loading|=1}),N.addEventListener("error",function(){M.loading|=2}),M.loading|=4,Cc(A,i,u)}A={type:"stylesheet",instance:A,count:1,state:M},p.set(b,A)}}}function Fw(n,i){ki.X(n,i);var o=Ja;if(o&&n){var u=wa(o).hoistableScripts,p=er(n),b=u.get(p);b||(b=o.querySelector(Oo(p)),b||(n=m({src:n,async:!0},i),(i=jn.get(p))&&Wh(n,i),b=o.createElement("script"),Me(b),Ie(b,"link",n),o.head.appendChild(b)),b={type:"script",instance:b,count:1,state:null},u.set(p,b))}}function $w(n,i){ki.M(n,i);var o=Ja;if(o&&n){var u=wa(o).hoistableScripts,p=er(n),b=u.get(p);b||(b=o.querySelector(Oo(p)),b||(n=m({src:n,async:!0,type:"module"},i),(i=jn.get(p))&&Wh(n,i),b=o.createElement("script"),Me(b),Ie(b,"link",n),o.head.appendChild(b)),b={type:"script",instance:b,count:1,state:null},u.set(p,b))}}function Sb(n,i,o,u){var p=(p=ot.current)?Tc(p):null;if(!p)throw Error(s(446));switch(n){case"meta":case"title":return null;case"style":return typeof o.precedence=="string"&&typeof o.href=="string"?(i=tr(o.href),o=wa(p).hoistableStyles,u=o.get(i),u||(u={type:"style",instance:null,count:0,state:null},o.set(i,u)),u):{type:"void",instance:null,count:0,state:null};case"link":if(o.rel==="stylesheet"&&typeof o.href=="string"&&typeof o.precedence=="string"){n=tr(o.href);var b=wa(p).hoistableStyles,A=b.get(n);if(A||(p=p.ownerDocument||p,A={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},b.set(n,A),(b=p.querySelector(Lo(n)))&&!b._p&&(A.instance=b,A.state.loading=5),jn.has(n)||(o={rel:"preload",as:"style",href:o.href,crossOrigin:o.crossOrigin,integrity:o.integrity,media:o.media,hrefLang:o.hrefLang,referrerPolicy:o.referrerPolicy},jn.set(n,o),b||Hw(p,n,o,A.state))),i&&u===null)throw Error(s(528,""));return A}if(i&&u!==null)throw Error(s(529,""));return null;case"script":return i=o.async,o=o.src,typeof o=="string"&&i&&typeof i!="function"&&typeof i!="symbol"?(i=er(o),o=wa(p).hoistableScripts,u=o.get(i),u||(u={type:"script",instance:null,count:0,state:null},o.set(i,u)),u):{type:"void",instance:null,count:0,state:null};default:throw Error(s(444,n))}}function tr(n){return'href="'+Cn(n)+'"'}function Lo(n){return'link[rel="stylesheet"]['+n+"]"}function Eb(n){return m({},n,{"data-precedence":n.precedence,precedence:null})}function Hw(n,i,o,u){n.querySelector('link[rel="preload"][as="style"]['+i+"]")?u.loading=1:(i=n.createElement("link"),u.preload=i,i.addEventListener("load",function(){return u.loading|=1}),i.addEventListener("error",function(){return u.loading|=2}),Ie(i,"link",o),Me(i),n.head.appendChild(i))}function er(n){return'[src="'+Cn(n)+'"]'}function Oo(n){return"script[async]"+n}function Tb(n,i,o){if(i.count++,i.instance===null)switch(i.type){case"style":var u=n.querySelector('style[data-href~="'+Cn(o.href)+'"]');if(u)return i.instance=u,Me(u),u;var p=m({},o,{"data-href":o.href,"data-precedence":o.precedence,href:null,precedence:null});return u=(n.ownerDocument||n).createElement("style"),Me(u),Ie(u,"style",p),Cc(u,o.precedence,n),i.instance=u;case"stylesheet":p=tr(o.href);var b=n.querySelector(Lo(p));if(b)return i.state.loading|=4,i.instance=b,Me(b),b;u=Eb(o),(p=jn.get(p))&&Xh(u,p),b=(n.ownerDocument||n).createElement("link"),Me(b);var A=b;return A._p=new Promise(function(M,N){A.onload=M,A.onerror=N}),Ie(b,"link",u),i.state.loading|=4,Cc(b,o.precedence,n),i.instance=b;case"script":return b=er(o.src),(p=n.querySelector(Oo(b)))?(i.instance=p,Me(p),p):(u=o,(p=jn.get(b))&&(u=m({},o),Wh(u,p)),n=n.ownerDocument||n,p=n.createElement("script"),Me(p),Ie(p,"link",u),n.head.appendChild(p),i.instance=p);case"void":return null;default:throw Error(s(443,i.type))}else i.type==="stylesheet"&&(i.state.loading&4)===0&&(u=i.instance,i.state.loading|=4,Cc(u,o.precedence,n));return i.instance}function Cc(n,i,o){for(var u=o.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),p=u.length?u[u.length-1]:null,b=p,A=0;A<u.length;A++){var M=u[A];if(M.dataset.precedence===i)b=M;else if(b!==p)break}b?b.parentNode.insertBefore(n,b.nextSibling):(i=o.nodeType===9?o.head:o,i.insertBefore(n,i.firstChild))}function Xh(n,i){n.crossOrigin==null&&(n.crossOrigin=i.crossOrigin),n.referrerPolicy==null&&(n.referrerPolicy=i.referrerPolicy),n.title==null&&(n.title=i.title)}function Wh(n,i){n.crossOrigin==null&&(n.crossOrigin=i.crossOrigin),n.referrerPolicy==null&&(n.referrerPolicy=i.referrerPolicy),n.integrity==null&&(n.integrity=i.integrity)}var _c=null;function Cb(n,i,o){if(_c===null){var u=new Map,p=_c=new Map;p.set(o,u)}else p=_c,u=p.get(o),u||(u=new Map,p.set(o,u));if(u.has(n))return u;for(u.set(n,null),o=o.getElementsByTagName(n),p=0;p<o.length;p++){var b=o[p];if(!(b[Xr]||b[Ne]||n==="link"&&b.getAttribute("rel")==="stylesheet")&&b.namespaceURI!=="http://www.w3.org/2000/svg"){var A=b.getAttribute(i)||"";A=n+A;var M=u.get(A);M?M.push(b):u.set(A,[b])}}return u}function _b(n,i,o){n=n.ownerDocument||n,n.head.insertBefore(o,i==="title"?n.querySelector("head > title"):null)}function Uw(n,i,o){if(o===1||i.itemProp!=null)return!1;switch(n){case"meta":case"title":return!0;case"style":if(typeof i.precedence!="string"||typeof i.href!="string"||i.href==="")break;return!0;case"link":if(typeof i.rel!="string"||typeof i.href!="string"||i.href===""||i.onLoad||i.onError)break;return i.rel==="stylesheet"?(n=i.disabled,typeof i.precedence=="string"&&n==null):!0;case"script":if(i.async&&typeof i.async!="function"&&typeof i.async!="symbol"&&!i.onLoad&&!i.onError&&i.src&&typeof i.src=="string")return!0}return!1}function kb(n){return!(n.type==="stylesheet"&&(n.state.loading&3)===0)}function Gw(n,i,o,u){if(o.type==="stylesheet"&&(typeof u.media!="string"||matchMedia(u.media).matches!==!1)&&(o.state.loading&4)===0){if(o.instance===null){var p=tr(u.href),b=i.querySelector(Lo(p));if(b){i=b._p,i!==null&&typeof i=="object"&&typeof i.then=="function"&&(n.count++,n=kc.bind(n),i.then(n,n)),o.state.loading|=4,o.instance=b,Me(b);return}b=i.ownerDocument||i,u=Eb(u),(p=jn.get(p))&&Xh(u,p),b=b.createElement("link"),Me(b);var A=b;A._p=new Promise(function(M,N){A.onload=M,A.onerror=N}),Ie(b,"link",u),o.instance=b}n.stylesheets===null&&(n.stylesheets=new Map),n.stylesheets.set(o,i),(i=o.state.preload)&&(o.state.loading&3)===0&&(n.count++,o=kc.bind(n),i.addEventListener("load",o),i.addEventListener("error",o))}}var Qh=0;function Vw(n,i){return n.stylesheets&&n.count===0&&Dc(n,n.stylesheets),0<n.count||0<n.imgCount?function(o){var u=setTimeout(function(){if(n.stylesheets&&Dc(n,n.stylesheets),n.unsuspend){var b=n.unsuspend;n.unsuspend=null,b()}},6e4+i);0<n.imgBytes&&Qh===0&&(Qh=62500*Tw());var p=setTimeout(function(){if(n.waitingForImages=!1,n.count===0&&(n.stylesheets&&Dc(n,n.stylesheets),n.unsuspend)){var b=n.unsuspend;n.unsuspend=null,b()}},(n.imgBytes>Qh?50:800)+i);return n.unsuspend=o,function(){n.unsuspend=null,clearTimeout(u),clearTimeout(p)}}:null}function kc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Dc(this,this.stylesheets);else if(this.unsuspend){var n=this.unsuspend;this.unsuspend=null,n()}}}var Mc=null;function Dc(n,i){n.stylesheets=null,n.unsuspend!==null&&(n.count++,Mc=new Map,i.forEach(qw,n),Mc=null,kc.call(n))}function qw(n,i){if(!(i.state.loading&4)){var o=Mc.get(n);if(o)var u=o.get(null);else{o=new Map,Mc.set(n,o);for(var p=n.querySelectorAll("link[data-precedence],style[data-precedence]"),b=0;b<p.length;b++){var A=p[b];(A.nodeName==="LINK"||A.getAttribute("media")!=="not all")&&(o.set(A.dataset.precedence,A),u=A)}u&&o.set(null,u)}p=i.instance,A=p.getAttribute("data-precedence"),b=o.get(A)||u,b===u&&o.set(null,p),o.set(A,p),this.count++,u=kc.bind(this),p.addEventListener("load",u),p.addEventListener("error",u),b?b.parentNode.insertBefore(p,b.nextSibling):(n=n.nodeType===9?n.head:n,n.insertBefore(p,n.firstChild)),i.state.loading|=4}}var jo={$$typeof:k,Provider:null,Consumer:null,_currentValue:K,_currentValue2:K,_threadCount:0};function Yw(n,i,o,u,p,b,A,M,N){this.tag=1,this.containerInfo=n,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Vu(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Vu(0),this.hiddenUpdates=Vu(null),this.identifierPrefix=u,this.onUncaughtError=p,this.onCaughtError=b,this.onRecoverableError=A,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=N,this.incompleteTransitions=new Map}function Mb(n,i,o,u,p,b,A,M,N,G,J,it){return n=new Yw(n,i,o,A,N,G,J,it,M),i=1,b===!0&&(i|=24),b=hn(3,null,null,i),n.current=b,b.stateNode=n,i=Md(),i.refCount++,n.pooledCache=i,i.refCount++,b.memoizedState={element:u,isDehydrated:o,cache:i},Od(b),n}function Db(n){return n?(n=La,n):La}function Rb(n,i,o,u,p,b){p=Db(p),u.context===null?u.context=p:u.pendingContext=p,u=Yi(i),u.payload={element:o},b=b===void 0?null:b,b!==null&&(u.callback=b),o=Xi(n,u,i),o!==null&&(sn(o,n,i),ho(o,n,i))}function Lb(n,i){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var o=n.retryLane;n.retryLane=o!==0&&o<i?o:i}}function Kh(n,i){Lb(n,i),(n=n.alternate)&&Lb(n,i)}function Ob(n){if(n.tag===13||n.tag===31){var i=Os(n,67108864);i!==null&&sn(i,n,67108864),Kh(n,67108864)}}function jb(n){if(n.tag===13||n.tag===31){var i=bn();i=qu(i);var o=Os(n,i);o!==null&&sn(o,n,i),Kh(n,i)}}var Rc=!0;function Xw(n,i,o,u){var p=P.T;P.T=null;var b=V.p;try{V.p=2,Zh(n,i,o,u)}finally{V.p=b,P.T=p}}function Ww(n,i,o,u){var p=P.T;P.T=null;var b=V.p;try{V.p=8,Zh(n,i,o,u)}finally{V.p=b,P.T=p}}function Zh(n,i,o,u){if(Rc){var p=Jh(u);if(p===null)Ph(n,i,u,Lc,o),Bb(n,u);else if(Kw(p,n,i,o,u))u.stopPropagation();else if(Bb(n,u),i&4&&-1<Qw.indexOf(n)){for(;p!==null;){var b=Aa(p);if(b!==null)switch(b.tag){case 3:if(b=b.stateNode,b.current.memoizedState.isDehydrated){var A=ks(b.pendingLanes);if(A!==0){var M=b;for(M.pendingLanes|=2,M.entangledLanes|=2;A;){var N=1<<31-un(A);M.entanglements[1]|=N,A&=~N}Jn(b),(qt&6)===0&&(pc=Ue()+500,ko(0))}}break;case 31:case 13:M=Os(b,2),M!==null&&sn(M,b,2),mc(),Kh(b,2)}if(b=Jh(u),b===null&&Ph(n,i,u,Lc,o),b===p)break;p=b}p!==null&&u.stopPropagation()}else Ph(n,i,u,null,o)}}function Jh(n){return n=ed(n),tf(n)}var Lc=null;function tf(n){if(Lc=null,n=va(n),n!==null){var i=l(n);if(i===null)n=null;else{var o=i.tag;if(o===13){if(n=c(i),n!==null)return n;n=null}else if(o===31){if(n=d(i),n!==null)return n;n=null}else if(o===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;n=null}else i!==n&&(n=null)}}return Lc=n,null}function Nb(n){switch(n){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Gu()){case vl:return 2;case Al:return 8;case ln:case Pi:return 32;case Fn:return 268435456;default:return 32}default:return 32}}var ef=!1,as=null,rs=null,os=null,No=new Map,Bo=new Map,ls=[],Qw="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function Bb(n,i){switch(n){case"focusin":case"focusout":as=null;break;case"dragenter":case"dragleave":rs=null;break;case"mouseover":case"mouseout":os=null;break;case"pointerover":case"pointerout":No.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":Bo.delete(i.pointerId)}}function zo(n,i,o,u,p,b){return n===null||n.nativeEvent!==b?(n={blockedOn:i,domEventName:o,eventSystemFlags:u,nativeEvent:b,targetContainers:[p]},i!==null&&(i=Aa(i),i!==null&&Ob(i)),n):(n.eventSystemFlags|=u,i=n.targetContainers,p!==null&&i.indexOf(p)===-1&&i.push(p),n)}function Kw(n,i,o,u,p){switch(i){case"focusin":return as=zo(as,n,i,o,u,p),!0;case"dragenter":return rs=zo(rs,n,i,o,u,p),!0;case"mouseover":return os=zo(os,n,i,o,u,p),!0;case"pointerover":var b=p.pointerId;return No.set(b,zo(No.get(b)||null,n,i,o,u,p)),!0;case"gotpointercapture":return b=p.pointerId,Bo.set(b,zo(Bo.get(b)||null,n,i,o,u,p)),!0}return!1}function zb(n){var i=va(n.target);if(i!==null){var o=l(i);if(o!==null){if(i=o.tag,i===13){if(i=c(o),i!==null){n.blockedOn=i,Kp(n.priority,function(){jb(o)});return}}else if(i===31){if(i=d(o),i!==null){n.blockedOn=i,Kp(n.priority,function(){jb(o)});return}}else if(i===3&&o.stateNode.current.memoizedState.isDehydrated){n.blockedOn=o.tag===3?o.stateNode.containerInfo:null;return}}}n.blockedOn=null}function Oc(n){if(n.blockedOn!==null)return!1;for(var i=n.targetContainers;0<i.length;){var o=Jh(n.nativeEvent);if(o===null){o=n.nativeEvent;var u=new o.constructor(o.type,o);td=u,o.target.dispatchEvent(u),td=null}else return i=Aa(o),i!==null&&Ob(i),n.blockedOn=o,!1;i.shift()}return!0}function Pb(n,i,o){Oc(n)&&o.delete(i)}function Zw(){ef=!1,as!==null&&Oc(as)&&(as=null),rs!==null&&Oc(rs)&&(rs=null),os!==null&&Oc(os)&&(os=null),No.forEach(Pb),Bo.forEach(Pb)}function jc(n,i){n.blockedOn===i&&(n.blockedOn=null,ef||(ef=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,Zw)))}var Nc=null;function Ib(n){Nc!==n&&(Nc=n,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){Nc===n&&(Nc=null);for(var i=0;i<n.length;i+=3){var o=n[i],u=n[i+1],p=n[i+2];if(typeof u!="function"){if(tf(u||o)===null)continue;break}var b=Aa(o);b!==null&&(n.splice(i,3),i-=3,Jd(b,{pending:!0,data:p,method:o.method,action:u},u,p))}}))}function nr(n){function i(N){return jc(N,n)}as!==null&&jc(as,n),rs!==null&&jc(rs,n),os!==null&&jc(os,n),No.forEach(i),Bo.forEach(i);for(var o=0;o<ls.length;o++){var u=ls[o];u.blockedOn===n&&(u.blockedOn=null)}for(;0<ls.length&&(o=ls[0],o.blockedOn===null);)zb(o),o.blockedOn===null&&ls.shift();if(o=(n.ownerDocument||n).$$reactFormReplay,o!=null)for(u=0;u<o.length;u+=3){var p=o[u],b=o[u+1],A=p[Ke]||null;if(typeof b=="function")A||Ib(o);else if(A){var M=null;if(b&&b.hasAttribute("formAction")){if(p=b,A=b[Ke]||null)M=A.formAction;else if(tf(p)!==null)continue}else M=A.action;typeof M=="function"?o[u+1]=M:(o.splice(u,3),u-=3),Ib(o)}}}function Fb(){function n(b){b.canIntercept&&b.info==="react-transition"&&b.intercept({handler:function(){return new Promise(function(A){return p=A})},focusReset:"manual",scroll:"manual"})}function i(){p!==null&&(p(),p=null),u||setTimeout(o,20)}function o(){if(!u&&!navigation.transition){var b=navigation.currentEntry;b&&b.url!=null&&navigation.navigate(b.url,{state:b.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var u=!1,p=null;return navigation.addEventListener("navigate",n),navigation.addEventListener("navigatesuccess",i),navigation.addEventListener("navigateerror",i),setTimeout(o,100),function(){u=!0,navigation.removeEventListener("navigate",n),navigation.removeEventListener("navigatesuccess",i),navigation.removeEventListener("navigateerror",i),p!==null&&(p(),p=null)}}}function nf(n){this._internalRoot=n}Bc.prototype.render=nf.prototype.render=function(n){var i=this._internalRoot;if(i===null)throw Error(s(409));var o=i.current,u=bn();Rb(o,u,n,i,null,null)},Bc.prototype.unmount=nf.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var i=n.containerInfo;Rb(n.current,2,null,n,null,null),mc(),i[xa]=null}};function Bc(n){this._internalRoot=n}Bc.prototype.unstable_scheduleHydration=function(n){if(n){var i=Qp();n={blockedOn:null,target:n,priority:i};for(var o=0;o<ls.length&&i!==0&&i<ls[o].priority;o++);ls.splice(o,0,n),o===0&&zb(n)}};var $b=t.version;if($b!=="19.2.3")throw Error(s(527,$b,"19.2.3"));V.findDOMNode=function(n){var i=n._reactInternals;if(i===void 0)throw typeof n.render=="function"?Error(s(188)):(n=Object.keys(n).join(","),Error(s(268,n)));return n=f(i),n=n!==null?g(n):null,n=n===null?null:n.stateNode,n};var Jw={bundleType:0,version:"19.2.3",rendererPackageName:"react-dom",currentDispatcherRef:P,reconcilerVersion:"19.2.3"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var zc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!zc.isDisabled&&zc.supportsFiber)try{Vr=zc.inject(Jw),cn=zc}catch{}}return Io.createRoot=function(n,i){if(!a(n))throw Error(s(299));var o=!1,u="",p=Xm,b=Wm,A=Qm;return i!=null&&(i.unstable_strictMode===!0&&(o=!0),i.identifierPrefix!==void 0&&(u=i.identifierPrefix),i.onUncaughtError!==void 0&&(p=i.onUncaughtError),i.onCaughtError!==void 0&&(b=i.onCaughtError),i.onRecoverableError!==void 0&&(A=i.onRecoverableError)),i=Mb(n,1,!1,null,null,o,u,null,p,b,A,Fb),n[xa]=i.current,zh(n),new nf(i)},Io.hydrateRoot=function(n,i,o){if(!a(n))throw Error(s(299));var u=!1,p="",b=Xm,A=Wm,M=Qm,N=null;return o!=null&&(o.unstable_strictMode===!0&&(u=!0),o.identifierPrefix!==void 0&&(p=o.identifierPrefix),o.onUncaughtError!==void 0&&(b=o.onUncaughtError),o.onCaughtError!==void 0&&(A=o.onCaughtError),o.onRecoverableError!==void 0&&(M=o.onRecoverableError),o.formState!==void 0&&(N=o.formState)),i=Mb(n,1,!0,i,o??null,u,p,N,b,A,M,Fb),i.context=Db(null),o=i.current,u=bn(),u=qu(u),p=Yi(u),p.callback=null,Xi(o,p,u),o=u,i.current.lanes=o,Yr(i,o),Jn(i),n[xa]=i.current,zh(n),new Bc(i)},Io.version="19.2.3",Io}var Jb;function lS(){if(Jb)return of.exports;Jb=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),of.exports=oS(),of.exports}var cS=lS(),Oe=function(){return Oe=Object.assign||function(t){for(var e,s=1,a=arguments.length;s<a;s++){e=arguments[s];for(var l in e)Object.prototype.hasOwnProperty.call(e,l)&&(t[l]=e[l])}return t},Oe.apply(this,arguments)};function Or(r,t,e){if(e||arguments.length===2)for(var s=0,a=t.length,l;s<a;s++)(l||!(s in t))&&(l||(l=Array.prototype.slice.call(t,0,s)),l[s]=t[s]);return r.concat(l||Array.prototype.slice.call(t))}var re="-ms-",Ko="-moz-",Yt="-webkit-",qx="comm",Cu="rule",cp="decl",uS="@import",dS="@namespace",Yx="@keyframes",hS="@layer",Xx=Math.abs,up=String.fromCharCode,Bf=Object.assign;function fS(r,t){return ke(r,0)^45?(((t<<2^ke(r,0))<<2^ke(r,1))<<2^ke(r,2))<<2^ke(r,3):0}function Wx(r){return r.trim()}function ji(r,t){return(r=t.exec(r))?r[0]:r}function Nt(r,t,e){return r.replace(t,e)}function ou(r,t,e){return r.indexOf(t,e)}function ke(r,t){return r.charCodeAt(t)|0}function oa(r,t,e){return r.slice(t,e)}function Vn(r){return r.length}function Qx(r){return r.length}function Yo(r,t){return t.push(r),r}function pS(r,t){return r.map(t).join("")}function ty(r,t){return r.filter(function(e){return!ji(e,t)})}var _u=1,jr=1,Kx=0,Pn=0,Ce=0,$r="";function ku(r,t,e,s,a,l,c,d){return{value:r,root:t,parent:e,type:s,props:a,children:l,line:_u,column:jr,length:c,return:"",siblings:d}}function xs(r,t){return Bf(ku("",null,null,"",null,null,0,r.siblings),r,{length:-r.length},t)}function ir(r){for(;r.root;)r=xs(r.root,{children:[r]});Yo(r,r.siblings)}function gS(){return Ce}function mS(){return Ce=Pn>0?ke($r,--Pn):0,jr--,Ce===10&&(jr=1,_u--),Ce}function qn(){return Ce=Pn<Kx?ke($r,Pn++):0,jr++,Ce===10&&(jr=1,_u++),Ce}function As(){return ke($r,Pn)}function lu(){return Pn}function Mu(r,t){return oa($r,r,t)}function tl(r){switch(r){case 0:case 9:case 10:case 13:case 32:return 5;case 33:case 43:case 44:case 47:case 62:case 64:case 126:case 59:case 123:case 125:return 4;case 58:return 3;case 34:case 39:case 40:case 91:return 2;case 41:case 93:return 1}return 0}function bS(r){return _u=jr=1,Kx=Vn($r=r),Pn=0,[]}function yS(r){return $r="",r}function df(r){return Wx(Mu(Pn-1,zf(r===91?r+2:r===40?r+1:r)))}function xS(r){for(;(Ce=As())&&Ce<33;)qn();return tl(r)>2||tl(Ce)>3?"":" "}function vS(r,t){for(;--t&&qn()&&!(Ce<48||Ce>102||Ce>57&&Ce<65||Ce>70&&Ce<97););return Mu(r,lu()+(t<6&&As()==32&&qn()==32))}function zf(r){for(;qn();)switch(Ce){case r:return Pn;case 34:case 39:r!==34&&r!==39&&zf(Ce);break;case 40:r===41&&zf(r);break;case 92:qn();break}return Pn}function AS(r,t){for(;qn()&&r+Ce!==57;)if(r+Ce===84&&As()===47)break;return"/*"+Mu(t,Pn-1)+"*"+up(r===47?r:qn())}function wS(r){for(;!tl(As());)qn();return Mu(r,Pn)}function SS(r){return yS(cu("",null,null,null,[""],r=bS(r),0,[0],r))}function cu(r,t,e,s,a,l,c,d,h){for(var f=0,g=0,m=c,x=0,v=0,E=0,S=1,C=1,T=1,_=0,k="",R=a,D=l,L=s,O=k;C;)switch(E=_,_=qn()){case 40:if(E!=108&&ke(O,m-1)==58){ou(O+=Nt(df(_),"&","&\f"),"&\f",Xx(f?d[f-1]:0))!=-1&&(T=-1);break}case 34:case 39:case 91:O+=df(_);break;case 9:case 10:case 13:case 32:O+=xS(E);break;case 92:O+=vS(lu()-1,7);continue;case 47:switch(As()){case 42:case 47:Yo(ES(AS(qn(),lu()),t,e,h),h),(tl(E||1)==5||tl(As()||1)==5)&&Vn(O)&&oa(O,-1,void 0)!==" "&&(O+=" ");break;default:O+="/"}break;case 123*S:d[f++]=Vn(O)*T;case 125*S:case 59:case 0:switch(_){case 0:case 125:C=0;case 59+g:T==-1&&(O=Nt(O,/\f/g,"")),v>0&&(Vn(O)-m||S===0&&E===47)&&Yo(v>32?ny(O+";",s,e,m-1,h):ny(Nt(O," ","")+";",s,e,m-2,h),h);break;case 59:O+=";";default:if(Yo(L=ey(O,t,e,f,g,a,d,k,R=[],D=[],m,l),l),_===123)if(g===0)cu(O,t,L,L,R,l,m,d,D);else{switch(x){case 99:if(ke(O,3)===110)break;case 108:if(ke(O,2)===97)break;default:g=0;case 100:case 109:case 115:}g?cu(r,L,L,s&&Yo(ey(r,L,L,0,0,a,d,k,a,R=[],m,D),D),a,D,m,d,s?R:D):cu(O,L,L,L,[""],D,0,d,D)}}f=g=v=0,S=T=1,k=O="",m=c;break;case 58:m=1+Vn(O),v=E;default:if(S<1){if(_==123)--S;else if(_==125&&S++==0&&mS()==125)continue}switch(O+=up(_),_*S){case 38:T=g>0?1:(O+="\f",-1);break;case 44:d[f++]=(Vn(O)-1)*T,T=1;break;case 64:As()===45&&(O+=df(qn())),x=As(),g=m=Vn(k=O+=wS(lu())),_++;break;case 45:E===45&&Vn(O)==2&&(S=0)}}return l}function ey(r,t,e,s,a,l,c,d,h,f,g,m){for(var x=a-1,v=a===0?l:[""],E=Qx(v),S=0,C=0,T=0;S<s;++S)for(var _=0,k=oa(r,x+1,x=Xx(C=c[S])),R=r;_<E;++_)(R=Wx(C>0?v[_]+" "+k:Nt(k,/&\f/g,v[_])))&&(h[T++]=R);return ku(r,t,e,a===0?Cu:d,h,f,g,m)}function ES(r,t,e,s){return ku(r,t,e,qx,up(gS()),oa(r,2,-2),0,s)}function ny(r,t,e,s,a){return ku(r,t,e,cp,oa(r,0,s),oa(r,s+1,-1),s,a)}function Zx(r,t,e){switch(fS(r,t)){case 5103:return Yt+"print-"+r+r;case 5737:case 4201:case 3177:case 3433:case 1641:case 4457:case 2921:case 5572:case 6356:case 5844:case 3191:case 6645:case 3005:case 4215:case 6389:case 5109:case 5365:case 5621:case 3829:case 6391:case 5879:case 5623:case 6135:case 4599:return Yt+r+r;case 4855:return Yt+r.replace("add","source-over").replace("substract","source-out").replace("intersect","source-in").replace("exclude","xor")+r;case 4789:return Ko+r+r;case 5349:case 4246:case 4810:case 6968:case 2756:return Yt+r+Ko+r+re+r+r;case 5936:switch(ke(r,t+11)){case 114:return Yt+r+re+Nt(r,/[svh]\w+-[tblr]{2}/,"tb")+r;case 108:return Yt+r+re+Nt(r,/[svh]\w+-[tblr]{2}/,"tb-rl")+r;case 45:return Yt+r+re+Nt(r,/[svh]\w+-[tblr]{2}/,"lr")+r}case 6828:case 4268:case 2903:return Yt+r+re+r+r;case 6165:return Yt+r+re+"flex-"+r+r;case 5187:return Yt+r+Nt(r,/(\w+).+(:[^]+)/,Yt+"box-$1$2"+re+"flex-$1$2")+r;case 5443:return Yt+r+re+"flex-item-"+Nt(r,/flex-|-self/g,"")+(ji(r,/flex-|baseline/)?"":re+"grid-row-"+Nt(r,/flex-|-self/g,""))+r;case 4675:return Yt+r+re+"flex-line-pack"+Nt(r,/align-content|flex-|-self/g,"")+r;case 5548:return Yt+r+re+Nt(r,"shrink","negative")+r;case 5292:return Yt+r+re+Nt(r,"basis","preferred-size")+r;case 6060:return Yt+"box-"+Nt(r,"-grow","")+Yt+r+re+Nt(r,"grow","positive")+r;case 4554:return Yt+Nt(r,/([^-])(transform)/g,"$1"+Yt+"$2")+r;case 6187:return Nt(Nt(Nt(r,/(zoom-|grab)/,Yt+"$1"),/(image-set)/,Yt+"$1"),r,"")+r;case 5495:case 3959:return Nt(r,/(image-set\([^]*)/,Yt+"$1$`$1");case 4968:return Nt(Nt(r,/(.+:)(flex-)?(.*)/,Yt+"box-pack:$3"+re+"flex-pack:$3"),/space-between/,"justify")+Yt+r+r;case 4200:if(!ji(r,/flex-|baseline/))return re+"grid-column-align"+oa(r,t)+r;break;case 2592:case 3360:return re+Nt(r,"template-","")+r;case 4384:case 3616:return e&&e.some(function(s,a){return t=a,ji(s.props,/grid-\w+-end/)})?~ou(r+(e=e[t].value),"span",0)?r:re+Nt(r,"-start","")+r+re+"grid-row-span:"+(~ou(e,"span",0)?ji(e,/\d+/):+ji(e,/\d+/)-+ji(r,/\d+/))+";":re+Nt(r,"-start","")+r;case 4896:case 4128:return e&&e.some(function(s){return ji(s.props,/grid-\w+-start/)})?r:re+Nt(Nt(r,"-end","-span"),"span ","")+r;case 4095:case 3583:case 4068:case 2532:return Nt(r,/(.+)-inline(.+)/,Yt+"$1$2")+r;case 8116:case 7059:case 5753:case 5535:case 5445:case 5701:case 4933:case 4677:case 5533:case 5789:case 5021:case 4765:if(Vn(r)-1-t>6)switch(ke(r,t+1)){case 109:if(ke(r,t+4)!==45)break;case 102:return Nt(r,/(.+:)(.+)-([^]+)/,"$1"+Yt+"$2-$3$1"+Ko+(ke(r,t+3)==108?"$3":"$2-$3"))+r;case 115:return~ou(r,"stretch",0)?Zx(Nt(r,"stretch","fill-available"),t,e)+r:r}break;case 5152:case 5920:return Nt(r,/(.+?):(\d+)(\s*\/\s*(span)?\s*(\d+))?(.*)/,function(s,a,l,c,d,h,f){return re+a+":"+l+f+(c?re+a+"-span:"+(d?h:+h-+l)+f:"")+r});case 4949:if(ke(r,t+6)===121)return Nt(r,":",":"+Yt)+r;break;case 6444:switch(ke(r,ke(r,14)===45?18:11)){case 120:return Nt(r,/(.+:)([^;\s!]+)(;|(\s+)?!.+)?/,"$1"+Yt+(ke(r,14)===45?"inline-":"")+"box$3$1"+Yt+"$2$3$1"+re+"$2box$3")+r;case 100:return Nt(r,":",":"+re)+r}break;case 5719:case 2647:case 2135:case 3927:case 2391:return Nt(r,"scroll-","scroll-snap-")+r}return r}function pu(r,t){for(var e="",s=0;s<r.length;s++)e+=t(r[s],s,r,t)||"";return e}function TS(r,t,e,s){switch(r.type){case hS:if(r.children.length)break;case uS:case dS:case cp:return r.return=r.return||r.value;case qx:return"";case Yx:return r.return=r.value+"{"+pu(r.children,s)+"}";case Cu:if(!Vn(r.value=r.props.join(",")))return""}return Vn(e=pu(r.children,s))?r.return=r.value+"{"+e+"}":""}function CS(r){var t=Qx(r);return function(e,s,a,l){for(var c="",d=0;d<t;d++)c+=r[d](e,s,a,l)||"";return c}}function _S(r){return function(t){t.root||(t=t.return)&&r(t)}}function kS(r,t,e,s){if(r.length>-1&&!r.return)switch(r.type){case cp:r.return=Zx(r.value,r.length,e);return;case Yx:return pu([xs(r,{value:Nt(r.value,"@","@"+Yt)})],s);case Cu:if(r.length)return pS(e=r.props,function(a){switch(ji(a,s=/(::plac\w+|:read-\w+)/)){case":read-only":case":read-write":ir(xs(r,{props:[Nt(a,/:(read-\w+)/,":"+Ko+"$1")]})),ir(xs(r,{props:[a]})),Bf(r,{props:ty(e,s)});break;case"::placeholder":ir(xs(r,{props:[Nt(a,/:(plac\w+)/,":"+Yt+"input-$1")]})),ir(xs(r,{props:[Nt(a,/:(plac\w+)/,":"+Ko+"$1")]})),ir(xs(r,{props:[Nt(a,/:(plac\w+)/,re+"input-$1")]})),ir(xs(r,{props:[a]})),Bf(r,{props:ty(e,s)});break}return""})}}var MS={animationIterationCount:1,aspectRatio:1,borderImageOutset:1,borderImageSlice:1,borderImageWidth:1,boxFlex:1,boxFlexGroup:1,boxOrdinalGroup:1,columnCount:1,columns:1,flex:1,flexGrow:1,flexPositive:1,flexShrink:1,flexNegative:1,flexOrder:1,gridRow:1,gridRowEnd:1,gridRowSpan:1,gridRowStart:1,gridColumn:1,gridColumnEnd:1,gridColumnSpan:1,gridColumnStart:1,msGridRow:1,msGridRowSpan:1,msGridColumn:1,msGridColumnSpan:1,fontWeight:1,lineHeight:1,opacity:1,order:1,orphans:1,scale:1,tabSize:1,widows:1,zIndex:1,zoom:1,WebkitLineClamp:1,fillOpacity:1,floodOpacity:1,stopOpacity:1,strokeDasharray:1,strokeDashoffset:1,strokeMiterlimit:1,strokeOpacity:1,strokeWidth:1},yn={},Nr=typeof process<"u"&&yn!==void 0&&(yn.REACT_APP_SC_ATTR||yn.SC_ATTR)||"data-styled",Jx="active",tv="data-styled-version",Du="6.3.5",dp=`/*!sc*/
`,gu=typeof window<"u"&&typeof document<"u",Es=X.createContext===void 0,DS=!!(typeof SC_DISABLE_SPEEDY=="boolean"?SC_DISABLE_SPEEDY:typeof process<"u"&&yn!==void 0&&yn.REACT_APP_SC_DISABLE_SPEEDY!==void 0&&yn.REACT_APP_SC_DISABLE_SPEEDY!==""?yn.REACT_APP_SC_DISABLE_SPEEDY!=="false"&&yn.REACT_APP_SC_DISABLE_SPEEDY:typeof process<"u"&&yn!==void 0&&yn.SC_DISABLE_SPEEDY!==void 0&&yn.SC_DISABLE_SPEEDY!==""&&yn.SC_DISABLE_SPEEDY!=="false"&&yn.SC_DISABLE_SPEEDY),RS={},Ru=Object.freeze([]),Br=Object.freeze({});function ev(r,t,e){return e===void 0&&(e=Br),r.theme!==e.theme&&r.theme||t||e.theme}var nv=new Set(["a","abbr","address","area","article","aside","audio","b","bdi","bdo","blockquote","body","button","canvas","caption","cite","code","col","colgroup","data","datalist","dd","del","details","dfn","dialog","div","dl","dt","em","embed","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","html","i","iframe","img","input","ins","kbd","label","legend","li","main","map","mark","menu","meter","nav","object","ol","optgroup","option","output","p","picture","pre","progress","q","rp","rt","ruby","s","samp","search","section","select","slot","small","span","strong","sub","summary","sup","table","tbody","td","template","textarea","tfoot","th","thead","time","tr","u","ul","var","video","wbr","circle","clipPath","defs","ellipse","feBlend","feColorMatrix","feComponentTransfer","feComposite","feConvolveMatrix","feDiffuseLighting","feDisplacementMap","feDistantLight","feDropShadow","feFlood","feFuncA","feFuncB","feFuncG","feFuncR","feGaussianBlur","feImage","feMerge","feMergeNode","feMorphology","feOffset","fePointLight","feSpecularLighting","feSpotLight","feTile","feTurbulence","filter","foreignObject","g","image","line","linearGradient","marker","mask","path","pattern","polygon","polyline","radialGradient","rect","stop","svg","switch","symbol","text","textPath","tspan","use"]),LS=/[!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~-]+/g,OS=/(^-|-$)/g;function iy(r){return r.replace(LS,"-").replace(OS,"")}var jS=/(a)(d)/gi,sy=function(r){return String.fromCharCode(r+(r>25?39:97))};function mu(r){var t,e="";for(t=Math.abs(r);t>52;t=t/52|0)e=sy(t%52)+e;return(sy(t%52)+e).replace(jS,"$1-$2")}var hf,Ar=function(r,t){for(var e=t.length;e;)r=33*r^t.charCodeAt(--e);return r},hp=function(r){return Ar(5381,r)};function fp(r){return mu(hp(r)>>>0)}function NS(r){return r.displayName||r.name||"Component"}function ff(r){return typeof r=="string"&&!0}var iv=typeof Symbol=="function"&&Symbol.for,sv=iv?Symbol.for("react.memo"):60115,BS=iv?Symbol.for("react.forward_ref"):60112,zS={childContextTypes:!0,contextType:!0,contextTypes:!0,defaultProps:!0,displayName:!0,getDefaultProps:!0,getDerivedStateFromError:!0,getDerivedStateFromProps:!0,mixins:!0,propTypes:!0,type:!0},PS={name:!0,length:!0,prototype:!0,caller:!0,callee:!0,arguments:!0,arity:!0},av={$$typeof:!0,compare:!0,defaultProps:!0,displayName:!0,propTypes:!0,type:!0},IS=((hf={})[BS]={$$typeof:!0,render:!0,defaultProps:!0,displayName:!0,propTypes:!0},hf[sv]=av,hf);function ay(r){return("type"in(t=r)&&t.type.$$typeof)===sv?av:"$$typeof"in r?IS[r.$$typeof]:zS;var t}var FS=Object.defineProperty,$S=Object.getOwnPropertyNames,ry=Object.getOwnPropertySymbols,HS=Object.getOwnPropertyDescriptor,US=Object.getPrototypeOf,oy=Object.prototype;function rv(r,t,e){if(typeof t!="string"){if(oy){var s=US(t);s&&s!==oy&&rv(r,s,e)}var a=$S(t);ry&&(a=a.concat(ry(t)));for(var l=ay(r),c=ay(t),d=0;d<a.length;++d){var h=a[d];if(!(h in PS||e&&e[h]||c&&h in c||l&&h in l)){var f=HS(t,h);try{FS(r,h,f)}catch{}}}}return r}function la(r){return typeof r=="function"}function pp(r){return typeof r=="object"&&"styledComponentId"in r}function Js(r,t){return r&&t?"".concat(r," ").concat(t):r||t||""}function bu(r,t){if(r.length===0)return"";for(var e=r[0],s=1;s<r.length;s++)e+=r[s];return e}function el(r){return r!==null&&typeof r=="object"&&r.constructor.name===Object.name&&!("props"in r&&r.$$typeof)}function Pf(r,t,e){if(e===void 0&&(e=!1),!e&&!el(r)&&!Array.isArray(r))return t;if(Array.isArray(t))for(var s=0;s<t.length;s++)r[s]=Pf(r[s],t[s]);else if(el(t))for(var s in t)r[s]=Pf(r[s],t[s]);return r}function gp(r,t){Object.defineProperty(r,"toString",{value:t})}function ca(r){for(var t=[],e=1;e<arguments.length;e++)t[e-1]=arguments[e];return new Error("An error occurred. See https://github.com/styled-components/styled-components/blob/main/packages/styled-components/src/utils/errors.md#".concat(r," for more information.").concat(t.length>0?" Args: ".concat(t.join(", ")):""))}var GS=(function(){function r(t){this.groupSizes=new Uint32Array(512),this.length=512,this.tag=t}return r.prototype.indexOfGroup=function(t){for(var e=0,s=0;s<t;s++)e+=this.groupSizes[s];return e},r.prototype.insertRules=function(t,e){if(t>=this.groupSizes.length){for(var s=this.groupSizes,a=s.length,l=a;t>=l;)if((l<<=1)<0)throw ca(16,"".concat(t));this.groupSizes=new Uint32Array(l),this.groupSizes.set(s),this.length=l;for(var c=a;c<l;c++)this.groupSizes[c]=0}for(var d=this.indexOfGroup(t+1),h=(c=0,e.length);c<h;c++)this.tag.insertRule(d,e[c])&&(this.groupSizes[t]++,d++)},r.prototype.clearGroup=function(t){if(t<this.length){var e=this.groupSizes[t],s=this.indexOfGroup(t),a=s+e;this.groupSizes[t]=0;for(var l=s;l<a;l++)this.tag.deleteRule(s)}},r.prototype.getGroup=function(t){var e="";if(t>=this.length||this.groupSizes[t]===0)return e;for(var s=this.groupSizes[t],a=this.indexOfGroup(t),l=a+s,c=a;c<l;c++)e+="".concat(this.tag.getRule(c)).concat(dp);return e},r})(),uu=new Map,yu=new Map,du=1,wr=function(r){if(uu.has(r))return uu.get(r);for(;yu.has(du);)du++;var t=du++;return uu.set(r,t),yu.set(t,r),t},VS=function(r,t){du=t+1,uu.set(r,t),yu.set(t,r)},qS="style[".concat(Nr,"][").concat(tv,'="').concat(Du,'"]'),YS=new RegExp("^".concat(Nr,'\\.g(\\d+)\\[id="([\\w\\d-]+)"\\].*?"([^"]*)')),XS=function(r,t,e){for(var s,a=e.split(","),l=0,c=a.length;l<c;l++)(s=a[l])&&r.registerName(t,s)},WS=function(r,t){for(var e,s=((e=t.textContent)!==null&&e!==void 0?e:"").split(dp),a=[],l=0,c=s.length;l<c;l++){var d=s[l].trim();if(d){var h=d.match(YS);if(h){var f=0|parseInt(h[1],10),g=h[2];f!==0&&(VS(g,f),XS(r,g,h[3]),r.getTag().insertRules(f,a)),a.length=0}else a.push(d)}}},ly=function(r){for(var t=document.querySelectorAll(qS),e=0,s=t.length;e<s;e++){var a=t[e];a&&a.getAttribute(Nr)!==Jx&&(WS(r,a),a.parentNode&&a.parentNode.removeChild(a))}};function QS(){return typeof __webpack_nonce__<"u"?__webpack_nonce__:null}var ov=function(r){var t=document.head,e=r||t,s=document.createElement("style"),a=(function(d){var h=Array.from(d.querySelectorAll("style[".concat(Nr,"]")));return h[h.length-1]})(e),l=a!==void 0?a.nextSibling:null;s.setAttribute(Nr,Jx),s.setAttribute(tv,Du);var c=QS();return c&&s.setAttribute("nonce",c),e.insertBefore(s,l),s},KS=(function(){function r(t){this.element=ov(t),this.element.appendChild(document.createTextNode("")),this.sheet=(function(e){if(e.sheet)return e.sheet;for(var s=document.styleSheets,a=0,l=s.length;a<l;a++){var c=s[a];if(c.ownerNode===e)return c}throw ca(17)})(this.element),this.length=0}return r.prototype.insertRule=function(t,e){try{return this.sheet.insertRule(e,t),this.length++,!0}catch{return!1}},r.prototype.deleteRule=function(t){this.sheet.deleteRule(t),this.length--},r.prototype.getRule=function(t){var e=this.sheet.cssRules[t];return e&&e.cssText?e.cssText:""},r})(),ZS=(function(){function r(t){this.element=ov(t),this.nodes=this.element.childNodes,this.length=0}return r.prototype.insertRule=function(t,e){if(t<=this.length&&t>=0){var s=document.createTextNode(e);return this.element.insertBefore(s,this.nodes[t]||null),this.length++,!0}return!1},r.prototype.deleteRule=function(t){this.element.removeChild(this.nodes[t]),this.length--},r.prototype.getRule=function(t){return t<this.length?this.nodes[t].textContent:""},r})(),JS=(function(){function r(t){this.rules=[],this.length=0}return r.prototype.insertRule=function(t,e){return t<=this.length&&(this.rules.splice(t,0,e),this.length++,!0)},r.prototype.deleteRule=function(t){this.rules.splice(t,1),this.length--},r.prototype.getRule=function(t){return t<this.length?this.rules[t]:""},r})(),cy=gu,tE={isServer:!gu,useCSSOMInjection:!DS},xu=(function(){function r(t,e,s){t===void 0&&(t=Br),e===void 0&&(e={});var a=this;this.options=Oe(Oe({},tE),t),this.gs=e,this.names=new Map(s),this.server=!!t.isServer,!this.server&&gu&&cy&&(cy=!1,ly(this)),gp(this,function(){return(function(l){for(var c=l.getTag(),d=c.length,h="",f=function(m){var x=(function(T){return yu.get(T)})(m);if(x===void 0)return"continue";var v=l.names.get(x),E=c.getGroup(m);if(v===void 0||!v.size||E.length===0)return"continue";var S="".concat(Nr,".g").concat(m,'[id="').concat(x,'"]'),C="";v!==void 0&&v.forEach(function(T){T.length>0&&(C+="".concat(T,","))}),h+="".concat(E).concat(S,'{content:"').concat(C,'"}').concat(dp)},g=0;g<d;g++)f(g);return h})(a)})}return r.registerId=function(t){return wr(t)},r.prototype.rehydrate=function(){!this.server&&gu&&ly(this)},r.prototype.reconstructWithOptions=function(t,e){return e===void 0&&(e=!0),new r(Oe(Oe({},this.options),t),this.gs,e&&this.names||void 0)},r.prototype.allocateGSInstance=function(t){return this.gs[t]=(this.gs[t]||0)+1},r.prototype.getTag=function(){return this.tag||(this.tag=(t=(function(e){var s=e.useCSSOMInjection,a=e.target;return e.isServer?new JS(a):s?new KS(a):new ZS(a)})(this.options),new GS(t)));var t},r.prototype.hasNameForId=function(t,e){return this.names.has(t)&&this.names.get(t).has(e)},r.prototype.registerName=function(t,e){if(wr(t),this.names.has(t))this.names.get(t).add(e);else{var s=new Set;s.add(e),this.names.set(t,s)}},r.prototype.insertRules=function(t,e,s){this.registerName(t,e),this.getTag().insertRules(wr(t),s)},r.prototype.clearNames=function(t){this.names.has(t)&&this.names.get(t).clear()},r.prototype.clearRules=function(t){this.getTag().clearGroup(wr(t)),this.clearNames(t)},r.prototype.clearTag=function(){this.tag=void 0},r})(),eE=/&/g,Sr=47;function uy(r){if(r.indexOf("}")===-1)return!1;for(var t=r.length,e=0,s=0,a=!1,l=0;l<t;l++){var c=r.charCodeAt(l);if(s!==0||a||c!==Sr||r.charCodeAt(l+1)!==42)if(a)c===42&&r.charCodeAt(l+1)===Sr&&(a=!1,l++);else if(c!==34&&c!==39||l!==0&&r.charCodeAt(l-1)===92){if(s===0){if(c===123)e++;else if(c===125&&--e<0)return!0}}else s===0?s=c:s===c&&(s=0);else a=!0,l++}return e!==0||s!==0}function lv(r,t){return r.map(function(e){return e.type==="rule"&&(e.value="".concat(t," ").concat(e.value),e.value=e.value.replaceAll(",",",".concat(t," ")),e.props=e.props.map(function(s){return"".concat(t," ").concat(s)})),Array.isArray(e.children)&&e.type!=="@keyframes"&&(e.children=lv(e.children,t)),e})}function nE(r){var t,e,s,a=Br,l=a.options,c=l===void 0?Br:l,d=a.plugins,h=d===void 0?Ru:d,f=function(x,v,E){return E.startsWith(e)&&E.endsWith(e)&&E.replaceAll(e,"").length>0?".".concat(t):x},g=h.slice();g.push(function(x){x.type===Cu&&x.value.includes("&")&&(x.props[0]=x.props[0].replace(eE,e).replace(s,f))}),c.prefix&&g.push(kS),g.push(TS);var m=function(x,v,E,S){v===void 0&&(v=""),E===void 0&&(E=""),S===void 0&&(S="&"),t=S,e=v,s=new RegExp("\\".concat(e,"\\b"),"g");var C=(function(k){if(!uy(k))return k;for(var R=k.length,D="",L=0,O=0,B=0,F=!1,W=0;W<R;W++){var Z=k.charCodeAt(W);if(B!==0||F||Z!==Sr||k.charCodeAt(W+1)!==42)if(F)Z===42&&k.charCodeAt(W+1)===Sr&&(F=!1,W++);else if(Z!==34&&Z!==39||W!==0&&k.charCodeAt(W-1)===92){if(B===0)if(Z===123)O++;else if(Z===125){if(--O<0){for(var rt=W+1;rt<R;){var dt=k.charCodeAt(rt);if(dt===59||dt===10)break;rt++}rt<R&&k.charCodeAt(rt)===59&&rt++,O=0,W=rt-1,L=rt;continue}O===0&&(D+=k.substring(L,W+1),L=W+1)}else Z===59&&O===0&&(D+=k.substring(L,W+1),L=W+1)}else B===0?B=Z:B===Z&&(B=0);else F=!0,W++}if(L<R){var lt=k.substring(L);uy(lt)||(D+=lt)}return D})((function(k){if(k.indexOf("//")===-1)return k;for(var R=k.length,D=[],L=0,O=0,B=0;O<R;){var F=k.charCodeAt(O);if(F!==34&&F!==39||O!==0&&k.charCodeAt(O-1)===92)if(B===0)if(F!==Sr||k.charCodeAt(O+1)!==Sr)O++;else{for(O>L&&D.push(k.substring(L,O));O<R&&k.charCodeAt(O)!==10;)O++;L=O}else O++;else B===0?B=F:B===F&&(B=0),O++}return L===0?k:(L<R&&D.push(k.substring(L)),D.join(""))})(x)),T=SS(E||v?"".concat(E," ").concat(v," { ").concat(C," }"):C);c.namespace&&(T=lv(T,c.namespace));var _=[];return pu(T,CS(g.concat(_S(function(k){return _.push(k)})))),_};return m.hash=h.length?h.reduce(function(x,v){return v.name||ca(15),Ar(x,v.name)},5381).toString():"",m}var iE=new xu,If=nE(),Ff={shouldForwardProp:void 0,styleSheet:iE,stylis:If},cv=Es?{Provider:function(r){return r.children},Consumer:function(r){return(0,r.children)(Ff)}}:X.createContext(Ff);cv.Consumer;Es||X.createContext(void 0);function $f(){return!Es&&X.useContext?X.useContext(cv):Ff}var uv=(function(){function r(t,e){var s=this;this.inject=function(a,l){l===void 0&&(l=If);var c=s.name+l.hash;a.hasNameForId(s.id,c)||a.insertRules(s.id,c,l(s.rules,c,"@keyframes"))},this.name=t,this.id="sc-keyframes-".concat(t),this.rules=e,gp(this,function(){throw ca(12,String(s.name))})}return r.prototype.getName=function(t){return t===void 0&&(t=If),this.name+t.hash},r})();function sE(r,t){return t==null||typeof t=="boolean"||t===""?"":typeof t!="number"||t===0||r in MS||r.startsWith("--")?String(t).trim():"".concat(t,"px")}var aE=function(r){return r>="A"&&r<="Z"};function dy(r){for(var t="",e=0;e<r.length;e++){var s=r[e];if(e===1&&s==="-"&&r[0]==="-")return r;aE(s)?t+="-"+s.toLowerCase():t+=s}return t.startsWith("ms-")?"-"+t:t}var dv=function(r){return r==null||r===!1||r===""},hv=function(r){var t=[];for(var e in r){var s=r[e];r.hasOwnProperty(e)&&!dv(s)&&(Array.isArray(s)&&s.isCss||la(s)?t.push("".concat(dy(e),":"),s,";"):el(s)?t.push.apply(t,Or(Or(["".concat(e," {")],hv(s),!1),["}"],!1)):t.push("".concat(dy(e),": ").concat(sE(e,s),";")))}return t};function ws(r,t,e,s){if(dv(r))return[];if(pp(r))return[".".concat(r.styledComponentId)];if(la(r)){if(!la(l=r)||l.prototype&&l.prototype.isReactComponent||!t)return[r];var a=r(t);return ws(a,t,e,s)}var l;return r instanceof uv?e?(r.inject(e,s),[r.getName(s)]):[r]:el(r)?hv(r):Array.isArray(r)?Array.prototype.concat.apply(Ru,r.map(function(c){return ws(c,t,e,s)})):[r.toString()]}function fv(r){for(var t=0;t<r.length;t+=1){var e=r[t];if(la(e)&&!pp(e))return!1}return!0}var rE=hp(Du),oE=(function(){function r(t,e,s){this.rules=t,this.staticRulesId="",this.isStatic=(s===void 0||s.isStatic)&&fv(t),this.componentId=e,this.baseHash=Ar(rE,e),this.baseStyle=s,xu.registerId(e)}return r.prototype.generateAndInjectStyles=function(t,e,s){var a=this.baseStyle?this.baseStyle.generateAndInjectStyles(t,e,s).className:"";if(this.isStatic&&!s.hash)if(this.staticRulesId&&e.hasNameForId(this.componentId,this.staticRulesId))a=Js(a,this.staticRulesId);else{var l=bu(ws(this.rules,t,e,s)),c=mu(Ar(this.baseHash,l)>>>0);if(!e.hasNameForId(this.componentId,c)){var d=s(l,".".concat(c),void 0,this.componentId);e.insertRules(this.componentId,c,d)}a=Js(a,c),this.staticRulesId=c}else{for(var h=Ar(this.baseHash,s.hash),f="",g=0;g<this.rules.length;g++){var m=this.rules[g];if(typeof m=="string")f+=m;else if(m){var x=bu(ws(m,t,e,s));h=Ar(h,x+g),f+=x}}if(f){var v=mu(h>>>0);if(!e.hasNameForId(this.componentId,v)){var E=s(f,".".concat(v),void 0,this.componentId);e.insertRules(this.componentId,v,E)}a=Js(a,v)}}return{className:a,css:typeof window>"u"?e.getTag().getGroup(wr(this.componentId)):""}},r})(),nl=Es?{Provider:function(r){return r.children},Consumer:function(r){return(0,r.children)(void 0)}}:X.createContext(void 0);nl.Consumer;function lE(r){if(Es||!X.useContext||!X.useMemo)return r.children;var t=X.useContext(nl),e=X.useMemo(function(){return(function(s,a){if(!s)throw ca(14);if(la(s)){var l=s(a);return l}if(Array.isArray(s)||typeof s!="object")throw ca(8);return a?Oe(Oe({},a),s):s})(r.theme,t)},[r.theme,t]);return r.children?X.createElement(nl.Provider,{value:e},r.children):null}var pf={};function cE(r,t,e){var s=pp(r),a=r,l=!ff(r),c=t.attrs,d=c===void 0?Ru:c,h=t.componentId,f=h===void 0?(function(R,D){var L=typeof R!="string"?"sc":iy(R);pf[L]=(pf[L]||0)+1;var O="".concat(L,"-").concat(fp(Du+L+pf[L]));return D?"".concat(D,"-").concat(O):O})(t.displayName,t.parentComponentId):h,g=t.displayName,m=g===void 0?(function(R){return ff(R)?"styled.".concat(R):"Styled(".concat(NS(R),")")})(r):g,x=t.displayName&&t.componentId?"".concat(iy(t.displayName),"-").concat(t.componentId):t.componentId||f,v=s&&a.attrs?a.attrs.concat(d).filter(Boolean):d,E=t.shouldForwardProp;if(s&&a.shouldForwardProp){var S=a.shouldForwardProp;if(t.shouldForwardProp){var C=t.shouldForwardProp;E=function(R,D){return S(R,D)&&C(R,D)}}else E=S}var T=new oE(e,x,s?a.componentStyle:void 0);function _(R,D){return(function(L,O,B){var F=L.attrs,W=L.componentStyle,Z=L.defaultProps,rt=L.foldedComponentIds,dt=L.styledComponentId,lt=L.target,ut=X.useContext?X.useContext(nl):void 0,P=$f(),V=L.shouldForwardProp||P.shouldForwardProp,K=ev(O,ut,Z)||Br,ct=(function(kt,et,xt){for(var ht,Ct=Oe(Oe({},et),{className:void 0,theme:xt}),At=0;At<kt.length;At+=1){var yt=la(ht=kt[At])?ht(Ct):ht;for(var Et in yt)Et==="className"?Ct.className=Js(Ct.className,yt[Et]):Et==="style"?Ct.style=Oe(Oe({},Ct.style),yt[Et]):Ct[Et]=yt[Et]}return"className"in et&&typeof et.className=="string"&&(Ct.className=Js(Ct.className,et.className)),Ct})(F,O,K),bt=ct.as||lt,z={};for(var H in ct)ct[H]===void 0||H[0]==="$"||H==="as"||H==="theme"&&ct.theme===K||(H==="forwardedAs"?z.as=ct.forwardedAs:V&&!V(H,bt)||(z[H]=ct[H]));var q=(function(kt,et){var xt=$f(),ht=kt.generateAndInjectStyles(et,xt.styleSheet,xt.stylis);return ht})(W,ct),tt=q.className,st=q.css,ot=Js(rt,dt);tt&&(ot+=" "+tt),ct.className&&(ot+=" "+ct.className),z[ff(bt)&&!nv.has(bt)?"class":"className"]=ot,B&&(z.ref=B);var at=j.createElement(bt,z);return Es&&st?X.createElement(X.Fragment,null,X.createElement("style",{precedence:"styled-components",href:"sc-".concat(dt,"-").concat(tt),children:st}),at):at})(k,R,D)}_.displayName=m;var k=X.forwardRef(_);return k.attrs=v,k.componentStyle=T,k.displayName=m,k.shouldForwardProp=E,k.foldedComponentIds=s?Js(a.foldedComponentIds,a.styledComponentId):"",k.styledComponentId=x,k.target=s?a.target:r,Object.defineProperty(k,"defaultProps",{get:function(){return this._foldedDefaultProps},set:function(R){this._foldedDefaultProps=s?(function(D){for(var L=[],O=1;O<arguments.length;O++)L[O-1]=arguments[O];for(var B=0,F=L;B<F.length;B++)Pf(D,F[B],!0);return D})({},a.defaultProps,R):R}}),gp(k,function(){return".".concat(k.styledComponentId)}),l&&rv(k,r,{attrs:!0,componentStyle:!0,displayName:!0,foldedComponentIds:!0,shouldForwardProp:!0,styledComponentId:!0,target:!0}),k}function hy(r,t){for(var e=[r[0]],s=0,a=t.length;s<a;s+=1)e.push(t[s],r[s+1]);return e}var fy=function(r){return Object.assign(r,{isCss:!0})};function ft(r){for(var t=[],e=1;e<arguments.length;e++)t[e-1]=arguments[e];if(la(r)||el(r))return fy(ws(hy(Ru,Or([r],t,!0))));var s=r;return t.length===0&&s.length===1&&typeof s[0]=="string"?ws(s):fy(ws(hy(s,t)))}function Hf(r,t,e){if(e===void 0&&(e=Br),!t)throw ca(1,t);var s=function(a){for(var l=[],c=1;c<arguments.length;c++)l[c-1]=arguments[c];return r(t,e,ft.apply(void 0,Or([a],l,!1)))};return s.attrs=function(a){return Hf(r,t,Oe(Oe({},e),{attrs:Array.prototype.concat(e.attrs,a).filter(Boolean)}))},s.withConfig=function(a){return Hf(r,t,Oe(Oe({},e),a))},s}var pv=function(r){return Hf(cE,r)},w=pv;nv.forEach(function(r){w[r]=pv(r)});var uE=(function(){function r(t,e){this.rules=t,this.componentId=e,this.isStatic=fv(t),xu.registerId(this.componentId+1)}return r.prototype.createStyles=function(t,e,s,a){var l=a(bu(ws(this.rules,e,s,a)),""),c=this.componentId+t;s.insertRules(c,c,l)},r.prototype.removeStyles=function(t,e){e.clearRules(this.componentId+t)},r.prototype.renderStyles=function(t,e,s,a){t>2&&xu.registerId(this.componentId+t),this.removeStyles(t,s),this.createStyles(t,e,s,a)},r})();function dE(r){for(var t=[],e=1;e<arguments.length;e++)t[e-1]=arguments[e];var s=ft.apply(void 0,Or([r],t,!1)),a="sc-global-".concat(fp(JSON.stringify(s))),l=new uE(s,a),c=new WeakMap,d=function(h){var f=$f(),g=X.useContext?X.useContext(nl):void 0,m=c.get(f.styleSheet);if(m===void 0&&(m=f.styleSheet.allocateGSInstance(a),c.set(f.styleSheet,m)),(typeof window>"u"||!f.styleSheet.server)&&(function(C,T,_,k,R){if(l.isStatic)l.renderStyles(C,RS,_,R);else{var D=Oe(Oe({},T),{theme:ev(T,k,d.defaultProps)});l.renderStyles(C,D,_,R)}})(m,h,f.styleSheet,g,f.stylis),Es||X.useLayoutEffect(function(){return function(){l.removeStyles(m,f.styleSheet)}},[m,f.styleSheet]),Es){var x=a+m,v=typeof window>"u"?f.styleSheet.getTag().getGroup(wr(x)):"";if(v){var E=mu(hp(v)>>>0),S="sc-global-".concat(a,"-").concat(m,"-").concat(E);return X.createElement("style",{key:S,"data-styled-global":a,precedence:"styled-components",href:S,children:v})}}return null};return X.memo(d)}function ue(r){for(var t=[],e=1;e<arguments.length;e++)t[e-1]=arguments[e];var s=bu(ft.apply(void 0,Or([r],t,!1))),a=fp(s);return new uv(a,s)}var gf,py;function hE(){if(py)return gf;py=1;var r={name:"original",anchor:"#1034a6",anchorVisited:"#440381",borderDark:"#848584",borderDarkest:"#0a0a0a",borderLight:"#dfdfdf",borderLightest:"#fefefe",canvas:"#ffffff",canvasText:"#0a0a0a",canvasTextDisabled:"#848584",canvasTextDisabledShadow:"#fefefe",canvasTextInvert:"#fefefe",checkmark:"#0a0a0a",checkmarkDisabled:"#848584",desktopBackground:"#008080",flatDark:"#9e9e9e",flatLight:"#d8d8d8",focusSecondary:"#fefe03",headerBackground:"#060084",headerNotActiveBackground:"#7f787f",headerNotActiveText:"#c6c6c6",headerText:"#fefefe",hoverBackground:"#060084",material:"#c6c6c6",materialDark:"#9a9e9c",materialText:"#0a0a0a",materialTextDisabled:"#848584",materialTextDisabledShadow:"#fefefe",materialTextInvert:"#fefefe",progress:"#060084",tooltip:"#fefbcc"};return gf=r,gf}var fE=hE();const pE=op(fE);var gE=`
  html,
body,
div,
span,
applet,
object,
iframe,
h1,
h2,
h3,
h4,
h5,
h6,
p,
blockquote,
pre,
a,
abbr,
acronym,
address,
big,
cite,
code,
del,
dfn,
em,
img,
ins,
kbd,
q,
s,
samp,
small,
strike,
strong,
sub,
sup,
tt,
var,
b,
u,
i,
center,
dl,
dt,
dd,
ol,
ul,
li,
fieldset,
form,
label,
legend,
table,
caption,
tbody,
tfoot,
thead,
tr,
th,
td,
article,
aside,
canvas,
details,
embed,
figure,
figcaption,
footer,
header,
hgroup,
menu,
nav,
output,
ruby,
section,
summary,
time,
mark,
audio,
video {
  margin: 0;
  padding: 0;
  border: 0;
  font-size: 100%;
  font: inherit;
  vertical-align: baseline;
}
/* HTML5 display-role reset for older browsers */
article,
aside,
details,
figcaption,
figure,
footer,
header,
hgroup,
menu,
nav,
section {
  display: block;
}
body {
  line-height: 1.5;
}
ol,
ul {
  list-style: none;
}
blockquote,
q {
  quotes: none;
}
blockquote:before,
blockquote:after,
q:before,
q:after {
  content: "";
  content: none;
}
table {
  border-collapse: collapse;
  border-spacing: 0;
}
a {
  color: inherit;
  text-decoration: none;
}
ul,
li {
  list-style-type: none;
}
button {
  outline: none;
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
}
body {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
  color: black;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, "Courier New",
    monospace;
}

input[type="number"]::-webkit-outer-spin-button,
input[type="number"]::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

input[type="number"] {
  -moz-appearance: textfield;
}

`;const mp="4px 4px 10px 0 rgba(0, 0, 0, 0.35)",bp="inset 2px 2px 3px rgba(0,0,0,0.2)",Yn=()=>ft`
  -webkit-text-fill-color: ${({theme:r})=>r.materialTextDisabled};
  color: ${({theme:r})=>r.materialTextDisabled};
  text-shadow: 1px 1px ${({theme:r})=>r.materialTextDisabledShadow};
  /* filter: grayscale(100%); */
`,Xn=({background:r="material",color:t="materialText"}={})=>ft`
  box-sizing: border-box;
  display: inline-block;
  background: ${({theme:e})=>e[r]};
  color: ${({theme:e})=>e[t]};
`,ul=({mainColor:r="black",secondaryColor:t="transparent",pixelSize:e=2})=>ft`
  background-image: ${[`linear-gradient(
      45deg,
      ${r} 25%,
      transparent 25%,
      transparent 75%,
      ${r} 75%
    )`,`linear-gradient(
      45deg,
      ${r} 25%,
      transparent 25%,
      transparent 75%,
      ${r} 75%
    )`].join(",")};
  background-color: ${t};
  background-size: ${`${e*2}px ${e*2}px`};
  background-position: 0 0, ${`${e}px ${e}px`};
`,ua=()=>ft`
  position: relative;
  box-sizing: border-box;
  display: inline-block;
  color: ${({theme:r})=>r.materialText};
  background: ${({$disabled:r,theme:t})=>r?t.flatLight:t.canvas};
  border: 2px solid ${({theme:r})=>r.canvas};
  outline: 2px solid ${({theme:r})=>r.flatDark};
  outline-offset: -4px;
`,sr={button:{topLeftOuter:"borderLightest",topLeftInner:"borderLight",bottomRightInner:"borderDark",bottomRightOuter:"borderDarkest"},buttonPressed:{topLeftOuter:"borderDarkest",topLeftInner:"borderDark",bottomRightInner:"borderLight",bottomRightOuter:"borderLightest"},buttonThin:{topLeftOuter:"borderLightest",topLeftInner:null,bottomRightInner:null,bottomRightOuter:"borderDark"},buttonThinPressed:{topLeftOuter:"borderDark",topLeftInner:null,bottomRightInner:null,bottomRightOuter:"borderLightest"},field:{topLeftOuter:"borderDark",topLeftInner:"borderDarkest",bottomRightInner:"borderLight",bottomRightOuter:"borderLightest"},grouping:{topLeftOuter:"borderDark",topLeftInner:"borderLightest",bottomRightInner:"borderDark",bottomRightOuter:"borderLightest"},status:{topLeftOuter:"borderDark",topLeftInner:null,bottomRightInner:null,bottomRightOuter:"borderLightest"},window:{topLeftOuter:"borderLight",topLeftInner:"borderLightest",bottomRightInner:"borderDark",bottomRightOuter:"borderDarkest"}},mE=({theme:r,topLeftInner:t,bottomRightInner:e,hasShadow:s=!1,hasInsetShadow:a=!1})=>[s?mp:!1,a?bp:!1,t!==null?`inset 1px 1px 0px 1px ${r[t]}`:!1,e!==null?`inset -1px -1px 0 1px ${r[e]}`:!1].filter(Boolean).join(", "),me=({invert:r=!1,style:t="button"}={})=>{const e={topLeftOuter:r?"bottomRightOuter":"topLeftOuter",topLeftInner:r?"bottomRightInner":"topLeftInner",bottomRightInner:r?"topLeftInner":"bottomRightInner",bottomRightOuter:r?"topLeftOuter":"bottomRightOuter"};return ft`
    border-style: solid;
    border-width: 2px;
    border-left-color: ${({theme:s})=>s[sr[t][e.topLeftOuter]]};
    border-top-color: ${({theme:s})=>s[sr[t][e.topLeftOuter]]};
    border-right-color: ${({theme:s})=>s[sr[t][e.bottomRightOuter]]};
    border-bottom-color: ${({theme:s})=>s[sr[t][e.bottomRightOuter]]};
    box-shadow: ${({theme:s,shadow:a})=>mE({theme:s,topLeftInner:sr[t][e.topLeftInner],bottomRightInner:sr[t][e.bottomRightInner],hasShadow:a})};
  `},zr=()=>ft`
  outline: 2px dotted ${({theme:r})=>r.materialText};
`,bE=r=>Buffer.from(r).toString("base64"),yE=typeof btoa<"u"?btoa:bE,Pc=(r,t=0)=>{const e=`<svg height="26" width="26" viewBox="0 0 26 26" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g transform="rotate(${t} 13 13)">
      <polygon fill="${r}" points="6,10 20,10 13,17"/>
    </g>
  </svg>`;return`url(data:image/svg+xml;base64,${yE(e)})`},yp=(r="default")=>ft`
  ::-webkit-scrollbar {
    width: 26px;
    height: 26px;
  }
  ::-webkit-scrollbar-track {
    ${({theme:t})=>ul({mainColor:r==="flat"?t.flatLight:t.material,secondaryColor:r==="flat"?t.canvas:t.borderLightest})}
  }
  ::-webkit-scrollbar-thumb {
    ${Xn()}
    ${r==="flat"?ua():me({style:"window"})}
      outline-offset: -2px;
  }

  ::-webkit-scrollbar-corner {
    background-color: ${({theme:t})=>t.material};
  }
  ::-webkit-scrollbar-button {
    ${Xn()}
    ${r==="flat"?ua():me({style:"window"})}
      display: block;
    outline-offset: -2px;
    height: 26px;
    width: 26px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-position: 0 0;
  }
  ::-webkit-scrollbar-button:active,
  ::-webkit-scrollbar-button:active {
    background-position: 0 1px;
    ${r==="default"?me({style:"window",invert:!0}):""}
  }

  ::-webkit-scrollbar-button:horizontal:increment:start,
  ::-webkit-scrollbar-button:horizontal:decrement:end,
  ::-webkit-scrollbar-button:vertical:increment:start,
  ::-webkit-scrollbar-button:vertical:decrement:end {
    display: none;
  }

  ::-webkit-scrollbar-button:horizontal:decrement {
    background-image: ${({theme:t})=>Pc(t.materialText,90)};
  }

  ::-webkit-scrollbar-button:horizontal:increment {
    background-image: ${({theme:t})=>Pc(t.materialText,270)};
  }

  ::-webkit-scrollbar-button:vertical:decrement {
    background-image: ${({theme:t})=>Pc(t.materialText,180)};
  }

  ::-webkit-scrollbar-button:vertical:increment {
    background-image: ${({theme:t})=>Pc(t.materialText,0)};
  }
`,xE=w.a`
  color: ${({theme:r})=>r.anchor};
  font-size: inherit;
  text-decoration: ${({underline:r})=>r?"underline":"none"};
  &:visited {
    color: ${({theme:r})=>r.anchorVisited};
  }
`,vE=j.forwardRef(({children:r,underline:t=!0,...e},s)=>X.createElement(xE,{ref:s,underline:t,...e},r));vE.displayName="Anchor";const AE=w.header`
  ${me()};
  ${Xn()};

  position: ${r=>{var t;return(t=r.position)!==null&&t!==void 0?t:r.fixed?"fixed":"absolute"}};
  top: 0;
  right: 0;
  left: auto;
  display: flex;
  flex-direction: column;
  width: 100%;
`,wE=j.forwardRef(({children:r,fixed:t=!0,position:e="fixed",...s},a)=>X.createElement(AE,{fixed:t,position:t!==!1?e:void 0,ref:a,...s},r));wE.displayName="AppBar";const pa=()=>{};function ta(r,t,e){return e!==null&&r>e?e:t!==null&&r<t?t:r}function SE(r){if(Math.abs(r)<1){const e=r.toExponential().split("e-"),s=e[0].split(".")[1];return(s?s.length:0)+parseInt(e[1],10)}const t=r.toString().split(".")[1];return t?t.length:0}function gy(r,t,e){const s=Math.round((r-e)/t)*t+e;return Number(s.toFixed(SE(t)))}function Ts(r){return typeof r=="number"?`${r}px`:r}const EE=w.div`
  display: inline-block;
  box-sizing: border-box;
  object-fit: contain;
  ${({size:r})=>`
    height: ${r};
    width: ${r};
    `}
  border-radius: ${({square:r})=>r?0:"50%"};
  overflow: hidden;
  ${({noBorder:r,theme:t})=>!r&&`
    border-top: 2px solid ${t.borderDark};
    border-left: 2px solid ${t.borderDark};
    border-bottom: 2px solid ${t.borderLightest};
    border-right: 2px solid ${t.borderLightest};
    background: ${t.material};
  `}
  ${({src:r})=>!r&&`
    display: flex;
    align-items: center;
    justify-content: space-around;
    font-weight: bold;
    font-size: 1rem;
  `}
`,TE=w.img`
  display: block;
  object-fit: contain;
  width: 100%;
  height: 100%;
`,CE=j.forwardRef(({alt:r="",children:t,noBorder:e=!1,size:s=35,square:a=!1,src:l,...c},d)=>X.createElement(EE,{noBorder:e,ref:d,size:Ts(s),square:a,src:l,...c},l?X.createElement(TE,{src:l,alt:r}):t));CE.displayName="Avatar";const He={sm:"28px",md:"36px",lg:"44px"},_E=ft`
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: ${({size:r="md"})=>He[r]};
  width: ${({fullWidth:r,size:t="md",square:e})=>r?"100%":e?He[t]:"auto"};
  padding: ${({square:r})=>r?0:"0 10px"};
  font-size: 1rem;
  user-select: none;
  &:active {
    padding-top: ${({disabled:r})=>!r&&"2px"};
  }
  padding-top: ${({active:r,disabled:t})=>r&&!t&&"2px"};
  &:after {
    content: '';
    position: absolute;
    display: block;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
  }
  &:not(:disabled) {
    cursor: pointer;
  }
  font-family: inherit;
`,Lu=w.button`
  ${({active:r,disabled:t,primary:e,theme:s,variant:a})=>a==="flat"?ft`
          ${ua()}
          ${e?`
          border: 2px solid ${s.checkmark};
            outline: 2px solid ${s.flatDark};
            outline-offset: -4px;
          `:`
          border: 2px solid ${s.flatDark};
            outline: 2px solid transparent;
            outline-offset: -4px;
          `}
          &:focus:after, &:active:after {
            ${!r&&!t&&zr}
            outline-offset: -4px;
          }
        `:a==="menu"||a==="thin"?ft`
          ${Xn()};
          border: 2px solid transparent;
          &:hover,
          &:focus {
            ${!t&&!r&&me({style:"buttonThin"})}
          }
          &:active {
            ${!t&&me({style:"buttonThinPressed"})}
          }
          ${r&&me({style:"buttonThinPressed"})}
          ${t&&Yn()}
        `:ft`
          ${Xn()};
          border: none;
          ${t&&Yn()}
          ${r?ul({mainColor:s.material,secondaryColor:s.borderLightest}):""}
          &:before {
            box-sizing: border-box;
            content: '';
            position: absolute;
            ${e?ft`
                  left: 2px;
                  top: 2px;
                  width: calc(100% - 4px);
                  height: calc(100% - 4px);
                  outline: 2px solid ${s.borderDarkest};
                `:ft`
                  left: 0;
                  top: 0;
                  width: 100%;
                  height: 100%;
                `}

            ${me(r?{style:a==="raised"?"window":"button",invert:!0}:{style:a==="raised"?"window":"button",invert:!1})}
          }
          &:active:before {
            ${!t&&me({style:a==="raised"?"window":"button",invert:!0})}
          }
          &:focus:after,
          &:active:after {
            ${!r&&!t&&zr}
            outline-offset: -8px;
          }
          &:active:focus:after,
          &:active:after {
            top: ${r?"0":"1px"};
          }
        `}
  ${_E}
`,il=j.forwardRef(({onClick:r,disabled:t=!1,children:e,type:s="button",fullWidth:a=!1,size:l="md",square:c=!1,active:d=!1,onTouchStart:h=pa,primary:f=!1,variant:g="default",...m},x)=>X.createElement(Lu,{active:d,disabled:t,$disabled:t,fullWidth:a,onClick:t?void 0:r,onTouchStart:h,primary:f,ref:x,size:l,square:c,type:s,variant:g,...m},e));il.displayName="Button";function Cs({defaultValue:r,onChange:t,onChangePropName:e="onChange",readOnly:s,value:a,valuePropName:l="value"}){const c=a!==void 0,[d,h]=j.useState(r),f=j.useCallback(g=>{c||h(g)},[c]);if(c&&typeof t!="function"&&!s){const g=`Warning: You provided a \`${l}\` prop to a component without an \`${e}\` handler.${l==="value"?`This will render a read-only field. If the field should be mutable use \`defaultValue\`. Otherwise, set either \`${e}\` or \`readOnly\`.`:`This breaks the component state. You must provide an \`${e}\` function that updates \`${l}\`.`}`;console.warn(g)}return[c?a:d,f]}const Uf=w.li`
  box-sizing: border-box;

  display: flex;
  align-items: center;
  position: relative;
  height: ${r=>He[r.size]};
  width: ${r=>r.square?He[r.size]:"auto"};
  padding: 0 8px;
  font-size: 1rem;
  white-space: nowrap;
  justify-content: ${r=>r.square?"space-around":"space-between"};
  text-align: center;
  line-height: ${r=>He[r.size]};
  color: ${({theme:r})=>r.materialText};
  pointer-events: ${({$disabled:r})=>r?"none":"auto"};
  font-weight: ${({primary:r})=>r?"bold":"normal"};
  &:hover {
    ${({theme:r,$disabled:t})=>!t&&`
        color: ${r.materialTextInvert};
        background: ${r.hoverBackground};
      `}

    cursor: default;
  }
  ${r=>r.$disabled&&Yn()}
`,kE=j.forwardRef(({size:r="lg",disabled:t,square:e,children:s,onClick:a,primary:l,...c},d)=>X.createElement(Uf,{$disabled:t,size:r,square:e,onClick:t?void 0:a,primary:l,role:"menuitem",ref:d,"aria-disabled":t,...c},s));kE.displayName="MenuListItem";const ME=w.ul.attrs(()=>({role:"menu"}))`
  box-sizing: border-box;
  width: ${r=>r.fullWidth?"100%":"auto"};
  padding: 4px;
  ${me({style:"window"})}
  ${Xn()}
  ${r=>r.inline&&`
    display: inline-flex;
    align-items: center;
  `}
  list-style: none;
  position: relative;
`;ME.displayName="MenuList";const li=20,vu=w.input`
  position: absolute;
  left: 0;
  margin: 0;
  width: ${li}px;
  height: ${li}px;
  opacity: 0;
  z-index: -1;
`,xp=w.label`
  display: inline-flex;
  align-items: center;
  position: relative;
  margin: 8px 0;
  cursor: ${({$disabled:r})=>r?"auto":"pointer"};
  user-select: none;
  font-size: 1rem;
  color: ${({theme:r})=>r.materialText};
  ${r=>r.$disabled&&Yn()}

  ${Uf} & {
    margin: 0;
    height: 100%;
  }
  ${Uf}:hover & {
    ${({$disabled:r,theme:t})=>!r&&ft`
        color: ${t.materialTextInvert};
      `};
  }
`,vp=w.span`
  display: inline-block;
  line-height: 1;
  padding: 2px;
  ${vu}:focus ~ & {
    ${zr}
  }
  ${vu}:not(:disabled) ~ &:active {
    ${zr}
  }
`,ci=w.div`
  position: relative;
  box-sizing: border-box;
  padding: 2px;
  font-size: 1rem;
  border-style: solid;
  border-width: 2px;
  border-left-color: ${({theme:r})=>r.borderDark};
  border-top-color: ${({theme:r})=>r.borderDark};
  border-right-color: ${({theme:r})=>r.borderLightest};
  border-bottom-color: ${({theme:r})=>r.borderLightest};
  line-height: 1.5;
  &:before {
    position: absolute;
    left: 0;
    top: 0;
    content: '';
    width: calc(100% - 4px);
    height: calc(100% - 4px);

    border-style: solid;
    border-width: 2px;
    border-left-color: ${({theme:r})=>r.borderDarkest};
    border-top-color: ${({theme:r})=>r.borderDarkest};
    border-right-color: ${({theme:r})=>r.borderLight};
    border-bottom-color: ${({theme:r})=>r.borderLight};

    pointer-events: none;
    ${r=>r.shadow&&`box-shadow:${bp};`}
  }
`,DE=w.div`
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  padding: 4px;
  overflow: auto;
  ${yp()}
`,gv=j.forwardRef(({children:r,shadow:t=!0,...e},s)=>X.createElement(ci,{ref:s,shadow:t,...e},X.createElement(DE,null,r)));gv.displayName="ScrollView";const mv=ft`
  width: ${li}px;
  height: ${li}px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin-right: 0.5rem;
`,RE=w(ci)`
  ${mv}
  width: ${li}px;
  height: ${li}px;
  background: ${({$disabled:r,theme:t})=>r?t.material:t.canvas};
  &:before {
    box-shadow: none;
  }
`,LE=w.div`
  position: relative;
  box-sizing: border-box;
  display: inline-block;
  background: ${({$disabled:r,theme:t})=>r?t.flatLight:t.canvas};
  ${mv}
  width: ${li-4}px;
  height: ${li-4}px;
  outline: none;
  border: 2px solid ${({theme:r})=>r.flatDark};
  background: ${({$disabled:r,theme:t})=>r?t.flatLight:t.canvas};
`,OE=w.span.attrs(()=>({"data-testid":"checkmarkIcon"}))`
  display: inline-block;
  position: relative;
  width: 100%;
  height: 100%;
  &:after {
    content: '';
    display: block;
    position: absolute;
    left: 50%;
    top: calc(50% - 1px);
    width: 3px;
    height: 7px;

    border: solid
      ${({$disabled:r,theme:t})=>r?t.checkmarkDisabled:t.checkmark};
    border-width: 0 3px 3px 0;
    transform: translate(-50%, -50%) rotate(45deg);

    border-color: ${r=>r.$disabled?r.theme.checkmarkDisabled:r.theme.checkmark};
  }
`,jE=w.span.attrs(()=>({"data-testid":"indeterminateIcon"}))`
  display: inline-block;
  position: relative;

  width: 100%;
  height: 100%;

  &:after {
    content: '';
    display: block;

    width: 100%;
    height: 100%;

    ${({$disabled:r,theme:t})=>ul({mainColor:r?t.checkmarkDisabled:t.checkmark})}
    background-position: 0px 0px, 2px 2px;
  }
`,NE={flat:LE,default:RE},BE=j.forwardRef(({checked:r,className:t="",defaultChecked:e=!1,disabled:s=!1,indeterminate:a=!1,label:l="",onChange:c=pa,style:d={},value:h,variant:f="default",...g},m)=>{var x;const[v,E]=Cs({defaultValue:e,onChange:c,readOnly:(x=g.readOnly)!==null&&x!==void 0?x:s,value:r}),S=j.useCallback(_=>{const k=_.target.checked;E(k),c(_)},[c,E]),C=NE[f];let T=null;return a?T=jE:v&&(T=OE),X.createElement(xp,{$disabled:s,className:t,style:d},X.createElement(vu,{disabled:s,onChange:s?void 0:S,readOnly:s,type:"checkbox",value:h,checked:v,"data-indeterminate":a,ref:m,...g}),X.createElement(C,{$disabled:s,role:"presentation"},T&&X.createElement(T,{$disabled:s,variant:f})),l&&X.createElement(vp,null,l))});BE.displayName="Checkbox";const bv=w.div`
  ${({orientation:r,theme:t,size:e="100%"})=>r==="vertical"?`
    height: ${Ts(e)};
    border-left: 2px solid ${t.borderDark};
    border-right: 2px solid ${t.borderLightest};
    margin: 0;
    `:`
    width: ${Ts(e)};
    border-bottom: 2px solid ${t.borderLightest};
    border-top: 2px solid ${t.borderDark};
    margin: 0;
    `}
`;bv.displayName="Separator";const zE=w(Lu)`
  padding-left: 8px;
`,PE=w(bv)`
  height: 21px;
  position: relative;
  top: 0;
`,yv=w.input`
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
  z-index: 1;
  cursor: pointer;
  &:disabled {
    cursor: default;
  }
`,IE=w.div`
  box-sizing: border-box;
  height: 19px;
  display: inline-block;
  width: 35px;
  margin-right: 5px;

  background: ${({color:r})=>r};

  ${({$disabled:r})=>r?ft`
          border: 2px solid ${({theme:t})=>t.materialTextDisabled};
          filter: drop-shadow(
            1px 1px 0px ${({theme:t})=>t.materialTextDisabledShadow}
          );
        `:ft`
          border: 2px solid ${({theme:t})=>t.materialText};
        `}
  ${yv}:focus:not(:active) + &:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    ${zr}
    outline-offset: -8px;
  }
`,FE=w.span`
  width: 0px;
  height: 0px;
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  display: inline-block;
  margin-left: 6px;

  ${({$disabled:r})=>r?ft`
          border-top: 6px solid ${({theme:t})=>t.materialTextDisabled};
          filter: drop-shadow(
            1px 1px 0px ${({theme:t})=>t.materialTextDisabledShadow}
          );
        `:ft`
          border-top: 6px solid ${({theme:t})=>t.materialText};
        `}
  &:after {
    content: '';
    box-sizing: border-box;
    position: absolute;
    top: ${({variant:r})=>r==="flat"?"6px":"8px"};
    right: 8px;
    width: 16px;
    height: 19px;
  }
`,$E=j.forwardRef(({value:r,defaultValue:t,onChange:e=pa,disabled:s=!1,variant:a="default",...l},c)=>{var d;const[h,f]=Cs({defaultValue:t,onChange:e,readOnly:(d=l.readOnly)!==null&&d!==void 0?d:s,value:r}),g=m=>{const x=m.target.value;f(x),e(m)};return X.createElement(zE,{disabled:s,as:"div",variant:a,size:"md"},X.createElement(yv,{onChange:g,readOnly:s,disabled:s,value:h??"#008080",type:"color",ref:c,...l}),X.createElement(IE,{$disabled:s,color:h??"#008080",role:"presentation"}),a==="default"&&X.createElement(PE,{orientation:"vertical"}),X.createElement(FE,{$disabled:s,variant:a}))});$E.displayName="ColorInput";const HE=w.div`
  position: relative;
  --react95-digit-primary-color: #ff0102;
  --react95-digit-secondary-color: #740201;
  --react95-digit-bg-color: #000000;

  ${({pixelSize:r})=>ft`
    width: ${11*r}px;
    height: ${21*r}px;
    margin: ${r}px;

    span,
    span:before,
    span:after {
      box-sizing: border-box;
      display: inline-block;
      position: absolute;
    }
    span.active,
    span.active:before,
    span.active:after {
      background: var(--react95-digit-primary-color);
    }
    span:not(.active),
    span:not(.active):before,
    span:not(.active):after {
      ${ul({mainColor:"var(--react95-digit-bg-color)",secondaryColor:"var(--react95-digit-secondary-color)",pixelSize:r})}
    }

    span.horizontal,
    span.horizontal:before,
    span.horizontal:after {
      height: ${r}px;
      border-left: ${r}px solid var(--react95-digit-bg-color);
      border-right: ${r}px solid var(--react95-digit-bg-color);
    }
    span.horizontal.active,
    span.horizontal.active:before,
    span.horizontal.active:after {
      height: ${r}px;
      border-left: ${r}px solid var(--react95-digit-primary-color);
      border-right: ${r}px solid var(--react95-digit-primary-color);
    }
    span.horizontal {
      left: ${r}px;
      width: ${9*r}px;
    }
    span.horizontal:before {
      content: '';
      width: 100%;
      top: ${r}px;
      left: ${0}px;
    }
    span.horizontal:after {
      content: '';
      width: calc(100% - ${r*2}px);
      top: ${2*r}px;
      left: ${r}px;
    }
    span.horizontal.top {
      top: 0;
    }
    span.horizontal.bottom {
      bottom: 0;
      transform: rotateX(180deg);
    }

    span.center,
    span.center:before,
    span.center:after {
      height: ${r}px;
      border-left: ${r}px solid var(--react95-digit-bg-color);
      border-right: ${r}px solid var(--react95-digit-bg-color);
    }
    span.center.active,
    span.center.active:before,
    span.center.active:after {
      border-left: ${r}px solid var(--react95-digit-primary-color);
      border-right: ${r}px solid var(--react95-digit-primary-color);
    }
    span.center {
      top: 50%;
      transform: translateY(-50%);
      left: ${r}px;
      width: ${9*r}px;
    }
    span.center:before,
    span.center:after {
      content: '';
      width: 100%;
    }
    span.center:before {
      top: ${r}px;
    }
    span.center:after {
      bottom: ${r}px;
    }

    span.vertical,
    span.vertical:before,
    span.vertical:after {
      width: ${r}px;
      border-top: ${r}px solid var(--react95-digit-bg-color);
      border-bottom: ${r}px solid var(--react95-digit-bg-color);
    }
    span.vertical {
      height: ${11*r}px;
    }
    span.vertical.left {
      left: 0;
    }
    span.vertical.right {
      right: 0;
      transform: rotateY(180deg);
    }
    span.vertical.top {
      top: 0px;
    }
    span.vertical.bottom {
      bottom: 0px;
    }
    span.vertical:before {
      content: '';
      height: 100%;
      top: ${0}px;
      left: ${r}px;
    }
    span.vertical:after {
      content: '';
      height: calc(100% - ${r*2}px);
      top: ${r}px;
      left: ${r*2}px;
    }
  `}
`,my=["horizontal top","center","horizontal bottom","vertical top left","vertical top right","vertical bottom left","vertical bottom right"],UE=[[1,0,1,1,1,1,1],[0,0,0,0,1,0,1],[1,1,1,0,1,1,0],[1,1,1,0,1,0,1],[0,1,0,1,1,0,1],[1,1,1,1,0,0,1],[1,1,1,1,0,1,1],[1,0,0,0,1,0,1],[1,1,1,1,1,1,1],[1,1,1,1,1,0,1]];function GE({digit:r=0,pixelSize:t=2,...e}){const s=UE[Number(r)].map((a,l)=>a?`${my[l]} active`:my[l]);return X.createElement(HE,{pixelSize:t,...e},s.map((a,l)=>X.createElement("span",{className:a,key:l})))}const VE=w.div`
  ${me({style:"status"})}
  display: inline-flex;
  background: #000000;
`,qE={sm:1,md:2,lg:3,xl:4},YE=j.forwardRef(({value:r=0,minLength:t=3,size:e="md",...s},a)=>{const l=j.useMemo(()=>r.toString().padStart(t,"0").split(""),[t,r]);return X.createElement(VE,{ref:a,...s},l.map((c,d)=>X.createElement(GE,{digit:c,pixelSize:qE[e],key:d})))});YE.displayName="Counter";const xv=ft`
  display: flex;
  align-items: center;
  width: ${({fullWidth:r})=>r?"100%":"auto"};
  min-height: ${He.md};
`,XE=w(ci).attrs({"data-testid":"variant-default"})`
  ${xv}
  background: ${({$disabled:r,theme:t})=>r?t.material:t.canvas};
`,WE=w.div.attrs({"data-testid":"variant-flat"})`
  ${ua()}
  ${xv}
  position: relative;
`,vv=ft`
  display: block;
  box-sizing: border-box;
  width: 100%;
  height: 100%;
  outline: none;
  border: none;
  background: none;
  font-size: 1rem;
  min-height: 27px;
  font-family: inherit;
  color: ${({theme:r})=>r.canvasText};
  ${({disabled:r,variant:t})=>t!=="flat"&&r&&Yn()}
`,QE=w.input`
  ${vv}
  padding: 0 8px;
`,KE=w.textarea`
  ${vv}
  padding: 8px;
  resize: none;
  ${({variant:r})=>yp(r)}
`,Av=j.forwardRef(({className:r,disabled:t=!1,fullWidth:e,onChange:s=pa,shadow:a=!0,style:l,variant:c="default",...d},h)=>{const f=c==="flat"?WE:XE,g=j.useMemo(()=>{var m;return d.multiline?X.createElement(KE,{disabled:t,onChange:t?void 0:s,readOnly:t,ref:h,variant:c,...d}):X.createElement(QE,{disabled:t,onChange:t?void 0:s,readOnly:t,ref:h,type:(m=d.type)!==null&&m!==void 0?m:"text",variant:c,...d})},[t,s,d,h,c]);return X.createElement(f,{className:r,fullWidth:e,$disabled:t,shadow:a,style:l},g)});Av.displayName="TextInput";const ZE=w.div`
  display: inline-flex;
  align-items: center;
`,Gf=w(il)`
  width: 30px;
  padding: 0;
  flex-shrink: 0;

  ${({variant:r})=>r==="flat"?ft`
          height: calc(50% - 1px);
        `:ft`
          height: 50%;
        `}
`,JE=w.div`
  display: flex;
  flex-direction: column;
  flex-wrap: nowrap;
  justify-content: space-between;

  ${({variant:r})=>r==="flat"?ft`
          height: calc(${He.md} - 4px);
        `:ft`
          height: ${He.md};
          margin-left: 2px;
        `}
`,by=w.span`
  width: 0px;
  height: 0px;
  display: inline-block;
  ${({invert:r})=>r?ft`
          border-left: 4px solid transparent;
          border-right: 4px solid transparent;
          border-bottom: 4px solid ${({theme:t})=>t.materialText};
        `:ft`
          border-left: 4px solid transparent;
          border-right: 4px solid transparent;
          border-top: 4px solid ${({theme:t})=>t.materialText};
        `}
  ${Gf}:disabled & {
    filter: drop-shadow(
      1px 1px 0px ${({theme:r})=>r.materialTextDisabledShadow}
    );
    ${({invert:r})=>r?ft`
            border-bottom-color: ${({theme:t})=>t.materialTextDisabled};
          `:ft`
            border-top-color: ${({theme:t})=>t.materialTextDisabled};
          `}
  }
`,wv=j.forwardRef(({className:r,defaultValue:t,disabled:e=!1,max:s,min:a,onChange:l,readOnly:c,step:d=1,style:h,value:f,variant:g="default",width:m,...x},v)=>{const[E,S]=Cs({defaultValue:t,onChange:l,readOnly:c,value:f}),C=j.useCallback(L=>{const O=parseFloat(L.target.value);S(O)},[S]),T=j.useCallback(L=>{const O=ta(parseFloat(((E??0)+L).toFixed(2)),a??null,s??null);S(O),l?.(O)},[s,a,l,S,E]),_=j.useCallback(()=>{E!==void 0&&l?.(E)},[l,E]),k=j.useCallback(()=>{T(d)},[T,d]),R=j.useCallback(()=>{T(-d)},[T,d]),D=g==="flat"?"flat":"raised";return X.createElement(ZE,{className:r,style:{...h,width:m!==void 0?Ts(m):"auto"},...x},X.createElement(Av,{value:E,variant:g,onChange:C,disabled:e,type:"number",readOnly:c,ref:v,fullWidth:!0,onBlur:_}),X.createElement(JE,{variant:g},X.createElement(Gf,{"data-testid":"increment",variant:D,disabled:e||c,onClick:k},X.createElement(by,{invert:!0})),X.createElement(Gf,{"data-testid":"decrement",variant:D,disabled:e||c,onClick:R},X.createElement(by,null))))});wv.displayName="NumberInput";function tT(){const r="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";let t="";for(let e=0;e<10;e+=1)t+=r[Math.floor(Math.random()*r.length)];return t}const Sv=r=>j.useMemo(()=>tT(),[r]),Ev=ft`
  box-sizing: border-box;
  padding-left: 4px;
  overflow: hidden;
  white-space: nowrap;
  user-select: none;
  line-height: 100%;
`,Tv=ft`
  background: ${({theme:r})=>r.hoverBackground};
  color: ${({theme:r})=>r.canvasTextInvert};
`,Ap=w.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
  width: 100%;
  &:focus {
    outline: none;
  }
`,eT=w.div`
  ${Ev}
  padding-right: 8px;
  align-items: center;
  display: flex;
  height: calc(100% - 4px);
  width: calc(100% - 4px);
  margin: 0 2px;
  border: 2px solid transparent;
  ${Ap}:focus & {
    ${Tv}
    border: 2px dotted ${({theme:r})=>r.focusSecondary};
  }
`,Cv=ft`
  height: ${He.md};
  display: inline-block;
  color: ${({$disabled:r=!1,theme:t})=>r?Yn():t.canvasText};
  font-size: 1rem;
  cursor: ${({$disabled:r})=>r?"default":"pointer"};
`,nT=w(ci)`
  ${Cv}
  background: ${({$disabled:r=!1,theme:t})=>r?t.material:t.canvas};
  &:focus {
    outline: 0;
  }
`,iT=w.div`
  ${ua()}
  ${Cv}
  background: ${({$disabled:r=!1,theme:t})=>r?t.flatLight:t.canvas};
`,sT=w.select`
  -moz-appearance: none;
  -webkit-appearance: none;
  display: block;
  width: 100%;
  height: 100%;
  color: inherit;
  font-size: 1rem;
  border: 0;
  margin: 0;
  background: none;
  -webkit-tap-highlight-color: transparent;
  border-radius: 0;
  padding-right: 30px;
  ${Ev}
  cursor: pointer;
  &:disabled {
    ${Yn()};
    background: ${({theme:r})=>r.material};
    cursor: default;
  }
`,_v=w(Lu).attrs(()=>({"aria-hidden":"true"}))`
  width: 30px;
  padding: 0;
  flex-shrink: 0;
  ${({variant:r="default"})=>r==="flat"?ft`
          height: 100%;
          margin-right: 0;
        `:ft`
          height: 100%;
        `}
  ${({native:r=!1,variant:t="default"})=>r&&(t==="flat"?`
      position: absolute;
      right: 0;
      height: 100%;
      `:`
    position: absolute;
    top: 2px;
    right: 2px;
    height: calc(100% - 4px);
    `)}
    pointer-events: ${({$disabled:r=!1,native:t=!1})=>r||t?"none":"auto"}
`,aT=w.span`
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  width: 0;
  height: 0;
  border-left: 6px solid transparent;
  border-right: 6px solid transparent;
  display: inline-block;
  border-top: 6px solid
    ${({$disabled:r=!1,theme:t})=>r?t.materialTextDisabled:t.materialText};
  ${({$disabled:r=!1,theme:t})=>r&&`
    filter: drop-shadow(1px 1px 0px ${t.materialTextDisabledShadow});
    border-top-color: ${t.materialTextDisabled};
    `}
  ${_v}:active & {
    margin-top: 2px;
  }
`,rT=w.ul`
  box-sizing: border-box;

  font-size: 1rem;
  position: absolute;
  transform: translateY(100%);
  left: 0;
  background: ${({theme:r})=>r.canvas};
  padding: 2px;
  border-top: none;
  cursor: default;
  z-index: 1;
  cursor: pointer;
  box-shadow: ${mp};
  ${({variant:r="default"})=>r==="flat"?ft`
          bottom: 2px;
          width: 100%;
          border: 2px solid ${({theme:t})=>t.flatDark};
        `:ft`
          bottom: -2px;
          width: calc(100% - 2px);
          border: 2px solid ${({theme:t})=>t.borderDarkest};
        `}
  ${({variant:r="default"})=>yp(r)}
`,oT=w.li`
  box-sizing: border-box;

  width: 100%;
  padding-left: 8px;

  height: calc(${He.md} - 4px);
  line-height: calc(${He.md} - 4px);
  font-size: 1rem;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: ${({theme:r})=>r.canvasText};
  &:focus {
    outline: 0;
  }
  ${({active:r})=>r?Tv:""}
  user-select: none;
`,lT=[],kv=({className:r,defaultValue:t,disabled:e,native:s,onChange:a,options:l=lT,readOnly:c,style:d,value:h,variant:f,width:g})=>{var m;const x=j.useMemo(()=>l.filter(Boolean),[l]),[v,E]=Cs({defaultValue:t??((m=x?.[0])===null||m===void 0?void 0:m.value),onChange:a,readOnly:c,value:h}),S=!(e||c),C=j.useMemo(()=>({className:r,style:{...d,width:g}}),[r,d,g]),T=j.useMemo(()=>X.createElement(_v,{as:"div","data-testid":"select-button",$disabled:e,native:s,tabIndex:-1,variant:f==="flat"?"flat":"raised"},X.createElement(aT,{"data-testid":"select-icon",$disabled:e})),[e,s,f]),_=j.useMemo(()=>f==="flat"?iT:nT,[f]);return j.useMemo(()=>({isEnabled:S,options:x,value:v,setValue:E,wrapperProps:C,DropdownButton:T,Wrapper:_}),[T,_,S,x,E,v,C])},cT={ARROW_DOWN:"ArrowDown",ARROW_UP:"ArrowUp",END:"End",ENTER:"Enter",ESC:"Escape",HOME:"Home",SPACE:"Space",TAB:"Tab"},uT=1e3,dT=({onBlur:r,onChange:t,onClose:e,onFocus:s,onKeyDown:a,onMouseDown:l,onOpen:c,open:d,options:h,readOnly:f,value:g,selectRef:m,setValue:x,wrapperRef:v})=>{const E=j.useRef(null),S=j.useRef([]),C=j.useRef(0),T=j.useRef(0),_=j.useRef(),k=j.useRef("search"),R=j.useRef(""),D=j.useRef(),[L,O]=Cs({defaultValue:!1,onChange:c,onChangePropName:"onOpen",readOnly:f,value:d,valuePropName:"open"}),B=j.useMemo(()=>{const et=h.findIndex(xt=>xt.value===g);return C.current=ta(et,0,null),h[et]},[h,g]),[F,W]=j.useState(h[0]),Z=j.useCallback(et=>{const xt=E.current,ht=S.current[et];if(!ht||!xt){_.current=et;return}_.current=void 0;const Ct=xt.clientHeight,At=xt.scrollTop,yt=xt.scrollTop+Ct,Et=ht.offsetTop,Vt=ht.offsetHeight,Xt=ht.offsetTop+ht.offsetHeight;Et<At&&xt.scrollTo(0,Et),Xt>yt&&xt.scrollTo(0,Et-Ct+Vt),ht.focus({preventScroll:!0})},[E]),rt=j.useCallback((et,{scroll:xt}={})=>{var ht;const Ct=h.length-1;let At;switch(et){case"first":{At=0;break}case"last":{At=Ct;break}case"next":{At=ta(T.current+1,0,Ct);break}case"previous":{At=ta(T.current-1,0,Ct);break}case"selected":{At=ta((ht=C.current)!==null&&ht!==void 0?ht:0,0,Ct);break}default:At=et}T.current=At,W(h[At]),xt&&Z(At)},[T,h,Z]),dt=j.useCallback(({fromEvent:et})=>{O(!0),rt("selected",{scroll:!0}),c?.({fromEvent:et})},[rt,c,O]),lt=j.useCallback(()=>{k.current="search",R.current="",clearTimeout(D.current)},[]),ut=j.useCallback(({focusSelect:et,fromEvent:xt})=>{var ht;e?.({fromEvent:xt}),O(!1),W(h[0]),lt(),_.current=void 0,et&&((ht=m.current)===null||ht===void 0||ht.focus())},[lt,e,h,m,O]),P=j.useCallback(({fromEvent:et})=>{L?ut({focusSelect:!1,fromEvent:et}):dt({fromEvent:et})},[ut,dt,L]),V=j.useCallback((et,{fromEvent:xt})=>{C.current!==et&&(C.current=et,x(h[et].value),t?.(h[et],{fromEvent:xt}))},[t,h,x]),K=j.useCallback(({focusSelect:et,fromEvent:xt})=>{V(T.current,{fromEvent:xt}),ut({focusSelect:et,fromEvent:xt})},[ut,V]),ct=j.useCallback((et,{fromEvent:xt,select:ht})=>{var Ct;switch(k.current==="cycleFirstLetter"&&et!==R.current&&(k.current="search"),et===R.current?k.current="cycleFirstLetter":R.current+=et,k.current){case"search":{let At=h.findIndex(yt=>{var Et;return((Et=yt.label)===null||Et===void 0?void 0:Et.toLocaleUpperCase().indexOf(R.current))===0});At<0&&(At=h.findIndex(yt=>{var Et;return((Et=yt.label)===null||Et===void 0?void 0:Et.toLocaleUpperCase().indexOf(et))===0}),R.current=et),At>=0&&(ht?V(At,{fromEvent:xt}):rt(At,{scroll:!0}));break}case"cycleFirstLetter":{const At=ht?(Ct=C.current)!==null&&Ct!==void 0?Ct:-1:T.current;let yt=h.findIndex((Et,Vt)=>{var Xt;return Vt>At&&((Xt=Et.label)===null||Xt===void 0?void 0:Xt.toLocaleUpperCase().indexOf(et))===0});yt<0&&(yt=h.findIndex(Et=>{var Vt;return((Vt=Et.label)===null||Vt===void 0?void 0:Vt.toLocaleUpperCase().indexOf(et))===0})),yt>=0&&(ht?V(yt,{fromEvent:xt}):rt(yt,{scroll:!0}));break}}clearTimeout(D.current),D.current=setTimeout(()=>{k.current==="search"&&(R.current="")},uT)},[rt,h,V]),bt=j.useCallback(et=>{var xt;et.button===0&&(et.preventDefault(),(xt=m.current)===null||xt===void 0||xt.focus(),P({fromEvent:et}),l?.(et))},[l,m,P]),z=j.useCallback(et=>{K({focusSelect:!0,fromEvent:et})},[K]),H=j.useCallback(et=>{const{altKey:xt,code:ht,ctrlKey:Ct,metaKey:At,shiftKey:yt}=et,{ARROW_DOWN:Et,ARROW_UP:Vt,END:Xt,ENTER:Sn,ESC:Qe,HOME:In,SPACE:ui,TAB:En}=cT,ya=xt||Ct||At||yt;if(!(ht===En&&(xt||Ct||At)||ht!==En&&ya))switch(ht){case Et:{if(et.preventDefault(),!L){dt({fromEvent:et});return}rt("next",{scroll:!0});break}case Vt:{if(et.preventDefault(),!L){dt({fromEvent:et});return}rt("previous",{scroll:!0});break}case Xt:{if(et.preventDefault(),!L){dt({fromEvent:et});return}rt("last",{scroll:!0});break}case Sn:{if(!L)return;et.preventDefault(),K({focusSelect:!0,fromEvent:et});break}case Qe:{if(!L)return;et.preventDefault(),ut({focusSelect:!0,fromEvent:et});break}case In:{if(et.preventDefault(),!L){dt({fromEvent:et});return}rt("first",{scroll:!0});break}case ui:{et.preventDefault(),L?K({focusSelect:!0,fromEvent:et}):dt({fromEvent:et});break}case En:{if(!L)return;yt||et.preventDefault(),K({focusSelect:!yt,fromEvent:et});break}default:!ya&&ht.match(/^Key/)&&(et.preventDefault(),et.stopPropagation(),ct(ht.replace(/^Key/,""),{select:!L,fromEvent:et}))}},[rt,ut,L,dt,ct,K]),q=j.useCallback(et=>{H(et),a?.(et)},[H,a]),tt=j.useCallback(et=>{rt(et)},[rt]),st=j.useCallback(et=>{L||(lt(),r?.(et))},[lt,r,L]),ot=j.useCallback(et=>{lt(),s?.(et)},[lt,s]),at=j.useCallback(et=>{E.current=et,_.current!==void 0&&Z(_.current)},[Z]),kt=j.useCallback((et,xt)=>{S.current[xt]=et,_.current===xt&&Z(_.current)},[Z]);return j.useEffect(()=>{if(!L)return()=>{};const et=xt=>{var ht;const Ct=xt.target;!((ht=v.current)===null||ht===void 0)&&ht.contains(Ct)||(xt.preventDefault(),ut({focusSelect:!1,fromEvent:xt}))};return document.addEventListener("mousedown",et),()=>{document.removeEventListener("mousedown",et)}},[ut,L,v]),j.useMemo(()=>({activeOption:F,handleActivateOptionIndex:tt,handleBlur:st,handleButtonKeyDown:q,handleDropdownKeyDown:H,handleFocus:ot,handleMouseDown:bt,handleOptionClick:z,handleSetDropdownRef:at,handleSetOptionRef:kt,open:L,selectedOption:B}),[F,tt,st,q,ot,H,bt,z,at,kt,L,B])},hT=j.forwardRef(({className:r,defaultValue:t,disabled:e,onChange:s,options:a,readOnly:l,style:c,value:d,variant:h,width:f,...g},m)=>{const{isEnabled:x,options:v,setValue:E,value:S,DropdownButton:C,Wrapper:T}=kv({defaultValue:t,disabled:e,native:!0,onChange:s,options:a,readOnly:l,value:d,variant:h}),_=j.useCallback(k=>{const R=v.find(D=>D.value===k.target.value);R&&(E(R.value),s?.(R,{fromEvent:k}))},[s,v,E]);return X.createElement(T,{className:r,style:{...c,width:f}},X.createElement(Ap,null,X.createElement(sT,{...g,disabled:e,onChange:x?_:pa,ref:m,value:S},v.map((k,R)=>{var D;return X.createElement("option",{key:`${k.value}-${R}`,value:k.value},(D=k.label)!==null&&D!==void 0?D:k.value)})),C))});hT.displayName="SelectNative";function fT({activateOptionIndex:r,active:t,index:e,onClick:s,option:a,selected:l,setRef:c}){const d=j.useCallback(()=>{r(e)},[r,e]),h=j.useCallback(g=>{c(g,e)},[e,c]),f=Sv();return X.createElement(oT,{active:t,"aria-selected":l?"true":void 0,"data-value":a.value,id:f,onClick:s,onMouseEnter:d,ref:h,role:"option",tabIndex:0},a.label)}function pT({"aria-label":r,"aria-labelledby":t,className:e,defaultValue:s,disabled:a=!1,formatDisplay:l,inputProps:c,labelId:d,menuMaxHeight:h,name:f,onBlur:g,onChange:m,onClose:x,onFocus:v,onKeyDown:E,onMouseDown:S,onOpen:C,open:T,options:_,readOnly:k,shadow:R=!0,style:D,variant:L="default",value:O,width:B="auto",...F},W){const{isEnabled:Z,options:rt,setValue:dt,value:lt,wrapperProps:ut,DropdownButton:P,Wrapper:V}=kv({className:e,defaultValue:s,disabled:a,native:!1,onChange:m,options:_,style:D,readOnly:k,value:O,variant:L,width:B}),K=j.useRef(null),ct=j.useRef(null),bt=j.useRef(null),{activeOption:z,handleActivateOptionIndex:H,handleBlur:q,handleButtonKeyDown:tt,handleDropdownKeyDown:st,handleFocus:ot,handleMouseDown:at,handleOptionClick:kt,handleSetDropdownRef:et,handleSetOptionRef:xt,open:ht,selectedOption:Ct}=dT({onBlur:g,onChange:m,onClose:x,onFocus:v,onKeyDown:E,onMouseDown:S,onOpen:C,open:T,options:rt,value:lt,selectRef:ct,setValue:dt,wrapperRef:bt});j.useImperativeHandle(W,()=>({focus:Sn=>{var Qe;(Qe=ct.current)===null||Qe===void 0||Qe.focus(Sn)},node:K.current,value:String(lt)}),[lt]);const At=j.useMemo(()=>Ct?typeof l=="function"?l(Ct):Ct.label:"",[l,Ct]),yt=Z?1:void 0,Et=j.useMemo(()=>h?{overflow:"auto",maxHeight:h}:void 0,[h]),Vt=Sv(),Xt=j.useMemo(()=>rt.map((Sn,Qe)=>{const In=`${lt}-${Qe}`,ui=Sn===z,En=Sn===Ct;return X.createElement(fT,{activateOptionIndex:H,active:ui,index:Qe,key:In,onClick:kt,option:Sn,selected:En,setRef:xt})}),[z,H,kt,xt,rt,Ct,lt]);return X.createElement(V,{...ut,$disabled:a,ref:bt,shadow:R,style:{...D,width:B}},X.createElement("input",{name:f,ref:K,type:"hidden",value:String(lt),...c}),X.createElement(Ap,{"aria-disabled":a,"aria-expanded":ht,"aria-haspopup":"listbox","aria-label":r,"aria-labelledby":t??d,"aria-owns":Z&&ht?Vt:void 0,onBlur:q,onFocus:ot,onKeyDown:tt,onMouseDown:Z?at:S,ref:ct,role:"button",tabIndex:yt,...F},X.createElement(eT,null,At),P),Z&&ht&&X.createElement(rT,{id:Vt,onKeyDown:st,ref:et,role:"listbox",style:Et,tabIndex:0,variant:L},Xt))}const Mv=j.forwardRef(pT);Mv.displayName="Select";const gT=w.div`
  position: relative;
  display: flex;
  align-items: center;
  padding: ${r=>r.noPadding?"0":"4px"};
`,Vf=j.forwardRef(function({children:t,noPadding:e=!1,...s},a){return X.createElement(gT,{noPadding:e,ref:a,...s},t)});Vf.displayName="Toolbar";const mT=w.div`
  padding: 16px;
`,Dv=j.forwardRef(function({children:t,...e},s){return X.createElement(mT,{ref:s,...e},t)});Dv.displayName="WindowContent";const bT=w.div`
  height: 33px;
  line-height: 33px;
  padding-left: 0.25rem;
  padding-right: 3px;
  font-weight: bold;
  border: 2px solid ${({theme:r})=>r.material};
  ${({active:r})=>r===!1?ft`
          background: ${({theme:t})=>t.headerNotActiveBackground};
          color: ${({theme:t})=>t.headerNotActiveText};
        `:ft`
          background: ${({theme:t})=>t.headerBackground};
          color: ${({theme:t})=>t.headerText};
        `}

  ${Lu} {
    padding-left: 0;
    padding-right: 0;
    height: 27px;
    width: 31px;
  }
`,Rv=j.forwardRef(function({active:t=!0,children:e,...s},a){return X.createElement(bT,{active:t,ref:a,...s},e)});Rv.displayName="WindowHeader";const yT=w.div`
  position: relative;
  padding: 4px;
  font-size: 1rem;
  ${me({style:"window"})}
  ${Xn()}
`,xT=w.span`
  ${({theme:r})=>ft`
    display: inline-block;
    position: absolute;
    bottom: 10px;
    right: 10px;
    width: 25px;
    height: 25px;
    background-image: linear-gradient(
      135deg,
      ${r.borderLightest} 16.67%,
      ${r.material} 16.67%,
      ${r.material} 33.33%,
      ${r.borderDark} 33.33%,
      ${r.borderDark} 50%,
      ${r.borderLightest} 50%,
      ${r.borderLightest} 66.67%,
      ${r.material} 66.67%,
      ${r.material} 83.33%,
      ${r.borderDark} 83.33%,
      ${r.borderDark} 100%
    );
    background-size: 8.49px 8.49px;
    clip-path: polygon(100% 0px, 0px 100%, 100% 100%);
    cursor: nwse-resize;
  `}
`,Lv=j.forwardRef(({children:r,resizable:t=!1,resizeRef:e,shadow:s=!0,...a},l)=>X.createElement(yT,{ref:l,shadow:s,...a},r,t&&X.createElement(xT,{"data-testid":"resizeHandle",ref:e})));Lv.displayName="Window";const vT=w(gv)`
  width: 234px;
  margin: 1rem 0;
  background: ${({theme:r})=>r.canvas};
`,AT=w.div`
  display: flex;
  background: ${({theme:r})=>r.materialDark};
  color: #dfe0e3;
`,wT=w.div`
  display: flex;
  flex-wrap: wrap;
`,Mi=w.div`
  text-align: center;
  height: 1.5em;
  line-height: 1.5em;
  width: 14.28%;
`,ST=w.span`
  cursor: pointer;

  background: ${({active:r,theme:t})=>r?t.hoverBackground:"transparent"};
  color: ${({active:r,theme:t})=>r?t.canvasTextInvert:t.canvasText};

  &:hover {
    border: 2px dashed
      ${({theme:r,active:t})=>t?"none":r.materialDark};
  }
`,ET=[{value:0,label:"January"},{value:1,label:"February"},{value:2,label:"March"},{value:3,label:"April"},{value:4,label:"May"},{value:5,label:"June"},{value:6,label:"July"},{value:7,label:"August"},{value:8,label:"September"},{value:9,label:"October"},{value:10,label:"November"},{value:11,label:"December"}];function TT(r,t){return new Date(r,t+1,0).getDate()}function CT(r,t,e){return new Date(r,t,e).getDay()}function _T(r){const t=new Date(Date.parse(r)),e=t.getUTCDate(),s=t.getUTCMonth(),a=t.getUTCFullYear();return{day:e,month:s,year:a}}const kT=j.forwardRef(({className:r,date:t=new Date().toISOString(),onAccept:e,onCancel:s,shadow:a=!0},l)=>{const[c,d]=j.useState(()=>_T(t)),{year:h,month:f,day:g}=c,m=j.useCallback(({value:C})=>{d(T=>({...T,month:C}))},[]),x=j.useCallback(C=>{d(T=>({...T,year:C}))},[]),v=j.useCallback(C=>{d(T=>({...T,day:C}))},[]),E=j.useCallback(()=>{const C=[c.year,c.month+1,c.day].map(T=>String(T).padStart(2,"0")).join("-");e?.(C)},[c.day,c.month,c.year,e]),S=j.useMemo(()=>{const C=Array.from({length:42}),T=CT(h,f,1);let _=g;const k=TT(h,f);return _=_<k?_:k,C.forEach((R,D)=>{if(D>=T&&D<k+T){const L=D-T+1;C[D]=X.createElement(Mi,{key:D,onClick:()=>{v(L)}},X.createElement(ST,{active:L===_},L))}else C[D]=X.createElement(Mi,{key:D})}),C},[g,v,f,h]);return X.createElement(Lv,{className:r,ref:l,shadow:a,style:{margin:20}},X.createElement(Rv,null,X.createElement("span",{role:"img","aria-label":"📆"},"📆"),"Date"),X.createElement(Dv,null,X.createElement(Vf,{noPadding:!0,style:{justifyContent:"space-between"}},X.createElement(Mv,{options:ET,value:f,onChange:m,width:128,menuMaxHeight:200}),X.createElement(wv,{value:h,onChange:x,width:100})),X.createElement(vT,null,X.createElement(AT,null,X.createElement(Mi,null,"S"),X.createElement(Mi,null,"M"),X.createElement(Mi,null,"T"),X.createElement(Mi,null,"W"),X.createElement(Mi,null,"T"),X.createElement(Mi,null,"F"),X.createElement(Mi,null,"S")),X.createElement(wT,null,S)),X.createElement(Vf,{noPadding:!0,style:{justifyContent:"space-between"}},X.createElement(il,{fullWidth:!0,onClick:s,disabled:!s},"Cancel"),X.createElement(il,{fullWidth:!0,onClick:e?E:void 0,disabled:!e},"OK"))))});kT.displayName="DatePicker";const MT=r=>{switch(r){case"status":case"well":return ft`
        ${me({style:"status"})}
      `;case"window":case"outside":return ft`
        ${me({style:"window"})}
      `;case"field":return ft`
        ${me({style:"field"})}
      `;default:return ft`
        ${me()}
      `}},DT=w.div`
  position: relative;
  font-size: 1rem;
  ${({variant:r})=>MT(r)}
  ${({variant:r})=>Xn(r==="field"?{background:"canvas",color:"canvasText"}:void 0)}
`,RT=j.forwardRef(({children:r,shadow:t=!1,variant:e="window",...s},a)=>X.createElement(DT,{ref:a,shadow:t,variant:e,...s},r));RT.displayName="Frame";const LT=w.fieldset`
  position: relative;
  border: 2px solid
    ${({theme:r,variant:t})=>t==="flat"?r.flatDark:r.borderLightest};
  padding: 16px;
  margin-top: 8px;
  font-size: 1rem;
  color: ${({theme:r})=>r.materialText};
  ${({variant:r})=>r!=="flat"&&ft`
      box-shadow: -1px -1px 0 1px ${({theme:t})=>t.borderDark},
        inset -1px -1px 0 1px ${({theme:t})=>t.borderDark};
    `}
  ${r=>r.$disabled&&Yn()}
`,OT=w.legend`
  display: flex;
  position: absolute;
  top: 0;
  left: 8px;
  transform: translateY(calc(-50% - 2px));
  padding: 0 8px;

  font-size: 1rem;
  background: ${({theme:r,variant:t})=>t==="flat"?r.canvas:r.material};
`,jT=j.forwardRef(({label:r,disabled:t=!1,variant:e="default",children:s,...a},l)=>X.createElement(LT,{"aria-disabled":t,$disabled:t,variant:e,ref:l,...a},r&&X.createElement(OT,{variant:e},r),s));jT.displayName="GroupBox";const NT=w.div`
  ${({theme:r,size:t="100%"})=>`
  display: inline-block;
  box-sizing: border-box;
  height: ${Ts(t)};
  width: 5px;
  border-top: 2px solid ${r.borderLightest};
  border-left: 2px solid ${r.borderLightest};
  border-bottom: 2px solid ${r.borderDark};
  border-right: 2px solid ${r.borderDark};
  background: ${r.material};
`}
`;NT.displayName="Handle";const BT="url('data:image/gif;base64,R0lGODlhPAA8APQAADc3N6+vr4+Pj05OTvn5+V1dXZ+fn29vby8vLw8PD/X19d/f37S0tJSUlLq6und3d39/f9XV1c/Pz+bm5qamphkZGWZmZsbGxr+/v+rq6tra2u/v7yIiIv///wAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFBAAfACH+I1Jlc2l6ZWQgb24gaHR0cHM6Ly9lemdpZi5jb20vcmVzaXplACwAAAAAPAA8AAAF/+AnjmRpnmiqrmzrvnAsz3Rt37jr7Xzv/8BebhQsGn1D0XFZTH6YUGQySvU4fYKAdsvtdi1Cp3In6ZjP6HTawBMTyWbFYk6v18/snXvsKXciUApmeVZ7PH6ATIIdhHtPcB0TDQ1gQBCTBINthpBnAUEaa5tuh2mfQKFojZx9aRMSEhA7FLAbonqsfmoUOxFqmriknWm8Hr6/q8IeCAAAx2cTERG2aBTNHMGOj8a/v8WF2m/c3cSj4SQ8C92n4Ocm6evm7ui9CosdBPbs8yo8E2YO5PE74Q+gwIElCnYImA3hux3/Fh50yCciw3YUt2GQtiiDtGQO4f3al1GkGpIDeXlg0KDhXpoMLBtMVPaMnJlv/HjUtIkzHA8HEya4tLkhqICGV4bZVAMyaaul3ZpOUQoVz8wbpaoyvWojq1ZVXGt4/QoM49SnZMs6GktW6hC2X93mgKtVbtceWbzo9VIJKdYqUJwCPiJ4cJOzhg+/TWwko+PHkCNLdhgCACH5BAUEAB8ALAAAAAABAAEAAAUD4BcCACH5BAUEAB8ALBYADAAQAA0AAAVFYCeOZPmVaKqimeO+MPxFXv3d+F17Cm3nuJ1ic7lAdroapUjABZCfnQb4ef6k1OHGULtsNk3qjVKLiIFkj/mMIygU4VwIACH5BAUEAB8ALAAAAAABAAEAAAUD4BcCACH5BAUEAB8ALBkAIwAKAAcAAAUp4CdehrGI6Ed5XpSKa4teguBoGlVPAXuJBpam5/l9gh7NZrFQiDJMRQgAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsFgAPABAAIQAABVBgJ45kaZ5oakZB67bZ+M10bd94ru987//AoHBILNYYAsGlR/F4IkwnlLeZTBQ9UlaWwzweERHjuzAKFZkMYYZWm4mOw0ETfdanO8Vms7aFAAAh+QQFBAAfACwAAAAAAQABAAAFA+AXAgAh+QQFBAAfACwZABIACgAeAAAFUGAnjmRpnij5rerqtu4Hx3Rt33iu758iZrUZa1TDCASLGsXjiSiZzmFnM5n4TNJSdmREElfL5lO8cgwGACbgrAkwPat3+x1naggKRS+f/4QAACH5BAUEAB8ALAAAAAABAAEAAAUD4BcCACH5BAUEAB8ALBYAIwAQAA0AAAVE4CeOXdmNaGqeabu27SUIC5xSnifZKK7zl8djkCsIaylGziNaakaEzcbH/Cwl0k9kuWxyPYptzrZULA7otFpNIK1eoxAAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkEBQQAHwAsAAAAAAEAAQAABQPgFwIAIfkECQQAHwAsDgAEACAANAAABTHgJ45kaZ5oqq5s675wLM90bd94ru987//AoHBILBqPyKRyyWw6n9CodEqtWq/Y7CoEACH5BAUEAB8ALAAAAAA8ADwAAAX/4CeOZGmeaKqubFt6biy3Xj3fuFjveU/vPJ/wBAQOj6RiEClUGpk9IMAJxQEdmQK1Grt2OhutkvurOb7f8JaM8qLT4iKbuDu/0erxfOS+4+NPex9mfn55coIfCAuFhoBLbDUAjI1vh4FkOxSVd5eQXB4GnI5rXAAbo6R6VTUFqKmWjzasNaKwsaVIHhAEt3cLTjBQA6++XwoHuUM1vMYdyMorwoN8wkC2t9A8s102204Wxana3DNAAQO1FjUCEDXhvuTT5nUdEwOiGxa8BBDwXxKaLTiAKoMFRvJy9CmmoFcHAgrQSEiwKwICDwU0pAMQIdmnboR8TfwWrJyMPrAiz1DkNs2aSRbe6hnr99LEvDJ9IB5DQ8Dhm36glNh5COGBAmQNHrbz+WXBFChOTqFx5+GBxwYCmL1ZcPHmMiWuvkTgECzBBUvrvH4tErbDWCcYDB2IBPbV2yJJ72SZ46TtXSB5v2RIp1ZXXbFkgWxCc68mk752E3tY/OZeIsiIaxi9o+BBokGH3SZ+4FPbZ8yiPQxNeDl0hNUeHWcKjYb1Zx20bd/GzRaV7t28gRSYELvw7pIfgVcLplwF8+bOo0Ffjmm6zerWrxvPzoe79w8hAAAh+QQJBAAfACwBAAEAOgA6AAAFRuAnjmRpnmiqrmzrvnAsz3Rt33iu73zv/8CgcEgsGo/IpHLJbDqf0Kh0Sq1ar9isdsvter/gsHhMLpvP6LR6zW673/D4MgQAIfkEBQQAHwAsAAAAADwAPAAABf/gJ45kaZ5oqq5s675wLM90bd94ru987//AoHBILBqPyJxnyTQym6nn0ilVSa9XGHY7jXKx2m/WK36Gy1CUVCBpu9+OtNqDeNslgip5Gej4/4ATcidLAICHHQF6c0x9iH+CXV6Gj36KZnsejgsREQSACp0Yg0ydEZWWi4RPjgdLG48apEuogJeDJVKtr7GzHrV/t5KrjX6uHhQMF4cKCwujTxHOwKmYjHzGTw+VEVIK1MGqJrrZTNuP3U/f4IniuazlSwMUFMugE/j47NW4JOQdx9bsoybMgxV4ALEIGAis4MFiCZkUaLPgUAYHGDF+Yucw0y5z3Lzt63hNUzwP5xCRpWOyDhxJYtgiStBQEVCGAAEM6MLp0p0/hMdgIZI17AOTntZgmowo9BBRgz9/EfQ54h8BBS39bKDXwBc9CrVejkNYKRLUSWGpivhXtt9PSpXEvmNiwYDdu3jzFB3LAa9fAxbUGkXjtmSZh4TPJM4kRgbhvVEL9xhTEongJJgza97MubPnz6BDix5NurTp0yJCAAAh+QQJBAAfACwEAA4ANAAgAAAFMeAnjmRpnmiqrmzrvnAsz3Rt33iu73zv/8CgcEgsGo/IpHLJbDqf0Kh0Sq1ar9jsKgQAIfkEBQQAHwAsAAAAADwAPAAABf/gJ45kaZ5oqq5s6bVwLHu0bN8uXeM8rP+9YOoHFBpHRN1xmSwue02A82lrFjaOKbVl3XQ6WeWWm7x+v+HdeFj2ntHaNbL9jUAI5/RLTurWOR53eXFbfh0RgB4PCm9hfCKGiDSLb18Bjx+RiR4HjG8TA3trmkSdZxuhalSkRA2VBqpPrD+ulR0Go3SHmz8CeG8bFqJMupJNHr5nCsKxQccTg4oUNA0YCYG/HQQQYsSlnmCUFLUXgm8EAsPeP6Zf2baV2+rEmTrt8PDyzS7O9uD4b5YV2VGjGw52/wB+CaYjlQcpNBAQioHwy4QMCxe4i3BKGIQN3K7AArBATz8anUDADcgQDMGCbQkknDKAh4ABNxQ0gpnoQ8eDVAUO0ADAzUNMhbZMQiG4R4mOo0gb8eTCQgeEqJVM7juCDWvWJnI4ev2aZIwHl2PfZIBIZBXKtAsLgC1kJu0GuWXNaoB7d67ZlWP75jVLw4JXwW35PNSJFPFUrmIb402smFNCW44N5kJ5+dTkx+vuAfus+VHF0X4xzeHsObXq1ZY7ZN76mt0C0rRf1zuWW/du175PHAu+YjhxFcCPm6CsHHnv5kig6w4BACH5BAkEAB8ALAEAAQA6ADoAAAVG4CeOZGmeaKqubOu+cCzPdG3feK7vfO//wKBwSCwaj8ikcslsOp/QqHRKrVqv2Kx2y+16v+CweEwum8/otHrNbrvf8PgyBAAh+QQFBAAfACwAAAAAPAA8AAAF/+AnjmRpnmiqrmzrvnAsz3Rt37jr7Xzv/8BebhQsGn1D0XFZTH6YUGQySvU4fYKAdsvtdi1Cp3In6ZjP6HTawBMTyWbFYk6v18/snXvsKXciUApmeVZ7PH6ATIIdhHtPcB0TDQ1gQBCTBINthpBnAUEaa5tuh2mfQKFojZx9aRMSEhA7FLAbonqsfmoUOxFqmriknWm8Hr6/q8IeCAAAx2cTERG2aBTNHMGOj8a/v8WF2m/c3cSj4SQ8C92n4Ocm6evm7ui9CosdBPbs8yo8E2YO5PE74Q+gwIElCnYImA3hux3/Fh50yCciw3YUt2GQtiiDtGQO4f3al1GkGpIDeXlg0KDhXpoMLBtMVPaMnJlv/HjUtIkzHA8HEya4tLkhqICGV4bZVAMyaaul3ZpOUQoVz8wbpaoyvWojq1ZVXGt4/QoM49SnZMs6GktW6hC2X93mgKtVbtceWbzo9VIJKdYqUJwCPiJ4cJOzhg+/TWwko+PHkCNLdhgCACH5BAUEAB8ALAAAAAABAAEAAAUD4BcCADs=')",zT=w.div`
  display: inline-block;
  height: ${({size:r})=>Ts(r)};
  width: ${({size:r})=>Ts(r)};
`,PT=w.span`
  display: block;
  background: ${BT};
  background-size: cover;
  width: 100%;
  height: 100%;
`,IT=j.forwardRef(({size:r=30,...t},e)=>X.createElement(zT,{size:r,ref:e,...t},X.createElement(PT,null)));IT.displayName="Hourglass";const FT=w.div`
  position: relative;
  display: inline-block;
  padding-bottom: 26px;
`,$T=w.div`
  position: relative;
`,HT=w.div`
  position: relative;
  z-index: 1;
  box-sizing: border-box;
  width: 195px;
  height: 155px;
  padding: 12px;
  background: ${({theme:r})=>r.material};
  border-top: 4px solid ${({theme:r})=>r.borderLightest};
  border-left: 4px solid ${({theme:r})=>r.borderLightest};
  border-bottom: 4px solid ${({theme:r})=>r.borderDark};
  border-right: 4px solid ${({theme:r})=>r.borderDark};

  outline: 1px dotted ${({theme:r})=>r.material};
  outline-offset: -3px;
  &:before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    outline: 1px dotted ${({theme:r})=>r.material};
  }
  box-shadow: 1px 1px 0 1px ${({theme:r})=>r.borderDarkest};

  &:after {
    content: '';
    display: inline-block;
    position: absolute;
    bottom: 4px;
    right: 12px;
    width: 10px;
    border-top: 2px solid #4d9046;
    border-bottom: 2px solid #07ff00;
  }
`,UT=w(ci).attrs(()=>({"data-testid":"background"}))`
  width: 100%;
  height: 100%;
`,GT=w.div`
  box-sizing: border-box;
  position: absolute;
  top: calc(100% + 2px);
  left: 50%;
  transform: translateX(-50%);
  height: 10px;
  width: 50%;
  background: ${({theme:r})=>r.material};
  border-left: 2px solid ${({theme:r})=>r.borderLightest};
  border-bottom: 2px solid ${({theme:r})=>r.borderDarkest};
  border-right: 2px solid ${({theme:r})=>r.borderDarkest};
  box-shadow: inset 0px 0px 0px 2px ${({theme:r})=>r.borderDark};

  &:before {
    content: '';
    position: absolute;
    top: calc(100% + 2px);
    left: 50%;
    transform: translateX(-50%);
    width: 80%;
    height: 8px;
    background: ${({theme:r})=>r.material};
    border-left: 2px solid ${({theme:r})=>r.borderLightest};
    border-right: 2px solid ${({theme:r})=>r.borderDarkest};
    box-shadow: inset 0px 0px 0px 2px ${({theme:r})=>r.borderDark};
  }
  &:after {
    content: '';
    position: absolute;
    top: calc(100% + 8px);
    left: 50%;
    transform: translateX(-50%);
    width: 150%;
    height: 4px;
    background: ${({theme:r})=>r.material};
    border: 2px solid ${({theme:r})=>r.borderDark};
    border-bottom: none;
    box-shadow: inset 1px 1px 0px 1px ${({theme:r})=>r.borderLightest},
      1px 1px 0 1px ${({theme:r})=>r.borderDarkest};
  }
`,VT=j.forwardRef(({backgroundStyles:r,children:t,...e},s)=>X.createElement(FT,{ref:s,...e},X.createElement($T,null,X.createElement(HT,null,X.createElement(UT,{style:r},t)),X.createElement(GT,null))));VT.displayName="Monitor";const qT=w.div`
  display: inline-block;
  height: ${He.md};
  width: 100%;
`,YT=w(ci)`
  width: 100%;
  height: 100%;
  position: relative;
  text-align: center;
  padding: 0;
  overflow: hidden;
  &:before {
    z-index: 1;
  }
`,Ov=ft`
  width: calc(100% - 4px);
  height: calc(100% - 4px);

  display: flex;
  align-items: center;
  justify-content: space-around;
`,XT=w.div`
  position: relative;
  top: 4px;
  ${Ov}
  background: ${({theme:r})=>r.canvas};
  color: #000;
  margin-left: 2px;
  margin-top: -2px;
  color: ${({theme:r})=>r.materialText};
`,WT=w.div`
  position: absolute;
  top: 2px;
  left: 2px;
  ${Ov}
  color: ${({theme:r})=>r.materialTextInvert};
  background: ${({theme:r})=>r.progress};
  clip-path: polygon(
    0 0,
    ${({value:r=0})=>r}% 0,
    ${({value:r=0})=>r}% 100%,
    0 100%
  );
  transition: 0.4s linear clip-path;
`,QT=w.div`
  width: calc(100% - 6px);
  height: calc(100% - 8px);
  position: absolute;
  left: 3px;
  top: 4px;
  box-sizing: border-box;
  display: inline-flex;
`,jv=17,KT=w.span`
  display: inline-block;
  width: ${jv}px;
  box-sizing: border-box;
  height: 100%;
  background: ${({theme:r})=>r.progress};
  border-color: ${({theme:r})=>r.material};
  border-width: 0px 1px;
  border-style: solid;
`,ZT=j.forwardRef(({hideValue:r=!1,shadow:t=!0,value:e,variant:s="default",...a},l)=>{const c=r?null:`${e}%`,d=j.useRef(null),[h,f]=j.useState([]),g=j.useCallback(()=>{if(!d.current||e===void 0)return;const m=d.current.getBoundingClientRect().width,x=Math.round(e/100*m/jv);f(Array.from({length:x}))},[e]);return j.useEffect(()=>(g(),window.addEventListener("resize",g),()=>window.removeEventListener("resize",g)),[g]),X.createElement(qT,{"aria-valuenow":e!==void 0?Math.round(e):void 0,ref:l,role:"progressbar",variant:s,...a},X.createElement(YT,{variant:s,shadow:t},s==="default"?X.createElement(X.Fragment,null,X.createElement(XT,{"data-testid":"defaultProgress1"},c),X.createElement(WT,{"data-testid":"defaultProgress2",value:e},c)):X.createElement(QT,{ref:d,"data-testid":"tileProgress"},h.map((m,x)=>X.createElement(KT,{key:x})))))});ZT.displayName="ProgressBar";const Nv=ft`
  width: ${li}px;
  height: ${li}px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin-right: 0.5rem;
`,JT=w(ci)`
  ${Nv}
  background: ${({$disabled:r,theme:t})=>r?t.material:t.canvas};

  &:before {
    content: '';
    position: absolute;
    left: 0px;
    top: 0px;
    width: calc(100% - 4px);
    height: calc(100% - 4px);
    border-radius: 50%;
    box-shadow: none;
  }
`,tC=w.div`
  ${ua()}
  ${Nv}
  outline: none;
  background: ${({$disabled:r,theme:t})=>r?t.flatLight:t.canvas};
  &:before {
    content: '';
    display: inline-block;
    position: absolute;
    top: 0;
    left: 0;
    width: calc(100% - 4px);
    height: calc(100% - 4px);
    border: 2px solid ${({theme:r})=>r.flatDark};
    border-radius: 50%;
  }
`,eC=w.span.attrs(()=>({"data-testid":"checkmarkIcon"}))`
  position: absolute;
  content: '';
  display: inline-block;
  top: 50%;
  left: 50%;
  width: 6px;
  height: 6px;
  transform: translate(-50%, -50%);
  border-radius: 50%;
  background: ${r=>r.$disabled?r.theme.checkmarkDisabled:r.theme.checkmark};
`,nC={flat:tC,default:JT},iC=j.forwardRef(({checked:r,className:t="",disabled:e=!1,label:s="",onChange:a,style:l={},variant:c="default",...d},h)=>{const f=nC[c];return X.createElement(xp,{$disabled:e,className:t,style:l},X.createElement(f,{$disabled:e,role:"presentation"},r&&X.createElement(eC,{$disabled:e,variant:c})),X.createElement(vu,{disabled:e,onChange:e?void 0:a,readOnly:e,type:"radio",checked:r,ref:h,...d}),s&&X.createElement(vp,null,s))});iC.displayName="Radio";const sC=typeof window<"u"?j.useLayoutEffect:j.useEffect;function qs(r){const t=j.useRef(r);return sC(()=>{t.current=r}),j.useCallback((...e)=>(0,t.current)(...e),[])}function yy(r,t){typeof r=="function"?r(t):r&&(r.current=t)}function xy(r,t){return j.useMemo(()=>r==null&&t==null?null:e=>{yy(r,e),yy(t,e)},[r,t])}var aC=Vx();let Ou=!0,qf=!1,vy;const rC={text:!0,search:!0,url:!0,tel:!0,email:!0,password:!0,number:!0,date:!0,month:!0,week:!0,time:!0,datetime:!0,"datetime-local":!0};function oC(r){if("type"in r){const{type:t,tagName:e}=r;if(e==="INPUT"&&rC[t]&&!r.readOnly||e==="TEXTAREA"&&!r.readOnly)return!0}return!!("isContentEditable"in r&&r.isContentEditable)}function lC(r){r.metaKey||r.altKey||r.ctrlKey||(Ou=!0)}function mf(){Ou=!1}function cC(){this.visibilityState==="hidden"&&qf&&(Ou=!0)}function uC(r){r.addEventListener("keydown",lC,!0),r.addEventListener("mousedown",mf,!0),r.addEventListener("pointerdown",mf,!0),r.addEventListener("touchstart",mf,!0),r.addEventListener("visibilitychange",cC,!0)}function dC(r){const{target:t}=r;try{return t.matches(":focus-visible")}catch{}return Ou||oC(t)}function hC(){qf=!0,window.clearTimeout(vy),vy=window.setTimeout(()=>{qf=!1},100)}function fC(){const r=j.useCallback(t=>{const e=aC.findDOMNode(t);e!=null&&uC(e.ownerDocument)},[]);return{isFocusVisible:dC,onBlurVisible:hC,ref:r}}function pC(r,t,e){return(e-t)*r+t}function Ic(r,t){if(t!==void 0&&"changedTouches"in r){for(let e=0;e<r.changedTouches.length;e+=1){const s=r.changedTouches[e];if(s.identifier===t)return{x:s.clientX,y:s.clientY}}return!1}return"clientX"in r?{x:r.clientX,y:r.clientY}:!1}function Fc(r){return r&&r.ownerDocument||document}function gC(r,t){var e;const{index:s}=(e=r.reduce((a,l,c)=>{const d=Math.abs(t-l);return a===null||d<a.distance||d===a.distance?{distance:d,index:c}:a},null))!==null&&e!==void 0?e:{};return s??-1}const mC=w.div`
  display: inline-block;
  position: relative;
  touch-action: none;
  &:before {
    content: '';
    display: inline-block;
    position: absolute;
    top: -2px;
    left: -15px;
    width: calc(100% + 30px);
    height: ${({hasMarks:r})=>r?"41px":"39px"};
    ${({isFocused:r,theme:t})=>r&&`
        outline: 2px dotted ${t.materialText};
        `}
  }

  ${({orientation:r,size:t})=>r==="vertical"?ft`
          height: ${t};
          margin-right: 1.5rem;
          &:before {
            left: -6px;
            top: -15px;
            height: calc(100% + 30px);
            width: ${({hasMarks:e})=>e?"41px":"39px"};
          }
        `:ft`
          width: ${t};
          margin-bottom: 1.5rem;
          &:before {
            top: -2px;
            left: -15px;
            width: calc(100% + 30px);
            height: ${({hasMarks:e})=>e?"41px":"39px"};
          }
        `}

  pointer-events: ${({$disabled:r})=>r?"none":"auto"};
`,Bv=()=>ft`
  position: absolute;
  ${({orientation:r})=>r==="vertical"?ft`
          bottom: 0;
          left: 50%;
          transform: translateX(-50%);
          height: 100%;
          width: 8px;
        `:ft`
          left: 0;
          top: 50%;
          transform: translateY(-50%);
          height: 8px;
          width: 100%;
        `}
`,bC=w(ci)`
  ${Bv()}
`,yC=w(ci)`
  ${Bv()}

  border-left-color: ${({theme:r})=>r.flatLight};
  border-top-color: ${({theme:r})=>r.flatLight};
  border-right-color: ${({theme:r})=>r.canvas};
  border-bottom-color: ${({theme:r})=>r.canvas};
  &:before {
    border-left-color: ${({theme:r})=>r.flatDark};
    border-top-color: ${({theme:r})=>r.flatDark};
    border-right-color: ${({theme:r})=>r.flatLight};
    border-bottom-color: ${({theme:r})=>r.flatLight};
  }
`,xC=w.span`
  position: relative;
  ${({orientation:r})=>r==="vertical"?ft`
          width: 32px;
          height: 18px;
          right: 2px;
          transform: translateY(-50%);
        `:ft`
          height: 32px;
          width: 18px;
          top: 2px;
          transform: translateX(-50%);
        `}
  ${({variant:r})=>r==="flat"?ft`
          ${ua()}
          outline: 2px solid ${({theme:t})=>t.flatDark};
          background: ${({theme:t})=>t.flatLight};
        `:ft`
          ${Xn()}
          ${me()}
          &:focus {
            outline: none;
          }
        `}
    ${({$disabled:r,theme:t})=>r&&ul({mainColor:t.material,secondaryColor:t.borderLightest})}
`,Er=6,vC=w.span`
  display: inline-block;
  position: absolute;

  ${({orientation:r})=>r==="vertical"?ft`
          right: ${-Er-2}px;
          bottom: 0px;
          transform: translateY(1px);
          width: ${Er}px;
          border-bottom: 2px solid ${({theme:t})=>t.materialText};
        `:ft`
          bottom: ${-Er}px;
          height: ${Er}px;
          transform: translateX(-1px);
          border-left: 1px solid ${({theme:t})=>t.materialText};
          border-right: 1px solid ${({theme:t})=>t.materialText};
        `}

  color:  ${({theme:r})=>r.materialText};
  ${({$disabled:r,theme:t})=>r&&ft`
      ${Yn()}
      box-shadow: 1px 1px 0px ${t.materialTextDisabledShadow};
      border-color: ${t.materialTextDisabled};
    `}
`,AC=w.div`
  position: absolute;
  bottom: 0;
  left: 0;
  line-height: 1;
  font-size: 0.875rem;

  ${({orientation:r})=>r==="vertical"?ft`
          transform: translate(${Er+2}px, ${Er+1}px);
        `:ft`
          transform: translate(-0.5ch, calc(100% + 2px));
        `}
`,wC=j.forwardRef(({defaultValue:r,disabled:t=!1,marks:e=!1,max:s=100,min:a=0,name:l,onChange:c,onChangeCommitted:d,onMouseDown:h,orientation:f="horizontal",size:g="100%",step:m=1,value:x,variant:v="default",...E},S)=>{const C=v==="flat"?yC:bC,T=f==="vertical",[_=a,k]=Cs({defaultValue:r,onChange:c??d,value:x}),{isFocusVisible:R,onBlurVisible:D,ref:L}=fC(),[O,B]=j.useState(!1),F=j.useRef(),W=j.useRef(null),Z=xy(L,F),rt=xy(S,Z),dt=qs(q=>{R(q)&&B(!0)}),lt=qs(()=>{O!==!1&&(B(!1),D())}),ut=j.useRef(),P=j.useMemo(()=>e===!0&&Number.isFinite(m)?[...Array(Math.round((s-a)/m)+1)].map((q,tt)=>({label:void 0,value:a+m*tt})):Array.isArray(e)?e:[],[e,s,a,m]),V=qs(q=>{const tt=(s-a)/10,st=P.map(kt=>kt.value),ot=st.indexOf(_);let at=0;switch(q.key){case"Home":at=a;break;case"End":at=s;break;case"PageUp":m&&(at=_+tt);break;case"PageDown":m&&(at=_-tt);break;case"ArrowRight":case"ArrowUp":m?at=_+m:at=st[ot+1]||st[st.length-1];break;case"ArrowLeft":case"ArrowDown":m?at=_-m:at=st[ot-1]||st[0];break;default:return}q.preventDefault(),m&&(at=gy(at,m,a)),at=ta(at,a,s),k(at),B(!0),c?.(at),d?.(at)}),K=j.useCallback(q=>{if(!F.current)return 0;const tt=F.current.getBoundingClientRect();let st;T?st=(tt.bottom-q.y)/tt.height:st=(q.x-tt.left)/tt.width;let ot;if(ot=pC(st,a,s),m)ot=gy(ot,m,a);else{const at=P.map(et=>et.value),kt=gC(at,ot);ot=at[kt]}return ot=ta(ot,a,s),ot},[P,s,a,m,T]),ct=qs(q=>{var tt;const st=Ic(q,ut.current);if(!st)return;const ot=K(st);(tt=W.current)===null||tt===void 0||tt.focus(),k(ot),B(!0),c?.(ot)}),bt=qs(q=>{const tt=Ic(q,ut.current);if(!tt)return;const st=K(tt);d?.(st),ut.current=void 0;const ot=Fc(F.current);ot.removeEventListener("mousemove",ct),ot.removeEventListener("mouseup",bt),ot.removeEventListener("touchmove",ct),ot.removeEventListener("touchend",bt)}),z=qs(q=>{var tt;h?.(q),q.preventDefault(),(tt=W.current)===null||tt===void 0||tt.focus(),B(!0);const st=Ic(q,ut.current);if(st){const at=K(st);k(at),c?.(at)}const ot=Fc(F.current);ot.addEventListener("mousemove",ct),ot.addEventListener("mouseup",bt)}),H=qs(q=>{var tt;q.preventDefault();const st=q.changedTouches[0];st!=null&&(ut.current=st.identifier),(tt=W.current)===null||tt===void 0||tt.focus(),B(!0);const ot=Ic(q,ut.current);if(ot){const kt=K(ot);k(kt),c?.(kt)}const at=Fc(F.current);at.addEventListener("touchmove",ct),at.addEventListener("touchend",bt)});return j.useEffect(()=>{const{current:q}=F;q?.addEventListener("touchstart",H);const tt=Fc(q);return()=>{q?.removeEventListener("touchstart",H),tt.removeEventListener("mousemove",ct),tt.removeEventListener("mouseup",bt),tt.removeEventListener("touchmove",ct),tt.removeEventListener("touchend",bt)}},[bt,ct,H]),X.createElement(mC,{$disabled:t,hasMarks:!!P.length,isFocused:O,onMouseDown:z,orientation:f,ref:rt,size:Ts(g),...E},X.createElement("input",{disabled:t,name:l,type:"hidden",value:_??0}),P&&P.map(q=>X.createElement(vC,{$disabled:t,"data-testid":"tick",key:q.value/(s-a)*100,orientation:f,style:{[T?"bottom":"left"]:`${(q.value-a)/(s-a)*100}%`}},q.label&&X.createElement(AC,{"aria-hidden":!0,"data-testid":"mark",orientation:f},q.label))),X.createElement(C,{orientation:f,variant:v}),X.createElement(xC,{$disabled:t,"aria-disabled":t?!0:void 0,"aria-orientation":f,"aria-valuemax":s,"aria-valuemin":a,"aria-valuenow":_,onBlur:lt,onFocus:dt,onKeyDown:V,orientation:f,ref:W,role:"slider",style:{[T?"bottom":"left"]:`${(T?-100:0)+100*(_-a)/(s-a)}%`},tabIndex:t?void 0:0,variant:v}))});wC.displayName="Slider";const SC=w.tbody`
  background: ${({theme:r})=>r.canvas};
  display: table-row-group;
  box-shadow: ${bp};
  overflow-y: auto;
`,EC=j.forwardRef(function({children:t,...e},s){return X.createElement(SC,{ref:s,...e},t)});EC.displayName="TableBody";const TC=w.td`
  padding: 0 8px;
`,CC=j.forwardRef(function({children:t,...e},s){return X.createElement(TC,{ref:s,...e},t)});CC.displayName="TableDataCell";const _C=w.thead`
  display: table-header-group;
`,kC=j.forwardRef(function({children:t,...e},s){return X.createElement(_C,{ref:s,...e},t)});kC.displayName="TableHead";const MC=w.th`
  position: relative;
  padding: 0 8px;
  display: table-cell;
  vertical-align: inherit;
  background: ${({theme:r})=>r.material};
  cursor: default;
  user-select: none;
  &:before {
    box-sizing: border-box;
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    ${me()}

    border-left: none;
    border-top: none;
  }
  ${({$disabled:r})=>!r&&ft`
      &:active {
        &:before {
          ${me({invert:!0,style:"window"})}
          border-left: none;
          border-top: none;
          padding-top: 2px;
        }

        & > div {
          position: relative;
          top: 2px;
        }
      }
    `}

  color: ${({theme:r})=>r.materialText};
  ${({$disabled:r})=>r&&Yn()}
  &:hover {
    color: ${({theme:r})=>r.materialText};
    ${({$disabled:r})=>r&&Yn()}
  }
`,DC=j.forwardRef(function({disabled:t=!1,children:e,onClick:s,onTouchStart:a=pa,sort:l,...c},d){const h=l==="asc"?"ascending":l==="desc"?"descending":void 0;return X.createElement(MC,{$disabled:t,"aria-disabled":t,"aria-sort":h,onClick:t?void 0:s,onTouchStart:t?void 0:a,ref:d,...c},X.createElement("div",null,e))});DC.displayName="TableHeadCell";const RC=w.tr`
  color: inherit;
  display: table-row;
  height: calc(${He.md} - 2px);
  line-height: calc(${He.md} - 2px);
  vertical-align: middle;
  outline: none;

  color: ${({theme:r})=>r.canvasText};
  &:hover {
    background: ${({theme:r})=>r.hoverBackground};
    color: ${({theme:r})=>r.canvasTextInvert};
  }
`,LC=j.forwardRef(function({children:t,...e},s){return X.createElement(RC,{ref:s,...e},t)});LC.displayName="TableRow";const OC=w.table`
  display: table;
  width: 100%;
  border-collapse: collapse;
  border-spacing: 0;
  font-size: 1rem;
`,jC=w(ci)`
  &:before {
    box-shadow: none;
  }
`,NC=j.forwardRef(({children:r,...t},e)=>X.createElement(jC,null,X.createElement(OC,{ref:e,...t},r)));NC.displayName="Table";const BC=w.button`
  ${Xn()}
  ${me()}
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
  height: ${He.md};
  line-height: ${He.md};
  padding: 0 8px;
  border-bottom: none;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  margin: 0 0 -2px 0;
  cursor: default;
  color: ${({theme:r})=>r.materialText};
  user-select: none;
  font-family: inherit;
  &:focus:after,
  &:active:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    ${zr}
    outline-offset: -6px;
  }
  ${r=>r.selected&&`
    z-index: 1;
    height: calc(${He.md} + 4px);
    top: -4px;
    margin-bottom: -6px;
    padding: 0 16px;
    margin-left: -8px;
    &:not(:last-child) {
      margin-right: -8px;
    }
  `}
  &:before {
    content: '';
    position: absolute;
    width: calc(100% - 4px);
    height: 6px;
    background: ${({theme:r})=>r.material};
    bottom: -4px;
    left: 2px;
  }
`,zC=j.forwardRef(({value:r,onClick:t,selected:e=!1,children:s,...a},l)=>X.createElement(BC,{"aria-selected":e,selected:e,onClick:c=>t?.(r,c),ref:l,role:"tab",...a},s));zC.displayName="Tab";const PC=w.div`
  ${Xn()}
  ${me()}
  position: relative;
  display: block;
  height: 100%;
  padding: 16px;
  font-size: 1rem;
`,IC=j.forwardRef(({children:r,...t},e)=>X.createElement(PC,{ref:e,...t},r));IC.displayName="TabBody";const FC=w.div`
  position: relative;
  ${({isMultiRow:r,theme:t})=>r&&`
  button {
    flex-grow: 1;
  }
  button:last-child:before {
    border-right: 2px solid ${t.borderDark};
  }
  `}
`,$C=w.div.attrs(()=>({"data-testid":"tab-row"}))`
  position: relative;
  display: flex;
  flex-wrap: no-wrap;
  text-align: left;
  left: 8px;
  width: calc(100% - 8px);

  &:not(:first-child):before {
    content: '';
    position: absolute;
    right: 0;
    left: 0;
    height: 100%;
    border-right: 2px solid ${({theme:r})=>r.borderDarkest};
    border-left: 2px solid ${({theme:r})=>r.borderLightest};
  }
`;function HC(r,t){const e=[];for(let s=t;s>0;s-=1)e.push(r.splice(0,Math.ceil(r.length/s)));return e}const UC=j.forwardRef(({value:r,onChange:t=pa,children:e,rows:s=1,...a},l)=>{const c=j.useMemo(()=>{var d;const h=(d=X.Children.map(e,m=>{if(!X.isValidElement(m))return null;const x={selected:m.props.value===r,onClick:t};return X.cloneElement(m,x)}))!==null&&d!==void 0?d:[],f=HC(h,s).map((m,x)=>({key:x,tabs:m})),g=f.findIndex(m=>m.tabs.some(x=>x.props.selected));return f.push(f.splice(g,1)[0]),f},[e,t,s,r]);return X.createElement(FC,{...a,isMultiRow:s>1,role:"tablist",ref:l},c.map(d=>X.createElement($C,{key:d.key},d.tabs)))});UC.displayName="Tabs";const GC=["blur","focus"],VC=["click","contextmenu","doubleclick","drag","dragend","dragenter","dragexit","dragleave","dragover","dragstart","drop","mousedown","mouseenter","mouseleave","mousemove","mouseout","mouseover","mouseup"];function Ay(r){return"nativeEvent"in r&&GC.includes(r.type)}function wy(r){return"nativeEvent"in r&&VC.includes(r.type)}const qC={top:`top: -4px;
        left: 50%;
        transform: translate(-50%, -100%);`,bottom:`bottom: -4px;
           left: 50%;
           transform: translate(-50%, 100%);`,left:`left: -4px;
         top: 50%;
         transform: translate(-100%, -50%);`,right:`right: -4px;
          top: 50%;
          transform: translate(100%, -50%);`},YC=w.span`
  position: absolute;

  z-index: 1;
  display: ${r=>r.show?"block":"none"};
  padding: 4px;
  border: 2px solid ${({theme:r})=>r.borderDarkest};
  background: ${({theme:r})=>r.tooltip};
  box-shadow: ${mp};
  text-align: center;
  font-size: 1rem;
  ${r=>qC[r.position]}
`,XC=w.div`
  position: relative;
  display: inline-block;
  white-space: nowrap;
`,WC=j.forwardRef(({className:r,children:t,disableFocusListener:e=!1,disableMouseListener:s=!1,enterDelay:a=1e3,leaveDelay:l=0,onBlur:c,onClose:d,onFocus:h,onMouseEnter:f,onMouseLeave:g,onOpen:m,style:x,text:v,position:E="top",...S},C)=>{const[T,_]=j.useState(!1),[k,R]=j.useState(),[D,L]=j.useState(),O=!e,B=!s,F=K=>{window.clearTimeout(k),window.clearTimeout(D);const ct=window.setTimeout(()=>{_(!0),m?.(K)},a);R(ct)},W=K=>{K.persist(),Ay(K)?h?.(K):wy(K)&&f?.(K),F(K)},Z=K=>{window.clearTimeout(k),window.clearTimeout(D);const ct=window.setTimeout(()=>{_(!1),d?.(K)},l);L(ct)},rt=K=>{K.persist(),Ay(K)?c?.(K):wy(K)&&g?.(K),Z(K)},dt=O?rt:void 0,lt=O?W:void 0,ut=B?W:void 0,P=B?rt:void 0,V=O?0:void 0;return X.createElement(XC,{"data-testid":"tooltip-wrapper",onBlur:dt,onFocus:lt,onMouseEnter:ut,onMouseLeave:P,tabIndex:V},X.createElement(YC,{className:r,"data-testid":"tooltip",position:E,ref:C,show:T,style:x,...S},v),t)});WC.displayName="Tooltip";const Yf=w(vp)`
  white-space: nowrap;
`,zv=ft`
  :focus {
    outline: none;
  }

  ${({$disabled:r})=>r?"cursor: default;":ft`
          cursor: pointer;

          :focus {
            ${Yf} {
              background: ${({theme:t})=>t.hoverBackground};
              color: ${({theme:t})=>t.materialTextInvert};
              outline: 2px dotted ${({theme:t})=>t.focusSecondary};
            }
          }
        `}
`,QC=w.ul`
  position: relative;
  isolation: isolate;

  ${({isRootLevel:r})=>r&&ft`
      &:before {
        content: '';
        position: absolute;
        top: 20px;
        bottom: 0;
        left: 5.5px;
        width: 1px;
        border-left: 2px dashed ${({theme:t})=>t.borderDark};
      }
    `}

  ul {
    padding-left: 19.5px;
  }

  li {
    position: relative;

    &:before {
      content: '';
      position: absolute;
      top: 17.5px;
      left: 5.5px;
      width: 22px;
      border-top: 2px dashed ${({theme:r})=>r.borderDark};
      font-size: 12px;
    }
  }
`,KC=w.li`
  position: relative;
  padding-left: ${({hasItems:r})=>r?"0":"13px"};

  ${({isRootLevel:r})=>r?ft`
          &:last-child {
            &:after {
              content: '';
              position: absolute;
              top: 19.5px;
              left: 1px;
              bottom: 0;
              width: 10px;
              background: ${({theme:t})=>t.material};
            }
          }
        `:ft`
          &:last-child {
            &:after {
              content: '';
              position: absolute;
              z-index: 1;
              top: 19.5px;
              bottom: 0;
              left: 1.5px;
              width: 10px;
              background: ${({theme:t})=>t.material};
            }
          }
        `}

  & > details > ul {
    &:after {
      content: '';
      position: absolute;
      top: -18px;
      bottom: 0;
      left: 25px;
      border-left: 2px dashed ${({theme:r})=>r.borderDark};
    }
  }
`,ZC=w.details`
  position: relative;
  z-index: 2;

  &[open] > summary:before {
    content: '-';
  }
`,JC=w.summary`
  position: relative;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  color: ${({theme:r})=>r.materialText};
  user-select: none;
  padding-left: 18px;
  ${zv};

  &::-webkit-details-marker {
    display: none;
  }

  &:before {
    content: '+';
    position: absolute;
    left: 0;
    display: block;
    width: 8px;
    height: 9px;
    border: 2px solid #808080;
    padding-left: 1px;
    background-color: #fff;
    line-height: 8px;
    text-align: center;
  }
`,Sy=w(xp)`
  position: relative;
  z-index: 1;
  background: none;
  border: 0;
  font-family: inherit;
  padding-top: 8px;
  padding-bottom: 8px;
  margin: 0;
  ${zv};
`,t_=w.span`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  margin-right: 6px;
`;function Ey(r,t){return r.includes(t)?r.filter(e=>e!==t):[...r,t]}function Ty(r){r.preventDefault()}function Pv({className:r,disabled:t,expanded:e,innerRef:s,level:a,select:l,selected:c,style:d,tree:h=[]}){const f=a===0,g=j.useCallback(m=>{var x,v;const E=!!(m.items&&m.items.length>0),S=e.includes(m.id),C=(x=t||m.disabled)!==null&&x!==void 0?x:!1,T=C?Ty:D=>l(D,m),_=C?Ty:D=>l(D,m),k=c===m.id,R=X.createElement(t_,{"aria-hidden":!0},m.icon);return X.createElement(KC,{key:m.label,isRootLevel:f,role:"treeitem","aria-expanded":S,"aria-selected":k,hasItems:E},E?X.createElement(ZC,{open:S},X.createElement(JC,{onClick:T,$disabled:C},X.createElement(Sy,{$disabled:C},R,X.createElement(Yf,null,m.label))),S&&X.createElement(Pv,{className:r,disabled:C,expanded:e,level:a+1,select:l,selected:c,style:d,tree:(v=m.items)!==null&&v!==void 0?v:[]})):X.createElement(Sy,{as:"button",$disabled:C,onClick:_},R,X.createElement(Yf,null,m.label)))},[r,t,e,f,a,l,c,d]);return X.createElement(QC,{className:f?r:void 0,style:f?d:void 0,ref:f?s:void 0,role:f?"tree":"group",isRootLevel:f},h.map(g))}function e_({className:r,defaultExpanded:t=[],defaultSelected:e,disabled:s=!1,expanded:a,onNodeSelect:l,onNodeToggle:c,selected:d,style:h,tree:f=[]},g){const[m,x]=Cs({defaultValue:t,onChange:c,onChangePropName:"onNodeToggle",value:a,valuePropName:"expanded"}),[v,E]=Cs({defaultValue:e,onChange:l,onChangePropName:"onNodeSelect",value:d,valuePropName:"selected"}),S=j.useCallback((_,k)=>{if(c){const R=Ey(m,k);c(_,R)}x(R=>Ey(R,k))},[m,c,x]),C=j.useCallback((_,k)=>{E(k),l&&l(_,k)},[l,E]),T=j.useCallback((_,k)=>{_.preventDefault(),C(_,k.id),k.items&&k.items.length&&S(_,k.id)},[C,S]);return X.createElement(Pv,{className:r,disabled:s,expanded:m,level:0,innerRef:g,select:T,selected:v,style:h,tree:f})}const n_=j.forwardRef(e_);n_.displayName="TreeView";const i_=r=>{const t=j.useRef(null),e=j.useCallback(()=>{t.current||(t.current=new Audio(r)),t.current.currentTime=0,t.current.play().catch(()=>{console.log("Sound playback blocked by browser")})},[r]),s=j.useCallback(()=>{t.current&&(t.current.pause(),t.current.currentTime=0)},[]);return{play:e,stop:s}},s_=({onBootComplete:r,duration:t=6e3})=>{const e=j.useRef(!1),{play:s}=i_("/sounds/startup.mp3");return j.useEffect(()=>{e.current||(e.current=!0,s());const a=setTimeout(r,t);return()=>clearTimeout(a)},[t,r,s]),y.jsx(a_,{children:y.jsx(r_,{src:"/images/win95-boot.png",alt:"Windows 95"})})},a_=w.div`
  width: 100vw;
  height: 100vh;
  /* Sky gradient that matches the Windows 95 boot screen clouds */
  background: linear-gradient(
    180deg,
    #7eb4ea 0%,
    #a8cff0 15%,
    #c5dff5 30%,
    #d9ebf9 45%,
    #e8f3fc 60%,
    #d9ebf9 75%,
    #c5dff5 85%,
    #a8cff0 100%
  );
  display: flex;
  align-items: center;
  justify-content: center;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9999;
  overflow: hidden;
`,r_=w.img`
  /* Fill the viewport height, width auto-scales proportionally */
  height: 100vh;
  width: auto;
  min-width: 100vw;
  object-fit: cover;
  object-position: center;
`,o_=({openWindows:r,startMenuOpen:t,onStartClick:e,onWindowClick:s,onICQClick:a})=>{const[l,c]=j.useState(new Date),[d,h]=j.useState("connecting");j.useEffect(()=>{const g=setInterval(()=>{c(new Date)},1e3);return()=>clearInterval(g)},[]),j.useEffect(()=>{const g=setTimeout(()=>{h("online")},3e3);return()=>clearTimeout(g)},[]);const f=g=>g.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit",hour12:!0});return y.jsxs(l_,{children:[y.jsxs(c_,{onClick:g=>{g.stopPropagation(),e()},active:t,children:[y.jsx(u_,{src:"/icons/start.png",alt:""}),y.jsx(d_,{children:"Start"})]}),y.jsx(h_,{}),y.jsx(f_,{children:r.map(g=>y.jsxs(g_,{$active:g.isActive,onClick:()=>s?.(g.id),children:[g.icon&&y.jsx(p_,{src:g.icon,alt:""}),g.title]},g.id))}),y.jsxs(m_,{children:[y.jsx(y_,{$status:d,title:d==="online"?"ICQ - Online (Click to chat)":"ICQ - Connecting...",onClick:a,children:y.jsx(x_,{src:"/icons/icq-flower.png",alt:"ICQ",$status:d})}),y.jsx(v_,{children:"🔊"}),y.jsx(A_,{children:f(l)})]})]})},l_=w.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 30px;
  background-color: #c0c0c0;
  border-top: 2px solid #dfdfdf;
  display: flex;
  align-items: center;
  padding: 1px 2px;
  gap: 2px;
`,c_=w(il)`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  font-weight: bold;
  min-width: 60px;
  height: 26px;
`,u_=w.img`
  width: 18px;
  height: 18px;
  image-rendering: pixelated;
`,d_=w.span`
  font-size: 12px;
  font-weight: bold;
`,h_=w.div`
  width: 2px;
  height: 24px;
  background: linear-gradient(to right, #808080, #fff);
  margin: 0 2px;
`,f_=w.div`
  flex: 1;
  display: flex;
  gap: 2px;
  overflow: hidden;
`,p_=w.img`
  width: 16px;
  height: 16px;
  margin-right: 4px;
  image-rendering: pixelated;
`,g_=w.button`
  height: 26px;
  min-width: 130px;
  max-width: 170px;
  padding: 2px 8px;
  font-size: 12px;
  text-align: left;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: flex;
  align-items: center;
  background-color: ${r=>(r.$active,"#c0c0c0")};
  border: 2px solid;
  border-top-color: ${r=>r.$active?"#404040":"#fff"};
  border-left-color: ${r=>r.$active?"#404040":"#fff"};
  border-bottom-color: ${r=>r.$active?"#fff":"#404040"};
  border-right-color: ${r=>r.$active?"#fff":"#404040"};
  cursor: pointer;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:active {
    border-top-color: #404040;
    border-left-color: #404040;
    border-bottom-color: #fff;
    border-right-color: #fff;
  }
`,m_=w.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 2px 8px;
  border: 2px solid;
  border-top-color: #808080;
  border-left-color: #808080;
  border-bottom-color: #fff;
  border-right-color: #fff;
  height: 26px;
`,b_=ue`
  0%, 50% { opacity: 1; }
  51%, 100% { opacity: 0.3; }
`,y_=w.div`
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
`,x_=w.img`
  width: 18px;
  height: 18px;
  animation: ${r=>r.$status==="connecting"?b_:"none"} 0.5s ease-in-out infinite;
  filter: ${r=>r.$status==="connecting"?"grayscale(50%)":"none"};
`,v_=w.span`
  font-size: 14px;
`,A_=w.span`
  font-size: 12px;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
`,w_=({isOpen:r,onClose:t,onOpenApp:e})=>{const[s,a]=j.useState(null);if(!r)return null;const l=[{id:"icq",title:"ICQ",icon:"🌸"},{id:"homepage",title:"Fonchi's Homepage",icon:"🌐"},{id:"my-computer",title:"My Computer",icon:"💻"},{id:"cv-doc",title:"CV.doc",icon:"📄"},{id:"minesweeper",title:"Minesweeper",icon:"💣"}],c=h=>{if(h.id==="shutdown"){window.location.href="https://alfonso.ridao.ar";return}e(h.id,h.title),t()},d=()=>{window.location.href="https://alfonso.ridao.ar"};return y.jsxs(S_,{onClick:h=>h.stopPropagation(),children:[y.jsx(E_,{children:y.jsxs(T_,{children:[y.jsx("span",{style:{fontWeight:"bold"},children:"Windows"}),y.jsx("span",{style:{fontWeight:"normal"},children:"95"})]})}),y.jsxs(C_,{children:[y.jsxs(Ys,{onMouseEnter:()=>a("programs"),onMouseLeave:()=>a(null),children:[y.jsx(us,{children:"📁"}),y.jsx(ds,{children:"Programs"}),y.jsx(bf,{children:"▶"}),s==="programs"&&y.jsx(__,{children:l.map(h=>y.jsxs(k_,{onClick:()=>c(h),children:[y.jsx(us,{children:h.icon}),y.jsx(ds,{children:h.title})]},h.id))})]}),y.jsxs(Ys,{onClick:()=>c({id:"cv-doc",title:"CV.doc"}),children:[y.jsx(us,{children:"📂"}),y.jsx(ds,{children:"Documents"})]}),y.jsxs(Ys,{$disabled:!0,children:[y.jsx(us,{children:"⚙️"}),y.jsx(ds,{children:"Settings"}),y.jsx(bf,{children:"▶"})]}),y.jsxs(Ys,{$disabled:!0,children:[y.jsx(us,{children:"🔍"}),y.jsx(ds,{children:"Find"}),y.jsx(bf,{children:"▶"})]}),y.jsxs(Ys,{$disabled:!0,children:[y.jsx(us,{children:"❓"}),y.jsx(ds,{children:"Help"})]}),y.jsxs(Ys,{$disabled:!0,children:[y.jsx(us,{children:"📋"}),y.jsx(ds,{children:"Run..."})]}),y.jsx(M_,{}),y.jsxs(Ys,{onClick:d,children:[y.jsx(us,{children:"🔌"}),y.jsx(ds,{children:"Shut Down..."})]})]})]})},S_=w.div`
  position: absolute;
  bottom: 30px;
  left: 0;
  width: 200px;
  background: #c0c0c0;
  border: 2px solid;
  border-top-color: #fff;
  border-left-color: #fff;
  border-right-color: #404040;
  border-bottom-color: #404040;
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  display: flex;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  z-index: 10000;
`,E_=w.div`
  width: 22px;
  background: linear-gradient(180deg, #000080 0%, #1084d0 100%);
  display: flex;
  align-items: flex-end;
  padding-bottom: 4px;
`,T_=w.div`
  writing-mode: vertical-rl;
  text-orientation: mixed;
  transform: rotate(180deg);
  color: #c0c0c0;
  font-size: 18px;
  letter-spacing: 2px;
  padding: 4px;
`,C_=w.div`
  flex: 1;
  padding: 2px 0;
`,Ys=w.div`
  display: flex;
  align-items: center;
  padding: 4px 8px;
  gap: 8px;
  cursor: ${r=>r.$disabled?"default":"pointer"};
  position: relative;
  color: ${r=>r.$disabled?"#808080":"#000"};

  &:hover {
    background: ${r=>r.$disabled?"transparent":"#000080"};
    color: ${r=>r.$disabled?"#808080":"#fff"};
  }
`,us=w.span`
  font-size: 16px;
  width: 20px;
  text-align: center;
`,ds=w.span`
  flex: 1;
  font-size: 11px;
`,bf=w.span`
  font-size: 8px;
`,__=w.div`
  position: absolute;
  left: 100%;
  top: -2px;
  width: 180px;
  background: #c0c0c0;
  border: 2px solid;
  border-top-color: #fff;
  border-left-color: #fff;
  border-right-color: #404040;
  border-bottom-color: #404040;
  padding: 2px 0;
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
`,k_=w.div`
  display: flex;
  align-items: center;
  padding: 4px 8px;
  gap: 8px;
  cursor: pointer;

  &:hover {
    background: #000080;
    color: #fff;
  }
`,M_=w.div`
  height: 1px;
  background: #808080;
  margin: 4px 4px;
  border-bottom: 1px solid #fff;
`,ar=({id:r,icon:t,label:e,onDoubleClick:s})=>{const[a,l]=j.useState(!1),c=f=>{f.stopPropagation(),l(!0)},d=f=>{f.stopPropagation(),s(r,e)},h=()=>{l(!1)};return y.jsxs(D_,{onClick:c,onDoubleClick:d,onBlur:h,tabIndex:0,$selected:a,children:[y.jsx(R_,{$selected:a,children:y.jsx(L_,{src:t,alt:e,draggable:!1})}),y.jsx(O_,{$selected:a,children:e})]})},D_=w.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 75px;
  padding: 4px;
  cursor: default;
  outline: none;

  &:focus {
    outline: none;
  }
`,R_=w.div`
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: ${r=>r.$selected?"rgba(0, 0, 128, 0.5)":"transparent"};
`,L_=w.img`
  width: 48px;
  height: 48px;
  image-rendering: pixelated;
`,O_=w.span`
  font-size: 11px;
  color: #fff;
  text-align: center;
  margin-top: 4px;
  padding: 1px 2px;
  background-color: ${r=>r.$selected?"#000080":"transparent"};
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  text-shadow: ${r=>r.$selected?"none":"1px 1px 1px #000"};
  word-wrap: break-word;
  max-width: 70px;
`,j_=({id:r,title:t,icon:e,isActive:s,isMinimized:a,initialPosition:l={x:100,y:50},initialSize:c={width:400,height:300},onClose:d,onMinimize:h,onFocus:f,zIndex:g,children:m,showMenuBar:x=!0,showStatusBar:v=!0,statusText:E="",resizable:S=!0,noPadding:C=!1})=>{const[T,_]=j.useState(l),[k,R]=j.useState(c),[D,L]=j.useState(!1),[O,B]=j.useState(!1),[F,W]=j.useState(""),[Z,rt]=j.useState(!1),[dt,lt]=j.useState({x:0,y:0}),[ut,P]=j.useState({x:0,y:0,width:0,height:0,posX:0,posY:0}),V=j.useRef(null),K=j.useRef(T),ct=j.useRef(k);j.useEffect(()=>{const q=st=>{if(D&&!Z&&_({x:st.clientX-dt.x,y:Math.max(0,st.clientY-dt.y)}),O&&!Z){const ot=st.clientX-ut.x,at=st.clientY-ut.y,kt=200,et=150;let xt=ut.width,ht=ut.height,Ct=ut.posX,At=ut.posY;if(F.includes("e")&&(xt=Math.max(kt,ut.width+ot)),F.includes("w")){const yt=ut.width-ot;yt>=kt&&(xt=yt,Ct=ut.posX+ot)}if(F.includes("s")&&(ht=Math.max(et,ut.height+at)),F.includes("n")){const yt=ut.height-at;yt>=et&&(ht=yt,At=ut.posY+at)}R({width:xt,height:ht}),_({x:Ct,y:Math.max(0,At)})}},tt=()=>{L(!1),B(!1),W("")};return(D||O)&&(document.addEventListener("mousemove",q),document.addEventListener("mouseup",tt)),()=>{document.removeEventListener("mousemove",q),document.removeEventListener("mouseup",tt)}},[D,O,dt,ut,F,Z]);const bt=q=>{if(q.target.closest("button"))return;f(r),L(!0);const st=V.current?.getBoundingClientRect();st&&lt({x:q.clientX-st.left,y:q.clientY-st.top})},z=()=>{Z?(_(K.current),R(ct.current)):(K.current=T,ct.current=k,_({x:0,y:0}),R({width:window.innerWidth,height:window.innerHeight-30})),rt(!Z)},H=q=>tt=>{tt.preventDefault(),tt.stopPropagation(),f(r),B(!0),W(q),P({x:tt.clientX,y:tt.clientY,width:k.width,height:k.height,posX:T.x,posY:T.y})};return a?null:y.jsxs(P_,{ref:V,style:{left:T.x,top:T.y,width:k.width,height:k.height,zIndex:g},onClick:()=>f(r),children:[y.jsxs(I_,{$isActive:s,onMouseDown:bt,children:[y.jsxs(F_,{children:[e&&y.jsx($_,{src:e,alt:""}),y.jsx(H_,{children:t})]}),y.jsxs(U_,{children:[y.jsx(yf,{onClick:()=>h(r),title:"Minimize",children:y.jsx(N_,{})}),y.jsx(yf,{onClick:z,title:Z?"Restore":"Maximize",children:y.jsx(B_,{})}),y.jsx(yf,{onClick:()=>d(r),title:"Close",children:y.jsx(z_,{})})]})]}),x&&y.jsxs(G_,{children:[y.jsx($c,{children:"File"}),y.jsx($c,{children:"Edit"}),y.jsx($c,{children:"View"}),y.jsx($c,{children:"Help"})]}),y.jsx(V_,{$noPadding:C,children:m}),v&&y.jsx(q_,{children:y.jsx(Y_,{children:E})}),S&&!Z&&y.jsxs(y.Fragment,{children:[y.jsx(hs,{$direction:"n",onMouseDown:H("n")}),y.jsx(hs,{$direction:"s",onMouseDown:H("s")}),y.jsx(hs,{$direction:"e",onMouseDown:H("e")}),y.jsx(hs,{$direction:"w",onMouseDown:H("w")}),y.jsx(hs,{$direction:"ne",onMouseDown:H("ne")}),y.jsx(hs,{$direction:"nw",onMouseDown:H("nw")}),y.jsx(hs,{$direction:"se",onMouseDown:H("se")}),y.jsx(hs,{$direction:"sw",onMouseDown:H("sw")})]})]})},N_=()=>y.jsx("svg",{width:"8",height:"7",viewBox:"0 0 8 7",children:y.jsx("rect",{x:"0",y:"5",width:"6",height:"2",fill:"black"})}),B_=()=>y.jsxs("svg",{width:"9",height:"9",viewBox:"0 0 9 9",children:[y.jsx("rect",{x:"0",y:"0",width:"9",height:"9",fill:"none",stroke:"black",strokeWidth:"1"}),y.jsx("rect",{x:"0",y:"0",width:"9",height:"2",fill:"black"})]}),z_=()=>y.jsxs("svg",{width:"8",height:"7",viewBox:"0 0 8 7",children:[y.jsx("line",{x1:"0",y1:"0",x2:"8",y2:"7",stroke:"black",strokeWidth:"1.5"}),y.jsx("line",{x1:"8",y1:"0",x2:"0",y2:"7",stroke:"black",strokeWidth:"1.5"})]}),P_=w.div`
  position: absolute;
  background-color: #c0c0c0;
  border: 2px solid;
  border-top-color: #dfdfdf;
  border-left-color: #dfdfdf;
  border-right-color: #404040;
  border-bottom-color: #404040;
  box-shadow: 1px 1px 0 #000;
  display: flex;
  flex-direction: column;
`,I_=w.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 18px;
  padding: 2px 2px 2px 3px;
  background: ${r=>r.$isActive?"linear-gradient(90deg, #000080, #1084d0)":"linear-gradient(90deg, #808080, #b0b0b0)"};
  cursor: move;
  user-select: none;
`,F_=w.div`
  display: flex;
  align-items: center;
  gap: 3px;
  flex: 1;
  min-width: 0;
  overflow: hidden;
`,$_=w.img`
  width: 14px;
  height: 14px;
  image-rendering: pixelated;
`,H_=w.span`
  color: #fff;
  font-size: 11px;
  font-weight: bold;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`,U_=w.div`
  display: flex;
  gap: 2px;
`,yf=w.button`
  width: 16px;
  height: 14px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #c0c0c0;
  border: none;
  outline: none;
  cursor: pointer;
  box-shadow:
    inset -1px -1px 0 #404040,
    inset 1px 1px 0 #fff,
    inset -2px -2px 0 #808080,
    inset 2px 2px 0 #dfdfdf;

  &:active {
    box-shadow:
      inset 1px 1px 0 #404040,
      inset -1px -1px 0 #fff,
      inset 2px 2px 0 #808080,
      inset -2px -2px 0 #dfdfdf;
    padding-top: 1px;
    padding-left: 1px;
  }
`,G_=w.div`
  display: flex;
  background-color: #c0c0c0;
  padding: 2px 0;
  border-bottom: 1px solid #808080;
`,$c=w.span`
  padding: 2px 8px;
  font-size: 11px;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  cursor: pointer;

  &:hover {
    background-color: #000080;
    color: #fff;
  }
`,V_=w.div`
  flex: 1;
  background-color: ${r=>r.$noPadding?"#c0c0c0":"#fff"};
  border: ${r=>r.$noPadding?"none":"2px solid"};
  border-top-color: #808080;
  border-left-color: #808080;
  border-right-color: #dfdfdf;
  border-bottom-color: #dfdfdf;
  margin: ${r=>r.$noPadding?"0":"2px"};
  overflow: ${r=>r.$noPadding?"hidden":"auto"};
  padding: ${r=>r.$noPadding?"0":"4px"};
`,q_=w.div`
  display: flex;
  align-items: center;
  height: 18px;
  padding: 2px 4px;
  background-color: #c0c0c0;
  border-top: 1px solid #dfdfdf;
`,Y_=w.span`
  font-size: 11px;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  padding: 1px 4px;
  border: 1px solid;
  border-top-color: #808080;
  border-left-color: #808080;
  border-right-color: #fff;
  border-bottom-color: #fff;
  flex: 1;
`,X_=r=>{switch(r){case"n":case"s":return"ns-resize";case"e":case"w":return"ew-resize";case"ne":case"sw":return"nesw-resize";case"nw":case"se":return"nwse-resize";default:return"default"}},W_=r=>({n:"top: -3px; left: 4px; right: 4px; height: 6px;",s:"bottom: -3px; left: 4px; right: 4px; height: 6px;",e:"right: -3px; top: 4px; bottom: 4px; width: 6px;",w:"left: -3px; top: 4px; bottom: 4px; width: 6px;",ne:"top: -3px; right: -3px; width: 10px; height: 10px;",nw:"top: -3px; left: -3px; width: 10px; height: 10px;",se:"bottom: -3px; right: -3px; width: 10px; height: 10px;",sw:"bottom: -3px; left: -3px; width: 10px; height: 10px;"})[r]||"",hs=w.div`
  position: absolute;
  ${r=>W_(r.$direction)}
  cursor: ${r=>X_(r.$direction)};
  z-index: 10;
`,Q_=({id:r,icon:t,label:e,isSelected:s,onSelect:a})=>y.jsxs(t2,{$isSelected:s,onClick:l=>{l.stopPropagation(),a(r)},children:[y.jsx(e2,{src:t,alt:e,$isSelected:s}),y.jsx(n2,{$isSelected:s,children:e})]}),K_=()=>{const[r,t]=j.useState(null),e=[{id:"floppy",icon:"/icons/floppy.svg",label:"3½ Floppy (A:)"},{id:"c-drive",icon:"/icons/hard-drive.png",label:"(C:)"},{id:"d-drive",icon:"/icons/cd-drive.png",label:"New (D:)"},{id:"control-panel",icon:"/icons/control-panel.svg",label:"Control Panel"},{id:"printers",icon:"/icons/printer.png",label:"Printers"},{id:"dialup",icon:"/icons/dialup.png",label:"Dial-Up Networking"}],s=l=>{t(l===r?null:l)},a=()=>{t(null)};return y.jsx(Z_,{onClick:a,children:y.jsx(J_,{children:e.map(l=>y.jsx(Q_,{id:l.id,icon:l.icon,label:l.label,isSelected:r===l.id,onSelect:s},l.id))})})},Z_=w.div`
  width: 100%;
  height: 100%;
  background-color: #fff;
`,J_=w.div`
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 8px;
  align-content: flex-start;
`,t2=w.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 70px;
  padding: 4px;
  cursor: pointer;
`,e2=w.img`
  width: 32px;
  height: 32px;
  image-rendering: pixelated;
  background-color: ${r=>r.$isSelected?"#000080":"transparent"};
  padding: 2px;
`,n2=w.span`
  font-size: 11px;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  text-align: center;
  margin-top: 2px;
  padding: 1px 2px;
  background-color: ${r=>r.$isSelected?"#000080":"transparent"};
  color: ${r=>r.$isSelected?"#fff":"#000"};
  word-wrap: break-word;
  max-width: 68px;
`,Di=[{title:"You Can't Always Get What You Want",year:"1969",youtubeId:"oqMl5CRoFdk"},{title:"Out of Time",year:"1966",youtubeId:"2GIOuEBrXII"},{title:"Honky Tonk Women",year:"1969",youtubeId:"bKPwNhPiYJ4"},{title:"Paint It Black",year:"1966",youtubeId:"O4irXQhgMqg"},{title:"Let It Bleed",year:"1969",youtubeId:"cT-dJvVJyPU"},{title:"It's Only Rock and Roll",year:"1974",youtubeId:"mwvJwKRvnG4"}],i2=()=>{const[r,t]=j.useState(0),[e,s]=j.useState(!1),[a,l]=j.useState(70),[c,d]=j.useState(0),[h,f]=j.useState(0),g=j.useRef(null),m=j.useRef(null);j.useEffect(()=>{if(!window.YT){const B=document.createElement("script");B.src="https://www.youtube.com/iframe_api";const F=document.getElementsByTagName("script")[0];F.parentNode?.insertBefore(B,F)}return window.onYouTubeIframeAPIReady=()=>{x()},window.YT&&window.YT.Player&&x(),()=>{m.current&&clearInterval(m.current)}},[]);const x=()=>{g.current=new window.YT.Player("youtube-player",{height:"0",width:"0",videoId:Di[0].youtubeId,playerVars:{autoplay:0,controls:0},events:{onReady:v,onStateChange:E}})},v=B=>{B.target.setVolume(a)},E=B=>{B.data===window.YT.PlayerState.ENDED?k():B.data===window.YT.PlayerState.PLAYING?(s(!0),f(g.current?.getDuration()||0),S()):B.data===window.YT.PlayerState.PAUSED&&(s(!1),C())},S=()=>{m.current&&clearInterval(m.current),m.current=window.setInterval(()=>{g.current&&d(g.current.getCurrentTime()||0)},1e3)},C=()=>{m.current&&(clearInterval(m.current),m.current=null)},T=()=>{g.current&&(e?g.current.pauseVideo():((g.current.getCurrentTime()||0)<5&&g.current.seekTo(5,!0),g.current.playVideo()))},_=()=>{const B=r===0?Di.length-1:r-1;t(B),d(5),g.current&&g.current.loadVideoById({videoId:Di[B].youtubeId,startSeconds:5})},k=()=>{const B=(r+1)%Di.length;t(B),d(5),g.current&&g.current.loadVideoById({videoId:Di[B].youtubeId,startSeconds:5})},R=()=>{g.current&&(g.current.stopVideo(),s(!1),d(0),C())},D=B=>{const F=parseInt(B.target.value);l(F),g.current&&g.current.setVolume(F)},L=B=>{t(B),d(5),g.current&&g.current.loadVideoById({videoId:Di[B].youtubeId,startSeconds:5})},O=B=>{const F=Math.floor(B/60),W=Math.floor(B%60);return`${F}:${W.toString().padStart(2,"0")}`};return y.jsxs(r2,{children:[y.jsx("div",{id:"youtube-player",style:{display:"none"}}),y.jsxs(o2,{children:[y.jsx(l2,{children:"WINAMP"}),y.jsxs(c2,{children:[y.jsx(xf,{children:"_"}),y.jsx(xf,{children:"□"}),y.jsx(xf,{children:"×"})]})]}),y.jsxs(u2,{children:[y.jsxs(d2,{children:[y.jsx(h2,{children:O(c)}),y.jsx(f2,{children:[...Array(16)].map((B,F)=>y.jsx(p2,{$active:e,style:{animationDelay:`${F*.05}s`}},F))})]}),y.jsxs(g2,{children:[y.jsx(m2,{children:y.jsxs(b2,{$isPlaying:e,children:[Di[r].title," - The Rolling Stones (",Di[r].year,")"]})}),y.jsxs(y2,{children:[y.jsx(Cy,{children:"kbps"}),y.jsx(_y,{children:"128"}),y.jsx(Cy,{children:"kHz"}),y.jsx(_y,{children:"44"})]})]})]}),y.jsx(x2,{children:y.jsx(v2,{style:{width:h?`${c/h*100}%`:"0%"}})}),y.jsxs(A2,{children:[y.jsx(Hc,{onClick:_,title:"Previous",children:"⏮"}),y.jsx(Hc,{onClick:T,title:e?"Pause":"Play",$primary:!0,children:e?"⏸":"▶"}),y.jsx(Hc,{onClick:R,title:"Stop",children:"⏹"}),y.jsx(Hc,{onClick:k,title:"Next",children:"⏭"}),y.jsxs(w2,{children:[y.jsx(S2,{children:"VOL"}),y.jsx(E2,{type:"range",min:"0",max:"100",value:a,onChange:D})]})]}),y.jsxs(T2,{children:[y.jsx(C2,{children:y.jsx(_2,{children:"🎵 PLAYLIST 🎵"})}),y.jsx(k2,{children:Di.map((B,F)=>y.jsxs(M2,{$active:F===r,onClick:()=>L(F),children:[y.jsxs(D2,{children:[F+1,"."]}),y.jsx(R2,{children:B.title}),y.jsxs(L2,{children:["(",B.year,")"]})]},F))})]})]})},s2=ue`
  0% { transform: translateX(100%); }
  100% { transform: translateX(-100%); }
`,a2=ue`
  0%, 100% { height: 3px; }
  50% { height: 15px; }
`,r2=w.div`
  background: linear-gradient(180deg, #3a3a50 0%, #28283a 100%);
  border: 2px solid #555;
  border-radius: 3px;
  padding: 5px;
  max-width: 350px;
  margin: 20px auto;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  box-shadow:
    inset 1px 1px 0 #666,
    inset -1px -1px 0 #222,
    3px 3px 10px rgba(0,0,0,0.5);
`,o2=w.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: linear-gradient(180deg, #4a4a6a 0%, #3a3a50 100%);
  padding: 2px 5px;
  border-bottom: 1px solid #222;
`,l2=w.span`
  color: #00ff00;
  font-size: 10px;
  font-weight: bold;
  letter-spacing: 1px;
`,c2=w.div`
  display: flex;
  gap: 2px;
`,xf=w.button`
  width: 12px;
  height: 12px;
  font-size: 8px;
  background: #555;
  border: 1px solid;
  border-color: #777 #333 #333 #777;
  color: #ccc;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  line-height: 1;
`,u2=w.div`
  display: flex;
  background: #000;
  border: 2px solid;
  border-color: #222 #444 #444 #222;
  margin: 5px 0;
  padding: 5px;
  min-height: 50px;
`,d2=w.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-right: 10px;
  border-right: 1px solid #333;
`,h2=w.div`
  color: #00ff00;
  font-family: 'Courier New', monospace;
  font-size: 16px;
  font-weight: bold;
  text-shadow: 0 0 5px #00ff00;
`,f2=w.div`
  display: flex;
  gap: 2px;
  align-items: flex-end;
  height: 20px;
  margin-top: 5px;
`,p2=w.div`
  width: 3px;
  background: linear-gradient(180deg, #00ff00 0%, #008800 100%);
  animation: ${r=>r.$active?a2:"none"} 0.3s ease-in-out infinite;
  height: 3px;
`,g2=w.div`
  flex: 1;
  padding-left: 10px;
  overflow: hidden;
`,m2=w.div`
  overflow: hidden;
  white-space: nowrap;
`,b2=w.div`
  color: #00ff00;
  font-size: 11px;
  animation: ${r=>r.$isPlaying?s2:"none"} 10s linear infinite;
  display: inline-block;
`,y2=w.div`
  display: flex;
  gap: 5px;
  margin-top: 8px;
`,Cy=w.span`
  color: #888;
  font-size: 8px;
`,_y=w.span`
  color: #00ff00;
  font-size: 10px;
  font-weight: bold;
`,x2=w.div`
  height: 8px;
  background: #222;
  border: 1px solid;
  border-color: #111 #444 #444 #111;
  margin: 5px 0;
`,v2=w.div`
  height: 100%;
  background: linear-gradient(180deg, #00ff00 0%, #008800 100%);
  transition: width 0.5s linear;
`,A2=w.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  padding: 5px;
`,Hc=w.button`
  width: ${r=>r.$primary?"35px":"28px"};
  height: ${r=>r.$primary?"25px":"22px"};
  font-size: ${r=>r.$primary?"14px":"12px"};
  background: linear-gradient(180deg, #555 0%, #333 100%);
  border: 2px solid;
  border-color: #666 #222 #222 #666;
  color: #00ff00;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;

  &:hover {
    background: linear-gradient(180deg, #666 0%, #444 100%);
  }

  &:active {
    border-color: #222 #666 #666 #222;
  }
`,w2=w.div`
  display: flex;
  align-items: center;
  gap: 5px;
  margin-left: 10px;
`,S2=w.span`
  color: #888;
  font-size: 8px;
`,E2=w.input`
  width: 60px;
  height: 8px;
  -webkit-appearance: none;
  background: #222;
  border: 1px solid #444;
  cursor: pointer;

  &::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 8px;
    height: 14px;
    background: #00ff00;
    border: 1px solid #008800;
    cursor: pointer;
  }
`,T2=w.div`
  background: #1a1a2a;
  border: 2px solid;
  border-color: #222 #444 #444 #222;
  margin-top: 5px;
`,C2=w.div`
  background: linear-gradient(180deg, #3a3a50 0%, #28283a 100%);
  padding: 3px 5px;
  border-bottom: 1px solid #222;
`,_2=w.div`
  color: #00ff00;
  font-size: 9px;
  text-align: center;
`,k2=w.div`
  max-height: 120px;
  overflow-y: auto;
`,M2=w.div`
  display: flex;
  gap: 5px;
  padding: 3px 5px;
  cursor: pointer;
  background: ${r=>r.$active?"#004400":"transparent"};
  color: ${r=>r.$active?"#00ff00":"#888"};
  font-size: 10px;

  &:hover {
    background: ${r=>r.$active?"#004400":"#2a2a3a"};
    color: #00ff00;
  }
`,D2=w.span`
  color: #666;
  width: 15px;
`,R2=w.span`
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`,L2=w.span`
  color: #666;
  font-size: 9px;
`,wp="https://7sv2xijrq7.execute-api.eu-west-2.amazonaws.com";async function O2(){const r=await fetch(`${wp}/api/guestbook`,{method:"GET",headers:{"Content-Type":"application/json"}});if(!r.ok)throw new Error("Failed to fetch guestbook entries");return r.json()}async function j2(){const r=await fetch(`${wp}/api/guestbook`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"visit"})});if(!r.ok)throw new Error("Failed to record visit");return r.json()}async function N2(r,t){const e=await fetch(`${wp}/api/guestbook`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:r,message:t})});if(!e.ok){const s=await e.json();throw new Error(s.error||"Failed to submit entry")}return e.json()}const B2=()=>{const[r,t]=j.useState([]),[e,s]=j.useState(1337),[a,l]=j.useState(!0),[c,d]=j.useState(!1),[h,f]=j.useState(null),[g,m]=j.useState(null),[x,v]=j.useState(""),[E,S]=j.useState(""),[C,T]=j.useState(!1);j.useEffect(()=>{(async()=>{try{const D=await j2();s(D.visitorCount);const L=await O2();t(L.entries)}catch(D){console.error("Failed to load guestbook:",D)}finally{l(!1)}})()},[]);const _=async R=>{if(R.preventDefault(),f(null),m(null),!x.trim()||!E.trim()){f("Please fill in both name and message!");return}d(!0);try{const D=await N2(x.trim(),E.trim());t([D.entry,...r]),v(""),S(""),T(!1),m("Thanks for signing my guestbook! You rock! 🎸"),setTimeout(()=>m(null),5e3)}catch(D){f(D instanceof Error?D.message:"Failed to submit. Try again!")}finally{d(!1)}},k=R=>String(R).padStart(6,"0");return y.jsxs(G2,{children:[y.jsxs(V2,{children:[y.jsx(q2,{children:y.jsx(Y2,{children:"*** Welcome to Fonchi's Cyber Corner of the Information Superhighway! *** Your #1 Source for Coding, BTTF & Retro Awesomeness! *** Last Updated: December 31, 1999 ***"})}),y.jsxs(X2,{children:[y.jsx(ky,{children:"🔥".repeat(15)}),y.jsxs(W2,{children:[y.jsx(Q2,{children:"Fonchi's"}),y.jsx(K2,{children:"HOMEPAGE"})]}),y.jsx(Z2,{children:"~ Established 1995 ~"}),y.jsx(ky,{children:"🔥".repeat(15)})]}),y.jsxs(J2,{children:[y.jsx(My,{children:"You are visitor #"}),y.jsx(tk,{children:y.jsx(ek,{children:k(e)})}),y.jsx(My,{children:"since 1995!"})]}),y.jsxs(nk,{children:[y.jsxs(ik,{children:[y.jsx(Dy,{children:"N"}),y.jsxs(Ry,{children:["Netscape",y.jsx("br",{}),"NOW!"]})]}),y.jsxs(sk,{children:[y.jsx(Dy,{children:"e"}),y.jsxs(Ry,{children:["Best with",y.jsx("br",{}),"IE 4.0"]})]}),y.jsx(ak,{children:"800x600"}),y.jsxs(rk,{children:["Y2K",y.jsx("br",{}),"READY!"]})]}),y.jsxs(ok,{children:[y.jsxs(Ly,{href:"https://www.linkedin.com/in/alfonsoridao/",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(Oy,{}),y.jsxs(jy,{children:[y.jsx(Ny,{children:"👔"}),y.jsx("span",{children:"LinkedIn"})]})]}),y.jsx(uk,{children:"✦ ✦ ✦"}),y.jsxs(Ly,{href:"https://www.instagram.com/alfonsoridao/",target:"_blank",rel:"noopener noreferrer",$gradient:!0,children:[y.jsx(Oy,{}),y.jsxs(jy,{children:[y.jsx(Ny,{children:"📷"}),y.jsx("span",{children:"Instagram"})]})]})]})]}),y.jsxs(dk,{children:[y.jsx(hk,{children:"*** NAVIGATION ***"}),y.jsxs(fk,{children:[y.jsx(Xs,{href:"#about",children:"[About Me]"}),y.jsx(Xs,{href:"#90sweb",children:"[90s Web]"}),y.jsx(Xs,{href:"#bttf",children:"[BTTF]"}),y.jsx(Xs,{href:"#coding",children:"[Coding]"}),y.jsx(Xs,{href:"#gaming",children:"[Gaming]"}),y.jsx(Xs,{href:"#music",children:"[Music]"}),y.jsx(Xs,{href:"#guestbook",children:"[Guestbook]"})]})]}),y.jsxs(pk,{children:[y.jsxs(fs,{id:"about",children:[y.jsxs(ps,{children:[y.jsx(By,{children:"✦ NEW! ✦"}),y.jsx(gs,{children:"About The Webmaster"}),y.jsx(By,{children:"✦ NEW! ✦"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(gk,{children:[y.jsxs(mk,{children:[y.jsx(bk,{children:`  ▓▓▓▓▓▓
 ▓░░░░░░▓
▓░▓░░░░▓░▓
▓░░░░░░░░▓
▓░░▓▓▓▓░░▓
▓░░░░░░░░▓
 ▓░░░░░░▓
  ▓▓▓▓▓▓  `}),y.jsx(yk,{children:"~ Fonchi ~"})]}),y.jsxs(xk,{children:[y.jsx(vk,{children:"Greetings, fellow Netizen!"}),y.jsxs("p",{children:["Welcome to my little corner of cyberspace! I'm ",y.jsx("strong",{children:"Fonchi"}),", a software developer, BTTF superfan, and time-travel enthusiast from the future."]}),y.jsx("p",{children:"I spend my days writing code in Pascal, C, and JavaScript, playing retro games, and dreaming about DeLoreans."}),y.jsxs(Ak,{children:[y.jsx(zy,{children:"✉"}),y.jsxs(wk,{children:["E-Mail me at: ",y.jsx(Py,{href:"mailto:alfonso@ridao.ar",children:"alfonso@ridao.ar"})]})]})]})]})]}),y.jsx(Ws,{children:y.jsx(Qs,{})}),y.jsxs(fs,{id:"90sweb",children:[y.jsxs(ps,{children:[y.jsx(Iy,{children:"🌐"}),y.jsx(gs,{children:"90s WEB NOSTALGIA"}),y.jsx(Iy,{children:"🌐"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(Sk,{children:[y.jsx(Ek,{children:"Remember when the internet was simple and fun?"}),y.jsxs(Tk,{children:[y.jsxs(Uc,{children:[y.jsx(Gc,{children:"📧"}),y.jsx(Vc,{children:"You've Got Mail!"}),y.jsx(qc,{children:"AOL dialup sounds"})]}),y.jsxs(Uc,{children:[y.jsx(Gc,{children:"💬"}),y.jsx(Vc,{children:"ICQ & MSN"}),y.jsx(qc,{children:"Uh-oh! messages"})]}),y.jsxs(Uc,{children:[y.jsx(Gc,{children:"🏠"}),y.jsx(Vc,{children:"GeoCities"}),y.jsx(qc,{children:"Free homepages!"})]}),y.jsxs(Uc,{children:[y.jsx(Gc,{children:"🔍"}),y.jsx(Vc,{children:"AltaVista"}),y.jsx(qc,{children:"Before Google"})]})]}),y.jsxs(Ck,{children:[y.jsx(_k,{children:"🌟 COOL SITES OF THE 90s 🌟"}),y.jsx(Mk,{children:"Click to visit! (Opens in new window)"}),y.jsxs(kk,{children:[y.jsxs(rr,{href:"https://www.spacejam.com/1996/",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(or,{children:"🏀"}),y.jsxs(lr,{children:[y.jsx(cr,{children:"Space Jam"}),y.jsx(ur,{children:"Still online since 1996! The original site!"})]})]}),y.jsxs(rr,{href:"https://www.oocities.org/",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(or,{children:"🏠"}),y.jsxs(lr,{children:[y.jsx(cr,{children:"GeoCities Archive"}),y.jsx(ur,{children:"Preserved GeoCities pages - explore the past!"})]})]}),y.jsxs(rr,{href:"https://theoldnet.com/",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(or,{children:"🌐"}),y.jsxs(lr,{children:[y.jsx(cr,{children:"TheOldNet"}),y.jsx(ur,{children:"Browse the web like it's 1999!"})]})]}),y.jsxs(rr,{href:"https://www.cameronsworld.net/",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(or,{children:"✨"}),y.jsxs(lr,{children:[y.jsx(cr,{children:"Cameron's World"}),y.jsx(ur,{children:"Beautiful GeoCities collage tribute"})]})]}),y.jsxs(rr,{href:"https://poolsuite.net/",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(or,{children:"🏖️"}),y.jsxs(lr,{children:[y.jsx(cr,{children:"Poolsuite FM"}),y.jsx(ur,{children:"Retro vacation vibes & music"})]})]}),y.jsxs(rr,{href:"https://wiby.me/",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(or,{children:"🔍"}),y.jsxs(lr,{children:[y.jsx(cr,{children:"Wiby.me"}),y.jsx(ur,{children:"Search engine for old-style websites"})]})]})]})]})]})]}),y.jsx(Ws,{children:y.jsx(Qs,{})}),y.jsxs(fs,{id:"bttf",children:[y.jsxs(ps,{children:[y.jsx(Fy,{children:"⚡"}),y.jsx(gs,{children:"BACK TO THE FUTURE FAN ZONE"}),y.jsx(Fy,{children:"⚡"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(Dk,{children:[y.jsxs($k,{children:[y.jsx(Ef,{src:"https://media.giphy.com/media/7TZvWKVkm0xXi/giphy.gif",alt:"DeLorean"}),y.jsx(Ef,{src:"https://media.giphy.com/media/xsF1FSDbjguis/giphy.gif",alt:"Doc Brown"})]}),y.jsx(Rk,{children:`"Roads? Where we're going, we don't need roads."`}),y.jsx(Lk,{children:"- Dr. Emmett Brown"}),y.jsxs(Ok,{children:[y.jsx(jk,{children:"⚡ TIME CIRCUITS ⚡"}),y.jsxs(Nk,{children:[y.jsxs(vf,{children:[y.jsx(Af,{$color:"#ff0000",children:"DESTINATION TIME"}),y.jsx(wf,{$color:"#ff0000",children:"OCT 21 2015 04:29"})]}),y.jsxs(vf,{children:[y.jsx(Af,{$color:"#00ff00",children:"PRESENT TIME"}),y.jsx(wf,{$color:"#00ff00",children:"NOV 05 1955 06:15"})]}),y.jsxs(vf,{children:[y.jsx(Af,{$color:"#ffff00",children:"LAST TIME DEPARTED"}),y.jsx(wf,{$color:"#ffff00",children:"OCT 26 1985 01:21"})]})]})]}),y.jsx(Bk,{children:y.jsx(zk,{children:"1.21 GIGAWATTS!"})}),y.jsx(Pk,{children:y.jsxs(Ik,{children:[y.jsx(Sf,{style:{transform:"rotate(0deg)"}}),y.jsx(Sf,{style:{transform:"rotate(120deg)"}}),y.jsx(Sf,{style:{transform:"rotate(240deg)"}}),y.jsx(Fk,{children:"Y"})]})}),y.jsxs(Hk,{children:[y.jsx(Uk,{children:"🧱 MY LEGO DELOREAN 🧱"}),y.jsx(Gk,{children:"Check out my working LEGO Time Machine with light-up flux capacitor!"}),y.jsx(Ef,{src:"https://media.giphy.com/media/hGwvzBNwXDwlO/giphy.gif",alt:"Time Travel"})]}),y.jsxs(Vk,{children:[y.jsx(qk,{children:"🔗 BTTF LINKS 🔗"}),y.jsx(Fo,{href:"https://www.backtothefuture.com/",target:"_blank",rel:"noopener noreferrer",children:"▶ Official BTTF Website"}),y.jsx(Fo,{href:"https://www.imdb.com/title/tt0088763/",target:"_blank",rel:"noopener noreferrer",children:"▶ BTTF on IMDB"}),y.jsx(Fo,{href:"https://delorean.com/",target:"_blank",rel:"noopener noreferrer",children:"▶ DeLorean Motor Company"}),y.jsx(Fo,{href:"https://www.lego.com/en-us/product/back-to-the-future-time-machine-10300",target:"_blank",rel:"noopener noreferrer",children:"▶ LEGO DeLorean Set"}),y.jsx(Fo,{href:"https://bttfcars.com/",target:"_blank",rel:"noopener noreferrer",children:"▶ Real BTTF DeLoreans"})]})]})]}),y.jsx(Ws,{children:y.jsx(Qs,{})}),y.jsxs(fs,{id:"coding",children:[y.jsxs(ps,{children:[y.jsx($y,{children:"</>"}),y.jsx(gs,{children:"CODING CORNER"}),y.jsx($y,{children:"</>"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(Yk,{children:[y.jsx(Xk,{children:"Check out my pinned projects on GitHub!"}),y.jsxs(Wk,{children:[y.jsx($o,{$bg:"#61dafb",$border:"#21a1cb",$dark:!0,children:"React"}),y.jsx($o,{$bg:"#3178c6",$border:"#235a97",children:"TypeScript"}),y.jsx($o,{$bg:"#f0db4f",$border:"#c9b800",$dark:!0,children:"JavaScript"}),y.jsx($o,{$bg:"#b07219",$border:"#8b5a00",children:"Java"}),y.jsx($o,{$bg:"#178600",$border:"#0d4d00",children:"C#"})]}),y.jsxs(Qk,{children:[y.jsxs(dr,{onClick:()=>window.open("https://github.com/fonCki/terminal-site","_blank"),children:[y.jsx(hr,{children:"💻"}),y.jsx(fr,{children:"terminal-site"}),y.jsx(pr,{children:"Personal Site Terminal - my retro CLI portfolio"}),y.jsx(gr,{children:"🔗 term.ridao.ar"})]}),y.jsxs(dr,{onClick:()=>window.open("https://github.com/fonCki/shoulder-presentation-eval","_blank"),children:[y.jsx(hr,{children:"📸"}),y.jsx(fr,{children:"shoulder-presentation-eval"}),y.jsx(pr,{children:"ID photo evaluator per ISO/IEC 39794-5 with MediaPipe"}),y.jsx(gr,{children:"🔗 shoulder-presentation-eval.ridao.ar"})]}),y.jsxs(dr,{onClick:()=>window.open("https://github.com/fonCki/chappar","_blank"),children:[y.jsx(hr,{children:"☕"}),y.jsx(fr,{children:"chappar"}),y.jsx(pr,{children:"Chrome extension from Via University Software Engineering"}),y.jsx(gr,{children:"▶ View on GitHub"})]}),y.jsxs(dr,{onClick:()=>window.open("https://github.com/fonCki/time-complexity-calculator","_blank"),children:[y.jsx(hr,{children:"⏱️"}),y.jsx(fr,{children:"time-complexity-calculator"}),y.jsx(pr,{children:"Calculate time complexity of functions - optimize your code!"}),y.jsx(gr,{children:"▶ View on GitHub"})]}),y.jsxs(dr,{onClick:()=>window.open("https://github.com/fonCki/ViaVai-chat-system","_blank"),children:[y.jsx(hr,{children:"💬"}),y.jsx(fr,{children:"ViaVai-chat-system"}),y.jsx(pr,{children:"Via University 3rd Semester Project - 3 tier chat system"}),y.jsx(gr,{children:"▶ View on GitHub"})]}),y.jsxs(dr,{onClick:()=>window.open("https://github.com/fonCki/w3tl","_blank"),children:[y.jsx(hr,{children:"🌐"}),y.jsx(fr,{children:"w3tl"}),y.jsx(pr,{children:"Decentralized Twitter Frontend with React & Web3"}),y.jsx(gr,{children:"🔗 w3tl.ridao.ar"})]})]}),y.jsxs(Kk,{onClick:()=>window.open("https://github.com/fonCki","_blank"),children:[y.jsx(Zk,{children:"★"}),"Visit My GitHub!"]})]})]}),y.jsx(Ws,{children:y.jsx(Qs,{})}),y.jsxs(fs,{id:"gaming",children:[y.jsxs(ps,{children:[y.jsx(qy,{children:"🎮"}),y.jsx(gs,{children:"RETRO GAMING ZONE"}),y.jsx(qy,{children:"🎮"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(Jk,{children:[y.jsxs(tM,{children:[y.jsxs(Hy,{href:"https://www.google.com/logos/2010/pacman10-i.html",target:"_blank",rel:"noopener noreferrer",children:[y.jsx(eM,{children:`  ████████
 ██████████
███    █████
██████████
 █████████
  ████████`}),y.jsx(Uy,{children:"PAC-MAN"}),y.jsx(Gy,{children:"HI-SCORE: 999,999"}),y.jsx(Vy,{children:"▶ Play Online!"})]}),y.jsxs(Hy,{href:"https://tetris.com/play-tetris",target:"_blank",rel:"noopener noreferrer",children:[y.jsxs(nM,{children:[y.jsxs(Yc,{children:[y.jsx(bs,{$color:"#ff0000"}),y.jsx(bs,{$color:"#ff0000"})]}),y.jsxs(Yc,{children:[y.jsx(bs,{$color:"#00ff00"}),y.jsx(bs,{$color:"#ff0000"})]}),y.jsxs(Yc,{children:[y.jsx(bs,{$color:"#00ff00"}),y.jsx(bs,{$color:"#0000ff"})]}),y.jsxs(Yc,{children:[y.jsx(bs,{$color:"#ffff00"}),y.jsx(bs,{$color:"#0000ff"})]})]}),y.jsx(Uy,{children:"TETRIS"}),y.jsx(Gy,{children:"HI-SCORE: 500,000"}),y.jsx(Vy,{children:"▶ Play Online!"})]})]}),y.jsxs(iM,{children:[y.jsx(sM,{children:"📥 CLASSIC GAMES ARCHIVE 📥"}),y.jsxs(aM,{children:[y.jsx(Xc,{href:"https://archive.org/details/doom-shareware",target:"_blank",rel:"noopener noreferrer",children:"▶ DOOM Shareware (Archive.org)"}),y.jsx(Xc,{href:"https://archive.org/details/DukeNukem3D1702Shareware1997",target:"_blank",rel:"noopener noreferrer",children:"▶ Duke Nukem 3D Demo (Archive.org)"}),y.jsx(Xc,{href:"https://archive.org/details/CommanderKeen4",target:"_blank",rel:"noopener noreferrer",children:"▶ Commander Keen 4 (Archive.org)"}),y.jsx(Xc,{href:"https://dos.zone/",target:"_blank",rel:"noopener noreferrer",children:"▶ DOS.Zone - Play DOS games in browser!"})]})]})]})]}),y.jsx(Ws,{children:y.jsx(Qs,{})}),y.jsxs(fs,{id:"music",children:[y.jsxs(ps,{children:[y.jsx(Yy,{children:"♪"}),y.jsx(gs,{children:"MUSIC CORNER"}),y.jsx(Yy,{children:"♫"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(rM,{children:[y.jsxs(oM,{children:[y.jsx(lM,{children:`    ██████████████
  ████            ████
 ██    ████████    ██
██   ██        ██   ██
██  ██    ██    ██  ██
 ██  ██████████  ██
  ████  ████  ████
    ████    ████
      ████████
        ████
         ██         `}),y.jsx(cM,{children:"THE ROLLING STONES"})]}),y.jsx(i2,{})]})]}),y.jsx(Ws,{children:y.jsx(Qs,{})}),y.jsxs(fs,{id:"construction",children:[y.jsxs(ps,{children:[y.jsx(Xy,{children:"🚧"}),y.jsx(gs,{children:"UNDER CONSTRUCTION"}),y.jsx(Xy,{children:"🚧"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(uM,{children:[y.jsx(dM,{children:`     _____
    /     \\
   | () () |
    \\  ^  /
     |||||
   __|   |__
  [__|___|__]
     |   |
     |   |
    _|   |_
   |_______|`}),y.jsxs(hM,{children:[y.jsx(fM,{children:"*** COMING SOON! ***"}),y.jsxs(pM,{children:[y.jsx("li",{children:"IRC Chat Room (#alfonso on EFnet)"}),y.jsx("li",{children:"MIDI Jukebox (50+ songs!)"}),y.jsx("li",{children:"Web Ring Links"}),y.jsx("li",{children:"More ASCII Art!"}),y.jsx("li",{children:"Secret Warez Page (shhh!)"})]}),y.jsx(gM,{children:"Check back soon!"})]})]})]}),y.jsx(Ws,{children:y.jsx(Qs,{})}),y.jsxs(fs,{id:"guestbook",children:[y.jsxs(ps,{children:[y.jsx(Ky,{children:"📖"}),y.jsx(gs,{children:"GUESTBOOK"}),y.jsx(Ky,{children:"📖"})]}),y.jsx(ms,{children:"═".repeat(60)}),y.jsxs(mM,{children:[y.jsx(bM,{children:"Sign my guestbook! Leave a message!"}),g&&y.jsx(jM,{children:g}),C?y.jsxs(TM,{onSubmit:_,children:[y.jsx(CM,{children:"✍️ SIGN MY GUESTBOOK! ✍️"}),h&&y.jsx(NM,{children:h}),y.jsxs(Wy,{children:[y.jsx(Qy,{children:"Your Name:"}),y.jsx(_M,{type:"text",value:x,onChange:R=>v(R.target.value),maxLength:50,placeholder:"Enter your name...",disabled:c})]}),y.jsxs(Wy,{children:[y.jsx(Qy,{children:"Message:"}),y.jsx(kM,{value:E,onChange:R=>S(R.target.value),maxLength:500,placeholder:"Leave a cool message!",rows:3,disabled:c})]}),y.jsxs(MM,{children:[y.jsx(DM,{type:"submit",disabled:c,children:c?"[ Sending... ]":"[ Submit Entry ]"}),y.jsx(RM,{type:"button",onClick:()=>T(!1),disabled:c,children:"[ Cancel ]"})]})]}):y.jsx(EM,{onClick:()=>T(!0),children:"[ ✍️ Sign My Guestbook! ]"}),y.jsx(yM,{children:a?y.jsx(LM,{children:"Loading guestbook entries..."}):r.length===0?y.jsx(OM,{children:"Be the first to sign my guestbook!"}):r.map(R=>y.jsxs(xM,{children:[y.jsxs(vM,{children:[y.jsx(AM,{children:R.name}),y.jsx(wM,{children:R.formattedDate})]}),y.jsx(SM,{children:R.message})]},R.id))})]})]}),y.jsxs(BM,{children:[y.jsx(zM,{children:"═".repeat(60)}),y.jsxs(PM,{children:[y.jsx(Zy,{children:"© 1995-1999 Fonchi's Homepage"}),y.jsx(Zy,{children:"All Rights Reserved"}),y.jsx(IM,{children:"Last updated: December 31, 1999 at 11:59 PM"}),y.jsx(FM,{children:"Made with Notepad and lots of ☕!"})]}),y.jsxs($M,{children:[y.jsx(HM,{children:"🕸️ WEB RING 🕸️"}),y.jsxs(UM,{children:[y.jsx(Wc,{children:"[ << Prev ]"}),y.jsx(Wc,{children:"[ 90s Retro Web Ring ]"}),y.jsx(Wc,{children:"[ Random ]"}),y.jsx(Wc,{children:"[ Next >> ]"})]})]}),y.jsxs(GM,{children:[y.jsx(zy,{children:"✉"}),"Questions? ",y.jsx(Py,{href:"mailto:alfonso@ridao.ar",children:"E-Mail the Webmaster!"})]})]})]})]})},ga=ue`
  0%, 49% { opacity: 1; }
  50%, 100% { opacity: 0; }
`,z2=ue`
  0%, 100% { text-shadow: 0 0 5px #0ff, 0 0 10px #0ff, 0 0 15px #0ff; }
  50% { text-shadow: 0 0 10px #0ff, 0 0 20px #0ff, 0 0 30px #0ff, 0 0 40px #0ff; }
`,P2=ue`
  0% { color: #ff0000; }
  17% { color: #ff7f00; }
  33% { color: #ffff00; }
  50% { color: #00ff00; }
  67% { color: #0000ff; }
  83% { color: #8b00ff; }
  100% { color: #ff0000; }
`,I2=ue`
  0% { transform: translateX(100%); }
  100% { transform: translateX(-100%); }
`,F2=ue`
  0%, 100% { opacity: 1; }
  50% { opacity: 0.8; }
`,$2=ue`
  0%, 100% { height: 4px; }
  50% { height: 24px; }
`;ue`
  0% { transform: translateY(-100%); opacity: 0; }
  10% { opacity: 1; }
  90% { opacity: 1; }
  100% { transform: translateY(100%); opacity: 0; }
`;const Iv=ue`
  0%, 100% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
`,H2=ue`
  0%, 100% { opacity: 0.3; box-shadow: 0 0 5px #ff0; }
  50% { opacity: 1; box-shadow: 0 0 20px #ff0, 0 0 40px #ff0; }
`,U2=ue`
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-3px); }
`;ue`
  0%, 100% { opacity: 0.3; }
  50% { opacity: 1; }
`;ue`
  0% { transform: translateY(0); }
  50% { transform: translateY(-5px); }
  100% { transform: translateY(0); }
`;ue`
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
`;const Sp=ue`
  0% { transform: rotateY(0deg); }
  100% { transform: rotateY(360deg); }
`,Fv=w.a`
  position: fixed;
  top: 50%;
  transform: translateY(-50%);
  z-index: 100;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-decoration: none;
  padding: 10px;
  background: rgba(0, 0, 50, 0.8);
  border: 2px solid #00ffff;
  border-radius: 8px;
  transition: all 0.3s;

  &:hover {
    background: rgba(0, 0, 100, 0.9);
    border-color: #ffff00;
    box-shadow: 0 0 20px #ffff00;
  }
`;w(Fv)`
  left: 10px;
`;w(Fv)`
  right: 10px;
`;w.img`
  width: 50px;
  height: 50px;
  animation: ${Sp} 4s linear infinite;

  &:hover {
    animation-play-state: paused;
  }
`;w.span`
  color: #00ffff;
  font-size: 10px;
  margin-top: 5px;
  font-weight: bold;
  text-shadow: 0 0 5px #00ffff;
`;w.div`
  width: 50px;
  height: 50px;
  background: #0077b5;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: ${Sp} 4s linear infinite;
  border: 2px solid #fff;
  box-shadow: 0 0 10px #0077b5;
`;w.span`
  font-size: 32px;
  font-weight: bold;
  color: #fff;
  font-family: Georgia, serif;
`;w.div`
  width: 50px;
  height: 50px;
  background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  animation: ${Sp} 4s linear infinite;
  border: 2px solid #fff;
  box-shadow: 0 0 10px #dc2743;
`;w.div`
  width: 22px;
  height: 22px;
  border: 3px solid #fff;
  border-radius: 50%;
`;w.div`
  position: absolute;
  top: 8px;
  right: 8px;
  width: 6px;
  height: 6px;
  background: #fff;
  border-radius: 50%;
`;const G2=w.div`
  min-height: 100%;
  background-color: #000011;
  background-image:
    radial-gradient(2px 2px at 20px 30px, #fff, transparent),
    radial-gradient(2px 2px at 40px 70px, rgba(255,255,255,0.8), transparent),
    radial-gradient(1px 1px at 90px 40px, #fff, transparent),
    radial-gradient(2px 2px at 130px 80px, rgba(255,255,255,0.6), transparent),
    radial-gradient(1px 1px at 160px 120px, #fff, transparent),
    radial-gradient(2px 2px at 200px 50px, rgba(255,255,255,0.7), transparent),
    radial-gradient(1px 1px at 230px 150px, #fff, transparent),
    radial-gradient(2px 2px at 280px 90px, rgba(255,255,255,0.5), transparent),
    radial-gradient(1px 1px at 320px 60px, #fff, transparent),
    radial-gradient(2px 2px at 360px 130px, rgba(255,255,255,0.8), transparent),
    linear-gradient(180deg, #000022 0%, #000044 50%, #000022 100%);
  background-size: 400px 200px;
  color: #00ff00;
  font-family: 'MS Sans Serif', 'Courier New', monospace;
  position: relative;
  overflow-x: hidden;
`,V2=w.header`
  text-align: center;
  padding: 20px;
  background: linear-gradient(180deg, #000033 0%, #000066 50%, #000033 100%);
  border-bottom: 3px solid #00ffff;
`,q2=w.div`
  background: linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #8b00ff, #ff0000);
  background-size: 200% 100%;
  animation: ${Iv} 3s ease infinite;
  padding: 4px;
  overflow: hidden;
  border: 2px solid #fff;
  margin-bottom: 20px;
`,Y2=w.div`
  color: #000;
  font-weight: bold;
  font-size: 12px;
  white-space: nowrap;
  animation: ${I2} 20s linear infinite;
  text-shadow: 1px 1px 0 #fff;
`,X2=w.div`
  margin: 20px 0;
`,ky=w.div`
  font-size: 16px;
  animation: ${F2} 0.2s ease-in-out infinite;
  letter-spacing: 2px;
`,W2=w.h1`
  margin: 10px 0;
  font-size: 48px;
  display: flex;
  flex-direction: column;
  align-items: center;
`,Q2=w.span`
  animation: ${P2} 3s linear infinite;
  font-size: 36px;
`,K2=w.span`
  color: #00ffff;
  animation: ${z2} 2s ease-in-out infinite;
  font-size: 48px;
  letter-spacing: 8px;
`,Z2=w.div`
  color: #ffff00;
  font-style: italic;
  font-size: 14px;
`,J2=w.div`
  margin: 20px 0;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
`,My=w.span`
  color: #ffffff;
  font-size: 12px;
`,tk=w.div`
  background: #000;
  border: 3px inset #333;
  padding: 4px 8px;
`,ek=w.span`
  font-family: 'Courier New', monospace;
  font-size: 20px;
  color: #00ff00;
  letter-spacing: 4px;
  text-shadow: 0 0 10px #00ff00;
`,nk=w.div`
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 20px;
  flex-wrap: wrap;
`,ik=w.div`
  display: flex;
  align-items: center;
  gap: 4px;
  background: #000;
  border: 2px outset #666;
  padding: 4px 8px;
`,sk=w.div`
  display: flex;
  align-items: center;
  gap: 4px;
  background: #000;
  border: 2px outset #666;
  padding: 4px 8px;
`,Dy=w.span`
  font-size: 20px;
  font-weight: bold;
  color: #00ff00;
`,Ry=w.span`
  font-size: 10px;
  color: #fff;
  line-height: 1.2;
`,ak=w.div`
  background: linear-gradient(180deg, #666 0%, #333 100%);
  border: 2px outset #888;
  padding: 4px 12px;
  font-size: 12px;
  color: #fff;
`,rk=w.div`
  background: #ff0000;
  border: 2px outset #ff6666;
  padding: 4px 8px;
  font-size: 10px;
  color: #fff;
  font-weight: bold;
  text-align: center;
  animation: ${ga} 1s step-end infinite;
`,ok=w.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 15px;
  margin-top: 20px;
  flex-wrap: wrap;
`,lk=ue`
  0%, 100% { box-shadow: 0 0 5px #0ff, inset 0 0 5px rgba(0,255,255,0.3); }
  50% { box-shadow: 0 0 20px #0ff, 0 0 30px #0ff, inset 0 0 10px rgba(0,255,255,0.5); }
`,ck=ue`
  0% { left: -100%; }
  50%, 100% { left: 100%; }
`,Ly=w.a`
  position: relative;
  display: flex;
  align-items: center;
  padding: 8px 16px;
  background: ${r=>r.$gradient?"linear-gradient(45deg, #405de6, #5851db, #833ab4, #c13584, #e1306c, #fd1d1d)":"linear-gradient(180deg, #0077b5 0%, #005582 100%)"};
  border: 3px outset ${r=>r.$gradient?"#e1306c":"#0099dd"};
  color: #fff;
  text-decoration: none;
  font-weight: bold;
  font-size: 14px;
  cursor: pointer;
  overflow: hidden;
  animation: ${lk} 2s ease-in-out infinite;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:hover {
    border-style: inset;
    filter: brightness(1.2);
  }

  &:active {
    border-style: inset;
  }
`,Oy=w.div`
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
  animation: ${ck} 2s ease-in-out infinite;
`,jy=w.div`
  display: flex;
  align-items: center;
  gap: 8px;
  position: relative;
  z-index: 1;
`,Ny=w.span`
  font-size: 18px;
`,uk=w.span`
  color: #ffff00;
  font-size: 14px;
  animation: ${ga} 0.5s step-end infinite;
  text-shadow: 0 0 10px #ffff00;
`;w.div`
  text-align: center;
  margin: 10px 0;
`;w.img`
  max-width: 100%;
  height: auto;
  image-rendering: pixelated;
`;const dk=w.nav`
  background: linear-gradient(180deg, #000066 0%, #000033 100%);
  border: 3px double #00ffff;
  padding: 10px;
  margin: 20px auto;
  max-width: 700px;
`,hk=w.div`
  color: #ffff00;
  font-size: 12px;
  margin-bottom: 10px;
`,fk=w.div`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
`,Xs=w.a`
  color: #00ffff;
  text-decoration: none;
  font-size: 14px;
  padding: 2px 4px;

  &:hover {
    color: #ffff00;
    background: #000080;
  }
`,pk=w.main`
  max-width: 750px;
  margin: 0 auto;
  padding: 20px;
`,fs=w.section`
  margin: 30px 0;
  padding: 15px;
  background: rgba(0, 0, 50, 0.5);
  border: 2px solid #00ff00;
`,ps=w.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
`,gs=w.h2`
  color: #ffff00;
  font-size: 20px;
  text-shadow: 2px 2px 0 #ff0000;
  margin: 0;
`,ms=w.div`
  color: #00ffff;
  text-align: center;
  font-size: 10px;
  margin-bottom: 15px;
  overflow: hidden;
`,By=w.span`
  color: #ff0000;
  animation: ${ga} 0.5s step-end infinite;
  font-size: 12px;
`,gk=w.div`
  display: flex;
  gap: 20px;
  align-items: flex-start;
  color: #ffffff;
`,mk=w.div`
  text-align: center;
`,bk=w.pre`
  font-family: monospace;
  font-size: 10px;
  line-height: 1;
  color: #00ff00;
  margin: 0;
`,yk=w.div`
  color: #ffff00;
  font-size: 12px;
  margin-top: 5px;
`,xk=w.div`
  flex: 1;
  font-size: 12px;
  line-height: 1.6;

  p {
    margin: 10px 0;
  }
`,vk=w.div`
  color: #00ffff;
  font-size: 16px;
  margin-bottom: 10px;
`,Ak=w.div`
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 15px;
  padding: 8px;
  background: #000033;
  border: 1px solid #00ffff;
`,zy=w.span`
  font-size: 20px;
  animation: ${U2} 1s ease-in-out infinite;
`,wk=w.span`
  color: #ff00ff;
`,Py=w.a`
  color: #ff00ff;
  text-decoration: underline;
  cursor: pointer;

  &:hover {
    color: #ffff00;
  }
`,Ws=w.div`
  margin: 20px 0;
  text-align: center;
`,Qs=w.div`
  height: 20px;
  background: linear-gradient(90deg,
    #ff0000, #ff4400, #ff8800, #ffcc00, #ff8800, #ff4400, #ff0000,
    #ff4400, #ff8800, #ffcc00, #ff8800, #ff4400, #ff0000
  );
  background-size: 200% 100%;
  animation: ${Iv} 0.5s ease infinite;
  border-top: 2px solid #ffff00;
  border-bottom: 2px solid #ff0000;
`,Sk=w.div`
  text-align: center;
`,Ek=w.div`
  color: #ffff00;
  font-size: 16px;
  margin-bottom: 20px;
  font-style: italic;
`,Tk=w.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
  margin-bottom: 20px;
`,Uc=w.div`
  background: linear-gradient(180deg, #000033 0%, #000066 100%);
  border: 2px solid #00ffff;
  padding: 15px;
  text-align: center;
`,Gc=w.div`
  font-size: 32px;
  margin-bottom: 8px;
`,Vc=w.div`
  color: #00ff00;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 5px;
`,qc=w.div`
  color: #808080;
  font-size: 11px;
`,Ck=w.div`
  background: #000033;
  border: 2px solid #ff00ff;
  padding: 15px;
  margin-top: 15px;
`,_k=w.div`
  color: #ffff00;
  font-size: 14px;
  margin-bottom: 10px;
`,kk=w.div`
  text-align: left;
`,Mk=w.div`
  color: #aaaaaa;
  font-size: 10px;
  margin-bottom: 15px;
  font-style: italic;
`,rr=w.a`
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 8px 0;
  padding: 8px;
  border-bottom: 1px dashed #333366;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background: rgba(0, 255, 255, 0.1);
    border-color: #00ffff;
  }
`,or=w.span`
  font-size: 20px;
`,lr=w.div`
  display: flex;
  flex-direction: column;
`,cr=w.span`
  color: #00ffff;
  font-size: 13px;
  font-weight: bold;
`,ur=w.span`
  color: #aaaaaa;
  font-size: 10px;
`,Iy=w.span`
  font-size: 20px;
`,Dk=w.div`
  text-align: center;
`;w.pre`
  color: #c0c0c0;
  font-family: monospace;
  font-size: 12px;
  line-height: 1;
  margin: 15px 0;
`;const Rk=w.div`
  color: #ffff00;
  font-size: 16px;
  font-style: italic;
  margin: 20px 0 5px;
`,Lk=w.div`
  color: #ffffff;
  font-size: 12px;
`,Ok=w.div`
  margin: 20px auto;
  max-width: 350px;
`,jk=w.div`
  color: #ffffff;
  font-size: 12px;
  margin-bottom: 5px;
`,Nk=w.div`
  background: #111;
  border: 3px solid #333;
  padding: 10px;
`,vf=w.div`
  display: flex;
  justify-content: space-between;
  margin: 5px 0;
  padding: 3px;
  background: #000;
`,Af=w.span`
  color: ${r=>r.$color};
  font-size: 10px;
`,wf=w.span`
  color: ${r=>r.$color};
  font-family: 'Courier New', monospace;
  font-size: 14px;
  text-shadow: 0 0 10px ${r=>r.$color};
`,Bk=w.div`
  margin: 20px 0;
`,zk=w.div`
  color: #00ffff;
  font-size: 28px;
  font-weight: bold;
  animation: ${ga} 0.3s step-end infinite;
  text-shadow: 0 0 20px #00ffff;
`,Pk=w.div`
  margin: 20px auto;
  width: 80px;
  height: 80px;
`,Ik=w.div`
  width: 100%;
  height: 100%;
  background: #222;
  border: 3px solid #444;
  border-radius: 50%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
`,Sf=w.div`
  position: absolute;
  width: 4px;
  height: 30px;
  background: #ffff00;
  top: 5px;
  left: calc(50% - 2px);
  transform-origin: bottom center;
  animation: ${H2} 0.5s ease-in-out infinite;
`,Fk=w.div`
  color: #ffff00;
  font-size: 20px;
  font-weight: bold;
  animation: ${ga} 0.2s step-end infinite;
`,Fy=w.span`
  color: #ffff00;
  font-size: 20px;
`,$k=w.div`
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-bottom: 20px;
  flex-wrap: wrap;
`,Ef=w.img`
  max-width: 200px;
  height: auto;
  border: 3px solid #00ffff;
  box-shadow: 0 0 10px #00ffff;
`,Hk=w.div`
  margin: 20px 0;
  padding: 15px;
  background: linear-gradient(180deg, #1a0000 0%, #330000 100%);
  border: 2px solid #ff6600;
`,Uk=w.div`
  color: #ff6600;
  font-size: 16px;
  font-weight: bold;
  margin-bottom: 10px;
`,Gk=w.div`
  color: #ffffff;
  font-size: 12px;
  margin-bottom: 15px;
`,Vk=w.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 20px;
`,qk=w.div`
  color: #ffff00;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 10px;
  text-align: center;
`,Fo=w.a`
  display: block;
  color: #00ffff;
  font-size: 12px;
  cursor: pointer;
  text-decoration: none;
  padding: 5px 0;
  transition: all 0.2s;

  &:hover {
    color: #ffff00;
    text-shadow: 0 0 10px #ffff00;
    padding-left: 10px;
  }
`,Yk=w.div``,Xk=w.div`
  color: #ffffff;
  font-size: 14px;
  text-align: center;
  margin-bottom: 15px;
`,Wk=w.div`
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-bottom: 20px;
`,$o=w.div`
  background: ${r=>r.$bg};
  border: 3px outset ${r=>r.$border};
  padding: 8px 20px;
  color: ${r=>r.$dark?"#000":"#fff"};
  font-weight: bold;
  font-size: 14px;
`;w.div`
  display: flex;
  flex-direction: column;
  gap: 15px;
`;w.div`
  background: #1a1a1a;
  border: 2px inset #333;
`;w.div`
  background: #000080;
  color: #fff;
  padding: 4px 8px;
  font-size: 11px;
`;w.pre`
  color: #00ff00;
  font-family: 'Courier New', monospace;
  font-size: 11px;
  padding: 10px;
  margin: 0;
`;const $y=w.span`
  color: #00ff00;
  font-size: 16px;
`,Qk=w.div`
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 15px;
  margin-bottom: 20px;
`,dr=w.div`
  background: linear-gradient(180deg, #000033 0%, #000066 100%);
  border: 2px solid #00ffff;
  padding: 12px;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    border-color: #ffff00;
    background: linear-gradient(180deg, #000044 0%, #000088 100%);
    transform: scale(1.02);
  }
`,hr=w.div`
  font-size: 24px;
  margin-bottom: 8px;
`,fr=w.div`
  color: #00ff00;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 5px;
`,pr=w.div`
  color: #ffffff;
  font-size: 11px;
  line-height: 1.3;
  margin-bottom: 8px;
`,gr=w.div`
  color: #00ffff;
  font-size: 10px;
`;w.div`
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-top: 20px;
  flex-wrap: wrap;
`;w.a`
  display: flex;
  align-items: center;
  gap: 8px;
  background: ${r=>r.$color||"#333"};
  color: #fff;
  padding: 10px 20px;
  border: 3px outset ${r=>r.$color||"#666"};
  text-decoration: none;
  font-size: 14px;
  font-weight: bold;
  cursor: pointer;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:hover {
    filter: brightness(1.2);
    border-style: inset;
  }

  &:active {
    border-style: inset;
  }
`;w.span`
  font-size: 18px;
  color: #fff;
`;w.span`
  font-size: 16px;
  font-weight: bold;
  color: #fff;
  background: #fff;
  color: #0077b5;
  padding: 2px 5px;
  border-radius: 3px;
`;w.span`
  font-size: 18px;
  color: #fff;
`;const Kk=w.button`
  background: linear-gradient(180deg, #333 0%, #111 100%);
  color: #ffffff;
  border: 3px outset #666;
  padding: 12px 24px;
  font-size: 16px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  margin: 20px auto 0;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:hover {
    background: linear-gradient(180deg, #444 0%, #222 100%);
  }

  &:active {
    border-style: inset;
  }
`,Zk=w.span`
  font-size: 24px;
  color: #ffffff;
`,Jk=w.div``,tM=w.div`
  display: flex;
  justify-content: center;
  gap: 30px;
  margin-bottom: 20px;
`;w.div`
  background: #000;
  border: 2px solid #ffff00;
  padding: 15px;
  text-align: center;
  min-width: 150px;
`;const Hy=w.a`
  background: #000;
  border: 2px solid #ffff00;
  padding: 15px;
  text-align: center;
  min-width: 150px;
  display: block;
  text-decoration: none;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    border-color: #00ffff;
    background: #001111;
    transform: scale(1.05);
    box-shadow: 0 0 15px #ffff00;
  }
`,eM=w.pre`
  color: #ffff00;
  font-family: monospace;
  font-size: 8px;
  line-height: 1;
  margin-bottom: 10px;
`,nM=w.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  margin-bottom: 10px;
`,Yc=w.div`
  display: flex;
  gap: 2px;
`,bs=w.div`
  width: 16px;
  height: 16px;
  background: ${r=>r.$color};
  border: 2px outset ${r=>r.$color};
`,Uy=w.div`
  color: #ffffff;
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 5px;
`,Gy=w.div`
  color: #00ff00;
  font-size: 11px;
  margin-bottom: 10px;
`,Vy=w.div`
  color: #00ffff;
  font-size: 12px;
  cursor: pointer;

  &:hover {
    color: #ffff00;
  }
`,iM=w.div`
  background: #000033;
  border: 2px solid #00ffff;
  padding: 15px;
  margin-top: 15px;
`,sM=w.div`
  color: #ffff00;
  font-size: 14px;
  text-align: center;
  margin-bottom: 10px;
`,aM=w.div``;w.div`
  color: #00ffff;
  font-size: 12px;
  margin: 5px 0;
  cursor: pointer;

  &:hover {
    color: #ffff00;
  }
`;const Xc=w.a`
  display: block;
  color: #00ffff;
  font-size: 12px;
  margin: 8px 0;
  cursor: pointer;
  text-decoration: none;
  transition: all 0.2s;

  &:hover {
    color: #ffff00;
    text-shadow: 0 0 10px #ffff00;
    padding-left: 10px;
  }
`,qy=w.span`
  font-size: 16px;
`,rM=w.div`
  text-align: center;
`,oM=w.div`
  margin-bottom: 20px;
`,lM=w.pre`
  color: #ff0000;
  font-family: monospace;
  font-size: 8px;
  line-height: 1;
  margin: 0 auto 10px;
`,cM=w.div`
  color: #ff0000;
  font-size: 20px;
  font-weight: bold;
  letter-spacing: 3px;
`;w.div`
  background: #000;
  border: 2px inset #333;
  padding: 15px;
  margin: 20px 0;
`;w.div`
  color: #808080;
  font-size: 10px;
  margin-bottom: 5px;
`;w.div`
  color: #00ff00;
  font-size: 16px;
  margin-bottom: 3px;
`;w.div`
  color: #00ffff;
  font-size: 12px;
  margin-bottom: 10px;
`;w.div`
  display: flex;
  justify-content: center;
  align-items: flex-end;
  gap: 3px;
  height: 30px;
`;w.div`
  width: 6px;
  background: linear-gradient(180deg, #00ff00, #ffff00, #ff0000);
  animation: ${$2} 0.4s ease-in-out infinite;
`;w.div`
  text-align: left;
  max-width: 250px;
  margin: 0 auto;
`;w.div`
  color: #ffff00;
  font-size: 12px;
  margin-bottom: 10px;
  text-align: center;
`;w.div`
  color: #ffffff;
  font-size: 12px;
  margin: 5px 0;
`;const Yy=w.span`
  color: #ff00ff;
  font-size: 16px;
`,uM=w.div`
  display: flex;
  gap: 20px;
  align-items: center;
  justify-content: center;
`,dM=w.pre`
  color: #ffff00;
  font-family: monospace;
  font-size: 10px;
  line-height: 1;
`,hM=w.div``,fM=w.div`
  color: #ff0000;
  font-size: 18px;
  font-weight: bold;
  animation: ${ga} 0.5s step-end infinite;
  margin-bottom: 15px;
`,pM=w.ul`
  color: #00ffff;
  font-size: 12px;
  text-align: left;
  margin: 0;
  padding-left: 20px;

  li {
    margin: 5px 0;
  }
`,gM=w.div`
  color: #ffffff;
  font-size: 12px;
  margin-top: 15px;
`,Xy=w.span`
  font-size: 20px;
`,mM=w.div``,bM=w.div`
  color: #ffffff;
  font-size: 14px;
  text-align: center;
  margin-bottom: 15px;
`,yM=w.div`
  margin-bottom: 15px;
`,xM=w.div`
  background: #000033;
  border: 1px solid #00ffff;
  padding: 10px;
  margin-bottom: 10px;
`,vM=w.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 5px;
`,AM=w.span`
  color: #00ff00;
  font-weight: bold;
  font-size: 12px;
`,wM=w.span`
  color: #808080;
  font-size: 10px;
`,SM=w.div`
  color: #ffffff;
  font-size: 12px;
`,EM=w.button`
  background: #000080;
  color: #ffffff;
  border: 2px outset #0000ff;
  padding: 8px 20px;
  font-size: 14px;
  cursor: pointer;
  display: block;
  margin: 0 auto 15px;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:hover {
    background: #0000aa;
  }

  &:active {
    border-style: inset;
  }
`,TM=w.form`
  background: #000033;
  border: 2px solid #00ffff;
  padding: 15px;
  margin-bottom: 15px;
`,CM=w.div`
  color: #ffff00;
  font-size: 14px;
  text-align: center;
  margin-bottom: 15px;
`,Wy=w.div`
  margin-bottom: 10px;
`,Qy=w.label`
  display: block;
  color: #00ffff;
  font-size: 12px;
  margin-bottom: 5px;
`,_M=w.input`
  width: 100%;
  padding: 6px 8px;
  background: #000;
  border: 2px inset #444;
  color: #00ff00;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  box-sizing: border-box;

  &::placeholder {
    color: #666;
  }

  &:focus {
    outline: none;
    border-color: #00ffff;
  }

  &:disabled {
    background: #111;
    color: #666;
  }
`,kM=w.textarea`
  width: 100%;
  padding: 6px 8px;
  background: #000;
  border: 2px inset #444;
  color: #00ff00;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  resize: vertical;
  min-height: 60px;
  box-sizing: border-box;

  &::placeholder {
    color: #666;
  }

  &:focus {
    outline: none;
    border-color: #00ffff;
  }

  &:disabled {
    background: #111;
    color: #666;
  }
`,MM=w.div`
  display: flex;
  gap: 10px;
  justify-content: center;
  margin-top: 15px;
`,DM=w.button`
  background: #008000;
  color: #ffffff;
  border: 2px outset #00aa00;
  padding: 8px 16px;
  font-size: 12px;
  cursor: pointer;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:hover {
    background: #00aa00;
  }

  &:active {
    border-style: inset;
  }

  &:disabled {
    background: #444;
    border-color: #666;
    cursor: not-allowed;
  }
`,RM=w.button`
  background: #800000;
  color: #ffffff;
  border: 2px outset #aa0000;
  padding: 8px 16px;
  font-size: 12px;
  cursor: pointer;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:hover {
    background: #aa0000;
  }

  &:active {
    border-style: inset;
  }

  &:disabled {
    background: #444;
    border-color: #666;
    cursor: not-allowed;
  }
`,LM=w.div`
  color: #ffff00;
  font-size: 12px;
  text-align: center;
  padding: 20px;
  animation: ${ga} 1s ease-in-out infinite;
`,OM=w.div`
  color: #808080;
  font-size: 12px;
  text-align: center;
  padding: 20px;
  font-style: italic;
`,jM=w.div`
  background: #004400;
  border: 2px solid #00ff00;
  color: #00ff00;
  padding: 10px;
  margin-bottom: 15px;
  text-align: center;
  font-size: 12px;
`,NM=w.div`
  background: #440000;
  border: 2px solid #ff0000;
  color: #ff0000;
  padding: 10px;
  margin-bottom: 10px;
  text-align: center;
  font-size: 12px;
`,Ky=w.span`
  font-size: 16px;
`,BM=w.footer`
  text-align: center;
  margin-top: 40px;
  padding: 20px;
  border-top: 3px double #00ff00;
`,zM=w.div`
  color: #00ff00;
  font-size: 10px;
  margin-bottom: 15px;
  overflow: hidden;
`,PM=w.div`
  margin-bottom: 20px;
`,Zy=w.div`
  color: #808080;
  font-size: 11px;
`,IM=w.div`
  color: #808080;
  font-size: 10px;
  margin-top: 5px;
`,FM=w.div`
  color: #ffff00;
  font-size: 11px;
  margin-top: 10px;
`,$M=w.div`
  background: #000033;
  border: 2px solid #00ffff;
  padding: 10px;
  margin: 15px auto;
  max-width: 400px;
`,HM=w.div`
  color: #ffff00;
  font-size: 12px;
  margin-bottom: 10px;
`,UM=w.div`
  display: flex;
  justify-content: center;
  gap: 10px;
`,Wc=w.span`
  color: #00ffff;
  font-size: 11px;
  cursor: pointer;

  &:hover {
    color: #ffff00;
  }
`,GM=w.div`
  color: #ff00ff;
  font-size: 12px;
  margin-top: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
`,ys={ie:"https://win98icons.alexmeub.com/icons/png/msie1-2.png",page:"https://win98icons.alexmeub.com/icons/png/html-3.png",search:"https://win98icons.alexmeub.com/icons/png/search_web-0.png",history:"https://win98icons.alexmeub.com/icons/png/history-0.png",mail:"https://win98icons.alexmeub.com/icons/png/outlook_express-0.png",print:"https://win98icons.alexmeub.com/icons/png/printer-0.png"},VM=()=>{const r="http://fonchi.ridao.ar/",[t,e]=j.useState(!0),[s,a]=j.useState("Opening page...");j.useEffect(()=>{const c=setTimeout(()=>{e(!1),a("Done")},2e3);return()=>clearTimeout(c)},[]);const l=()=>{e(!0),a("Refreshing..."),setTimeout(()=>{e(!1),a("Done")},1e3)};return y.jsxs(tD,{children:[y.jsxs(eD,{children:[y.jsx(mr,{children:"File"}),y.jsx(mr,{children:"Edit"}),y.jsx(mr,{children:"View"}),y.jsx(mr,{children:"Go"}),y.jsx(mr,{children:"Favorites"}),y.jsx(mr,{children:"Help"})]}),y.jsxs(nD,{children:[y.jsxs(iD,{children:[y.jsxs(Ri,{disabled:!0,title:"Back",children:[y.jsx(Ho,{children:y.jsx(qM,{disabled:!0})}),y.jsx(Li,{children:"Back"})]}),y.jsxs(Ri,{disabled:!0,title:"Forward",children:[y.jsx(Ho,{children:y.jsx(YM,{disabled:!0})}),y.jsx(Li,{children:"Forward"})]}),y.jsx(Jy,{}),y.jsxs(Ri,{disabled:!0,title:"Stop",children:[y.jsx(Ho,{children:y.jsx(XM,{disabled:!0})}),y.jsx(Li,{children:"Stop"})]}),y.jsxs(Ri,{onClick:l,title:"Refresh",children:[y.jsx(Ho,{children:y.jsx(WM,{})}),y.jsx(Li,{children:"Refresh"})]}),y.jsxs(Ri,{onClick:l,title:"Home",children:[y.jsx(Ho,{children:y.jsx(QM,{})}),y.jsx(Li,{children:"Home"})]}),y.jsx(Jy,{}),y.jsxs(Ri,{disabled:!0,title:"Search",children:[y.jsx(Qc,{src:ys.search,alt:"Search"}),y.jsx(Li,{children:"Search"})]}),y.jsxs(Ri,{disabled:!0,title:"History",children:[y.jsx(Qc,{src:ys.history,alt:"History"}),y.jsx(Li,{children:"History"})]}),y.jsxs(Ri,{disabled:!0,title:"Print",children:[y.jsx(Qc,{src:ys.print,alt:"Print"}),y.jsx(Li,{children:"Print"})]}),y.jsxs(Ri,{disabled:!0,title:"Mail",children:[y.jsx(Qc,{src:ys.mail,alt:"Mail"}),y.jsx(Li,{children:"Mail"})]})]}),y.jsx(sD,{children:y.jsx(aD,{$spinning:t,children:y.jsx(rD,{src:ys.ie,alt:"IE"})})})]}),y.jsxs(oD,{children:[y.jsx(lD,{children:"Address"}),y.jsxs(cD,{children:[y.jsx(uD,{src:ys.page,alt:""}),y.jsx(dD,{children:r}),y.jsx(hD,{type:"button",children:"▼"})]})]}),y.jsx(fD,{children:t?y.jsxs(pD,{children:[y.jsx(gD,{children:y.jsx(mD,{src:ys.ie,alt:"IE"})}),y.jsxs(bD,{children:["Opening page ",r]}),y.jsx(yD,{children:y.jsx(xD,{})})]}):y.jsx(B2,{})}),y.jsxs(vD,{children:[y.jsx(tx,{$flex:3,children:t?y.jsxs(y.Fragment,{children:[y.jsx(AD,{src:ys.ie,alt:""}),s]}):s||"Done"}),y.jsxs(tx,{$flex:1,children:[y.jsx(wD,{children:"🌐"}),"Internet zone"]})]})]})},qM=({disabled:r})=>y.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 22 22",fill:"none",children:[y.jsx("rect",{x:"8",y:"4",width:"10",height:"14",fill:r?"#808080":"#ffff80",stroke:r?"#404040":"#000",strokeWidth:"1"}),y.jsx("rect",{x:"10",y:"6",width:"6",height:"1",fill:r?"#404040":"#000"}),y.jsx("rect",{x:"10",y:"8",width:"6",height:"1",fill:r?"#404040":"#000"}),y.jsx("rect",{x:"10",y:"10",width:"4",height:"1",fill:r?"#404040":"#000"}),y.jsx("polygon",{points:"2,11 9,5 9,8 9,8 9,14 9,14 9,17",fill:r?"#808080":"#008000",stroke:r?"#404040":"#004000",strokeWidth:"1"}),y.jsx("polygon",{points:"3,11 8,7 8,15",fill:r?"#a0a0a0":"#00c000"})]}),YM=({disabled:r})=>y.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 22 22",fill:"none",children:[y.jsx("rect",{x:"4",y:"4",width:"10",height:"14",fill:r?"#808080":"#ffff80",stroke:r?"#404040":"#000",strokeWidth:"1"}),y.jsx("rect",{x:"6",y:"6",width:"6",height:"1",fill:r?"#404040":"#000"}),y.jsx("rect",{x:"6",y:"8",width:"6",height:"1",fill:r?"#404040":"#000"}),y.jsx("rect",{x:"6",y:"10",width:"4",height:"1",fill:r?"#404040":"#000"}),y.jsx("polygon",{points:"20,11 13,5 13,8 13,8 13,14 13,14 13,17",fill:r?"#808080":"#008000",stroke:r?"#404040":"#004000",strokeWidth:"1"}),y.jsx("polygon",{points:"19,11 14,7 14,15",fill:r?"#a0a0a0":"#00c000"})]}),XM=({disabled:r})=>y.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 22 22",fill:"none",children:[y.jsx("circle",{cx:"11",cy:"11",r:"9",fill:r?"#808080":"#ff0000",stroke:r?"#404040":"#800000",strokeWidth:"1"}),y.jsx("circle",{cx:"11",cy:"11",r:"7",fill:r?"#a0a0a0":"#ff4040"}),y.jsx("line",{x1:"7",y1:"7",x2:"15",y2:"15",stroke:r?"#606060":"#fff",strokeWidth:"2"}),y.jsx("line",{x1:"15",y1:"7",x2:"7",y2:"15",stroke:r?"#606060":"#fff",strokeWidth:"2"})]}),WM=()=>y.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 22 22",fill:"none",children:[y.jsx("path",{d:"M11 3 A8 8 0 1 1 3 11",stroke:"#008000",strokeWidth:"2",fill:"none"}),y.jsx("path",{d:"M11 19 A8 8 0 1 1 19 11",stroke:"#00c000",strokeWidth:"2",fill:"none"}),y.jsx("polygon",{points:"11,1 14,5 8,5",fill:"#008000"}),y.jsx("polygon",{points:"11,21 8,17 14,17",fill:"#00c000"})]}),QM=()=>y.jsxs("svg",{width:"22",height:"22",viewBox:"0 0 22 22",fill:"none",children:[y.jsx("polygon",{points:"11,2 2,10 4,10 4,19 18,19 18,10 20,10",fill:"#c0c0c0",stroke:"#000",strokeWidth:"1"}),y.jsx("polygon",{points:"11,3 4,9 18,9",fill:"#ff8080"}),y.jsx("rect",{x:"5",y:"10",width:"12",height:"8",fill:"#ffff80",stroke:"#000",strokeWidth:"1"}),y.jsx("rect",{x:"9",y:"12",width:"4",height:"6",fill:"#804000",stroke:"#000",strokeWidth:"1"}),y.jsx("rect",{x:"6",y:"11",width:"3",height:"3",fill:"#80c0ff",stroke:"#000",strokeWidth:"1"}),y.jsx("rect",{x:"13",y:"11",width:"3",height:"3",fill:"#80c0ff",stroke:"#000",strokeWidth:"1"})]}),KM=ue`
  0% { transform: rotateY(0deg); }
  100% { transform: rotateY(360deg); }
`,ZM=ue`
  0% { width: 0%; }
  100% { width: 100%; }
`,JM=ue`
  0%, 100% { opacity: 1; }
  50% { opacity: 0.7; }
`,tD=w.div`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  background-color: #c0c0c0;
  font-family: 'MS Sans Serif', 'Segoe UI', Tahoma, sans-serif;
  font-size: 11px;
`,eD=w.div`
  display: flex;
  padding: 2px 0;
  background-color: #c0c0c0;
  border-bottom: 1px solid #808080;
`,mr=w.span`
  padding: 2px 8px;
  cursor: default;
  &:hover {
    background-color: #000080;
    color: #fff;
  }
`,nD=w.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding: 2px 4px;
  background-color: #c0c0c0;
  border-bottom: 1px solid #808080;
  min-height: 50px;
`,iD=w.div`
  display: flex;
  align-items: flex-start;
  gap: 2px;
  flex-wrap: wrap;
`,Ri=w.button`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 3px 4px;
  background-color: transparent;
  border: none;
  cursor: ${r=>r.disabled?"default":"pointer"};
  min-width: 44px;
  opacity: ${r=>r.disabled?.6:1};

  &:hover:not(:disabled) {
    background-color: #dfdfdf;
    border: 1px solid;
    border-color: #fff #808080 #808080 #fff;
    padding: 2px 3px;
  }

  &:active:not(:disabled) {
    background-color: #c0c0c0;
    border: 1px solid;
    border-color: #808080 #fff #fff #808080;
    padding: 2px 3px;
  }
`,Ho=w.div`
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
`,Qc=w.img`
  width: 24px;
  height: 24px;
  image-rendering: pixelated;
`,Li=w.span`
  font-size: 9px;
  color: #000;
  margin-top: 2px;
`,Jy=w.div`
  width: 2px;
  height: 40px;
  margin: 0 4px;
  border-left: 1px solid #808080;
  border-right: 1px solid #fff;
`,sD=w.div`
  padding: 2px;
`,aD=w.div`
  width: 42px;
  height: 42px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(180deg, #87ceeb 0%, #4169e1 50%, #000080 100%);
  border: 2px solid;
  border-color: #fff #808080 #808080 #fff;
  animation: ${r=>r.$spinning?KM:"none"} 1.5s linear infinite;
  transform-style: preserve-3d;
`,rD=w.img`
  width: 32px;
  height: 32px;
  image-rendering: pixelated;
`,oD=w.div`
  display: flex;
  align-items: center;
  padding: 2px 4px;
  background-color: #c0c0c0;
  border-bottom: 1px solid #808080;
  gap: 4px;
`,lD=w.span`
  padding: 2px 6px;
  background-color: #c0c0c0;
  border: 1px solid;
  border-color: #fff #808080 #808080 #fff;
`,cD=w.div`
  flex: 1;
  display: flex;
  align-items: center;
  background-color: #fff;
  border: 2px solid;
  border-color: #808080 #dfdfdf #dfdfdf #808080;
  height: 22px;
`,uD=w.img`
  width: 16px;
  height: 16px;
  margin: 0 2px;
  image-rendering: pixelated;
`,dD=w.span`
  flex: 1;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  font-size: 11px;
  padding: 0 4px;
  color: #000;
`,hD=w.button`
  width: 18px;
  height: 18px;
  border: 1px solid;
  border-color: #dfdfdf #808080 #808080 #dfdfdf;
  background: #c0c0c0;
  font-size: 8px;
  cursor: default;
  display: flex;
  align-items: center;
  justify-content: center;
`,fD=w.div`
  flex: 1;
  overflow: auto;
  background-color: #fff;
  border: 2px solid;
  border-color: #808080 #dfdfdf #dfdfdf #808080;
  margin: 2px;
  position: relative;
`,pD=w.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background-color: #c0c0c0;
  gap: 15px;
`,gD=w.div`
  width: 72px;
  height: 72px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(180deg, #87ceeb 0%, #4169e1 50%, #000080 100%);
  border: 3px solid;
  border-color: #fff #808080 #808080 #fff;
  animation: ${JM} 1s ease-in-out infinite;
`,mD=w.img`
  width: 48px;
  height: 48px;
  image-rendering: pixelated;
`,bD=w.div`
  color: #000;
`,yD=w.div`
  width: 300px;
  height: 20px;
  border: 2px solid;
  border-color: #808080 #dfdfdf #dfdfdf #808080;
  background-color: #fff;
  padding: 2px;
`,xD=w.div`
  height: 100%;
  background: repeating-linear-gradient(
    90deg,
    #000080,
    #000080 10px,
    transparent 10px,
    transparent 12px
  );
  animation: ${ZM} 2s ease-out forwards;
`,vD=w.div`
  display: flex;
  padding: 2px;
  background-color: #c0c0c0;
  gap: 2px;
`,tx=w.div`
  flex: ${r=>r.$flex};
  padding: 2px 4px;
  border: 1px solid;
  border-color: #808080 #dfdfdf #dfdfdf #808080;
  display: flex;
  align-items: center;
  gap: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`,AD=w.img`
  width: 16px;
  height: 16px;
  image-rendering: pixelated;
`,wD=w.span`
  font-size: 12px;
`,aa=9,ra=9,Xf=10,ex=()=>Array(aa).fill(null).map(()=>Array(ra).fill(null).map(()=>({isMine:!1,isRevealed:!1,isFlagged:!1,adjacentMines:0}))),SD=(r,t,e)=>{let s=0;for(;s<Xf;){const a=Math.floor(Math.random()*aa),l=Math.floor(Math.random()*ra),c=Math.abs(a-t)<=1&&Math.abs(l-e)<=1;!r[a][l].isMine&&!c&&(r[a][l].isMine=!0,s++)}},ED=r=>{for(let t=0;t<aa;t++)for(let e=0;e<ra;e++){if(r[t][e].isMine)continue;let s=0;for(let a=-1;a<=1;a++)for(let l=-1;l<=1;l++){const c=t+a,d=e+l;c>=0&&c<aa&&d>=0&&d<ra&&r[c][d].isMine&&s++}r[t][e].adjacentMines=s}},TD=()=>{const[r,t]=j.useState(ex),[e,s]=j.useState("playing"),[a,l]=j.useState(Xf),[c,d]=j.useState(0),[h,f]=j.useState(!0),[g,m]=j.useState(!1);j.useEffect(()=>{if(e!=="playing"||h)return;const D=setInterval(()=>{d(L=>Math.min(L+1,999))},1e3);return()=>clearInterval(D)},[e,h]);const x=j.useCallback(()=>{t(ex()),s("playing"),l(Xf),d(0),f(!0)},[]),v=j.useCallback((D,L,O)=>{if(D<0||D>=aa||L<0||L>=ra)return;const B=O[D][L];if(!(B.isRevealed||B.isFlagged)&&(B.isRevealed=!0,B.adjacentMines===0&&!B.isMine))for(let F=-1;F<=1;F++)for(let W=-1;W<=1;W++)v(D+F,L+W,O)},[]),E=j.useCallback(D=>{for(let L=0;L<aa;L++)for(let O=0;O<ra;O++){const B=D[L][O];if(!B.isMine&&!B.isRevealed)return!1}return!0},[]),S=j.useCallback((D,L)=>{if(e!=="playing")return;const O=r[D][L];if(O.isRevealed||O.isFlagged)return;const B=r.map(F=>F.map(W=>({...W})));if(h&&(SD(B,D,L),ED(B),f(!1)),B[D][L].isMine){for(let F=0;F<aa;F++)for(let W=0;W<ra;W++)B[F][W].isMine&&(B[F][W].isRevealed=!0);t(B),s("lost");return}v(D,L,B),t(B),E(B)&&s("won")},[r,e,h,v,E]),C=j.useCallback((D,L,O)=>{if(D.preventDefault(),e!=="playing")return;const B=r[L][O];if(B.isRevealed)return;const F=r.map(W=>W.map(Z=>({...Z})));F[L][O].isFlagged=!B.isFlagged,t(F),l(W=>B.isFlagged?W+1:W-1)},[r,e]),T=D=>String(Math.max(0,Math.min(999,D))).padStart(3,"0"),_=()=>e==="won"?"😎":e==="lost"?"😵":g?"😮":"🙂",k=D=>D.isFlagged&&!D.isRevealed?"🚩":D.isRevealed?D.isMine?"💣":D.adjacentMines===0?null:D.adjacentMines:null,R=D=>({1:"#0000ff",2:"#008000",3:"#ff0000",4:"#000080",5:"#800000",6:"#008080",7:"#000000",8:"#808080"})[D]||"#000";return y.jsxs(CD,{children:[y.jsxs(_D,{children:[y.jsx(nx,{children:T(a)}),y.jsx(kD,{onClick:x,onMouseDown:()=>m(!0),onMouseUp:()=>m(!1),onMouseLeave:()=>m(!1),children:_()}),y.jsx(nx,{children:T(c)})]}),y.jsx(MD,{onMouseDown:()=>m(!0),onMouseUp:()=>m(!1),onMouseLeave:()=>m(!1),children:r.map((D,L)=>y.jsx(DD,{children:D.map((O,B)=>y.jsx(RD,{$revealed:O.isRevealed,$mine:O.isMine&&O.isRevealed,onClick:()=>S(L,B),onContextMenu:F=>C(F,L,B),children:y.jsx(LD,{$color:R(O.adjacentMines),children:k(O)})},B))},L))}),e==="won"&&y.jsx(OD,{children:"You Win!"})]})},CD=w.div`
  background: #c0c0c0;
  padding: 6px;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
`,_D=w.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #c0c0c0;
  padding: 4px 6px;
  margin-bottom: 6px;
  border: 2px inset #808080;
`,nx=w.div`
  background: #000;
  color: #ff0000;
  font-family: 'Courier New', monospace;
  font-size: 24px;
  font-weight: bold;
  padding: 2px 4px;
  min-width: 50px;
  text-align: center;
  border: 1px inset #808080;
`,kD=w.button`
  width: 36px;
  height: 36px;
  font-size: 20px;
  border: 3px outset #fff;
  background: #c0c0c0;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;

  &:active {
    border-style: inset;
  }
`,MD=w.div`
  border: 3px inset #808080;
  background: #c0c0c0;
`,DD=w.div`
  display: flex;
`,RD=w.div`
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  user-select: none;
  font-size: 14px;
  font-weight: bold;
  border: ${r=>r.$revealed?"1px solid #808080":"3px outset #fff"};
  background: ${r=>r.$mine?"#ff0000":(r.$revealed,"#c0c0c0")};
  box-sizing: border-box;

  &:active {
    ${r=>!r.$revealed&&`
      border-style: inset;
    `}
  }
`,LD=w.span`
  color: ${r=>r.$color};
`,OD=w.div`
  text-align: center;
  margin-top: 8px;
  font-weight: bold;
  color: #008000;
  font-size: 14px;
`,Xe=typeof process=="object"&&process+""=="[object process]"&&!process.versions.nw&&!(process.versions.electron&&process.type&&process.type!=="browser"),Wf=[.001,0,0,.001,0,0],Tf=1.35,xn={ANY:1,DISPLAY:2,PRINT:4,ANNOTATIONS_FORMS:16,ANNOTATIONS_STORAGE:32,ANNOTATIONS_DISABLE:64,IS_EDITING:128,OPLIST:256},oi={DISABLE:0,ENABLE:1,ENABLE_FORMS:2,ENABLE_STORAGE:3},sl="pdfjs_internal_editor_",Dt={DISABLE:-1,NONE:0,FREETEXT:3,HIGHLIGHT:9,STAMP:13,INK:15,POPUP:16,SIGNATURE:101,COMMENT:102},Ft={RESIZE:1,CREATE:2,FREETEXT_SIZE:11,FREETEXT_COLOR:12,FREETEXT_OPACITY:13,INK_COLOR:21,INK_THICKNESS:22,INK_OPACITY:23,HIGHLIGHT_COLOR:31,HIGHLIGHT_THICKNESS:32,HIGHLIGHT_FREE:33,HIGHLIGHT_SHOW_ALL:34,DRAW_STEP:41},$v={PRINT:4,MODIFY_CONTENTS:8,COPY:16,MODIFY_ANNOTATIONS:32,FILL_INTERACTIVE_FORMS:256,COPY_FOR_ACCESSIBILITY:512,ASSEMBLE:1024,PRINT_HIGH_QUALITY:2048},Fe={FILL:0,STROKE:1,FILL_STROKE:2,INVISIBLE:3,FILL_STROKE_MASK:3,ADD_TO_PATH_FLAG:4},Zo={GRAYSCALE_1BPP:1,RGB_24BPP:2,RGBA_32BPP:3},xe={TEXT:1,LINK:2,FREETEXT:3,LINE:4,SQUARE:5,CIRCLE:6,POLYGON:7,POLYLINE:8,HIGHLIGHT:9,UNDERLINE:10,SQUIGGLY:11,STRIKEOUT:12,STAMP:13,CARET:14,INK:15,POPUP:16,FILEATTACHMENT:17,SOUND:18,MOVIE:19,WIDGET:20,SCREEN:21,PRINTERMARK:22,TRAPNET:23,WATERMARK:24,THREED:25,REDACT:26},xr={SOLID:1,DASHED:2,BEVELED:3,INSET:4,UNDERLINE:5},dl={ERRORS:0,WARNINGS:1,INFOS:5},Pr={dependency:1,setLineWidth:2,setLineCap:3,setLineJoin:4,setMiterLimit:5,setDash:6,setRenderingIntent:7,setFlatness:8,setGState:9,save:10,restore:11,transform:12,moveTo:13,lineTo:14,curveTo:15,curveTo2:16,curveTo3:17,closePath:18,rectangle:19,stroke:20,closeStroke:21,fill:22,eoFill:23,fillStroke:24,eoFillStroke:25,closeFillStroke:26,closeEOFillStroke:27,endPath:28,clip:29,eoClip:30,beginText:31,endText:32,setCharSpacing:33,setWordSpacing:34,setHScale:35,setLeading:36,setFont:37,setTextRenderingMode:38,setTextRise:39,moveText:40,setLeadingMoveText:41,setTextMatrix:42,nextLine:43,showText:44,showSpacedText:45,nextLineShowText:46,nextLineSetSpacingShowText:47,setCharWidth:48,setCharWidthAndBounds:49,setStrokeColorSpace:50,setFillColorSpace:51,setStrokeColor:52,setStrokeColorN:53,setFillColor:54,setFillColorN:55,setStrokeGray:56,setFillGray:57,setStrokeRGBColor:58,setFillRGBColor:59,setStrokeCMYKColor:60,setFillCMYKColor:61,shadingFill:62,beginInlineImage:63,beginImageData:64,endInlineImage:65,paintXObject:66,markPoint:67,markPointProps:68,beginMarkedContent:69,beginMarkedContentProps:70,endMarkedContent:71,beginCompat:72,endCompat:73,paintFormXObjectBegin:74,paintFormXObjectEnd:75,beginGroup:76,endGroup:77,beginAnnotation:80,endAnnotation:81,paintImageMaskXObject:83,paintImageMaskXObjectGroup:84,paintImageXObject:85,paintInlineImageXObject:86,paintInlineImageXObjectGroup:87,paintImageXObjectRepeat:88,paintImageMaskXObjectRepeat:89,paintSolidColorImageMask:90,constructPath:91,setStrokeTransparent:92,setFillTransparent:93,rawFillPath:94},Kc={moveTo:0,lineTo:1,curveTo:2,closePath:3},Hv={NEED_PASSWORD:1,INCORRECT_PASSWORD:2};let ju=dl.WARNINGS;function jD(r){Number.isInteger(r)&&(ju=r)}function ND(){return ju}function Nu(r){ju>=dl.INFOS&&console.info(`Info: ${r}`)}function Rt(r){ju>=dl.WARNINGS&&console.warn(`Warning: ${r}`)}function ie(r){throw new Error(r)}function Ht(r,t){r||ie(t)}function BD(r){switch(r?.protocol){case"http:":case"https:":case"ftp:":case"mailto:":case"tel:":return!0;default:return!1}}function Ep(r,t=null,e=null){if(!r)return null;if(e&&typeof r=="string"&&(e.addDefaultProtocol&&r.startsWith("www.")&&r.match(/\./g)?.length>=2&&(r=`http://${r}`),e.tryConvertEncoding))try{r=$D(r)}catch{}const s=t?URL.parse(r,t):URL.parse(r);return BD(s)?s:null}function Tp(r,t,e=!1){const s=URL.parse(r);return s?(s.hash=t,s.href):e&&Ep(r,"http://example.com")?r.split("#",1)[0]+`${t?`#${t}`:""}`:""}function jt(r,t,e,s=!1){return Object.defineProperty(r,t,{value:e,enumerable:!s,configurable:!0,writable:!1}),e}const ma=(function(){function t(e,s){this.message=e,this.name=s}return t.prototype=new Error,t.constructor=t,t})();class ix extends ma{constructor(t,e){super(t,"PasswordException"),this.code=e}}class Cf extends ma{constructor(t,e){super(t,"UnknownErrorException"),this.details=e}}class Au extends ma{constructor(t){super(t,"InvalidPDFException")}}class al extends ma{constructor(t,e,s){super(t,"ResponseException"),this.status=e,this.missing=s}}class zD extends ma{constructor(t){super(t,"FormatError")}}class Bi extends ma{constructor(t){super(t,"AbortException")}}function Uv(r){(typeof r!="object"||r?.length===void 0)&&ie("Invalid argument for bytesToString");const t=r.length,e=8192;if(t<e)return String.fromCharCode.apply(null,r);const s=[];for(let a=0;a<t;a+=e){const l=Math.min(a+e,t),c=r.subarray(a,l);s.push(String.fromCharCode.apply(null,c))}return s.join("")}function hl(r){typeof r!="string"&&ie("Invalid argument for stringToBytes");const t=r.length,e=new Uint8Array(t);for(let s=0;s<t;++s)e[s]=r.charCodeAt(s)&255;return e}function PD(r){return String.fromCharCode(r>>24&255,r>>16&255,r>>8&255,r&255)}function ID(){const r=new Uint8Array(4);return r[0]=1,new Uint32Array(r.buffer,0,1)[0]===1}function FD(){try{return new Function(""),!0}catch{return!1}}class je{static get isLittleEndian(){return jt(this,"isLittleEndian",ID())}static get isEvalSupported(){return jt(this,"isEvalSupported",FD())}static get isOffscreenCanvasSupported(){return jt(this,"isOffscreenCanvasSupported",typeof OffscreenCanvas<"u")}static get isImageDecoderSupported(){return jt(this,"isImageDecoderSupported",typeof ImageDecoder<"u")}static get platform(){const{platform:t,userAgent:e}=navigator;return jt(this,"platform",{isAndroid:e.includes("Android"),isLinux:t.includes("Linux"),isMac:t.includes("Mac"),isWindows:t.includes("Win"),isFirefox:e.includes("Firefox")})}static get isCSSRoundSupported(){return jt(this,"isCSSRoundSupported",globalThis.CSS?.supports?.("width: round(1.5px, 1px)"))}}const _f=Array.from(Array(256).keys(),r=>r.toString(16).padStart(2,"0"));class gt{static makeHexColor(t,e,s){return`#${_f[t]}${_f[e]}${_f[s]}`}static domMatrixToTransform(t){return[t.a,t.b,t.c,t.d,t.e,t.f]}static scaleMinMax(t,e){let s;t[0]?(t[0]<0&&(s=e[0],e[0]=e[2],e[2]=s),e[0]*=t[0],e[2]*=t[0],t[3]<0&&(s=e[1],e[1]=e[3],e[3]=s),e[1]*=t[3],e[3]*=t[3]):(s=e[0],e[0]=e[1],e[1]=s,s=e[2],e[2]=e[3],e[3]=s,t[1]<0&&(s=e[1],e[1]=e[3],e[3]=s),e[1]*=t[1],e[3]*=t[1],t[2]<0&&(s=e[0],e[0]=e[2],e[2]=s),e[0]*=t[2],e[2]*=t[2]),e[0]+=t[4],e[1]+=t[5],e[2]+=t[4],e[3]+=t[5]}static transform(t,e){return[t[0]*e[0]+t[2]*e[1],t[1]*e[0]+t[3]*e[1],t[0]*e[2]+t[2]*e[3],t[1]*e[2]+t[3]*e[3],t[0]*e[4]+t[2]*e[5]+t[4],t[1]*e[4]+t[3]*e[5]+t[5]]}static multiplyByDOMMatrix(t,e){return[t[0]*e.a+t[2]*e.b,t[1]*e.a+t[3]*e.b,t[0]*e.c+t[2]*e.d,t[1]*e.c+t[3]*e.d,t[0]*e.e+t[2]*e.f+t[4],t[1]*e.e+t[3]*e.f+t[5]]}static applyTransform(t,e,s=0){const a=t[s],l=t[s+1];t[s]=a*e[0]+l*e[2]+e[4],t[s+1]=a*e[1]+l*e[3]+e[5]}static applyTransformToBezier(t,e,s=0){const a=e[0],l=e[1],c=e[2],d=e[3],h=e[4],f=e[5];for(let g=0;g<6;g+=2){const m=t[s+g],x=t[s+g+1];t[s+g]=m*a+x*c+h,t[s+g+1]=m*l+x*d+f}}static applyInverseTransform(t,e){const s=t[0],a=t[1],l=e[0]*e[3]-e[1]*e[2];t[0]=(s*e[3]-a*e[2]+e[2]*e[5]-e[4]*e[3])/l,t[1]=(-s*e[1]+a*e[0]+e[4]*e[1]-e[5]*e[0])/l}static axialAlignedBoundingBox(t,e,s){const a=e[0],l=e[1],c=e[2],d=e[3],h=e[4],f=e[5],g=t[0],m=t[1],x=t[2],v=t[3];let E=a*g+h,S=E,C=a*x+h,T=C,_=d*m+f,k=_,R=d*v+f,D=R;if(l!==0||c!==0){const L=l*g,O=l*x,B=c*m,F=c*v;E+=B,T+=B,C+=F,S+=F,_+=L,D+=L,R+=O,k+=O}s[0]=Math.min(s[0],E,C,S,T),s[1]=Math.min(s[1],_,R,k,D),s[2]=Math.max(s[2],E,C,S,T),s[3]=Math.max(s[3],_,R,k,D)}static inverseTransform(t){const e=t[0]*t[3]-t[1]*t[2];return[t[3]/e,-t[1]/e,-t[2]/e,t[0]/e,(t[2]*t[5]-t[4]*t[3])/e,(t[4]*t[1]-t[5]*t[0])/e]}static singularValueDecompose2dScale(t,e){const s=t[0],a=t[1],l=t[2],c=t[3],d=s**2+a**2,h=s*l+a*c,f=l**2+c**2,g=(d+f)/2,m=Math.sqrt(g**2-(d*f-h**2));e[0]=Math.sqrt(g+m||1),e[1]=Math.sqrt(g-m||1)}static normalizeRect(t){const e=t.slice(0);return t[0]>t[2]&&(e[0]=t[2],e[2]=t[0]),t[1]>t[3]&&(e[1]=t[3],e[3]=t[1]),e}static intersect(t,e){const s=Math.max(Math.min(t[0],t[2]),Math.min(e[0],e[2])),a=Math.min(Math.max(t[0],t[2]),Math.max(e[0],e[2]));if(s>a)return null;const l=Math.max(Math.min(t[1],t[3]),Math.min(e[1],e[3])),c=Math.min(Math.max(t[1],t[3]),Math.max(e[1],e[3]));return l>c?null:[s,l,a,c]}static pointBoundingBox(t,e,s){s[0]=Math.min(s[0],t),s[1]=Math.min(s[1],e),s[2]=Math.max(s[2],t),s[3]=Math.max(s[3],e)}static rectBoundingBox(t,e,s,a,l){l[0]=Math.min(l[0],t,s),l[1]=Math.min(l[1],e,a),l[2]=Math.max(l[2],t,s),l[3]=Math.max(l[3],e,a)}static#t(t,e,s,a,l,c,d,h,f,g){if(f<=0||f>=1)return;const m=1-f,x=f*f,v=x*f,E=m*(m*(m*t+3*f*e)+3*x*s)+v*a,S=m*(m*(m*l+3*f*c)+3*x*d)+v*h;g[0]=Math.min(g[0],E),g[1]=Math.min(g[1],S),g[2]=Math.max(g[2],E),g[3]=Math.max(g[3],S)}static#e(t,e,s,a,l,c,d,h,f,g,m,x){if(Math.abs(f)<1e-12){Math.abs(g)>=1e-12&&this.#t(t,e,s,a,l,c,d,h,-m/g,x);return}const v=g**2-4*m*f;if(v<0)return;const E=Math.sqrt(v),S=2*f;this.#t(t,e,s,a,l,c,d,h,(-g+E)/S,x),this.#t(t,e,s,a,l,c,d,h,(-g-E)/S,x)}static bezierBoundingBox(t,e,s,a,l,c,d,h,f){f[0]=Math.min(f[0],t,d),f[1]=Math.min(f[1],e,h),f[2]=Math.max(f[2],t,d),f[3]=Math.max(f[3],e,h),this.#e(t,s,l,d,e,a,c,h,3*(-t+3*(s-l)+d),6*(t-2*s+l),3*(s-t),f),this.#e(t,s,l,d,e,a,c,h,3*(-e+3*(a-c)+h),6*(e-2*a+c),3*(a-e),f)}}function $D(r){return decodeURIComponent(escape(r))}let kf=null,sx=null;function Gv(r){return kf||(kf=/([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc-\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa-\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu,sx=new Map([["ﬅ","ſt"]])),r.replaceAll(kf,(t,e,s)=>e?e.normalize("NFKC"):sx.get(s))}function Cp(){if(typeof crypto.randomUUID=="function")return crypto.randomUUID();const r=new Uint8Array(32);return crypto.getRandomValues(r),Uv(r)}const _p="pdfjs_internal_id_";function HD(r,t,e){if(!Array.isArray(e)||e.length<2)return!1;const[s,a,...l]=e;if(!r(s)&&!Number.isInteger(s)||!t(a))return!1;const c=l.length;let d=!0;switch(a.name){case"XYZ":if(c<2||c>3)return!1;break;case"Fit":case"FitB":return c===0;case"FitH":case"FitBH":case"FitV":case"FitBV":if(c>1)return!1;break;case"FitR":if(c!==4)return!1;d=!1;break;default:return!1}for(const h of l)if(!(typeof h=="number"||d&&h===null))return!1;return!0}function Ve(r,t,e){return Math.min(Math.max(r,t),e)}function Vv(r){return Uint8Array.prototype.toBase64?r.toBase64():btoa(Uv(r))}function UD(r){return Uint8Array.fromBase64?Uint8Array.fromBase64(r):hl(atob(r))}typeof Promise.try!="function"&&(Promise.try=function(r,...t){return new Promise(e=>{e(r(...t))})});typeof Math.sumPrecise!="function"&&(Math.sumPrecise=function(r){return r.reduce((t,e)=>t+e,0)});class rl{static textContent(t){const e=[],s={items:e,styles:Object.create(null)};function a(l){if(!l)return;let c=null;const d=l.name;if(d==="#text")c=l.value;else if(rl.shouldBuildText(d))l?.attributes?.textContent?c=l.attributes.textContent:l.value&&(c=l.value);else return;if(c!==null&&e.push({str:c}),!!l.children)for(const h of l.children)a(h)}return a(t),s}static shouldBuildText(t){return!(t==="textarea"||t==="input"||t==="option"||t==="select")}}class kp{static setupStorage(t,e,s,a,l){const c=a.getValue(e,{value:null});switch(s.name){case"textarea":if(c.value!==null&&(t.textContent=c.value),l==="print")break;t.addEventListener("input",d=>{a.setValue(e,{value:d.target.value})});break;case"input":if(s.attributes.type==="radio"||s.attributes.type==="checkbox"){if(c.value===s.attributes.xfaOn?t.setAttribute("checked",!0):c.value===s.attributes.xfaOff&&t.removeAttribute("checked"),l==="print")break;t.addEventListener("change",d=>{a.setValue(e,{value:d.target.checked?d.target.getAttribute("xfaOn"):d.target.getAttribute("xfaOff")})})}else{if(c.value!==null&&t.setAttribute("value",c.value),l==="print")break;t.addEventListener("input",d=>{a.setValue(e,{value:d.target.value})})}break;case"select":if(c.value!==null){t.setAttribute("value",c.value);for(const d of s.children)d.attributes.value===c.value?d.attributes.selected=!0:d.attributes.hasOwnProperty("selected")&&delete d.attributes.selected}t.addEventListener("input",d=>{const h=d.target.options,f=h.selectedIndex===-1?"":h[h.selectedIndex].value;a.setValue(e,{value:f})});break}}static setAttributes({html:t,element:e,storage:s=null,intent:a,linkService:l}){const{attributes:c}=e,d=t instanceof HTMLAnchorElement;c.type==="radio"&&(c.name=`${c.name}-${a}`);for(const[h,f]of Object.entries(c))if(f!=null)switch(h){case"class":f.length&&t.setAttribute(h,f.join(" "));break;case"dataId":break;case"id":t.setAttribute("data-element-id",f);break;case"style":Object.assign(t.style,f);break;case"textContent":t.textContent=f;break;default:(!d||h!=="href"&&h!=="newWindow")&&t.setAttribute(h,f)}d&&l.addLinkAttributes(t,c.href,c.newWindow),s&&c.dataId&&this.setupStorage(t,c.dataId,e,s)}static render(t){const e=t.annotationStorage,s=t.linkService,a=t.xfaHtml,l=t.intent||"display",c=document.createElement(a.name);a.attributes&&this.setAttributes({html:c,element:a,intent:l,linkService:s});const d=l!=="richText",h=t.div;if(h.append(c),t.viewport){const m=`matrix(${t.viewport.transform.join(",")})`;h.style.transform=m}d&&h.setAttribute("class","xfaLayer xfaFont");const f=[];if(a.children.length===0){if(a.value){const m=document.createTextNode(a.value);c.append(m),d&&rl.shouldBuildText(a.name)&&f.push(m)}return{textDivs:f}}const g=[[a,-1,c]];for(;g.length>0;){const[m,x,v]=g.at(-1);if(x+1===m.children.length){g.pop();continue}const E=m.children[++g.at(-1)[1]];if(E===null)continue;const{name:S}=E;if(S==="#text"){const T=document.createTextNode(E.value);f.push(T),v.append(T);continue}const C=E?.attributes?.xmlns?document.createElementNS(E.attributes.xmlns,S):document.createElement(S);if(v.append(C),E.attributes&&this.setAttributes({html:C,element:E,storage:e,intent:l,linkService:s}),E.children?.length>0)g.push([E,-1,C]);else if(E.value){const T=document.createTextNode(E.value);d&&rl.shouldBuildText(S)&&f.push(T),C.append(T)}}for(const m of h.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))m.setAttribute("readOnly",!0);return{textDivs:f}}static update(t){const e=`matrix(${t.viewport.transform.join(",")})`;t.div.style.transform=e,t.div.hidden=!1}}const Oi="http://www.w3.org/2000/svg";class da{static CSS=96;static PDF=72;static PDF_TO_CSS_UNITS=this.CSS/this.PDF}async function Hr(r,t="text"){if(Xo(r,document.baseURI)){const e=await fetch(r);if(!e.ok)throw new Error(e.statusText);switch(t){case"arraybuffer":return e.arrayBuffer();case"blob":return e.blob();case"json":return e.json()}return e.text()}return new Promise((e,s)=>{const a=new XMLHttpRequest;a.open("GET",r,!0),a.responseType=t,a.onreadystatechange=()=>{if(a.readyState===XMLHttpRequest.DONE){if(a.status===200||a.status===0){switch(t){case"arraybuffer":case"blob":case"json":e(a.response);return}e(a.responseText);return}s(new Error(a.statusText))}},a.send(null)})}class fl{constructor({viewBox:t,userUnit:e,scale:s,rotation:a,offsetX:l=0,offsetY:c=0,dontFlip:d=!1}){this.viewBox=t,this.userUnit=e,this.scale=s,this.rotation=a,this.offsetX=l,this.offsetY=c,s*=e;const h=(t[2]+t[0])/2,f=(t[3]+t[1])/2;let g,m,x,v;switch(a%=360,a<0&&(a+=360),a){case 180:g=-1,m=0,x=0,v=1;break;case 90:g=0,m=1,x=1,v=0;break;case 270:g=0,m=-1,x=-1,v=0;break;case 0:g=1,m=0,x=0,v=-1;break;default:throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.")}d&&(x=-x,v=-v);let E,S,C,T;g===0?(E=Math.abs(f-t[1])*s+l,S=Math.abs(h-t[0])*s+c,C=(t[3]-t[1])*s,T=(t[2]-t[0])*s):(E=Math.abs(h-t[0])*s+l,S=Math.abs(f-t[1])*s+c,C=(t[2]-t[0])*s,T=(t[3]-t[1])*s),this.transform=[g*s,m*s,x*s,v*s,E-g*s*h-x*s*f,S-m*s*h-v*s*f],this.width=C,this.height=T}get rawDims(){const t=this.viewBox;return jt(this,"rawDims",{pageWidth:t[2]-t[0],pageHeight:t[3]-t[1],pageX:t[0],pageY:t[1]})}clone({scale:t=this.scale,rotation:e=this.rotation,offsetX:s=this.offsetX,offsetY:a=this.offsetY,dontFlip:l=!1}={}){return new fl({viewBox:this.viewBox.slice(),userUnit:this.userUnit,scale:t,rotation:e,offsetX:s,offsetY:a,dontFlip:l})}convertToViewportPoint(t,e){const s=[t,e];return gt.applyTransform(s,this.transform),s}convertToViewportRectangle(t){const e=[t[0],t[1]];gt.applyTransform(e,this.transform);const s=[t[2],t[3]];return gt.applyTransform(s,this.transform),[e[0],e[1],s[0],s[1]]}convertToPdfPoint(t,e){const s=[t,e];return gt.applyInverseTransform(s,this.transform),s}}class Bu extends ma{constructor(t,e=0){super(t,"RenderingCancelledException"),this.extraDelay=e}}function pl(r){const t=r.length;let e=0;for(;e<t&&r[e].trim()==="";)e++;return r.substring(e,e+5).toLowerCase()==="data:"}function zu(r){return typeof r=="string"&&/\.pdf$/i.test(r)}function qv(r){return[r]=r.split(/[#?]/,1),r.substring(r.lastIndexOf("/")+1)}function Yv(r,t="document.pdf"){if(typeof r!="string")return t;if(pl(r))return Rt('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'),t;const s=(d=>{try{return new URL(d)}catch{try{return new URL(decodeURIComponent(d))}catch{try{return new URL(d,"https://foo.bar")}catch{try{return new URL(decodeURIComponent(d),"https://foo.bar")}catch{return null}}}}})(r);if(!s)return t;const a=d=>{try{let h=decodeURIComponent(d);return h.includes("/")?(h=h.split("/").at(-1),h.test(/^\.pdf$/i)?h:d):h}catch{return d}},l=/\.pdf$/i,c=s.pathname.split("/").at(-1);if(l.test(c))return a(c);if(s.searchParams.size>0){const d=Array.from(s.searchParams.values()).reverse();for(const f of d)if(l.test(f))return a(f);const h=Array.from(s.searchParams.keys()).reverse();for(const f of h)if(l.test(f))return a(f)}if(s.hash){const h=/[^/?#=]+\.pdf\b(?!.*\.pdf\b)/i.exec(s.hash);if(h)return a(h[0])}return t}class ax{started=Object.create(null);times=[];time(t){t in this.started&&Rt(`Timer is already running for ${t}`),this.started[t]=Date.now()}timeEnd(t){t in this.started||Rt(`Timer has not been started for ${t}`),this.times.push({name:t,start:this.started[t],end:Date.now()}),delete this.started[t]}toString(){const t=[];let e=0;for(const{name:s}of this.times)e=Math.max(s.length,e);for(const{name:s,start:a,end:l}of this.times)t.push(`${s.padEnd(e)} ${l-a}ms
`);return t.join("")}}function Xo(r,t){const e=t?URL.parse(r,t):URL.parse(r);return e?.protocol==="http:"||e?.protocol==="https:"}function wn(r){r.preventDefault()}function he(r){r.preventDefault(),r.stopPropagation()}function GD(r){console.log("Deprecated API usage: "+r)}class wu{static#t;static toDateObject(t){if(t instanceof Date)return t;if(!t||typeof t!="string")return null;this.#t||=new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+|-])?(\\d{2})?'?(\\d{2})?'?");const e=this.#t.exec(t);if(!e)return null;const s=parseInt(e[1],10);let a=parseInt(e[2],10);a=a>=1&&a<=12?a-1:0;let l=parseInt(e[3],10);l=l>=1&&l<=31?l:1;let c=parseInt(e[4],10);c=c>=0&&c<=23?c:0;let d=parseInt(e[5],10);d=d>=0&&d<=59?d:0;let h=parseInt(e[6],10);h=h>=0&&h<=59?h:0;const f=e[7]||"Z";let g=parseInt(e[8],10);g=g>=0&&g<=23?g:0;let m=parseInt(e[9],10)||0;return m=m>=0&&m<=59?m:0,f==="-"?(c+=g,d+=m):f==="+"&&(c-=g,d-=m),new Date(Date.UTC(s,a,l,c,d,h))}}function Xv(r,{scale:t=1,rotation:e=0}){const{width:s,height:a}=r.attributes.style,l=[0,0,parseInt(s),parseInt(a)];return new fl({viewBox:l,userUnit:1,scale:t,rotation:e})}function Ur(r){if(r.startsWith("#")){const t=parseInt(r.slice(1),16);return[(t&16711680)>>16,(t&65280)>>8,t&255]}return r.startsWith("rgb(")?r.slice(4,-1).split(",").map(t=>parseInt(t)):r.startsWith("rgba(")?r.slice(5,-1).split(",").map(t=>parseInt(t)).slice(0,3):(Rt(`Not a valid color format: "${r}"`),[0,0,0])}function VD(r){const t=document.createElement("span");t.style.visibility="hidden",t.style.colorScheme="only light",document.body.append(t);for(const e of r.keys()){t.style.color=e;const s=window.getComputedStyle(t).color;r.set(e,Ur(s))}t.remove()}function de(r){const{a:t,b:e,c:s,d:a,e:l,f:c}=r.getTransform();return[t,e,s,a,l,c]}function ni(r){const{a:t,b:e,c:s,d:a,e:l,f:c}=r.getTransform().invertSelf();return[t,e,s,a,l,c]}function _s(r,t,e=!1,s=!0){if(t instanceof fl){const{pageWidth:a,pageHeight:l}=t.rawDims,{style:c}=r,d=je.isCSSRoundSupported,h=`var(--total-scale-factor) * ${a}px`,f=`var(--total-scale-factor) * ${l}px`,g=d?`round(down, ${h}, var(--scale-round-x))`:`calc(${h})`,m=d?`round(down, ${f}, var(--scale-round-y))`:`calc(${f})`;!e||t.rotation%180===0?(c.width=g,c.height=m):(c.width=m,c.height=g)}s&&r.setAttribute("data-main-rotation",t.rotation)}class Wn{constructor(){const{pixelRatio:t}=Wn;this.sx=t,this.sy=t}get scaled(){return this.sx!==1||this.sy!==1}get symmetric(){return this.sx===this.sy}limitCanvas(t,e,s,a,l=-1){let c=1/0,d=1/0,h=1/0;s=Wn.capPixels(s,l),s>0&&(c=Math.sqrt(s/(t*e))),a!==-1&&(d=a/t,h=a/e);const f=Math.min(c,d,h);return this.sx>f||this.sy>f?(this.sx=f,this.sy=f,!0):!1}static get pixelRatio(){return globalThis.devicePixelRatio||1}static capPixels(t,e){if(e>=0){const s=Math.ceil(window.screen.availWidth*window.screen.availHeight*this.pixelRatio**2*(1+e/100));return t>0?Math.min(t,s):s}return t}}const Su=["image/apng","image/avif","image/bmp","image/gif","image/jpeg","image/png","image/svg+xml","image/webp","image/x-icon"];class qD{static get isDarkMode(){return jt(this,"isDarkMode",!!window?.matchMedia?.("(prefers-color-scheme: dark)").matches)}}class Wv{static get commentForegroundColor(){const t=document.createElement("span");t.classList.add("comment","sidebar");const{style:e}=t;e.width=e.height="0",e.display="none",e.color="var(--comment-fg-color)",document.body.append(t);const{color:s}=window.getComputedStyle(t);return t.remove(),jt(this,"commentForegroundColor",Ur(s))}}function Qv(r,t,e,s){s=Math.min(Math.max(s??1,0),1);const a=255*(1-s);return r=Math.round(r*s+a),t=Math.round(t*s+a),e=Math.round(e*s+a),[r,t,e]}function rx(r,t){const e=r[0]/255,s=r[1]/255,a=r[2]/255,l=Math.max(e,s,a),c=Math.min(e,s,a),d=(l+c)/2;if(l===c)t[0]=t[1]=0;else{const h=l-c;switch(t[1]=d<.5?h/(l+c):h/(2-l-c),l){case e:t[0]=((s-a)/h+(s<a?6:0))*60;break;case s:t[0]=((a-e)/h+2)*60;break;case a:t[0]=((e-s)/h+4)*60;break}}t[2]=d}function Qf(r,t){const e=r[0],s=r[1],a=r[2],l=(1-Math.abs(2*a-1))*s,c=l*(1-Math.abs(e/60%2-1)),d=a-l/2;switch(Math.floor(e/60)){case 0:t[0]=l+d,t[1]=c+d,t[2]=d;break;case 1:t[0]=c+d,t[1]=l+d,t[2]=d;break;case 2:t[0]=d,t[1]=l+d,t[2]=c+d;break;case 3:t[0]=d,t[1]=c+d,t[2]=l+d;break;case 4:t[0]=c+d,t[1]=d,t[2]=l+d;break;case 5:case 6:t[0]=l+d,t[1]=d,t[2]=c+d;break}}function ox(r){return r<=.03928?r/12.92:((r+.055)/1.055)**2.4}function lx(r,t,e){Qf(r,e),e.map(ox);const s=.2126*e[0]+.7152*e[1]+.0722*e[2];Qf(t,e),e.map(ox);const a=.2126*e[0]+.7152*e[1]+.0722*e[2];return s>a?(s+.05)/(a+.05):(a+.05)/(s+.05)}const cx=new Map;function Kv(r,t){const e=r[0]+r[1]*256+r[2]*65536+t[0]*16777216+t[1]*4294967296+t[2]*1099511627776;let s=cx.get(e);if(s)return s;const a=new Float32Array(9),l=a.subarray(0,3),c=a.subarray(3,6);rx(r,c);const d=a.subarray(6,9);rx(t,d);const h=d[2]<.5,f=h?12:4.5;if(c[2]=h?Math.sqrt(c[2]):1-Math.sqrt(1-c[2]),lx(c,d,l)<f){let g,m;h?(g=c[2],m=1):(g=0,m=c[2]);const x=.005;for(;m-g>x;){const v=c[2]=(g+m)/2;h===lx(c,d,l)<f?g=v:m=v}c[2]=h?m:g}return Qf(c,l),s=gt.makeHexColor(Math.round(l[0]*255),Math.round(l[1]*255),Math.round(l[2]*255)),cx.set(e,s),s}function Mp({html:r,dir:t,className:e},s){const a=document.createDocumentFragment();if(typeof r=="string"){const l=document.createElement("p");l.dir=t||"auto";const c=r.split(/(?:\r\n?|\n)/);for(let d=0,h=c.length;d<h;++d){const f=c[d];l.append(document.createTextNode(f)),d<h-1&&l.append(document.createElement("br"))}a.append(l)}else kp.render({xfaHtml:r,div:a,intent:"richText"});a.firstChild.classList.add("richText",e),s.append(a)}class Jo{#t=null;#e=null;#i;#n=null;#r=null;#s=null;#a=null;#o=null;static#c=null;constructor(t){this.#i=t,Jo.#c||=Object.freeze({freetext:"pdfjs-editor-remove-freetext-button",highlight:"pdfjs-editor-remove-highlight-button",ink:"pdfjs-editor-remove-ink-button",stamp:"pdfjs-editor-remove-stamp-button",signature:"pdfjs-editor-remove-signature-button"})}render(){const t=this.#t=document.createElement("div");t.classList.add("editToolbar","hidden"),t.setAttribute("role","toolbar");const e=this.#i._uiManager._signal;e instanceof AbortSignal&&!e.aborted&&(t.addEventListener("contextmenu",wn,{signal:e}),t.addEventListener("pointerdown",Jo.#l,{signal:e}));const s=this.#n=document.createElement("div");s.className="buttons",t.append(s);const a=this.#i.toolbarPosition;if(a){const{style:l}=t,c=this.#i._uiManager.direction==="ltr"?1-a[0]:a[0];l.insetInlineEnd=`${100*c}%`,l.top=`calc(${100*a[1]}% + var(--editor-toolbar-vert-offset))`}return t}get div(){return this.#t}static#l(t){t.stopPropagation()}#h(t){this.#i._focusEventsAllowed=!1,he(t)}#d(t){this.#i._focusEventsAllowed=!0,he(t)}#f(t){const e=this.#i._uiManager._signal;return!(e instanceof AbortSignal)||e.aborted?!1:(t.addEventListener("focusin",this.#h.bind(this),{capture:!0,signal:e}),t.addEventListener("focusout",this.#d.bind(this),{capture:!0,signal:e}),t.addEventListener("contextmenu",wn,{signal:e}),!0)}hide(){this.#t.classList.add("hidden"),this.#e?.hideDropdown()}show(){this.#t.classList.remove("hidden"),this.#r?.shown(),this.#s?.shown()}addDeleteButton(){const{editorType:t,_uiManager:e}=this.#i,s=document.createElement("button");s.classList.add("basic","deleteButton"),s.tabIndex=0,s.setAttribute("data-l10n-id",Jo.#c[t]),this.#f(s)&&s.addEventListener("click",a=>{e.delete()},{signal:e._signal}),this.#n.append(s)}get#m(){const t=document.createElement("div");return t.className="divider",t}async addAltText(t){const e=await t.render();this.#f(e),this.#n.append(e,this.#m),this.#r=t}addComment(t,e=null){if(this.#s)return;const s=t.renderForToolbar();if(!s)return;this.#f(s);const a=this.#a=this.#m;e?(this.#n.insertBefore(s,e),this.#n.insertBefore(a,e)):this.#n.append(s,a),this.#s=t,t.toolbar=this}addColorPicker(t){if(this.#e)return;this.#e=t;const e=t.renderButton();this.#f(e),this.#n.append(e,this.#m)}async addEditSignatureButton(t){const e=this.#o=await t.renderEditButton(this.#i);this.#f(e),this.#n.append(e,this.#m)}removeButton(t){t==="comment"&&(this.#s?.removeToolbarCommentButton(),this.#s=null,this.#a?.remove(),this.#a=null)}async addButton(t,e){switch(t){case"colorPicker":this.addColorPicker(e);break;case"altText":await this.addAltText(e);break;case"editSignature":await this.addEditSignatureButton(e);break;case"delete":this.addDeleteButton();break;case"comment":this.addComment(e);break}}async addButtonBefore(t,e,s){const a=this.#n.querySelector(s);a&&t==="comment"&&this.addComment(e,a)}updateEditSignatureButton(t){this.#o&&(this.#o.title=t)}remove(){this.#t.remove(),this.#e?.destroy(),this.#e=null}}class YD{#t=null;#e=null;#i;constructor(t){this.#i=t}#n(){const t=this.#e=document.createElement("div");t.className="editToolbar",t.setAttribute("role","toolbar");const e=this.#i._signal;e instanceof AbortSignal&&!e.aborted&&t.addEventListener("contextmenu",wn,{signal:e});const s=this.#t=document.createElement("div");return s.className="buttons",t.append(s),this.#i.hasCommentManager()&&this.#s("commentButton","pdfjs-comment-floating-button","pdfjs-comment-floating-button-label",()=>{this.#i.commentSelection("floating_button")}),this.#s("highlightButton","pdfjs-highlight-floating-button1","pdfjs-highlight-floating-button-label",()=>{this.#i.highlightSelection("floating_button")}),t}#r(t,e){let s=0,a=0;for(const l of t){const c=l.y+l.height;if(c<s)continue;const d=l.x+(e?l.width:0);if(c>s){a=d,s=c;continue}e?d>a&&(a=d):d<a&&(a=d)}return[e?1-a:a,s]}show(t,e,s){const[a,l]=this.#r(e,s),{style:c}=this.#e||=this.#n();t.append(this.#e),c.insetInlineEnd=`${100*a}%`,c.top=`calc(${100*l}% + var(--editor-toolbar-vert-offset))`}hide(){this.#e.remove()}#s(t,e,s,a){const l=document.createElement("button");l.classList.add("basic",t),l.tabIndex=0,l.setAttribute("data-l10n-id",e);const c=document.createElement("span");l.append(c),c.className="visuallyHidden",c.setAttribute("data-l10n-id",s);const d=this.#i._signal;d instanceof AbortSignal&&!d.aborted&&(l.addEventListener("contextmenu",wn,{signal:d}),l.addEventListener("click",a,{signal:d})),this.#t.append(l)}}function Zv(r,t,e){for(const s of e)t.addEventListener(s,r[s].bind(r))}class XD{#t=0;get id(){return`${sl}${this.#t++}`}}class Dp{#t=Cp();#e=0;#i=null;static get _isSVGFittingCanvas(){const t='data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" style="fill:red;"/></svg>',s=new OffscreenCanvas(1,3).getContext("2d",{willReadFrequently:!0}),a=new Image;a.src=t;const l=a.decode().then(()=>(s.drawImage(a,0,0,1,1,0,0,1,3),new Uint32Array(s.getImageData(0,0,1,1).data.buffer)[0]===0));return jt(this,"_isSVGFittingCanvas",l)}async#n(t,e){this.#i||=new Map;let s=this.#i.get(t);if(s===null)return null;if(s?.bitmap)return s.refCounter+=1,s;try{s||={bitmap:null,id:`image_${this.#t}_${this.#e++}`,refCounter:0,isSvg:!1};let a;if(typeof e=="string"?(s.url=e,a=await Hr(e,"blob")):e instanceof File?a=s.file=e:e instanceof Blob&&(a=e),a.type==="image/svg+xml"){const l=Dp._isSVGFittingCanvas,c=new FileReader,d=new Image,h=new Promise((f,g)=>{d.onload=()=>{s.bitmap=d,s.isSvg=!0,f()},c.onload=async()=>{const m=s.svgUrl=c.result;d.src=await l?`${m}#svgView(preserveAspectRatio(none))`:m},d.onerror=c.onerror=g});c.readAsDataURL(a),await h}else s.bitmap=await createImageBitmap(a);s.refCounter=1}catch(a){Rt(a),s=null}return this.#i.set(t,s),s&&this.#i.set(s.id,s),s}async getFromFile(t){const{lastModified:e,name:s,size:a,type:l}=t;return this.#n(`${e}_${s}_${a}_${l}`,t)}async getFromUrl(t){return this.#n(t,t)}async getFromBlob(t,e){const s=await e;return this.#n(t,s)}async getFromId(t){this.#i||=new Map;const e=this.#i.get(t);if(!e)return null;if(e.bitmap)return e.refCounter+=1,e;if(e.file)return this.getFromFile(e.file);if(e.blobPromise){const{blobPromise:s}=e;return delete e.blobPromise,this.getFromBlob(e.id,s)}return this.getFromUrl(e.url)}getFromCanvas(t,e){this.#i||=new Map;let s=this.#i.get(t);if(s?.bitmap)return s.refCounter+=1,s;const a=new OffscreenCanvas(e.width,e.height);return a.getContext("2d").drawImage(e,0,0),s={bitmap:a.transferToImageBitmap(),id:`image_${this.#t}_${this.#e++}`,refCounter:1,isSvg:!1},this.#i.set(t,s),this.#i.set(s.id,s),s}getSvgUrl(t){const e=this.#i.get(t);return e?.isSvg?e.svgUrl:null}deleteId(t){this.#i||=new Map;const e=this.#i.get(t);if(!e||(e.refCounter-=1,e.refCounter!==0))return;const{bitmap:s}=e;if(!e.url&&!e.file){const a=new OffscreenCanvas(s.width,s.height);a.getContext("bitmaprenderer").transferFromImageBitmap(s),e.blobPromise=a.convertToBlob()}s.close?.(),e.bitmap=null}isValidId(t){return t.startsWith(`image_${this.#t}_`)}}class WD{#t=[];#e=!1;#i;#n=-1;constructor(t=128){this.#i=t}add({cmd:t,undo:e,post:s,mustExec:a,type:l=NaN,overwriteIfSameType:c=!1,keepUndo:d=!1}){if(a&&t(),this.#e)return;const h={cmd:t,undo:e,post:s,type:l};if(this.#n===-1){this.#t.length>0&&(this.#t.length=0),this.#n=0,this.#t.push(h);return}if(c&&this.#t[this.#n].type===l){d&&(h.undo=this.#t[this.#n].undo),this.#t[this.#n]=h;return}const f=this.#n+1;f===this.#i?this.#t.splice(0,1):(this.#n=f,f<this.#t.length&&this.#t.splice(f)),this.#t.push(h)}undo(){if(this.#n===-1)return;this.#e=!0;const{undo:t,post:e}=this.#t[this.#n];t(),e?.(),this.#e=!1,this.#n-=1}redo(){if(this.#n<this.#t.length-1){this.#n+=1,this.#e=!0;const{cmd:t,post:e}=this.#t[this.#n];t(),e?.(),this.#e=!1}}hasSomethingToUndo(){return this.#n!==-1}hasSomethingToRedo(){return this.#n<this.#t.length-1}cleanType(t){if(this.#n!==-1){for(let e=this.#n;e>=0;e--)if(this.#t[e].type!==t){this.#t.splice(e+1,this.#n-e),this.#n=e;return}this.#t.length=0,this.#n=-1}}destroy(){this.#t=null}}class gl{constructor(t){this.buffer=[],this.callbacks=new Map,this.allKeys=new Set;const{isMac:e}=je.platform;for(const[s,a,l={}]of t)for(const c of s){const d=c.startsWith("mac+");e&&d?(this.callbacks.set(c.slice(4),{callback:a,options:l}),this.allKeys.add(c.split("+").at(-1))):!e&&!d&&(this.callbacks.set(c,{callback:a,options:l}),this.allKeys.add(c.split("+").at(-1)))}}#t(t){t.altKey&&this.buffer.push("alt"),t.ctrlKey&&this.buffer.push("ctrl"),t.metaKey&&this.buffer.push("meta"),t.shiftKey&&this.buffer.push("shift"),this.buffer.push(t.key);const e=this.buffer.join("+");return this.buffer.length=0,e}exec(t,e){if(!this.allKeys.has(e.key))return;const s=this.callbacks.get(this.#t(e));if(!s)return;const{callback:a,options:{bubbles:l=!1,args:c=[],checker:d=null}}=s;d&&!d(t,e)||(a.bind(t,...c,e)(),l||he(e))}}class Rp{static _colorsMapping=new Map([["CanvasText",[0,0,0]],["Canvas",[255,255,255]]]);get _colors(){const t=new Map([["CanvasText",null],["Canvas",null]]);return VD(t),jt(this,"_colors",t)}convert(t){const e=Ur(t);if(!window.matchMedia("(forced-colors: active)").matches)return e;for(const[s,a]of this._colors)if(a.every((l,c)=>l===e[c]))return Rp._colorsMapping.get(s);return e}getHexCode(t){const e=this._colors.get(t);return e?gt.makeHexColor(...e):t}}class zi{#t=new AbortController;#e=null;#i=null;#n=new Map;#r=new Map;#s=null;#a=null;#o=null;#c=new WD;#l=null;#h=null;#d=null;#f=0;#m=new Set;#p=null;#u=null;#g=new Set;_editorUndoBar=null;#b=!1;#x=!1;#y=!1;#T=null;#S=null;#v=null;#_=null;#w=!1;#E=null;#D=new XD;#k=!1;#M=!1;#z=!1;#L=null;#j=null;#P=null;#N=null;#G=null;#C=Dt.NONE;#A=new Set;#O=null;#I=null;#$=null;#Y=null;#q=null;#X={isEditing:!1,isEmpty:!0,hasSomethingToUndo:!1,hasSomethingToRedo:!1,hasSelectedEditor:!1,hasSelectedText:!1};#H=[0,0];#B=null;#V=null;#Z=null;#J=null;#F=null;static TRANSLATE_SMALL=1;static TRANSLATE_BIG=10;static get _keyboardManager(){const t=zi.prototype,e=c=>c.#V.contains(document.activeElement)&&document.activeElement.tagName!=="BUTTON"&&c.hasSomethingToControl(),s=(c,{target:d})=>{if(d instanceof HTMLInputElement){const{type:h}=d;return h!=="text"&&h!=="number"}return!0},a=this.TRANSLATE_SMALL,l=this.TRANSLATE_BIG;return jt(this,"_keyboardManager",new gl([[["ctrl+a","mac+meta+a"],t.selectAll,{checker:s}],[["ctrl+z","mac+meta+z"],t.undo,{checker:s}],[["ctrl+y","ctrl+shift+z","mac+meta+shift+z","ctrl+shift+Z","mac+meta+shift+Z"],t.redo,{checker:s}],[["Backspace","alt+Backspace","ctrl+Backspace","shift+Backspace","mac+Backspace","mac+alt+Backspace","mac+ctrl+Backspace","Delete","ctrl+Delete","shift+Delete","mac+Delete"],t.delete,{checker:s}],[["Enter","mac+Enter"],t.addNewEditorFromKeyboard,{checker:(c,{target:d})=>!(d instanceof HTMLButtonElement)&&c.#V.contains(d)&&!c.isEnterHandled}],[[" ","mac+ "],t.addNewEditorFromKeyboard,{checker:(c,{target:d})=>!(d instanceof HTMLButtonElement)&&c.#V.contains(document.activeElement)}],[["Escape","mac+Escape"],t.unselectAll],[["ArrowLeft","mac+ArrowLeft"],t.translateSelectedEditors,{args:[-a,0],checker:e}],[["ctrl+ArrowLeft","mac+shift+ArrowLeft"],t.translateSelectedEditors,{args:[-l,0],checker:e}],[["ArrowRight","mac+ArrowRight"],t.translateSelectedEditors,{args:[a,0],checker:e}],[["ctrl+ArrowRight","mac+shift+ArrowRight"],t.translateSelectedEditors,{args:[l,0],checker:e}],[["ArrowUp","mac+ArrowUp"],t.translateSelectedEditors,{args:[0,-a],checker:e}],[["ctrl+ArrowUp","mac+shift+ArrowUp"],t.translateSelectedEditors,{args:[0,-l],checker:e}],[["ArrowDown","mac+ArrowDown"],t.translateSelectedEditors,{args:[0,a],checker:e}],[["ctrl+ArrowDown","mac+shift+ArrowDown"],t.translateSelectedEditors,{args:[0,l],checker:e}]]))}constructor(t,e,s,a,l,c,d,h,f,g,m,x,v,E,S,C){const T=this._signal=this.#t.signal;this.#V=t,this.#Z=e,this.#J=s,this.#s=a,this.#l=l,this.#I=c,this.#q=h,this._eventBus=d,d._on("editingaction",this.onEditingAction.bind(this),{signal:T}),d._on("pagechanging",this.onPageChanging.bind(this),{signal:T}),d._on("scalechanging",this.onScaleChanging.bind(this),{signal:T}),d._on("rotationchanging",this.onRotationChanging.bind(this),{signal:T}),d._on("setpreference",this.onSetPreference.bind(this),{signal:T}),d._on("switchannotationeditorparams",_=>this.updateParams(_.type,_.value),{signal:T}),window.addEventListener("pointerdown",()=>{this.#M=!0},{capture:!0,signal:T}),window.addEventListener("pointerup",()=>{this.#M=!1},{capture:!0,signal:T}),this.#lt(),this.#ht(),this.#et(),this.#a=h.annotationStorage,this.#T=h.filterFactory,this.#$=f,this.#_=g||null,this.#b=m,this.#x=x,this.#y=v,this.#G=E||null,this.viewParameters={realScale:da.PDF_TO_CSS_UNITS,rotation:0},this.isShiftKeyDown=!1,this._editorUndoBar=S||null,this._supportsPinchToZoom=C!==!1,l?.setSidebarUiManager(this)}destroy(){this.#F?.resolve(),this.#F=null,this.#t?.abort(),this.#t=null,this._signal=null;for(const t of this.#r.values())t.destroy();this.#r.clear(),this.#n.clear(),this.#g.clear(),this.#N?.clear(),this.#e=null,this.#A.clear(),this.#c.destroy(),this.#s?.destroy(),this.#l?.destroy(),this.#I?.destroy(),this.#E?.hide(),this.#E=null,this.#P?.destroy(),this.#P=null,this.#i=null,this.#S&&(clearTimeout(this.#S),this.#S=null),this.#B&&(clearTimeout(this.#B),this.#B=null),this._editorUndoBar?.destroy(),this.#q=null}combinedSignal(t){return AbortSignal.any([this._signal,t.signal])}get mlManager(){return this.#G}get useNewAltTextFlow(){return this.#x}get useNewAltTextWhenAddingImage(){return this.#y}get hcmFilter(){return jt(this,"hcmFilter",this.#$?this.#T.addHCMFilter(this.#$.foreground,this.#$.background):"none")}get direction(){return jt(this,"direction",getComputedStyle(this.#V).direction)}get _highlightColors(){return jt(this,"_highlightColors",this.#_?new Map(this.#_.split(",").map(t=>(t=t.split("=").map(e=>e.trim()),t[1]=t[1].toUpperCase(),t))):null)}get highlightColors(){const{_highlightColors:t}=this;if(!t)return jt(this,"highlightColors",null);const e=new Map,s=!!this.#$;for(const[a,l]of t){const c=a.endsWith("_HCM");if(s&&c){e.set(a.replace("_HCM",""),l);continue}!s&&!c&&e.set(a,l)}return jt(this,"highlightColors",e)}get highlightColorNames(){return jt(this,"highlightColorNames",this.highlightColors?new Map(Array.from(this.highlightColors,t=>t.reverse())):null)}getNonHCMColor(t){if(!this._highlightColors)return t;const e=this.highlightColorNames.get(t);return this._highlightColors.get(e)||t}getNonHCMColorName(t){return this.highlightColorNames.get(t)||t}setCurrentDrawingSession(t){t?(this.unselectAll(),this.disableUserSelect(!0)):this.disableUserSelect(!1),this.#d=t}setMainHighlightColorPicker(t){this.#P=t}editAltText(t,e=!1){this.#s?.editAltText(this,t,e)}hasCommentManager(){return!!this.#l}editComment(t,e,s,a){this.#l?.showDialog(this,t,e,s,a)}selectComment(t,e){this.#r.get(t)?.getEditorByUID(e)?.toggleComment(!0,!0)}updateComment(t){this.#l?.updateComment(t.getData())}updatePopupColor(t){this.#l?.updatePopupColor(t)}removeComment(t){this.#l?.removeComments([t.uid])}toggleComment(t,e,s=void 0){this.#l?.toggleCommentPopup(t,e,s)}makeCommentColor(t,e){return t&&this.#l?.makeCommentColor(t,e)||null}getCommentDialogElement(){return this.#l?.dialogElement||null}async waitForEditorsRendered(t){if(this.#r.has(t-1))return;const{resolve:e,promise:s}=Promise.withResolvers(),a=l=>{l.pageNumber===t&&(this._eventBus._off("editorsrendered",a),e())};this._eventBus.on("editorsrendered",a),await s}getSignature(t){this.#I?.getSignature({uiManager:this,editor:t})}get signatureManager(){return this.#I}switchToMode(t,e){this._eventBus.on("annotationeditormodechanged",e,{once:!0,signal:this._signal}),this._eventBus.dispatch("showannotationeditorui",{source:this,mode:t})}setPreference(t,e){this._eventBus.dispatch("setpreference",{source:this,name:t,value:e})}onSetPreference({name:t,value:e}){t==="enableNewAltTextWhenAddingImage"&&(this.#y=e)}onPageChanging({pageNumber:t}){this.#f=t-1}focusMainContainer(){this.#V.focus()}findParent(t,e){for(const s of this.#r.values()){const{x:a,y:l,width:c,height:d}=s.div.getBoundingClientRect();if(t>=a&&t<=a+c&&e>=l&&e<=l+d)return s}return null}disableUserSelect(t=!1){this.#Z.classList.toggle("noUserSelect",t)}addShouldRescale(t){this.#g.add(t)}removeShouldRescale(t){this.#g.delete(t)}onScaleChanging({scale:t}){this.commitOrRemove(),this.viewParameters.realScale=t*da.PDF_TO_CSS_UNITS;for(const e of this.#g)e.onScaleChanging();this.#d?.onScaleChanging()}onRotationChanging({pagesRotation:t}){this.commitOrRemove(),this.viewParameters.rotation=t}#K({anchorNode:t}){return t.nodeType===Node.TEXT_NODE?t.parentElement:t}#tt(t){const{currentLayer:e}=this;if(e.hasTextLayer(t))return e;for(const s of this.#r.values())if(s.hasTextLayer(t))return s;return null}highlightSelection(t="",e=!1){const s=document.getSelection();if(!s||s.isCollapsed)return;const{anchorNode:a,anchorOffset:l,focusNode:c,focusOffset:d}=s,h=s.toString(),g=this.#K(s).closest(".textLayer"),m=this.getSelectionBoxes(g);if(!m)return;s.empty();const x=this.#tt(g),v=this.#C===Dt.NONE,E=()=>{const S=x?.createAndAddNewEditor({x:0,y:0},!1,{methodOfCreation:t,boxes:m,anchorNode:a,anchorOffset:l,focusNode:c,focusOffset:d,text:h});v&&this.showAllEditors("highlight",!0,!0),e&&S?.editComment()};if(v){this.switchToMode(Dt.HIGHLIGHT,E);return}E()}commentSelection(t=""){this.highlightSelection(t,!0)}#rt(){const t=document.getSelection();if(!t||t.isCollapsed)return;const s=this.#K(t).closest(".textLayer"),a=this.getSelectionBoxes(s);a&&(this.#E||=new YD(this),this.#E.show(s,a,this.direction==="ltr"))}getAndRemoveDataFromAnnotationStorage(t){if(!this.#a)return null;const e=`${sl}${t}`,s=this.#a.getRawValue(e);return s&&this.#a.remove(e),s}addToAnnotationStorage(t){!t.isEmpty()&&this.#a&&!this.#a.has(t.id)&&this.#a.setValue(t.id,t)}a11yAlert(t,e=null){const s=this.#J;s&&(s.setAttribute("data-l10n-id",t),e?s.setAttribute("data-l10n-args",JSON.stringify(e)):s.removeAttribute("data-l10n-args"))}#ot(){const t=document.getSelection();if(!t||t.isCollapsed){this.#O&&(this.#E?.hide(),this.#O=null,this.#R({hasSelectedText:!1}));return}const{anchorNode:e}=t;if(e===this.#O)return;const a=this.#K(t).closest(".textLayer");if(!a){this.#O&&(this.#E?.hide(),this.#O=null,this.#R({hasSelectedText:!1}));return}if(this.#E?.hide(),this.#O=e,this.#R({hasSelectedText:!0}),!(this.#C!==Dt.HIGHLIGHT&&this.#C!==Dt.NONE)&&(this.#C===Dt.HIGHLIGHT&&this.showAllEditors("highlight",!0,!0),this.#w=this.isShiftKeyDown,!this.isShiftKeyDown)){const l=this.#C===Dt.HIGHLIGHT?this.#tt(a):null;if(l?.toggleDrawing(),this.#M){const c=new AbortController,d=this.combinedSignal(c),h=f=>{f.type==="pointerup"&&f.button!==0||(c.abort(),l?.toggleDrawing(!0),f.type==="pointerup"&&this.#W("main_toolbar"))};window.addEventListener("pointerup",h,{signal:d}),window.addEventListener("blur",h,{signal:d})}else l?.toggleDrawing(!0),this.#W("main_toolbar")}}#W(t=""){this.#C===Dt.HIGHLIGHT?this.highlightSelection(t):this.#b&&this.#rt()}#lt(){document.addEventListener("selectionchange",this.#ot.bind(this),{signal:this._signal})}#ct(){if(this.#v)return;this.#v=new AbortController;const t=this.combinedSignal(this.#v);window.addEventListener("focus",this.focus.bind(this),{signal:t}),window.addEventListener("blur",this.blur.bind(this),{signal:t})}#ut(){this.#v?.abort(),this.#v=null}blur(){if(this.isShiftKeyDown=!1,this.#w&&(this.#w=!1,this.#W("main_toolbar")),!this.hasSelection)return;const{activeElement:t}=document;for(const e of this.#A)if(e.div.contains(t)){this.#j=[e,t],e._focusEventsAllowed=!1;break}}focus(){if(!this.#j)return;const[t,e]=this.#j;this.#j=null,e.addEventListener("focusin",()=>{t._focusEventsAllowed=!0},{once:!0,signal:this._signal}),e.focus()}#et(){if(this.#L)return;this.#L=new AbortController;const t=this.combinedSignal(this.#L);window.addEventListener("keydown",this.keydown.bind(this),{signal:t}),window.addEventListener("keyup",this.keyup.bind(this),{signal:t})}#dt(){this.#L?.abort(),this.#L=null}#nt(){if(this.#h)return;this.#h=new AbortController;const t=this.combinedSignal(this.#h);document.addEventListener("copy",this.copy.bind(this),{signal:t}),document.addEventListener("cut",this.cut.bind(this),{signal:t}),document.addEventListener("paste",this.paste.bind(this),{signal:t})}#it(){this.#h?.abort(),this.#h=null}#ht(){const t=this._signal;document.addEventListener("dragover",this.dragOver.bind(this),{signal:t}),document.addEventListener("drop",this.drop.bind(this),{signal:t})}addEditListeners(){this.#et(),this.#nt()}removeEditListeners(){this.#dt(),this.#it()}dragOver(t){for(const{type:e}of t.dataTransfer.items)for(const s of this.#u)if(s.isHandlingMimeForPasting(e)){t.dataTransfer.dropEffect="copy",t.preventDefault();return}}drop(t){for(const e of t.dataTransfer.items)for(const s of this.#u)if(s.isHandlingMimeForPasting(e.type)){s.paste(e,this.currentLayer),t.preventDefault();return}}copy(t){if(t.preventDefault(),this.#e?.commitOrRemove(),!this.hasSelection)return;const e=[];for(const s of this.#A){const a=s.serialize(!0);a&&e.push(a)}e.length!==0&&t.clipboardData.setData("application/pdfjs",JSON.stringify(e))}cut(t){this.copy(t),this.delete()}async paste(t){t.preventDefault();const{clipboardData:e}=t;for(const l of e.items)for(const c of this.#u)if(c.isHandlingMimeForPasting(l.type)){c.paste(l,this.currentLayer);return}let s=e.getData("application/pdfjs");if(!s)return;try{s=JSON.parse(s)}catch(l){Rt(`paste: "${l.message}".`);return}if(!Array.isArray(s))return;this.unselectAll();const a=this.currentLayer;try{const l=[];for(const h of s){const f=await a.deserialize(h);if(!f)return;l.push(f)}const c=()=>{for(const h of l)this.#st(h);this.#at(l)},d=()=>{for(const h of l)h.remove()};this.addCommands({cmd:c,undo:d,mustExec:!0})}catch(l){Rt(`paste: "${l.message}".`)}}keydown(t){!this.isShiftKeyDown&&t.key==="Shift"&&(this.isShiftKeyDown=!0),this.#C!==Dt.NONE&&!this.isEditorHandlingKeyboard&&zi._keyboardManager.exec(this,t)}keyup(t){this.isShiftKeyDown&&t.key==="Shift"&&(this.isShiftKeyDown=!1,this.#w&&(this.#w=!1,this.#W("main_toolbar")))}onEditingAction({name:t}){switch(t){case"undo":case"redo":case"delete":case"selectAll":this[t]();break;case"highlightSelection":this.highlightSelection("context_menu");break;case"commentSelection":this.commentSelection("context_menu");break}}#R(t){Object.entries(t).some(([s,a])=>this.#X[s]!==a)&&(this._eventBus.dispatch("annotationeditorstateschanged",{source:this,details:Object.assign(this.#X,t)}),this.#C===Dt.HIGHLIGHT&&t.hasSelectedEditor===!1&&this.#U([[Ft.HIGHLIGHT_FREE,!0]]))}#U(t){this._eventBus.dispatch("annotationeditorparamschanged",{source:this,details:t})}setEditingState(t){t?(this.#ct(),this.#nt(),this.#R({isEditing:this.#C!==Dt.NONE,isEmpty:this.#Q(),hasSomethingToUndo:this.#c.hasSomethingToUndo(),hasSomethingToRedo:this.#c.hasSomethingToRedo(),hasSelectedEditor:!1})):(this.#ut(),this.#it(),this.#R({isEditing:!1}),this.disableUserSelect(!1))}registerEditorTypes(t){if(!this.#u){this.#u=t;for(const e of this.#u)this.#U(e.defaultPropertiesToUpdate)}}getId(){return this.#D.id}get currentLayer(){return this.#r.get(this.#f)}getLayer(t){return this.#r.get(t)}get currentPageIndex(){return this.#f}addLayer(t){this.#r.set(t.pageIndex,t),this.#k?t.enable():t.disable()}removeLayer(t){this.#r.delete(t.pageIndex)}async updateMode(t,e=null,s=!1,a=!1,l=!1){if(this.#C!==t&&!(this.#F&&(await this.#F.promise,!this.#F))){if(this.#F=Promise.withResolvers(),this.#d?.commitOrRemove(),this.#C===Dt.POPUP&&this.#l?.hideSidebar(),this.#l?.destroyPopup(),this.#C=t,t===Dt.NONE){this.setEditingState(!1),this.#pt();for(const c of this.#n.values())c.hideStandaloneCommentButton();this._editorUndoBar?.hide(),this.toggleComment(null),this.#F.resolve();return}for(const c of this.#n.values())c.addStandaloneCommentButton();t===Dt.SIGNATURE&&await this.#I?.loadSignatures(),this.setEditingState(!0),await this.#ft(),this.unselectAll();for(const c of this.#r.values())c.updateMode(t);if(t===Dt.POPUP){this.#i||=await this.#q.getAnnotationsByType(new Set(this.#u.map(h=>h._editorType)));const c=new Set,d=[];for(const h of this.#n.values()){const{annotationElementId:f,hasComment:g,deleted:m}=h;f&&c.add(f),g&&!m&&d.push(h.getData())}for(const h of this.#i){const{id:f,popupRef:g,contentsObj:m}=h;g&&m?.str&&!c.has(f)&&!this.#m.has(f)&&d.push(h)}this.#l?.showSidebar(d)}if(!e){s&&this.addNewEditorFromKeyboard(),this.#F.resolve();return}for(const c of this.#n.values())c.uid===e?(this.setSelected(c),l?c.editComment():a?c.enterInEditMode():c.focus()):c.unselect();this.#F.resolve()}}addNewEditorFromKeyboard(){this.currentLayer.canCreateNewEmptyEditor()&&this.currentLayer.addNewEditor()}updateToolbar(t){t.mode!==this.#C&&this._eventBus.dispatch("switchannotationeditormode",{source:this,...t})}updateParams(t,e){if(this.#u){switch(t){case Ft.CREATE:this.currentLayer.addNewEditor(e);return;case Ft.HIGHLIGHT_SHOW_ALL:this._eventBus.dispatch("reporttelemetry",{source:this,details:{type:"editing",data:{type:"highlight",action:"toggle_visibility"}}}),(this.#Y||=new Map).set(t,e),this.showAllEditors("highlight",e);break}if(this.hasSelection)for(const s of this.#A)s.updateParams(t,e);else for(const s of this.#u)s.updateDefaultParams(t,e)}}showAllEditors(t,e,s=!1){for(const l of this.#n.values())l.editorType===t&&l.show(e);(this.#Y?.get(Ft.HIGHLIGHT_SHOW_ALL)??!0)!==e&&this.#U([[Ft.HIGHLIGHT_SHOW_ALL,e]])}enableWaiting(t=!1){if(this.#z!==t){this.#z=t;for(const e of this.#r.values())t?e.disableClick():e.enableClick(),e.div.classList.toggle("waiting",t)}}async#ft(){if(!this.#k){this.#k=!0;const t=[];for(const e of this.#r.values())t.push(e.enable());await Promise.all(t);for(const e of this.#n.values())e.enable()}}#pt(){if(this.unselectAll(),this.#k){this.#k=!1;for(const t of this.#r.values())t.disable();for(const t of this.#n.values())t.disable()}}*getEditors(t){for(const e of this.#n.values())e.pageIndex===t&&(yield e)}getEditor(t){return this.#n.get(t)}addEditor(t){this.#n.set(t.id,t)}removeEditor(t){t.div.contains(document.activeElement)&&(this.#S&&clearTimeout(this.#S),this.#S=setTimeout(()=>{this.focusMainContainer(),this.#S=null},0)),this.#n.delete(t.id),t.annotationElementId&&this.#N?.delete(t.annotationElementId),this.unselect(t),(!t.annotationElementId||!this.#m.has(t.annotationElementId))&&this.#a?.remove(t.id)}addDeletedAnnotationElement(t){this.#m.add(t.annotationElementId),this.addChangedExistingAnnotation(t),t.deleted=!0}isDeletedAnnotationElement(t){return this.#m.has(t)}removeDeletedAnnotationElement(t){this.#m.delete(t.annotationElementId),this.removeChangedExistingAnnotation(t),t.deleted=!1}#st(t){const e=this.#r.get(t.pageIndex);e?e.addOrRebuild(t):(this.addEditor(t),this.addToAnnotationStorage(t))}setActiveEditor(t){this.#e!==t&&(this.#e=t,t&&this.#U(t.propertiesToUpdate))}get#gt(){let t=null;for(t of this.#A);return t}updateUI(t){this.#gt===t&&this.#U(t.propertiesToUpdate)}updateUIForDefaultProperties(t){this.#U(t.defaultPropertiesToUpdate)}toggleSelected(t){if(this.#A.has(t)){this.#A.delete(t),t.unselect(),this.#R({hasSelectedEditor:this.hasSelection});return}this.#A.add(t),t.select(),this.#U(t.propertiesToUpdate),this.#R({hasSelectedEditor:!0})}setSelected(t){this.updateToolbar({mode:t.mode,editId:t.id}),this.#d?.commitOrRemove();for(const e of this.#A)e!==t&&e.unselect();this.#A.clear(),this.#A.add(t),t.select(),this.#U(t.propertiesToUpdate),this.#R({hasSelectedEditor:!0})}isSelected(t){return this.#A.has(t)}get firstSelectedEditor(){return this.#A.values().next().value}unselect(t){t.unselect(),this.#A.delete(t),this.#R({hasSelectedEditor:this.hasSelection})}get hasSelection(){return this.#A.size!==0}get isEnterHandled(){return this.#A.size===1&&this.firstSelectedEditor.isEnterHandled}undo(){this.#c.undo(),this.#R({hasSomethingToUndo:this.#c.hasSomethingToUndo(),hasSomethingToRedo:!0,isEmpty:this.#Q()}),this._editorUndoBar?.hide()}redo(){this.#c.redo(),this.#R({hasSomethingToUndo:!0,hasSomethingToRedo:this.#c.hasSomethingToRedo(),isEmpty:this.#Q()})}addCommands(t){this.#c.add(t),this.#R({hasSomethingToUndo:!0,hasSomethingToRedo:!1,isEmpty:this.#Q()})}cleanUndoStack(t){this.#c.cleanType(t)}#Q(){if(this.#n.size===0)return!0;if(this.#n.size===1)for(const t of this.#n.values())return t.isEmpty();return!1}delete(){this.commitOrRemove();const t=this.currentLayer?.endDrawingSession(!0);if(!this.hasSelection&&!t)return;const e=t?[t]:[...this.#A],s=()=>{this._editorUndoBar?.show(a,e.length===1?e[0].editorType:e.length);for(const l of e)l.remove()},a=()=>{for(const l of e)this.#st(l)};this.addCommands({cmd:s,undo:a,mustExec:!0})}commitOrRemove(){this.#e?.commitOrRemove()}hasSomethingToControl(){return this.#e||this.hasSelection}#at(t){for(const e of this.#A)e.unselect();this.#A.clear();for(const e of t)e.isEmpty()||(this.#A.add(e),e.select());this.#R({hasSelectedEditor:this.hasSelection})}selectAll(){for(const t of this.#A)t.commit();this.#at(this.#n.values())}unselectAll(){if(!(this.#e&&(this.#e.commitOrRemove(),this.#C!==Dt.NONE))&&!this.#d?.commitOrRemove()&&this.hasSelection){for(const t of this.#A)t.unselect();this.#A.clear(),this.#R({hasSelectedEditor:!1})}}translateSelectedEditors(t,e,s=!1){if(s||this.commitOrRemove(),!this.hasSelection)return;this.#H[0]+=t,this.#H[1]+=e;const[a,l]=this.#H,c=[...this.#A],d=1e3;this.#B&&clearTimeout(this.#B),this.#B=setTimeout(()=>{this.#B=null,this.#H[0]=this.#H[1]=0,this.addCommands({cmd:()=>{for(const h of c)this.#n.has(h.id)&&(h.translateInPage(a,l),h.translationDone())},undo:()=>{for(const h of c)this.#n.has(h.id)&&(h.translateInPage(-a,-l),h.translationDone())},mustExec:!1})},d);for(const h of c)h.translateInPage(t,e),h.translationDone()}setUpDragSession(){if(this.hasSelection){this.disableUserSelect(!0),this.#p=new Map;for(const t of this.#A)this.#p.set(t,{savedX:t.x,savedY:t.y,savedPageIndex:t.pageIndex,newX:0,newY:0,newPageIndex:-1})}}endDragSession(){if(!this.#p)return!1;this.disableUserSelect(!1);const t=this.#p;this.#p=null;let e=!1;for(const[{x:a,y:l,pageIndex:c},d]of t)d.newX=a,d.newY=l,d.newPageIndex=c,e||=a!==d.savedX||l!==d.savedY||c!==d.savedPageIndex;if(!e)return!1;const s=(a,l,c,d)=>{if(this.#n.has(a.id)){const h=this.#r.get(d);h?a._setParentAndPosition(h,l,c):(a.pageIndex=d,a.x=l,a.y=c)}};return this.addCommands({cmd:()=>{for(const[a,{newX:l,newY:c,newPageIndex:d}]of t)s(a,l,c,d)},undo:()=>{for(const[a,{savedX:l,savedY:c,savedPageIndex:d}]of t)s(a,l,c,d)},mustExec:!0}),!0}dragSelectedEditors(t,e){if(this.#p)for(const s of this.#p.keys())s.drag(t,e)}rebuild(t){if(t.parent===null){const e=this.getLayer(t.pageIndex);e?(e.changeParent(t),e.addOrRebuild(t)):(this.addEditor(t),this.addToAnnotationStorage(t),t.rebuild())}else t.parent.addOrRebuild(t)}get isEditorHandlingKeyboard(){return this.getActive()?.shouldGetKeyboardEvents()||this.#A.size===1&&this.firstSelectedEditor.shouldGetKeyboardEvents()}isActive(t){return this.#e===t}getActive(){return this.#e}getMode(){return this.#C}isEditingMode(){return this.#C!==Dt.NONE}get imageManager(){return jt(this,"imageManager",new Dp)}getSelectionBoxes(t){if(!t)return null;const e=document.getSelection();for(let f=0,g=e.rangeCount;f<g;f++)if(!t.contains(e.getRangeAt(f).commonAncestorContainer))return null;const{x:s,y:a,width:l,height:c}=t.getBoundingClientRect();let d;switch(t.getAttribute("data-main-rotation")){case"90":d=(f,g,m,x)=>({x:(g-a)/c,y:1-(f+m-s)/l,width:x/c,height:m/l});break;case"180":d=(f,g,m,x)=>({x:1-(f+m-s)/l,y:1-(g+x-a)/c,width:m/l,height:x/c});break;case"270":d=(f,g,m,x)=>({x:1-(g+x-a)/c,y:(f-s)/l,width:x/c,height:m/l});break;default:d=(f,g,m,x)=>({x:(f-s)/l,y:(g-a)/c,width:m/l,height:x/c});break}const h=[];for(let f=0,g=e.rangeCount;f<g;f++){const m=e.getRangeAt(f);if(!m.collapsed)for(const{x,y:v,width:E,height:S}of m.getClientRects())E===0||S===0||h.push(d(x,v,E,S))}return h.length===0?null:h}addChangedExistingAnnotation({annotationElementId:t,id:e}){(this.#o||=new Map).set(t,e)}removeChangedExistingAnnotation({annotationElementId:t}){this.#o?.delete(t)}renderAnnotationElement(t){const e=this.#o?.get(t.data.id);if(!e)return;const s=this.#a.getRawValue(e);s&&(this.#C===Dt.NONE&&!s.hasBeenModified||s.renderAnnotationElement(t))}setMissingCanvas(t,e,s){const a=this.#N?.get(t);a&&(a.setCanvas(e,s),this.#N.delete(t))}addMissingCanvas(t,e){(this.#N||=new Map).set(t,e)}}class ai{#t=null;#e=!1;#i=null;#n=null;#r=null;#s=null;#a=!1;#o=null;#c=null;#l=null;#h=null;#d=!1;static#f=null;static _l10n=null;constructor(t){this.#c=t,this.#d=t._uiManager.useNewAltTextFlow,ai.#f||=Object.freeze({added:"pdfjs-editor-new-alt-text-added-button","added-label":"pdfjs-editor-new-alt-text-added-button-label",missing:"pdfjs-editor-new-alt-text-missing-button","missing-label":"pdfjs-editor-new-alt-text-missing-button-label",review:"pdfjs-editor-new-alt-text-to-review-button","review-label":"pdfjs-editor-new-alt-text-to-review-button-label"})}static initialize(t){ai._l10n??=t}async render(){const t=this.#i=document.createElement("button");t.className="altText",t.tabIndex="0";const e=this.#n=document.createElement("span");t.append(e),this.#d?(t.classList.add("new"),t.setAttribute("data-l10n-id",ai.#f.missing),e.setAttribute("data-l10n-id",ai.#f["missing-label"])):(t.setAttribute("data-l10n-id","pdfjs-editor-alt-text-button"),e.setAttribute("data-l10n-id","pdfjs-editor-alt-text-button-label"));const s=this.#c._uiManager._signal;t.addEventListener("contextmenu",wn,{signal:s}),t.addEventListener("pointerdown",l=>l.stopPropagation(),{signal:s});const a=l=>{l.preventDefault(),this.#c._uiManager.editAltText(this.#c),this.#d&&this.#c._reportTelemetry({action:"pdfjs.image.alt_text.image_status_label_clicked",data:{label:this.#m}})};return t.addEventListener("click",a,{capture:!0,signal:s}),t.addEventListener("keydown",l=>{l.target===t&&l.key==="Enter"&&(this.#a=!0,a(l))},{signal:s}),await this.#p(),t}get#m(){return this.#t&&"added"||this.#t===null&&this.guessedText&&"review"||"missing"}finish(){this.#i&&(this.#i.focus({focusVisible:this.#a}),this.#a=!1)}isEmpty(){return this.#d?this.#t===null:!this.#t&&!this.#e}hasData(){return this.#d?this.#t!==null||!!this.#l:this.isEmpty()}get guessedText(){return this.#l}async setGuessedText(t){this.#t===null&&(this.#l=t,this.#h=await ai._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer",{generatedAltText:t}),this.#p())}toggleAltTextBadge(t=!1){if(!this.#d||this.#t){this.#o?.remove(),this.#o=null;return}if(!this.#o){const e=this.#o=document.createElement("div");e.className="noAltTextBadge",this.#c.div.append(e)}this.#o.classList.toggle("hidden",!t)}serialize(t){let e=this.#t;return!t&&this.#l===e&&(e=this.#h),{altText:e,decorative:this.#e,guessedText:this.#l,textWithDisclaimer:this.#h}}get data(){return{altText:this.#t,decorative:this.#e}}set data({altText:t,decorative:e,guessedText:s,textWithDisclaimer:a,cancel:l=!1}){s&&(this.#l=s,this.#h=a),!(this.#t===t&&this.#e===e)&&(l||(this.#t=t,this.#e=e),this.#p())}toggle(t=!1){this.#i&&(!t&&this.#s&&(clearTimeout(this.#s),this.#s=null),this.#i.disabled=!t)}shown(){this.#c._reportTelemetry({action:"pdfjs.image.alt_text.image_status_label_displayed",data:{label:this.#m}})}destroy(){this.#i?.remove(),this.#i=null,this.#n=null,this.#r=null,this.#o?.remove(),this.#o=null}async#p(){const t=this.#i;if(!t)return;if(this.#d){if(t.classList.toggle("done",!!this.#t),t.setAttribute("data-l10n-id",ai.#f[this.#m]),this.#n?.setAttribute("data-l10n-id",ai.#f[`${this.#m}-label`]),!this.#t){this.#r?.remove();return}}else{if(!this.#t&&!this.#e){t.classList.remove("done"),this.#r?.remove();return}t.classList.add("done"),t.setAttribute("data-l10n-id","pdfjs-editor-alt-text-edit-button")}let e=this.#r;if(!e){this.#r=e=document.createElement("span"),e.className="tooltip",e.setAttribute("role","tooltip"),e.id=`alt-text-tooltip-${this.#c.id}`;const a=100,l=this.#c._uiManager._signal;l.addEventListener("abort",()=>{clearTimeout(this.#s),this.#s=null},{once:!0}),t.addEventListener("mouseenter",()=>{this.#s=setTimeout(()=>{this.#s=null,this.#r.classList.add("show"),this.#c._reportTelemetry({action:"alt_text_tooltip"})},a)},{signal:l}),t.addEventListener("mouseleave",()=>{this.#s&&(clearTimeout(this.#s),this.#s=null),this.#r?.classList.remove("show")},{signal:l})}this.#e?e.setAttribute("data-l10n-id","pdfjs-editor-alt-text-decorative-tooltip"):(e.removeAttribute("data-l10n-id"),e.textContent=this.#t),e.parentNode||t.append(e),this.#c.getElementForAltText()?.setAttribute("aria-describedby",e.id)}}class Zc{#t=null;#e=null;#i=!1;#n=null;#r=null;#s=null;#a=null;#o=null;#c=!1;#l=null;constructor(t){this.#n=t}renderForToolbar(){const t=this.#e=document.createElement("button");return t.className="comment",this.#h(t,!1)}renderForStandalone(){const t=this.#t=document.createElement("button");t.className="annotationCommentButton";const e=this.#n.commentButtonPosition;if(e){const{style:s}=t;s.insetInlineEnd=`calc(${100*(this.#n._uiManager.direction==="ltr"?1-e[0]:e[0])}% - var(--comment-button-dim))`,s.top=`calc(${100*e[1]}% - var(--comment-button-dim))`;const a=this.#n.commentButtonColor;a&&(s.backgroundColor=a)}return this.#h(t,!0)}focusButton(){setTimeout(()=>{(this.#t??this.#e)?.focus()},0)}onUpdatedColor(){if(!this.#t)return;const t=this.#n.commentButtonColor;t&&(this.#t.style.backgroundColor=t),this.#n._uiManager.updatePopupColor(this.#n)}get commentButtonWidth(){return(this.#t?.getBoundingClientRect().width??0)/this.#n.parent.boundingClientRect.width}get commentPopupPositionInLayer(){if(this.#l)return this.#l;if(!this.#t)return null;const{x:t,y:e,height:s}=this.#t.getBoundingClientRect(),{x:a,y:l,width:c,height:d}=this.#n.parent.boundingClientRect;return[(t-a)/c,(e+s-l)/d]}set commentPopupPositionInLayer(t){this.#l=t}hasDefaultPopupPosition(){return this.#l===null}removeStandaloneCommentButton(){this.#t?.remove(),this.#t=null}removeToolbarCommentButton(){this.#e?.remove(),this.#e=null}setCommentButtonStates({selected:t,hasPopup:e}){this.#t&&(this.#t.classList.toggle("selected",t),this.#t.ariaExpanded=e)}#h(t,e){if(!this.#n._uiManager.hasCommentManager())return null;t.tabIndex="0",t.ariaHasPopup="dialog",e?(t.ariaControls="commentPopup",t.setAttribute("data-l10n-id","pdfjs-show-comment-button")):(t.ariaControlsElements=[this.#n._uiManager.getCommentDialogElement()],t.setAttribute("data-l10n-id","pdfjs-editor-edit-comment-button"));const s=this.#n._uiManager._signal;if(!(s instanceof AbortSignal)||s.aborted)return t;t.addEventListener("contextmenu",wn,{signal:s}),e&&(t.addEventListener("focusin",l=>{this.#n._focusEventsAllowed=!1,he(l)},{capture:!0,signal:s}),t.addEventListener("focusout",l=>{this.#n._focusEventsAllowed=!0,he(l)},{capture:!0,signal:s})),t.addEventListener("pointerdown",l=>l.stopPropagation(),{signal:s});const a=l=>{l.preventDefault(),t===this.#e?this.edit():this.#n.toggleComment(!0)};return t.addEventListener("click",a,{capture:!0,signal:s}),t.addEventListener("keydown",l=>{l.target===t&&l.key==="Enter"&&(this.#i=!0,a(l))},{signal:s}),t.addEventListener("pointerenter",()=>{this.#n.toggleComment(!1,!0)},{signal:s}),t.addEventListener("pointerleave",()=>{this.#n.toggleComment(!1,!1)},{signal:s}),t}edit(t){const e=this.commentPopupPositionInLayer;let s,a;if(e)[s,a]=e;else{[s,a]=this.#n.commentButtonPosition;const{width:g,height:m,x,y:v}=this.#n;s=x+s*g,a=v+a*m}const l=this.#n.parent.boundingClientRect,{x:c,y:d,width:h,height:f}=l;this.#n._uiManager.editComment(this.#n,c+s*h,d+a*f,{...t,parentDimensions:l})}finish(){this.#e&&(this.#e.focus({focusVisible:this.#i}),this.#i=!1)}isDeleted(){return this.#c||this.#a===""}isEmpty(){return this.#a===null}hasBeenEdited(){return this.isDeleted()||this.#a!==this.#r}serialize(){return this.data}get data(){return{text:this.#a,richText:this.#s,date:this.#o,deleted:this.isDeleted()}}set data(t){if(t!==this.#a&&(this.#s=null),t===null){this.#a="",this.#c=!0;return}this.#a=t,this.#o=new Date,this.#c=!1}setInitialText(t,e=null){this.#r=t,this.data=t,this.#o=null,this.#s=e}shown(){}destroy(){this.#e?.remove(),this.#e=null,this.#t?.remove(),this.#t=null,this.#a="",this.#s=null,this.#o=null,this.#n=null,this.#i=!1,this.#c=!1}}class ml{#t;#e=!1;#i=null;#n;#r;#s;#a;#o=null;#c;#l=null;#h;#d=null;constructor({container:t,isPinchingDisabled:e=null,isPinchingStopped:s=null,onPinchStart:a=null,onPinching:l=null,onPinchEnd:c=null,signal:d}){this.#t=t,this.#i=s,this.#n=e,this.#r=a,this.#s=l,this.#a=c,this.#h=new AbortController,this.#c=AbortSignal.any([d,this.#h.signal]),t.addEventListener("touchstart",this.#f.bind(this),{passive:!1,signal:this.#c})}get MIN_TOUCH_DISTANCE_TO_PINCH(){return 35/Wn.pixelRatio}#f(t){if(this.#n?.())return;if(t.touches.length===1){if(this.#o)return;const a=this.#o=new AbortController,l=AbortSignal.any([this.#c,a.signal]),c=this.#t,d={capture:!0,signal:l,passive:!1},h=f=>{f.pointerType==="touch"&&(this.#o?.abort(),this.#o=null)};c.addEventListener("pointerdown",f=>{f.pointerType==="touch"&&(he(f),h(f))},d),c.addEventListener("pointerup",h,d),c.addEventListener("pointercancel",h,d);return}if(!this.#d){this.#d=new AbortController;const a=AbortSignal.any([this.#c,this.#d.signal]),l=this.#t,c={signal:a,capture:!1,passive:!1};l.addEventListener("touchmove",this.#m.bind(this),c);const d=this.#p.bind(this);l.addEventListener("touchend",d,c),l.addEventListener("touchcancel",d,c),c.capture=!0,l.addEventListener("pointerdown",he,c),l.addEventListener("pointermove",he,c),l.addEventListener("pointercancel",he,c),l.addEventListener("pointerup",he,c),this.#r?.()}if(he(t),t.touches.length!==2||this.#i?.()){this.#l=null;return}let[e,s]=t.touches;e.identifier>s.identifier&&([e,s]=[s,e]),this.#l={touch0X:e.screenX,touch0Y:e.screenY,touch1X:s.screenX,touch1Y:s.screenY}}#m(t){if(!this.#l||t.touches.length!==2)return;he(t);let[e,s]=t.touches;e.identifier>s.identifier&&([e,s]=[s,e]);const{screenX:a,screenY:l}=e,{screenX:c,screenY:d}=s,h=this.#l,{touch0X:f,touch0Y:g,touch1X:m,touch1Y:x}=h,v=m-f,E=x-g,S=c-a,C=d-l,T=Math.hypot(S,C)||1,_=Math.hypot(v,E)||1;if(!this.#e&&Math.abs(_-T)<=ml.MIN_TOUCH_DISTANCE_TO_PINCH)return;if(h.touch0X=a,h.touch0Y=l,h.touch1X=c,h.touch1Y=d,!this.#e){this.#e=!0;return}const k=[(a+c)/2,(l+d)/2];this.#s?.(k,_,T)}#p(t){t.touches.length>=2||(this.#d&&(this.#d.abort(),this.#d=null,this.#a?.()),this.#l&&(he(t),this.#l=null,this.#e=!1))}destroy(){this.#h?.abort(),this.#h=null,this.#o?.abort(),this.#o=null}}class St{#t=null;#e=null;#i=null;#n=null;#r=null;#s=!1;#a=null;#o="";#c=null;#l=null;#h=null;#d=null;#f=null;#m="";#p=!1;#u=null;#g=!1;#b=!1;#x=!1;#y=null;#T=0;#S=0;#v=null;#_=null;isSelected=!1;_isCopy=!1;_editToolbar=null;_initialOptions=Object.create(null);_initialData=null;_isVisible=!0;_uiManager=null;_focusEventsAllowed=!0;static _l10n=null;static _l10nResizer=null;#w=!1;#E=St._zIndex++;static _borderLineWidth=-1;static _colorManager=new Rp;static _zIndex=1;static _telemetryTimeout=1e3;static get _resizerKeyboardManager(){const t=St.prototype._resizeWithKeyboard,e=zi.TRANSLATE_SMALL,s=zi.TRANSLATE_BIG;return jt(this,"_resizerKeyboardManager",new gl([[["ArrowLeft","mac+ArrowLeft"],t,{args:[-e,0]}],[["ctrl+ArrowLeft","mac+shift+ArrowLeft"],t,{args:[-s,0]}],[["ArrowRight","mac+ArrowRight"],t,{args:[e,0]}],[["ctrl+ArrowRight","mac+shift+ArrowRight"],t,{args:[s,0]}],[["ArrowUp","mac+ArrowUp"],t,{args:[0,-e]}],[["ctrl+ArrowUp","mac+shift+ArrowUp"],t,{args:[0,-s]}],[["ArrowDown","mac+ArrowDown"],t,{args:[0,e]}],[["ctrl+ArrowDown","mac+shift+ArrowDown"],t,{args:[0,s]}],[["Escape","mac+Escape"],St.prototype._stopResizingWithKeyboard]]))}constructor(t){this.parent=t.parent,this.id=t.id,this.width=this.height=null,this.pageIndex=t.parent.pageIndex,this.name=t.name,this.div=null,this._uiManager=t.uiManager,this.annotationElementId=null,this._willKeepAspectRatio=!1,this._initialOptions.isCentered=t.isCentered,this._structTreeParentId=null,this.annotationElementId=t.annotationElementId||null,this.creationDate=t.creationDate||new Date,this.modificationDate=t.modificationDate||null;const{rotation:e,rawDims:{pageWidth:s,pageHeight:a,pageX:l,pageY:c}}=this.parent.viewport;this.rotation=e,this.pageRotation=(360+e-this._uiManager.viewParameters.rotation)%360,this.pageDimensions=[s,a],this.pageTranslation=[l,c];const[d,h]=this.parentDimensions;this.x=t.x/d,this.y=t.y/h,this.isAttachedToDOM=!1,this.deleted=!1}get editorType(){return Object.getPrototypeOf(this).constructor._type}get mode(){return Object.getPrototypeOf(this).constructor._editorType}static get isDrawer(){return!1}static get _defaultLineColor(){return jt(this,"_defaultLineColor",this._colorManager.getHexCode("CanvasText"))}static deleteAnnotationElement(t){const e=new QD({id:t.parent.getNextId(),parent:t.parent,uiManager:t._uiManager});e.annotationElementId=t.annotationElementId,e.deleted=!0,e._uiManager.addToAnnotationStorage(e)}static initialize(t,e){if(St._l10n??=t,St._l10nResizer||=Object.freeze({topLeft:"pdfjs-editor-resizer-top-left",topMiddle:"pdfjs-editor-resizer-top-middle",topRight:"pdfjs-editor-resizer-top-right",middleRight:"pdfjs-editor-resizer-middle-right",bottomRight:"pdfjs-editor-resizer-bottom-right",bottomMiddle:"pdfjs-editor-resizer-bottom-middle",bottomLeft:"pdfjs-editor-resizer-bottom-left",middleLeft:"pdfjs-editor-resizer-middle-left"}),St._borderLineWidth!==-1)return;const s=getComputedStyle(document.documentElement);St._borderLineWidth=parseFloat(s.getPropertyValue("--outline-width"))||0}static updateDefaultParams(t,e){}static get defaultPropertiesToUpdate(){return[]}static isHandlingMimeForPasting(t){return!1}static paste(t,e){ie("Not implemented")}get propertiesToUpdate(){return[]}get _isDraggable(){return this.#w}set _isDraggable(t){this.#w=t,this.div?.classList.toggle("draggable",t)}get uid(){return this.annotationElementId||this.id}get isEnterHandled(){return!0}center(){const[t,e]=this.pageDimensions;switch(this.parentRotation){case 90:this.x-=this.height*e/(t*2),this.y+=this.width*t/(e*2);break;case 180:this.x+=this.width/2,this.y+=this.height/2;break;case 270:this.x+=this.height*e/(t*2),this.y-=this.width*t/(e*2);break;default:this.x-=this.width/2,this.y-=this.height/2;break}this.fixAndSetPosition()}addCommands(t){this._uiManager.addCommands(t)}get currentLayer(){return this._uiManager.currentLayer}setInBackground(){this.div.style.zIndex=0}setInForeground(){this.div.style.zIndex=this.#E}setParent(t){t!==null?(this.pageIndex=t.pageIndex,this.pageDimensions=t.pageDimensions):(this.#B(),this.#d?.remove(),this.#d=null),this.parent=t}focusin(t){this._focusEventsAllowed&&(this.#p?this.#p=!1:this.parent.setSelected(this))}focusout(t){!this._focusEventsAllowed||!this.isAttachedToDOM||t.relatedTarget?.closest(`#${this.id}`)||(t.preventDefault(),this.parent?.isMultipleSelection||this.commitOrRemove())}commitOrRemove(){this.isEmpty()?this.remove():this.commit()}commit(){this.isInEditMode()&&this.addToAnnotationStorage()}addToAnnotationStorage(){this._uiManager.addToAnnotationStorage(this)}setAt(t,e,s,a){const[l,c]=this.parentDimensions;[s,a]=this.screenToPageTranslation(s,a),this.x=(t+s)/l,this.y=(e+a)/c,this.fixAndSetPosition()}_moveAfterPaste(t,e){const[s,a]=this.parentDimensions;this.setAt(t*s,e*a,this.width*s,this.height*a),this._onTranslated()}#D([t,e],s,a){[s,a]=this.screenToPageTranslation(s,a),this.x+=s/t,this.y+=a/e,this._onTranslating(this.x,this.y),this.fixAndSetPosition()}translate(t,e){this.#D(this.parentDimensions,t,e)}translateInPage(t,e){this.#u||=[this.x,this.y,this.width,this.height],this.#D(this.pageDimensions,t,e),this.div.scrollIntoView({block:"nearest"})}translationDone(){this._onTranslated(this.x,this.y)}drag(t,e){this.#u||=[this.x,this.y,this.width,this.height];const{div:s,parentDimensions:[a,l]}=this;if(this.x+=t/a,this.y+=e/l,this.parent&&(this.x<0||this.x>1||this.y<0||this.y>1)){const{x:m,y:x}=this.div.getBoundingClientRect();this.parent.findNewParent(this,m,x)&&(this.x-=Math.floor(this.x),this.y-=Math.floor(this.y))}let{x:c,y:d}=this;const[h,f]=this.getBaseTranslation();c+=h,d+=f;const{style:g}=s;g.left=`${(100*c).toFixed(2)}%`,g.top=`${(100*d).toFixed(2)}%`,this._onTranslating(c,d),s.scrollIntoView({block:"nearest"})}_onTranslating(t,e){}_onTranslated(t,e){}get _hasBeenMoved(){return!!this.#u&&(this.#u[0]!==this.x||this.#u[1]!==this.y)}get _hasBeenResized(){return!!this.#u&&(this.#u[2]!==this.width||this.#u[3]!==this.height)}getBaseTranslation(){const[t,e]=this.parentDimensions,{_borderLineWidth:s}=St,a=s/t,l=s/e;switch(this.rotation){case 90:return[-a,l];case 180:return[a,l];case 270:return[a,-l];default:return[-a,-l]}}get _mustFixPosition(){return!0}fixAndSetPosition(t=this.rotation){const{div:{style:e},pageDimensions:[s,a]}=this;let{x:l,y:c,width:d,height:h}=this;if(d*=s,h*=a,l*=s,c*=a,this._mustFixPosition)switch(t){case 0:l=Ve(l,0,s-d),c=Ve(c,0,a-h);break;case 90:l=Ve(l,0,s-h),c=Ve(c,d,a);break;case 180:l=Ve(l,d,s),c=Ve(c,h,a);break;case 270:l=Ve(l,h,s),c=Ve(c,0,a-d);break}this.x=l/=s,this.y=c/=a;const[f,g]=this.getBaseTranslation();l+=f,c+=g,e.left=`${(100*l).toFixed(2)}%`,e.top=`${(100*c).toFixed(2)}%`,this.moveInDOM()}static#k(t,e,s){switch(s){case 90:return[e,-t];case 180:return[-t,-e];case 270:return[-e,t];default:return[t,e]}}screenToPageTranslation(t,e){return St.#k(t,e,this.parentRotation)}pageTranslationToScreen(t,e){return St.#k(t,e,360-this.parentRotation)}#M(t){switch(t){case 90:{const[e,s]=this.pageDimensions;return[0,-e/s,s/e,0]}case 180:return[-1,0,0,-1];case 270:{const[e,s]=this.pageDimensions;return[0,e/s,-s/e,0]}default:return[1,0,0,1]}}get parentScale(){return this._uiManager.viewParameters.realScale}get parentRotation(){return(this._uiManager.viewParameters.rotation+this.pageRotation)%360}get parentDimensions(){const{parentScale:t,pageDimensions:[e,s]}=this;return[e*t,s*t]}setDims(){const{div:{style:t},width:e,height:s}=this;t.width=`${(100*e).toFixed(2)}%`,t.height=`${(100*s).toFixed(2)}%`}getInitialTranslation(){return[0,0]}#z(){if(this.#c)return;this.#c=document.createElement("div"),this.#c.classList.add("resizers");const t=this._willKeepAspectRatio?["topLeft","topRight","bottomRight","bottomLeft"]:["topLeft","topMiddle","topRight","middleRight","bottomRight","bottomMiddle","bottomLeft","middleLeft"],e=this._uiManager._signal;for(const s of t){const a=document.createElement("div");this.#c.append(a),a.classList.add("resizer",s),a.setAttribute("data-resizer-name",s),a.addEventListener("pointerdown",this.#L.bind(this,s),{signal:e}),a.addEventListener("contextmenu",wn,{signal:e}),a.tabIndex=-1}this.div.prepend(this.#c)}#L(t,e){e.preventDefault();const{isMac:s}=je.platform;if(e.button!==0||e.ctrlKey&&s)return;this.#i?.toggle(!1);const a=this._isDraggable;this._isDraggable=!1,this.#l=[e.screenX,e.screenY];const l=new AbortController,c=this._uiManager.combinedSignal(l);this.parent.togglePointerEvents(!1),window.addEventListener("pointermove",this.#N.bind(this,t),{passive:!0,capture:!0,signal:c}),window.addEventListener("touchmove",he,{passive:!1,signal:c}),window.addEventListener("contextmenu",wn,{signal:c}),this.#h={savedX:this.x,savedY:this.y,savedWidth:this.width,savedHeight:this.height};const d=this.parent.div.style.cursor,h=this.div.style.cursor;this.div.style.cursor=this.parent.div.style.cursor=window.getComputedStyle(e.target).cursor;const f=()=>{l.abort(),this.parent.togglePointerEvents(!0),this.#i?.toggle(!0),this._isDraggable=a,this.parent.div.style.cursor=d,this.div.style.cursor=h,this.#P()};window.addEventListener("pointerup",f,{signal:c}),window.addEventListener("blur",f,{signal:c})}#j(t,e,s,a){this.width=s,this.height=a,this.x=t,this.y=e,this.setDims(),this.fixAndSetPosition(),this._onResized()}_onResized(){}#P(){if(!this.#h)return;const{savedX:t,savedY:e,savedWidth:s,savedHeight:a}=this.#h;this.#h=null;const l=this.x,c=this.y,d=this.width,h=this.height;l===t&&c===e&&d===s&&h===a||this.addCommands({cmd:this.#j.bind(this,l,c,d,h),undo:this.#j.bind(this,t,e,s,a),mustExec:!0})}static _round(t){return Math.round(t*1e4)/1e4}#N(t,e){const[s,a]=this.parentDimensions,l=this.x,c=this.y,d=this.width,h=this.height,f=St.MIN_SIZE/s,g=St.MIN_SIZE/a,m=this.#M(this.rotation),x=(P,V)=>[m[0]*P+m[2]*V,m[1]*P+m[3]*V],v=this.#M(360-this.rotation),E=(P,V)=>[v[0]*P+v[2]*V,v[1]*P+v[3]*V];let S,C,T=!1,_=!1;switch(t){case"topLeft":T=!0,S=(P,V)=>[0,0],C=(P,V)=>[P,V];break;case"topMiddle":S=(P,V)=>[P/2,0],C=(P,V)=>[P/2,V];break;case"topRight":T=!0,S=(P,V)=>[P,0],C=(P,V)=>[0,V];break;case"middleRight":_=!0,S=(P,V)=>[P,V/2],C=(P,V)=>[0,V/2];break;case"bottomRight":T=!0,S=(P,V)=>[P,V],C=(P,V)=>[0,0];break;case"bottomMiddle":S=(P,V)=>[P/2,V],C=(P,V)=>[P/2,0];break;case"bottomLeft":T=!0,S=(P,V)=>[0,V],C=(P,V)=>[P,0];break;case"middleLeft":_=!0,S=(P,V)=>[0,V/2],C=(P,V)=>[P,V/2];break}const k=S(d,h),R=C(d,h);let D=x(...R);const L=St._round(l+D[0]),O=St._round(c+D[1]);let B=1,F=1,W,Z;if(e.fromKeyboard)({deltaX:W,deltaY:Z}=e);else{const{screenX:P,screenY:V}=e,[K,ct]=this.#l;[W,Z]=this.screenToPageTranslation(P-K,V-ct),this.#l[0]=P,this.#l[1]=V}if([W,Z]=E(W/s,Z/a),T){const P=Math.hypot(d,h);B=F=Math.max(Math.min(Math.hypot(R[0]-k[0]-W,R[1]-k[1]-Z)/P,1/d,1/h),f/d,g/h)}else _?B=Ve(Math.abs(R[0]-k[0]-W),f,1)/d:F=Ve(Math.abs(R[1]-k[1]-Z),g,1)/h;const rt=St._round(d*B),dt=St._round(h*F);D=x(...C(rt,dt));const lt=L-D[0],ut=O-D[1];this.#u||=[this.x,this.y,this.width,this.height],this.width=rt,this.height=dt,this.x=lt,this.y=ut,this.setDims(),this.fixAndSetPosition(),this._onResizing()}_onResizing(){}altTextFinish(){this.#i?.finish()}get toolbarButtons(){return null}async addEditToolbar(){if(this._editToolbar||this.#b)return this._editToolbar;this._editToolbar=new Jo(this),this.div.append(this._editToolbar.render());const{toolbarButtons:t}=this;if(t)for(const[e,s]of t)await this._editToolbar.addButton(e,s);return this.hasComment||this._editToolbar.addButton("comment",this.addCommentButton()),this._editToolbar.addButton("delete"),this._editToolbar}addCommentButtonInToolbar(){this._editToolbar?.addButtonBefore("comment",this.addCommentButton(),".deleteButton")}removeCommentButtonFromToolbar(){this._editToolbar?.removeButton("comment")}removeEditToolbar(){this._editToolbar?.remove(),this._editToolbar=null,this.#i?.destroy()}addContainer(t){const e=this._editToolbar?.div;e?e.before(t):this.div.append(t)}getClientDimensions(){return this.div.getBoundingClientRect()}createAltText(){return this.#i||(ai.initialize(St._l10n),this.#i=new ai(this),this.#t&&(this.#i.data=this.#t,this.#t=null)),this.#i}get altTextData(){return this.#i?.data}set altTextData(t){this.#i&&(this.#i.data=t)}get guessedAltText(){return this.#i?.guessedText}async setGuessedAltText(t){await this.#i?.setGuessedText(t)}serializeAltText(t){return this.#i?.serialize(t)}hasAltText(){return!!this.#i&&!this.#i.isEmpty()}hasAltTextData(){return this.#i?.hasData()??!1}focusCommentButton(){this.#n?.focusButton()}addCommentButton(){return this.#n||=new Zc(this)}addStandaloneCommentButton(){if(this.#r){this._uiManager.isEditingMode()&&this.#r.classList.remove("hidden");return}this.hasComment&&(this.#r=this.#n.renderForStandalone(),this.div.append(this.#r))}removeStandaloneCommentButton(){this.#n.removeStandaloneCommentButton(),this.#r=null}hideStandaloneCommentButton(){this.#r?.classList.add("hidden")}get comment(){const{data:{richText:t,text:e,date:s,deleted:a}}=this.#n;return{text:e,richText:t,date:s,deleted:a,color:this.getNonHCMColor(),opacity:this.opacity??1}}set comment(t){this.#n||=new Zc(this),this.#n.data=t,this.hasComment?(this.removeCommentButtonFromToolbar(),this.addStandaloneCommentButton(),this._uiManager.updateComment(this)):(this.addCommentButtonInToolbar(),this.removeStandaloneCommentButton(),this._uiManager.removeComment(this))}setCommentData({comment:t,popupRef:e,richText:s}){if(!e||(this.#n||=new Zc(this),this.#n.setInitialText(t,s),!this.annotationElementId))return;const a=this._uiManager.getAndRemoveDataFromAnnotationStorage(this.annotationElementId);a&&this.updateFromAnnotationLayer(a)}get hasEditedComment(){return this.#n?.hasBeenEdited()}get hasDeletedComment(){return this.#n?.isDeleted()}get hasComment(){return!!this.#n&&!this.#n.isEmpty()&&!this.#n.isDeleted()}async editComment(t){this.#n||=new Zc(this),this.#n.edit(t)}toggleComment(t,e=void 0){this.hasComment&&this._uiManager.toggleComment(this,t,e)}setSelectedCommentButton(t){this.#n.setSelectedButton(t)}addComment(t){if(this.hasEditedComment){const[,,,a]=t.rect,[l]=this.pageDimensions,[c]=this.pageTranslation,d=c+l+1,h=a-100,f=d+180;t.popup={contents:this.comment.text,deleted:this.comment.deleted,rect:[d,h,f,a]}}}updateFromAnnotationLayer({popup:{contents:t,deleted:e}}){this.#n.data=e?null:t}get parentBoundingClientRect(){return this.parent.boundingClientRect}render(){const t=this.div=document.createElement("div");t.setAttribute("data-editor-rotation",(360-this.rotation)%360),t.className=this.name,t.setAttribute("id",this.id),t.tabIndex=this.#s?-1:0,t.setAttribute("role","application"),this.defaultL10nId&&t.setAttribute("data-l10n-id",this.defaultL10nId),this._isVisible||t.classList.add("hidden"),this.setInForeground(),this.#$();const[e,s]=this.parentDimensions;this.parentRotation%180!==0&&(t.style.maxWidth=`${(100*s/e).toFixed(2)}%`,t.style.maxHeight=`${(100*e/s).toFixed(2)}%`);const[a,l]=this.getInitialTranslation();return this.translate(a,l),Zv(this,t,["keydown","pointerdown","dblclick"]),this.isResizable&&this._uiManager._supportsPinchToZoom&&(this.#_||=new ml({container:t,isPinchingDisabled:()=>!this.isSelected,onPinchStart:this.#G.bind(this),onPinching:this.#C.bind(this),onPinchEnd:this.#A.bind(this),signal:this._uiManager._signal})),this.addStandaloneCommentButton(),this._uiManager._editorUndoBar?.hide(),t}#G(){this.#h={savedX:this.x,savedY:this.y,savedWidth:this.width,savedHeight:this.height},this.#i?.toggle(!1),this.parent.togglePointerEvents(!1)}#C(t,e,s){let l=.7*(s/e)+1-.7;if(l===1)return;const c=this.#M(this.rotation),d=(L,O)=>[c[0]*L+c[2]*O,c[1]*L+c[3]*O],[h,f]=this.parentDimensions,g=this.x,m=this.y,x=this.width,v=this.height,E=St.MIN_SIZE/h,S=St.MIN_SIZE/f;l=Math.max(Math.min(l,1/x,1/v),E/x,S/v);const C=St._round(x*l),T=St._round(v*l);if(C===x&&T===v)return;this.#u||=[g,m,x,v];const _=d(x/2,v/2),k=St._round(g+_[0]),R=St._round(m+_[1]),D=d(C/2,T/2);this.x=k-D[0],this.y=R-D[1],this.width=C,this.height=T,this.setDims(),this.fixAndSetPosition(),this._onResizing()}#A(){this.#i?.toggle(!0),this.parent.togglePointerEvents(!0),this.#P()}pointerdown(t){const{isMac:e}=je.platform;if(t.button!==0||t.ctrlKey&&e){t.preventDefault();return}if(this.#p=!0,this._isDraggable){this.#I(t);return}this.#O(t)}#O(t){const{isMac:e}=je.platform;t.ctrlKey&&!e||t.shiftKey||t.metaKey&&e?this.parent.toggleSelected(this):this.parent.setSelected(this)}#I(t){const{isSelected:e}=this;this._uiManager.setUpDragSession();let s=!1;const a=new AbortController,l=this._uiManager.combinedSignal(a),c={capture:!0,passive:!1,signal:l},d=f=>{a.abort(),this.#a=null,this.#p=!1,this._uiManager.endDragSession()||this.#O(f),s&&this._onStopDragging()};e&&(this.#T=t.clientX,this.#S=t.clientY,this.#a=t.pointerId,this.#o=t.pointerType,window.addEventListener("pointermove",f=>{s||(s=!0,this._uiManager.toggleComment(this,!0,!1),this._onStartDragging());const{clientX:g,clientY:m,pointerId:x}=f;if(x!==this.#a){he(f);return}const[v,E]=this.screenToPageTranslation(g-this.#T,m-this.#S);this.#T=g,this.#S=m,this._uiManager.dragSelectedEditors(v,E)},c),window.addEventListener("touchmove",he,c),window.addEventListener("pointerdown",f=>{f.pointerType===this.#o&&(this.#_||f.isPrimary)&&d(f),he(f)},c));const h=f=>{if(!this.#a||this.#a===f.pointerId){d(f);return}he(f)};window.addEventListener("pointerup",h,{signal:l}),window.addEventListener("blur",h,{signal:l})}_onStartDragging(){}_onStopDragging(){}moveInDOM(){this.#y&&clearTimeout(this.#y),this.#y=setTimeout(()=>{this.#y=null,this.parent?.moveEditorInDOM(this)},0)}_setParentAndPosition(t,e,s){t.changeParent(this),this.x=e,this.y=s,this.fixAndSetPosition(),this._onTranslated()}getRect(t,e,s=this.rotation){const a=this.parentScale,[l,c]=this.pageDimensions,[d,h]=this.pageTranslation,f=t/a,g=e/a,m=this.x*l,x=this.y*c,v=this.width*l,E=this.height*c;switch(s){case 0:return[m+f+d,c-x-g-E+h,m+f+v+d,c-x-g+h];case 90:return[m+g+d,c-x+f+h,m+g+E+d,c-x+f+v+h];case 180:return[m-f-v+d,c-x+g+h,m-f+d,c-x+g+E+h];case 270:return[m-g-E+d,c-x-f-v+h,m-g+d,c-x-f+h];default:throw new Error("Invalid rotation")}}getRectInCurrentCoords(t,e){const[s,a,l,c]=t,d=l-s,h=c-a;switch(this.rotation){case 0:return[s,e-c,d,h];case 90:return[s,e-a,h,d];case 180:return[l,e-a,d,h];case 270:return[l,e-c,h,d];default:throw new Error("Invalid rotation")}}getPDFRect(){return this.getRect(0,0)}getNonHCMColor(){return this.color&&St._colorManager.convert(this._uiManager.getNonHCMColor(this.color))}onUpdatedColor(){this.#n?.onUpdatedColor()}getData(){const{comment:{text:t,color:e,date:s,opacity:a,deleted:l,richText:c},uid:d,pageIndex:h,creationDate:f,modificationDate:g}=this;return{id:d,pageIndex:h,rect:this.getPDFRect(),richText:c,contentsObj:{str:t},creationDate:f,modificationDate:s||g,popupRef:!l,color:e,opacity:a}}onceAdded(t){}isEmpty(){return!1}enableEditMode(){return this.isInEditMode()?!1:(this.parent.setEditingState(!1),this.#b=!0,!0)}disableEditMode(){return this.isInEditMode()?(this.parent.setEditingState(!0),this.#b=!1,!0):!1}isInEditMode(){return this.#b}shouldGetKeyboardEvents(){return this.#x}needsToBeRebuilt(){return this.div&&!this.isAttachedToDOM}get isOnScreen(){const{top:t,left:e,bottom:s,right:a}=this.getClientDimensions(),{innerHeight:l,innerWidth:c}=window;return e<c&&a>0&&t<l&&s>0}#$(){if(this.#f||!this.div)return;this.#f=new AbortController;const t=this._uiManager.combinedSignal(this.#f);this.div.addEventListener("focusin",this.focusin.bind(this),{signal:t}),this.div.addEventListener("focusout",this.focusout.bind(this),{signal:t})}rebuild(){this.#$()}rotate(t){}resize(){}serializeDeleted(){return{id:this.annotationElementId,deleted:!0,pageIndex:this.pageIndex,popupRef:this._initialData?.popupRef||""}}serialize(t=!1,e=null){return{annotationType:this.mode,pageIndex:this.pageIndex,rect:this.getPDFRect(),rotation:this.rotation,structTreeParentId:this._structTreeParentId,popupRef:this._initialData?.popupRef||""}}static async deserialize(t,e,s){const a=new this.prototype.constructor({parent:e,id:e.getNextId(),uiManager:s,annotationElementId:t.annotationElementId,creationDate:t.creationDate,modificationDate:t.modificationDate});a.rotation=t.rotation,a.#t=t.accessibilityData,a._isCopy=t.isCopy||!1;const[l,c]=a.pageDimensions,[d,h,f,g]=a.getRectInCurrentCoords(t.rect,c);return a.x=d/l,a.y=h/c,a.width=f/l,a.height=g/c,a}get hasBeenModified(){return!!this.annotationElementId&&(this.deleted||this.serialize()!==null)}remove(){if(this.#f?.abort(),this.#f=null,this.isEmpty()||this.commit(),this.parent?this.parent.remove(this):this._uiManager.removeEditor(this),this.#y&&(clearTimeout(this.#y),this.#y=null),this.#B(),this.removeEditToolbar(),this.#v){for(const t of this.#v.values())clearTimeout(t);this.#v=null}this.parent=null,this.#_?.destroy(),this.#_=null}get isResizable(){return!1}makeResizable(){this.isResizable&&(this.#z(),this.#c.classList.remove("hidden"))}get toolbarPosition(){return null}get commentButtonPosition(){return this._uiManager.direction==="ltr"?[1,0]:[0,0]}get commentButtonPositionInPage(){const{commentButtonPosition:[t,e]}=this,[s,a,l,c]=this.getPDFRect();return[St._round(s+(l-s)*t),St._round(a+(c-a)*(1-e))]}get commentButtonColor(){return this._uiManager.makeCommentColor(this.getNonHCMColor(),this.opacity)}get commentPopupPosition(){return this.#n.commentPopupPositionInLayer}set commentPopupPosition(t){this.#n.commentPopupPositionInLayer=t}hasDefaultPopupPosition(){return this.#n.hasDefaultPopupPosition()}get commentButtonWidth(){return this.#n.commentButtonWidth}get elementBeforePopup(){return this.div}setCommentButtonStates(t){this.#n.setCommentButtonStates(t)}keydown(t){if(!this.isResizable||t.target!==this.div||t.key!=="Enter")return;this._uiManager.setSelected(this),this.#h={savedX:this.x,savedY:this.y,savedWidth:this.width,savedHeight:this.height};const e=this.#c.children;if(!this.#e){this.#e=Array.from(e);const c=this.#Y.bind(this),d=this.#q.bind(this),h=this._uiManager._signal;for(const f of this.#e){const g=f.getAttribute("data-resizer-name");f.setAttribute("role","spinbutton"),f.addEventListener("keydown",c,{signal:h}),f.addEventListener("blur",d,{signal:h}),f.addEventListener("focus",this.#X.bind(this,g),{signal:h}),f.setAttribute("data-l10n-id",St._l10nResizer[g])}}const s=this.#e[0];let a=0;for(const c of e){if(c===s)break;a++}const l=(360-this.rotation+this.parentRotation)%360/90*(this.#e.length/4);if(l!==a){if(l<a)for(let d=0;d<a-l;d++)this.#c.append(this.#c.firstChild);else if(l>a)for(let d=0;d<l-a;d++)this.#c.firstChild.before(this.#c.lastChild);let c=0;for(const d of e){const f=this.#e[c++].getAttribute("data-resizer-name");d.setAttribute("data-l10n-id",St._l10nResizer[f])}}this.#H(0),this.#x=!0,this.#c.firstChild.focus({focusVisible:!0}),t.preventDefault(),t.stopImmediatePropagation()}#Y(t){St._resizerKeyboardManager.exec(this,t)}#q(t){this.#x&&t.relatedTarget?.parentNode!==this.#c&&this.#B()}#X(t){this.#m=this.#x?t:""}#H(t){if(this.#e)for(const e of this.#e)e.tabIndex=t}_resizeWithKeyboard(t,e){this.#x&&this.#N(this.#m,{deltaX:t,deltaY:e,fromKeyboard:!0})}#B(){this.#x=!1,this.#H(-1),this.#P()}_stopResizingWithKeyboard(){this.#B(),this.div.focus()}select(){if(this.isSelected&&this._editToolbar){this._editToolbar.show();return}if(this.isSelected=!0,this.makeResizable(),this.div?.classList.add("selectedEditor"),!this._editToolbar){this.addEditToolbar().then(()=>{this.div?.classList.contains("selectedEditor")&&this._editToolbar?.show()});return}this._editToolbar?.show(),this.#i?.toggleAltTextBadge(!1)}focus(){this.div&&!this.div.contains(document.activeElement)&&setTimeout(()=>this.div?.focus({preventScroll:!0}),0)}unselect(){this.isSelected&&(this.isSelected=!1,this.#c?.classList.add("hidden"),this.div?.classList.remove("selectedEditor"),this.div?.contains(document.activeElement)&&this._uiManager.currentLayer.div.focus({preventScroll:!0}),this._editToolbar?.hide(),this.#i?.toggleAltTextBadge(!0),this.hasComment&&this._uiManager.toggleComment(this,!1,!1))}updateParams(t,e){}disableEditing(){}enableEditing(){}get canChangeContent(){return!1}enterInEditMode(){this.canChangeContent&&(this.enableEditMode(),this.div.focus())}dblclick(t){t.target.nodeName!=="BUTTON"&&(this.enterInEditMode(),this.parent.updateToolbar({mode:this.constructor._editorType,editId:this.id}))}getElementForAltText(){return this.div}get contentDiv(){return this.div}get isEditing(){return this.#g}set isEditing(t){this.#g=t,this.parent&&(t?(this.parent.setSelected(this),this.parent.setActiveEditor(this)):this.parent.setActiveEditor(null))}static get MIN_SIZE(){return 16}static canCreateNewEmptyEditor(){return!0}get telemetryInitialData(){return{action:"added"}}get telemetryFinalData(){return null}_reportTelemetry(t,e=!1){if(e){this.#v||=new Map;const{action:s}=t;let a=this.#v.get(s);a&&clearTimeout(a),a=setTimeout(()=>{this._reportTelemetry(t),this.#v.delete(s),this.#v.size===0&&(this.#v=null)},St._telemetryTimeout),this.#v.set(s,a);return}t.type||=this.editorType,this._uiManager._eventBus.dispatch("reporttelemetry",{source:this,details:{type:"editing",data:t}})}show(t=this._isVisible){this.div.classList.toggle("hidden",!t),this._isVisible=t}enable(){this.div&&(this.div.tabIndex=0),this.#s=!1}disable(){this.div&&(this.div.tabIndex=-1),this.#s=!0}updateFakeAnnotationElement(t){if(!this.#d&&!this.deleted){this.#d=t.addFakeAnnotation(this);return}if(this.deleted){this.#d.remove(),this.#d=null;return}(this.hasEditedComment||this._hasBeenMoved||this._hasBeenResized)&&this.#d.updateEdited({rect:this.getPDFRect(),popup:this.comment})}renderAnnotationElement(t){if(this.deleted)return t.hide(),null;let e=t.container.querySelector(".annotationContent");if(!e)e=document.createElement("div"),e.classList.add("annotationContent",this.editorType),t.container.prepend(e);else if(e.nodeName==="CANVAS"){const s=e;e=document.createElement("div"),e.classList.add("annotationContent",this.editorType),s.before(e)}return e}resetAnnotationElement(t){const{firstChild:e}=t.container;e?.nodeName==="DIV"&&e.classList.contains("annotationContent")&&e.remove()}}class QD extends St{constructor(t){super(t),this.annotationElementId=t.annotationElementId,this.deleted=!0}serialize(){return this.serializeDeleted()}}const ux=3285377520,Nn=4294901760,ii=65535;class Jv{constructor(t){this.h1=t?t&4294967295:ux,this.h2=t?t&4294967295:ux}update(t){let e,s;if(typeof t=="string"){e=new Uint8Array(t.length*2),s=0;for(let S=0,C=t.length;S<C;S++){const T=t.charCodeAt(S);T<=255?e[s++]=T:(e[s++]=T>>>8,e[s++]=T&255)}}else if(ArrayBuffer.isView(t))e=t.slice(),s=e.byteLength;else throw new Error("Invalid data format, must be a string or TypedArray.");const a=s>>2,l=s-a*4,c=new Uint32Array(e.buffer,0,a);let d=0,h=0,f=this.h1,g=this.h2;const m=3432918353,x=461845907,v=m&ii,E=x&ii;for(let S=0;S<a;S++)S&1?(d=c[S],d=d*m&Nn|d*v&ii,d=d<<15|d>>>17,d=d*x&Nn|d*E&ii,f^=d,f=f<<13|f>>>19,f=f*5+3864292196):(h=c[S],h=h*m&Nn|h*v&ii,h=h<<15|h>>>17,h=h*x&Nn|h*E&ii,g^=h,g=g<<13|g>>>19,g=g*5+3864292196);switch(d=0,l){case 3:d^=e[a*4+2]<<16;case 2:d^=e[a*4+1]<<8;case 1:d^=e[a*4],d=d*m&Nn|d*v&ii,d=d<<15|d>>>17,d=d*x&Nn|d*E&ii,a&1?f^=d:g^=d}this.h1=f,this.h2=g}hexdigest(){let t=this.h1,e=this.h2;return t^=e>>>1,t=t*3981806797&Nn|t*36045&ii,e=e*4283543511&Nn|((e<<16|t>>>16)*2950163797&Nn)>>>16,t^=e>>>1,t=t*444984403&Nn|t*60499&ii,e=e*3301882366&Nn|((e<<16|t>>>16)*3120437893&Nn)>>>16,t^=e>>>1,(t>>>0).toString(16).padStart(8,"0")+(e>>>0).toString(16).padStart(8,"0")}}const Kf=Object.freeze({map:null,hash:"",transfer:void 0});class Lp{#t=!1;#e=null;#i=null;#n=new Map;constructor(){this.onSetModified=null,this.onResetModified=null,this.onAnnotationEditor=null}getValue(t,e){const s=this.#n.get(t);return s===void 0?e:Object.assign(e,s)}getRawValue(t){return this.#n.get(t)}remove(t){const e=this.#n.get(t);if(e!==void 0&&(e instanceof St&&this.#i.delete(e.annotationElementId),this.#n.delete(t),this.#n.size===0&&this.resetModified(),typeof this.onAnnotationEditor=="function")){for(const s of this.#n.values())if(s instanceof St)return;this.onAnnotationEditor(null)}}setValue(t,e){const s=this.#n.get(t);let a=!1;if(s!==void 0)for(const[l,c]of Object.entries(e))s[l]!==c&&(a=!0,s[l]=c);else a=!0,this.#n.set(t,e);a&&this.#r(),e instanceof St&&((this.#i||=new Map).set(e.annotationElementId,e),typeof this.onAnnotationEditor=="function"&&this.onAnnotationEditor(e.constructor._type))}has(t){return this.#n.has(t)}get size(){return this.#n.size}#r(){this.#t||(this.#t=!0,typeof this.onSetModified=="function"&&this.onSetModified())}resetModified(){this.#t&&(this.#t=!1,typeof this.onResetModified=="function"&&this.onResetModified())}get print(){return new t1(this)}get serializable(){if(this.#n.size===0)return Kf;const t=new Map,e=new Jv,s=[],a=Object.create(null);let l=!1;for(const[c,d]of this.#n){const h=d instanceof St?d.serialize(!1,a):d;h&&(t.set(c,h),e.update(`${c}:${JSON.stringify(h)}`),l||=!!h.bitmap)}if(l)for(const c of t.values())c.bitmap&&s.push(c.bitmap);return t.size>0?{map:t,hash:e.hexdigest(),transfer:s}:Kf}get editorStats(){let t=null;const e=new Map;let s=0,a=0;for(const l of this.#n.values()){if(!(l instanceof St)){l.popup&&(l.popup.deleted?a+=1:s+=1);continue}l.isCommentDeleted?a+=1:l.hasEditedComment&&(s+=1);const c=l.telemetryFinalData;if(!c)continue;const{type:d}=c;e.has(d)||e.set(d,Object.getPrototypeOf(l).constructor),t||=Object.create(null);const h=t[d]||=new Map;for(const[f,g]of Object.entries(c)){if(f==="type")continue;let m=h.get(f);m||(m=new Map,h.set(f,m));const x=m.get(g)??0;m.set(g,x+1)}}if((a>0||s>0)&&(t||=Object.create(null),t.comments={deleted:a,edited:s}),!t)return null;for(const[l,c]of e)t[l]=c.computeTelemetryFinalData(t[l]);return t}resetModifiedIds(){this.#e=null}updateEditor(t,e){const s=this.#i?.get(t);return s?(s.updateFromAnnotationLayer(e),!0):!1}getEditor(t){return this.#i?.get(t)||null}get modifiedIds(){if(this.#e)return this.#e;const t=[];if(this.#i)for(const e of this.#i.values())e.serialize()&&t.push(e.annotationElementId);return this.#e={ids:new Set(t),hash:t.join(",")}}[Symbol.iterator](){return this.#n.entries()}}class t1 extends Lp{#t;constructor(t){super();const{map:e,hash:s,transfer:a}=t.serializable,l=structuredClone(e,a?{transfer:a}:null);this.#t={map:l,hash:s,transfer:a}}get print(){ie("Should not call PrintAnnotationStorage.print")}get serializable(){return this.#t}get modifiedIds(){return jt(this,"modifiedIds",{ids:new Set,hash:""})}}class KD{#t=new Set;constructor({ownerDocument:t=globalThis.document,styleElement:e=null}){this._document=t,this.nativeFontFaces=new Set,this.styleElement=null,this.loadingRequests=[],this.loadTestFontId=0}addNativeFontFace(t){this.nativeFontFaces.add(t),this._document.fonts.add(t)}removeNativeFontFace(t){this.nativeFontFaces.delete(t),this._document.fonts.delete(t)}insertRule(t){this.styleElement||(this.styleElement=this._document.createElement("style"),this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement));const e=this.styleElement.sheet;e.insertRule(t,e.cssRules.length)}clear(){for(const t of this.nativeFontFaces)this._document.fonts.delete(t);this.nativeFontFaces.clear(),this.#t.clear(),this.styleElement&&(this.styleElement.remove(),this.styleElement=null)}async loadSystemFont({systemFontInfo:t,disableFontFace:e,_inspectFont:s}){if(!(!t||this.#t.has(t.loadedName))){if(Ht(!e,"loadSystemFont shouldn't be called when `disableFontFace` is set."),this.isFontLoadingAPISupported){const{loadedName:a,src:l,style:c}=t,d=new FontFace(a,l,c);this.addNativeFontFace(d);try{await d.load(),this.#t.add(a),s?.(t)}catch{Rt(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`),this.removeNativeFontFace(d)}return}ie("Not implemented: loadSystemFont without the Font Loading API.")}}async bind(t){if(t.attached||t.missingFile&&!t.systemFontInfo)return;if(t.attached=!0,t.systemFontInfo){await this.loadSystemFont(t);return}if(this.isFontLoadingAPISupported){const s=t.createNativeFontFace();if(s){this.addNativeFontFace(s);try{await s.loaded}catch(a){throw Rt(`Failed to load font '${s.family}': '${a}'.`),t.disableFontFace=!0,a}}return}const e=t.createFontFaceRule();if(e){if(this.insertRule(e),this.isSyncFontLoadingSupported)return;await new Promise(s=>{const a=this._queueLoadingCallback(s);this._prepareFontLoadEvent(t,a)})}}get isFontLoadingAPISupported(){const t=!!this._document?.fonts;return jt(this,"isFontLoadingAPISupported",t)}get isSyncFontLoadingSupported(){return jt(this,"isSyncFontLoadingSupported",Xe||je.platform.isFirefox)}_queueLoadingCallback(t){function e(){for(Ht(!a.done,"completeRequest() cannot be called twice."),a.done=!0;s.length>0&&s[0].done;){const l=s.shift();setTimeout(l.callback,0)}}const{loadingRequests:s}=this,a={done:!1,complete:e,callback:t};return s.push(a),a}get _loadTestFont(){const t=atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");return jt(this,"_loadTestFont",t)}_prepareFontLoadEvent(t,e){function s(R,D){return R.charCodeAt(D)<<24|R.charCodeAt(D+1)<<16|R.charCodeAt(D+2)<<8|R.charCodeAt(D+3)&255}function a(R,D,L,O){const B=R.substring(0,D),F=R.substring(D+L);return B+O+F}let l,c;const d=this._document.createElement("canvas");d.width=1,d.height=1;const h=d.getContext("2d");let f=0;function g(R,D){if(++f>30){Rt("Load test font never loaded."),D();return}if(h.font="30px "+R,h.fillText(".",0,20),h.getImageData(0,0,1,1).data[3]>0){D();return}setTimeout(g.bind(null,R,D))}const m=`lt${Date.now()}${this.loadTestFontId++}`;let x=this._loadTestFont;x=a(x,976,m.length,m);const E=16,S=1482184792;let C=s(x,E);for(l=0,c=m.length-3;l<c;l+=4)C=C-S+s(m,l)|0;l<m.length&&(C=C-S+s(m+"XXX",l)|0),x=a(x,E,4,PD(C));const T=`url(data:font/opentype;base64,${btoa(x)});`,_=`@font-face {font-family:"${m}";src:${T}}`;this.insertRule(_);const k=this._document.createElement("div");k.style.visibility="hidden",k.style.width=k.style.height="10px",k.style.position="absolute",k.style.top=k.style.left="0px";for(const R of[t.loadedName,m]){const D=this._document.createElement("span");D.textContent="Hi",D.style.fontFamily=R,k.append(D)}this._document.body.append(k),g(m,()=>{k.remove(),e.complete()})}}class ZD{#t;constructor(t,e=null,s,a){this.compiledGlyphs=Object.create(null),this.#t=t,this._inspectFont=e,s&&Object.assign(this,s),a&&(this.charProcOperatorList=a)}createNativeFontFace(){if(!this.data||this.disableFontFace)return null;let t;if(!this.cssFontInfo)t=new FontFace(this.loadedName,this.data,{});else{const e={weight:this.cssFontInfo.fontWeight};this.cssFontInfo.italicAngle&&(e.style=`oblique ${this.cssFontInfo.italicAngle}deg`),t=new FontFace(this.cssFontInfo.fontFamily,this.data,e)}return this._inspectFont?.(this),t}createFontFaceRule(){if(!this.data||this.disableFontFace)return null;const t=`url(data:${this.mimetype};base64,${Vv(this.data)});`;let e;if(!this.cssFontInfo)e=`@font-face {font-family:"${this.loadedName}";src:${t}}`;else{let s=`font-weight: ${this.cssFontInfo.fontWeight};`;this.cssFontInfo.italicAngle&&(s+=`font-style: oblique ${this.cssFontInfo.italicAngle}deg;`),e=`@font-face {font-family:"${this.cssFontInfo.fontFamily}";${s}src:${t}}`}return this._inspectFont?.(this,t),e}getPathGenerator(t,e){if(this.compiledGlyphs[e]!==void 0)return this.compiledGlyphs[e];const s=this.loadedName+"_path_"+e;let a;try{a=t.get(s)}catch(c){Rt(`getPathGenerator - ignoring character: "${c}".`)}const l=new Path2D(a||"");return this.fontExtraProperties||t.delete(s),this.compiledGlyphs[e]=l}get black(){return this.#t.black}get bold(){return this.#t.bold}get disableFontFace(){return this.#t.disableFontFace??!1}get fontExtraProperties(){return this.#t.fontExtraProperties??!1}get isInvalidPDFjsFont(){return this.#t.isInvalidPDFjsFont}get isType3Font(){return this.#t.isType3Font}get italic(){return this.#t.italic}get missingFile(){return this.#t.missingFile}get remeasure(){return this.#t.remeasure}get vertical(){return this.#t.vertical}get ascent(){return this.#t.ascent}get defaultWidth(){return this.#t.defaultWidth}get descent(){return this.#t.descent}get bbox(){return this.#t.bbox}get fontMatrix(){return this.#t.fontMatrix}get fallbackName(){return this.#t.fallbackName}get loadedName(){return this.#t.loadedName}get mimetype(){return this.#t.mimetype}get name(){return this.#t.name}get data(){return this.#t.data}clearData(){this.#t.clearData()}get cssFontInfo(){return this.#t.cssFontInfo}get systemFontInfo(){return this.#t.systemFontInfo}get defaultVMetrics(){return this.#t.defaultVMetrics}}function JD(r){if(r instanceof URL)return r.href;if(typeof r=="string"){if(Xe)return r;const t=URL.parse(r,window.location);if(t)return t.href}throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.")}function tR(r){if(Xe&&typeof Buffer<"u"&&r instanceof Buffer)throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");if(r instanceof Uint8Array&&r.byteLength===r.buffer.byteLength)return r;if(typeof r=="string")return hl(r);if(r instanceof ArrayBuffer||ArrayBuffer.isView(r)||typeof r=="object"&&!isNaN(r?.length))return new Uint8Array(r);throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.")}function Jc(r){if(typeof r!="string")return null;if(r.endsWith("/"))return r;throw new Error(`Invalid factory url: "${r}" must include trailing slash.`)}const Zf=r=>typeof r=="object"&&Number.isInteger(r?.num)&&r.num>=0&&Number.isInteger(r?.gen)&&r.gen>=0,eR=r=>typeof r=="object"&&typeof r?.name=="string",e1=HD.bind(null,Zf,eR);class nR{#t=new Map;#e=Promise.resolve();postMessage(t,e){const s={data:structuredClone(t,e?{transfer:e}:null)};this.#e.then(()=>{for(const[a]of this.#t)a.call(this,s)})}addEventListener(t,e,s=null){let a=null;if(s?.signal instanceof AbortSignal){const{signal:l}=s;if(l.aborted){Rt("LoopbackPort - cannot use an `aborted` signal.");return}const c=()=>this.removeEventListener(t,e);a=()=>l.removeEventListener("abort",c),l.addEventListener("abort",c)}this.#t.set(e,a)}removeEventListener(t,e){this.#t.get(e)?.(),this.#t.delete(e)}terminate(){for(const[,t]of this.#t)t?.();this.#t.clear()}}const tu={DATA:1,ERROR:2},Te={CANCEL:1,CANCEL_COMPLETE:2,CLOSE:3,ENQUEUE:4,ERROR:5,PULL:6,PULL_COMPLETE:7,START_COMPLETE:8};function dx(){}function rn(r){if(r instanceof Bi||r instanceof Au||r instanceof ix||r instanceof al||r instanceof Cf)return r;switch(r instanceof Error||typeof r=="object"&&r!==null||ie('wrapReason: Expected "reason" to be a (possibly cloned) Error.'),r.name){case"AbortException":return new Bi(r.message);case"InvalidPDFException":return new Au(r.message);case"PasswordException":return new ix(r.message,r.code);case"ResponseException":return new al(r.message,r.status,r.missing);case"UnknownErrorException":return new Cf(r.message,r.details)}return new Cf(r.message,r.toString())}class Wo{#t=new AbortController;constructor(t,e,s){this.sourceName=t,this.targetName=e,this.comObj=s,this.callbackId=1,this.streamId=1,this.streamSinks=Object.create(null),this.streamControllers=Object.create(null),this.callbackCapabilities=Object.create(null),this.actionHandler=Object.create(null),s.addEventListener("message",this.#e.bind(this),{signal:this.#t.signal})}#e({data:t}){if(t.targetName!==this.sourceName)return;if(t.stream){this.#n(t);return}if(t.callback){const s=t.callbackId,a=this.callbackCapabilities[s];if(!a)throw new Error(`Cannot resolve callback ${s}`);if(delete this.callbackCapabilities[s],t.callback===tu.DATA)a.resolve(t.data);else if(t.callback===tu.ERROR)a.reject(rn(t.reason));else throw new Error("Unexpected callback case");return}const e=this.actionHandler[t.action];if(!e)throw new Error(`Unknown action from worker: ${t.action}`);if(t.callbackId){const s=this.sourceName,a=t.sourceName,l=this.comObj;Promise.try(e,t.data).then(function(c){l.postMessage({sourceName:s,targetName:a,callback:tu.DATA,callbackId:t.callbackId,data:c})},function(c){l.postMessage({sourceName:s,targetName:a,callback:tu.ERROR,callbackId:t.callbackId,reason:rn(c)})});return}if(t.streamId){this.#i(t);return}e(t.data)}on(t,e){const s=this.actionHandler;if(s[t])throw new Error(`There is already an actionName called "${t}"`);s[t]=e}send(t,e,s){this.comObj.postMessage({sourceName:this.sourceName,targetName:this.targetName,action:t,data:e},s)}sendWithPromise(t,e,s){const a=this.callbackId++,l=Promise.withResolvers();this.callbackCapabilities[a]=l;try{this.comObj.postMessage({sourceName:this.sourceName,targetName:this.targetName,action:t,callbackId:a,data:e},s)}catch(c){l.reject(c)}return l.promise}sendWithStream(t,e,s,a){const l=this.streamId++,c=this.sourceName,d=this.targetName,h=this.comObj;return new ReadableStream({start:f=>{const g=Promise.withResolvers();return this.streamControllers[l]={controller:f,startCall:g,pullCall:null,cancelCall:null,isClosed:!1},h.postMessage({sourceName:c,targetName:d,action:t,streamId:l,data:e,desiredSize:f.desiredSize},a),g.promise},pull:f=>{const g=Promise.withResolvers();return this.streamControllers[l].pullCall=g,h.postMessage({sourceName:c,targetName:d,stream:Te.PULL,streamId:l,desiredSize:f.desiredSize}),g.promise},cancel:f=>{Ht(f instanceof Error,"cancel must have a valid reason");const g=Promise.withResolvers();return this.streamControllers[l].cancelCall=g,this.streamControllers[l].isClosed=!0,h.postMessage({sourceName:c,targetName:d,stream:Te.CANCEL,streamId:l,reason:rn(f)}),g.promise}},s)}#i(t){const e=t.streamId,s=this.sourceName,a=t.sourceName,l=this.comObj,c=this,d=this.actionHandler[t.action],h={enqueue(f,g=1,m){if(this.isCancelled)return;const x=this.desiredSize;this.desiredSize-=g,x>0&&this.desiredSize<=0&&(this.sinkCapability=Promise.withResolvers(),this.ready=this.sinkCapability.promise),l.postMessage({sourceName:s,targetName:a,stream:Te.ENQUEUE,streamId:e,chunk:f},m)},close(){this.isCancelled||(this.isCancelled=!0,l.postMessage({sourceName:s,targetName:a,stream:Te.CLOSE,streamId:e}),delete c.streamSinks[e])},error(f){Ht(f instanceof Error,"error must have a valid reason"),!this.isCancelled&&(this.isCancelled=!0,l.postMessage({sourceName:s,targetName:a,stream:Te.ERROR,streamId:e,reason:rn(f)}))},sinkCapability:Promise.withResolvers(),onPull:null,onCancel:null,isCancelled:!1,desiredSize:t.desiredSize,ready:null};h.sinkCapability.resolve(),h.ready=h.sinkCapability.promise,this.streamSinks[e]=h,Promise.try(d,t.data,h).then(function(){l.postMessage({sourceName:s,targetName:a,stream:Te.START_COMPLETE,streamId:e,success:!0})},function(f){l.postMessage({sourceName:s,targetName:a,stream:Te.START_COMPLETE,streamId:e,reason:rn(f)})})}#n(t){const e=t.streamId,s=this.sourceName,a=t.sourceName,l=this.comObj,c=this.streamControllers[e],d=this.streamSinks[e];switch(t.stream){case Te.START_COMPLETE:t.success?c.startCall.resolve():c.startCall.reject(rn(t.reason));break;case Te.PULL_COMPLETE:t.success?c.pullCall.resolve():c.pullCall.reject(rn(t.reason));break;case Te.PULL:if(!d){l.postMessage({sourceName:s,targetName:a,stream:Te.PULL_COMPLETE,streamId:e,success:!0});break}d.desiredSize<=0&&t.desiredSize>0&&d.sinkCapability.resolve(),d.desiredSize=t.desiredSize,Promise.try(d.onPull||dx).then(function(){l.postMessage({sourceName:s,targetName:a,stream:Te.PULL_COMPLETE,streamId:e,success:!0})},function(f){l.postMessage({sourceName:s,targetName:a,stream:Te.PULL_COMPLETE,streamId:e,reason:rn(f)})});break;case Te.ENQUEUE:if(Ht(c,"enqueue should have stream controller"),c.isClosed)break;c.controller.enqueue(t.chunk);break;case Te.CLOSE:if(Ht(c,"close should have stream controller"),c.isClosed)break;c.isClosed=!0,c.controller.close(),this.#r(c,e);break;case Te.ERROR:Ht(c,"error should have stream controller"),c.controller.error(rn(t.reason)),this.#r(c,e);break;case Te.CANCEL_COMPLETE:t.success?c.cancelCall.resolve():c.cancelCall.reject(rn(t.reason)),this.#r(c,e);break;case Te.CANCEL:if(!d)break;const h=rn(t.reason);Promise.try(d.onCancel||dx,h).then(function(){l.postMessage({sourceName:s,targetName:a,stream:Te.CANCEL_COMPLETE,streamId:e,success:!0})},function(f){l.postMessage({sourceName:s,targetName:a,stream:Te.CANCEL_COMPLETE,streamId:e,reason:rn(f)})}),d.sinkCapability.reject(h),d.isCancelled=!0,delete this.streamSinks[e];break;default:throw new Error("Unexpected stream case")}}async#r(t,e){await Promise.allSettled([t.startCall?.promise,t.pullCall?.promise,t.cancelCall?.promise]),delete this.streamControllers[e]}destroy(){this.#t?.abort(),this.#t=null}}class n1{#t=!1;constructor({enableHWA:t=!1}){this.#t=t}create(t,e){if(t<=0||e<=0)throw new Error("Invalid canvas size");const s=this._createCanvas(t,e);return{canvas:s,context:s.getContext("2d",{willReadFrequently:!this.#t})}}reset(t,e,s){if(!t.canvas)throw new Error("Canvas is not specified");if(e<=0||s<=0)throw new Error("Invalid canvas size");t.canvas.width=e,t.canvas.height=s}destroy(t){if(!t.canvas)throw new Error("Canvas is not specified");t.canvas.width=0,t.canvas.height=0,t.canvas=null,t.context=null}_createCanvas(t,e){ie("Abstract method `_createCanvas` called.")}}class iR extends n1{constructor({ownerDocument:t=globalThis.document,enableHWA:e=!1}){super({enableHWA:e}),this._document=t}_createCanvas(t,e){const s=this._document.createElement("canvas");return s.width=t,s.height=e,s}}class i1{constructor({baseUrl:t=null,isCompressed:e=!0}){this.baseUrl=t,this.isCompressed=e}async fetch({name:t}){if(!this.baseUrl)throw new Error("Ensure that the `cMapUrl` and `cMapPacked` API parameters are provided.");if(!t)throw new Error("CMap name must be specified.");const e=this.baseUrl+t+(this.isCompressed?".bcmap":"");return this._fetch(e).then(s=>({cMapData:s,isCompressed:this.isCompressed})).catch(s=>{throw new Error(`Unable to load ${this.isCompressed?"binary ":""}CMap at: ${e}`)})}async _fetch(t){ie("Abstract method `_fetch` called.")}}class hx extends i1{async _fetch(t){const e=await Hr(t,this.isCompressed?"arraybuffer":"text");return e instanceof ArrayBuffer?new Uint8Array(e):hl(e)}}class s1{addFilter(t){return"none"}addHCMFilter(t,e){return"none"}addAlphaFilter(t){return"none"}addLuminosityFilter(t){return"none"}addHighlightHCMFilter(t,e,s,a,l){return"none"}destroy(t=!1){}}class sR extends s1{#t;#e;#i;#n;#r;#s;#a=0;constructor({docId:t,ownerDocument:e=globalThis.document}){super(),this.#n=t,this.#r=e}get#o(){return this.#e||=new Map}get#c(){return this.#s||=new Map}get#l(){if(!this.#i){const t=this.#r.createElement("div"),{style:e}=t;e.visibility="hidden",e.contain="strict",e.width=e.height=0,e.position="absolute",e.top=e.left=0,e.zIndex=-1;const s=this.#r.createElementNS(Oi,"svg");s.setAttribute("width",0),s.setAttribute("height",0),this.#i=this.#r.createElementNS(Oi,"defs"),t.append(s),s.append(this.#i),this.#r.body.append(t)}return this.#i}#h(t){if(t.length===1){const h=t[0],f=new Array(256);for(let m=0;m<256;m++)f[m]=h[m]/255;const g=f.join(",");return[g,g,g]}const[e,s,a]=t,l=new Array(256),c=new Array(256),d=new Array(256);for(let h=0;h<256;h++)l[h]=e[h]/255,c[h]=s[h]/255,d[h]=a[h]/255;return[l.join(","),c.join(","),d.join(",")]}#d(t){if(this.#t===void 0){this.#t="";const e=this.#r.URL;e!==this.#r.baseURI&&(pl(e)?Rt('#createUrl: ignore "data:"-URL for performance reasons.'):this.#t=Tp(e,""))}return`url(${this.#t}#${t})`}addFilter(t){if(!t)return"none";let e=this.#o.get(t);if(e)return e;const[s,a,l]=this.#h(t),c=t.length===1?s:`${s}${a}${l}`;if(e=this.#o.get(c),e)return this.#o.set(t,e),e;const d=`g_${this.#n}_transfer_map_${this.#a++}`,h=this.#d(d);this.#o.set(t,h),this.#o.set(c,h);const f=this.#p(d);return this.#g(s,a,l,f),h}addHCMFilter(t,e){const s=`${t}-${e}`,a="base";let l=this.#c.get(a);if(l?.key===s||(l?(l.filter?.remove(),l.key=s,l.url="none",l.filter=null):(l={key:s,url:"none",filter:null},this.#c.set(a,l)),!t||!e))return l.url;const c=this.#x(t);t=gt.makeHexColor(...c);const d=this.#x(e);if(e=gt.makeHexColor(...d),this.#l.style.color="",t==="#000000"&&e==="#ffffff"||t===e)return l.url;const h=new Array(256);for(let v=0;v<=255;v++){const E=v/255;h[v]=E<=.03928?E/12.92:((E+.055)/1.055)**2.4}const f=h.join(","),g=`g_${this.#n}_hcm_filter`,m=l.filter=this.#p(g);this.#g(f,f,f,m),this.#m(m);const x=(v,E)=>{const S=c[v]/255,C=d[v]/255,T=new Array(E+1);for(let _=0;_<=E;_++)T[_]=S+_/E*(C-S);return T.join(",")};return this.#g(x(0,5),x(1,5),x(2,5),m),l.url=this.#d(g),l.url}addAlphaFilter(t){let e=this.#o.get(t);if(e)return e;const[s]=this.#h([t]),a=`alpha_${s}`;if(e=this.#o.get(a),e)return this.#o.set(t,e),e;const l=`g_${this.#n}_alpha_map_${this.#a++}`,c=this.#d(l);this.#o.set(t,c),this.#o.set(a,c);const d=this.#p(l);return this.#b(s,d),c}addLuminosityFilter(t){let e=this.#o.get(t||"luminosity");if(e)return e;let s,a;if(t?([s]=this.#h([t]),a=`luminosity_${s}`):a="luminosity",e=this.#o.get(a),e)return this.#o.set(t,e),e;const l=`g_${this.#n}_luminosity_map_${this.#a++}`,c=this.#d(l);this.#o.set(t,c),this.#o.set(a,c);const d=this.#p(l);return this.#f(d),t&&this.#b(s,d),c}addHighlightHCMFilter(t,e,s,a,l){const c=`${e}-${s}-${a}-${l}`;let d=this.#c.get(t);if(d?.key===c||(d?(d.filter?.remove(),d.key=c,d.url="none",d.filter=null):(d={key:c,url:"none",filter:null},this.#c.set(t,d)),!e||!s))return d.url;const[h,f]=[e,s].map(this.#x.bind(this));let g=Math.round(.2126*h[0]+.7152*h[1]+.0722*h[2]),m=Math.round(.2126*f[0]+.7152*f[1]+.0722*f[2]),[x,v]=[a,l].map(this.#x.bind(this));m<g&&([g,m,x,v]=[m,g,v,x]),this.#l.style.color="";const E=(T,_,k)=>{const R=new Array(256),D=(m-g)/k,L=T/255,O=(_-T)/(255*k);let B=0;for(let F=0;F<=k;F++){const W=Math.round(g+F*D),Z=L+F*O;for(let rt=B;rt<=W;rt++)R[rt]=Z;B=W+1}for(let F=B;F<256;F++)R[F]=R[B-1];return R.join(",")},S=`g_${this.#n}_hcm_${t}_filter`,C=d.filter=this.#p(S);return this.#m(C),this.#g(E(x[0],v[0],5),E(x[1],v[1],5),E(x[2],v[2],5),C),d.url=this.#d(S),d.url}destroy(t=!1){t&&this.#s?.size||(this.#i?.parentNode.parentNode.remove(),this.#i=null,this.#e?.clear(),this.#e=null,this.#s?.clear(),this.#s=null,this.#a=0)}#f(t){const e=this.#r.createElementNS(Oi,"feColorMatrix");e.setAttribute("type","matrix"),e.setAttribute("values","0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"),t.append(e)}#m(t){const e=this.#r.createElementNS(Oi,"feColorMatrix");e.setAttribute("type","matrix"),e.setAttribute("values","0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"),t.append(e)}#p(t){const e=this.#r.createElementNS(Oi,"filter");return e.setAttribute("color-interpolation-filters","sRGB"),e.setAttribute("id",t),this.#l.append(e),e}#u(t,e,s){const a=this.#r.createElementNS(Oi,e);a.setAttribute("type","discrete"),a.setAttribute("tableValues",s),t.append(a)}#g(t,e,s,a){const l=this.#r.createElementNS(Oi,"feComponentTransfer");a.append(l),this.#u(l,"feFuncR",t),this.#u(l,"feFuncG",e),this.#u(l,"feFuncB",s)}#b(t,e){const s=this.#r.createElementNS(Oi,"feComponentTransfer");e.append(s),this.#u(s,"feFuncA",t)}#x(t){return this.#l.style.color=t,Ur(getComputedStyle(this.#l).getPropertyValue("color"))}}class a1{constructor({baseUrl:t=null}){this.baseUrl=t}async fetch({filename:t}){if(!this.baseUrl)throw new Error("Ensure that the `standardFontDataUrl` API parameter is provided.");if(!t)throw new Error("Font filename must be specified.");const e=`${this.baseUrl}${t}`;return this._fetch(e).catch(s=>{throw new Error(`Unable to load font data at: ${e}`)})}async _fetch(t){ie("Abstract method `_fetch` called.")}}class fx extends a1{async _fetch(t){const e=await Hr(t,"arraybuffer");return new Uint8Array(e)}}class r1{constructor({baseUrl:t=null}){this.baseUrl=t}async fetch({filename:t}){if(!this.baseUrl)throw new Error("Ensure that the `wasmUrl` API parameter is provided.");if(!t)throw new Error("Wasm filename must be specified.");const e=`${this.baseUrl}${t}`;return this._fetch(e).catch(s=>{throw new Error(`Unable to load wasm data at: ${e}`)})}async _fetch(t){ie("Abstract method `_fetch` called.")}}class px extends r1{async _fetch(t){const e=await Hr(t,"arraybuffer");return new Uint8Array(e)}}Xe&&Rt("Please use the `legacy` build in Node.js environments.");async function Op(r){const e=await process.getBuiltinModule("fs").promises.readFile(r);return new Uint8Array(e)}class aR extends s1{}class rR extends n1{_createCanvas(t,e){return process.getBuiltinModule("module").createRequire(import.meta.url)("@napi-rs/canvas").createCanvas(t,e)}}class oR extends i1{async _fetch(t){return Op(t)}}class lR extends a1{async _fetch(t){return Op(t)}}class cR extends r1{async _fetch(t){return Op(t)}}const br="__forcedDependency",{floor:gx,ceil:mx}=Math;function eu(r,t,e,s,a,l){r[t*4+0]=Math.min(r[t*4+0],e),r[t*4+1]=Math.min(r[t*4+1],s),r[t*4+2]=Math.max(r[t*4+2],a),r[t*4+3]=Math.max(r[t*4+3],l)}const Jf=new Uint32Array(new Uint8Array([255,255,0,0]).buffer)[0];class uR{#t;#e;constructor(t,e){this.#t=t,this.#e=e}get length(){return this.#t.length}isEmpty(t){return this.#t[t]===Jf}minX(t){return this.#e[t*4+0]/256}minY(t){return this.#e[t*4+1]/256}maxX(t){return(this.#e[t*4+2]+1)/256}maxY(t){return(this.#e[t*4+3]+1)/256}}const nu=(r,t)=>{if(!r)return;let e=r.get(t);return e||(e={dependencies:new Set,isRenderingOperation:!1},r.set(t,e)),e};class dR{#t={__proto__:null};#e={__proto__:null,transform:[],moveText:[],sameLineText:[],[br]:[]};#i=new Map;#n=[];#r=[];#s=[[1,0,0,1,0,0]];#a=[-1/0,-1/0,1/0,1/0];#o=new Float64Array([1/0,1/0,-1/0,-1/0]);#c=-1;#l=new Set;#h=new Map;#d=new Map;#f;#m;#p;#u;#g;constructor(t,e,s=!1){this.#f=t.width,this.#m=t.height,this.#b(e),s&&(this.#g=new Map)}growOperationsCount(t){t>=this.#u.length&&this.#b(t,this.#u)}#b(t,e){const s=new ArrayBuffer(t*4);this.#p=new Uint8ClampedArray(s),this.#u=new Uint32Array(s),e&&e.length>0?(this.#u.set(e),this.#u.fill(Jf,e.length)):this.#u.fill(Jf)}save(t){return this.#t={__proto__:this.#t},this.#e={__proto__:this.#e,transform:{__proto__:this.#e.transform},moveText:{__proto__:this.#e.moveText},sameLineText:{__proto__:this.#e.sameLineText},[br]:{__proto__:this.#e[br]}},this.#a={__proto__:this.#a},this.#n.push(t),this}restore(t){const e=Object.getPrototypeOf(this.#t);if(e===null)return this;this.#t=e,this.#e=Object.getPrototypeOf(this.#e),this.#a=Object.getPrototypeOf(this.#a);const s=this.#n.pop();return s!==void 0&&(nu(this.#g,t)?.dependencies.add(s),this.#u[t]=this.#u[s]),this}recordOpenMarker(t){return this.#n.push(t),this}getOpenMarker(){return this.#n.length===0?null:this.#n.at(-1)}recordCloseMarker(t){const e=this.#n.pop();return e!==void 0&&(nu(this.#g,t)?.dependencies.add(e),this.#u[t]=this.#u[e]),this}beginMarkedContent(t){return this.#r.push(t),this}endMarkedContent(t){const e=this.#r.pop();return e!==void 0&&(nu(this.#g,t)?.dependencies.add(e),this.#u[t]=this.#u[e]),this}pushBaseTransform(t){return this.#s.push(gt.multiplyByDOMMatrix(this.#s.at(-1),t.getTransform())),this}popBaseTransform(){return this.#s.length>1&&this.#s.pop(),this}recordSimpleData(t,e){return this.#t[t]=e,this}recordIncrementalData(t,e){return this.#e[t].push(e),this}resetIncrementalData(t,e){return this.#e[t].length=0,this}recordNamedData(t,e){return this.#i.set(t,e),this}recordSimpleDataFromNamed(t,e,s){this.#t[t]=this.#i.get(e)??s}recordFutureForcedDependency(t,e){return this.recordIncrementalData(br,e),this}inheritSimpleDataAsFutureForcedDependencies(t){for(const e of t)e in this.#t&&this.recordFutureForcedDependency(e,this.#t[e]);return this}inheritPendingDependenciesAsFutureForcedDependencies(){for(const t of this.#l)this.recordFutureForcedDependency(br,t);return this}resetBBox(t){return this.#c!==t&&(this.#c=t,this.#o[0]=1/0,this.#o[1]=1/0,this.#o[2]=-1/0,this.#o[3]=-1/0),this}recordClipBox(t,e,s,a,l,c){const d=gt.multiplyByDOMMatrix(this.#s.at(-1),e.getTransform()),h=[1/0,1/0,-1/0,-1/0];gt.axialAlignedBoundingBox([s,l,a,c],d,h);const f=gt.intersect(this.#a,h);return f?(this.#a[0]=f[0],this.#a[1]=f[1],this.#a[2]=f[2],this.#a[3]=f[3]):(this.#a[0]=this.#a[1]=1/0,this.#a[2]=this.#a[3]=-1/0),this}recordBBox(t,e,s,a,l,c){const d=this.#a;if(d[0]===1/0)return this;const h=gt.multiplyByDOMMatrix(this.#s.at(-1),e.getTransform());if(d[0]===-1/0)return gt.axialAlignedBoundingBox([s,l,a,c],h,this.#o),this;const f=[1/0,1/0,-1/0,-1/0];return gt.axialAlignedBoundingBox([s,l,a,c],h,f),this.#o[0]=Math.min(this.#o[0],Math.max(f[0],d[0])),this.#o[1]=Math.min(this.#o[1],Math.max(f[1],d[1])),this.#o[2]=Math.max(this.#o[2],Math.min(f[2],d[2])),this.#o[3]=Math.max(this.#o[3],Math.min(f[3],d[3])),this}recordCharacterBBox(t,e,s,a=1,l=0,c=0,d){const h=s.bbox;let f,g;if(h&&(f=h[2]!==h[0]&&h[3]!==h[1]&&this.#d.get(s),f!==!1&&(g=[0,0,0,0],gt.axialAlignedBoundingBox(h,s.fontMatrix,g),(a!==1||l!==0||c!==0)&&gt.scaleMinMax([a,0,0,-a,l,c],g),f)))return this.recordBBox(t,e,g[0],g[2],g[1],g[3]);if(!d)return this.recordFullPageBBox(t);const m=d();return h&&g&&f===void 0&&(f=g[0]<=l-m.actualBoundingBoxLeft&&g[2]>=l+m.actualBoundingBoxRight&&g[1]<=c-m.actualBoundingBoxAscent&&g[3]>=c+m.actualBoundingBoxDescent,this.#d.set(s,f),f)?this.recordBBox(t,e,g[0],g[2],g[1],g[3]):this.recordBBox(t,e,l-m.actualBoundingBoxLeft,l+m.actualBoundingBoxRight,c-m.actualBoundingBoxAscent,c+m.actualBoundingBoxDescent)}recordFullPageBBox(t){return this.#o[0]=Math.max(0,this.#a[0]),this.#o[1]=Math.max(0,this.#a[1]),this.#o[2]=Math.min(this.#f,this.#a[2]),this.#o[3]=Math.min(this.#m,this.#a[3]),this}getSimpleIndex(t){return this.#t[t]}recordDependencies(t,e){const s=this.#l,a=this.#t,l=this.#e;for(const c of e)c in this.#t?s.add(a[c]):c in l&&l[c].forEach(s.add,s);return this}recordNamedDependency(t,e){return this.#i.has(e)&&this.#l.add(this.#i.get(e)),this}recordOperation(t,e=!1){if(this.recordDependencies(t,[br]),this.#g){const s=nu(this.#g,t),{dependencies:a}=s;this.#l.forEach(a.add,a),this.#n.forEach(a.add,a),this.#r.forEach(a.add,a),a.delete(t),s.isRenderingOperation=!0}if(this.#c===t){const s=gx(this.#o[0]*256/this.#f),a=gx(this.#o[1]*256/this.#m),l=mx(this.#o[2]*256/this.#f),c=mx(this.#o[3]*256/this.#m);eu(this.#p,t,s,a,l,c);for(const d of this.#l)d!==t&&eu(this.#p,d,s,a,l,c);for(const d of this.#n)d!==t&&eu(this.#p,d,s,a,l,c);for(const d of this.#r)d!==t&&eu(this.#p,d,s,a,l,c);e||(this.#l.clear(),this.#c=-1)}return this}recordShowTextOperation(t,e=!1){const s=Array.from(this.#l);this.recordOperation(t,e),this.recordIncrementalData("sameLineText",t);for(const a of s)this.recordIncrementalData("sameLineText",a);return this}bboxToClipBoxDropOperation(t,e=!1){return this.#c===t&&(this.#c=-1,this.#a[0]=Math.max(this.#a[0],this.#o[0]),this.#a[1]=Math.max(this.#a[1],this.#o[1]),this.#a[2]=Math.min(this.#a[2],this.#o[2]),this.#a[3]=Math.min(this.#a[3],this.#o[3]),e||this.#l.clear()),this}_takePendingDependencies(){const t=this.#l;return this.#l=new Set,t}_extractOperation(t){const e=this.#h.get(t);return this.#h.delete(t),e}_pushPendingDependencies(t){for(const e of t)this.#l.add(e)}take(){return this.#d.clear(),new uR(this.#u,this.#p)}takeDebugMetadata(){return this.#g}}class Eu{#t;#e;#i;#n=0;#r=0;constructor(t,e,s){if(t instanceof Eu&&t.#i===!!s)return t;this.#t=t,this.#e=e,this.#i=!!s}growOperationsCount(){throw new Error("Unreachable")}save(t){return this.#r++,this.#t.save(this.#e),this}restore(t){return this.#r>0&&(this.#t.restore(this.#e),this.#r--),this}recordOpenMarker(t){return this.#n++,this}getOpenMarker(){return this.#n>0?this.#e:this.#t.getOpenMarker()}recordCloseMarker(t){return this.#n--,this}beginMarkedContent(t){return this}endMarkedContent(t){return this}pushBaseTransform(t){return this.#t.pushBaseTransform(t),this}popBaseTransform(){return this.#t.popBaseTransform(),this}recordSimpleData(t,e){return this.#t.recordSimpleData(t,this.#e),this}recordIncrementalData(t,e){return this.#t.recordIncrementalData(t,this.#e),this}resetIncrementalData(t,e){return this.#t.resetIncrementalData(t,this.#e),this}recordNamedData(t,e){return this}recordSimpleDataFromNamed(t,e,s){return this.#t.recordSimpleDataFromNamed(t,e,this.#e),this}recordFutureForcedDependency(t,e){return this.#t.recordFutureForcedDependency(t,this.#e),this}inheritSimpleDataAsFutureForcedDependencies(t){return this.#t.inheritSimpleDataAsFutureForcedDependencies(t),this}inheritPendingDependenciesAsFutureForcedDependencies(){return this.#t.inheritPendingDependenciesAsFutureForcedDependencies(),this}resetBBox(t){return this.#i||this.#t.resetBBox(this.#e),this}recordClipBox(t,e,s,a,l,c){return this.#i||this.#t.recordClipBox(this.#e,e,s,a,l,c),this}recordBBox(t,e,s,a,l,c){return this.#i||this.#t.recordBBox(this.#e,e,s,a,l,c),this}recordCharacterBBox(t,e,s,a,l,c,d){return this.#i||this.#t.recordCharacterBBox(this.#e,e,s,a,l,c,d),this}recordFullPageBBox(t){return this.#i||this.#t.recordFullPageBBox(this.#e),this}getSimpleIndex(t){return this.#t.getSimpleIndex(t)}recordDependencies(t,e){return this.#t.recordDependencies(this.#e,e),this}recordNamedDependency(t,e){return this.#t.recordNamedDependency(this.#e,e),this}recordOperation(t){return this.#t.recordOperation(this.#e,!0),this}recordShowTextOperation(t){return this.#t.recordShowTextOperation(this.#e,!0),this}bboxToClipBoxDropOperation(t){return this.#i||this.#t.bboxToClipBoxDropOperation(this.#e,!0),this}take(){throw new Error("Unreachable")}takeDebugMetadata(){throw new Error("Unreachable")}}const Bn={stroke:["path","transform","filter","strokeColor","strokeAlpha","lineWidth","lineCap","lineJoin","miterLimit","dash"],fill:["path","transform","filter","fillColor","fillAlpha","globalCompositeOperation","SMask"],imageXObject:["transform","SMask","filter","fillAlpha","strokeAlpha","globalCompositeOperation"],rawFillPath:["filter","fillColor","fillAlpha"],showText:["transform","leading","charSpacing","wordSpacing","hScale","textRise","moveText","textMatrix","font","fontObj","filter","fillColor","textRenderingMode","SMask","fillAlpha","strokeAlpha","globalCompositeOperation","sameLineText"],transform:["transform"],transformAndFill:["transform","fillColor"]},$e={FILL:"Fill",STROKE:"Stroke",SHADING:"Shading"};function tp(r,t){if(!t)return;const e=t[2]-t[0],s=t[3]-t[1],a=new Path2D;a.rect(t[0],t[1],e,s),r.clip(a)}class jp{isModifyingCurrentTransform(){return!1}getPattern(){ie("Abstract method `getPattern` called.")}}class hR extends jp{constructor(t){super(),this._type=t[1],this._bbox=t[2],this._colorStops=t[3],this._p0=t[4],this._p1=t[5],this._r0=t[6],this._r1=t[7],this.matrix=null}_createGradient(t){let e;this._type==="axial"?e=t.createLinearGradient(this._p0[0],this._p0[1],this._p1[0],this._p1[1]):this._type==="radial"&&(e=t.createRadialGradient(this._p0[0],this._p0[1],this._r0,this._p1[0],this._p1[1],this._r1));for(const s of this._colorStops)e.addColorStop(s[0],s[1]);return e}getPattern(t,e,s,a){let l;if(a===$e.STROKE||a===$e.FILL){const c=e.current.getClippedPathBoundingBox(a,de(t))||[0,0,0,0],d=Math.ceil(c[2]-c[0])||1,h=Math.ceil(c[3]-c[1])||1,f=e.cachedCanvases.getCanvas("pattern",d,h),g=f.context;g.clearRect(0,0,g.canvas.width,g.canvas.height),g.beginPath(),g.rect(0,0,g.canvas.width,g.canvas.height),g.translate(-c[0],-c[1]),s=gt.transform(s,[1,0,0,1,c[0],c[1]]),g.transform(...e.baseTransform),this.matrix&&g.transform(...this.matrix),tp(g,this._bbox),g.fillStyle=this._createGradient(g),g.fill(),l=t.createPattern(f.canvas,"no-repeat");const m=new DOMMatrix(s);l.setTransform(m)}else tp(t,this._bbox),l=this._createGradient(t);return l}}function Mf(r,t,e,s,a,l,c,d){const h=t.coords,f=t.colors,g=r.data,m=r.width*4;let x;h[e+1]>h[s+1]&&(x=e,e=s,s=x,x=l,l=c,c=x),h[s+1]>h[a+1]&&(x=s,s=a,a=x,x=c,c=d,d=x),h[e+1]>h[s+1]&&(x=e,e=s,s=x,x=l,l=c,c=x);const v=(h[e]+t.offsetX)*t.scaleX,E=(h[e+1]+t.offsetY)*t.scaleY,S=(h[s]+t.offsetX)*t.scaleX,C=(h[s+1]+t.offsetY)*t.scaleY,T=(h[a]+t.offsetX)*t.scaleX,_=(h[a+1]+t.offsetY)*t.scaleY;if(E>=_)return;const k=f[l],R=f[l+1],D=f[l+2],L=f[c],O=f[c+1],B=f[c+2],F=f[d],W=f[d+1],Z=f[d+2],rt=Math.round(E),dt=Math.round(_);let lt,ut,P,V,K,ct,bt,z;for(let H=rt;H<=dt;H++){if(H<C){const at=H<E?0:(E-H)/(E-C);lt=v-(v-S)*at,ut=k-(k-L)*at,P=R-(R-O)*at,V=D-(D-B)*at}else{let at;H>_?at=1:C===_?at=0:at=(C-H)/(C-_),lt=S-(S-T)*at,ut=L-(L-F)*at,P=O-(O-W)*at,V=B-(B-Z)*at}let q;H<E?q=0:H>_?q=1:q=(E-H)/(E-_),K=v-(v-T)*q,ct=k-(k-F)*q,bt=R-(R-W)*q,z=D-(D-Z)*q;const tt=Math.round(Math.min(lt,K)),st=Math.round(Math.max(lt,K));let ot=m*H+tt*4;for(let at=tt;at<=st;at++)q=(lt-at)/(lt-K),q<0?q=0:q>1&&(q=1),g[ot++]=ut-(ut-ct)*q|0,g[ot++]=P-(P-bt)*q|0,g[ot++]=V-(V-z)*q|0,g[ot++]=255}}function fR(r,t,e){const s=t.coords,a=t.colors;let l,c;switch(t.type){case"lattice":const d=t.verticesPerRow,h=Math.floor(s.length/d)-1,f=d-1;for(l=0;l<h;l++){let g=l*d;for(let m=0;m<f;m++,g++)Mf(r,e,s[g],s[g+1],s[g+d],a[g],a[g+1],a[g+d]),Mf(r,e,s[g+d+1],s[g+1],s[g+d],a[g+d+1],a[g+1],a[g+d])}break;case"triangles":for(l=0,c=s.length;l<c;l+=3)Mf(r,e,s[l],s[l+1],s[l+2],a[l],a[l+1],a[l+2]);break;default:throw new Error("illegal figure")}}class pR extends jp{constructor(t){super(),this._coords=t[2],this._colors=t[3],this._figures=t[4],this._bounds=t[5],this._bbox=t[6],this._background=t[7],this.matrix=null}_createMeshCanvas(t,e,s){const d=Math.floor(this._bounds[0]),h=Math.floor(this._bounds[1]),f=Math.ceil(this._bounds[2])-d,g=Math.ceil(this._bounds[3])-h,m=Math.min(Math.ceil(Math.abs(f*t[0]*1.1)),3e3),x=Math.min(Math.ceil(Math.abs(g*t[1]*1.1)),3e3),v=f/m,E=g/x,S={coords:this._coords,colors:this._colors,offsetX:-d,offsetY:-h,scaleX:1/v,scaleY:1/E},C=m+4,T=x+4,_=s.getCanvas("mesh",C,T),k=_.context,R=k.createImageData(m,x);if(e){const L=R.data;for(let O=0,B=L.length;O<B;O+=4)L[O]=e[0],L[O+1]=e[1],L[O+2]=e[2],L[O+3]=255}for(const L of this._figures)fR(R,L,S);return k.putImageData(R,2,2),{canvas:_.canvas,offsetX:d-2*v,offsetY:h-2*E,scaleX:v,scaleY:E}}isModifyingCurrentTransform(){return!0}getPattern(t,e,s,a){tp(t,this._bbox);const l=new Float32Array(2);if(a===$e.SHADING)gt.singularValueDecompose2dScale(de(t),l);else if(this.matrix){gt.singularValueDecompose2dScale(this.matrix,l);const[d,h]=l;gt.singularValueDecompose2dScale(e.baseTransform,l),l[0]*=d,l[1]*=h}else gt.singularValueDecompose2dScale(e.baseTransform,l);const c=this._createMeshCanvas(l,a===$e.SHADING?null:this._background,e.cachedCanvases);return a!==$e.SHADING&&(t.setTransform(...e.baseTransform),this.matrix&&t.transform(...this.matrix)),t.translate(c.offsetX,c.offsetY),t.scale(c.scaleX,c.scaleY),t.createPattern(c.canvas,"no-repeat")}}class gR extends jp{getPattern(){return"hotpink"}}function mR(r){switch(r[0]){case"RadialAxial":return new hR(r);case"Mesh":return new pR(r);case"Dummy":return new gR}throw new Error(`Unknown IR type: ${r[0]}`)}const bx={COLORED:1,UNCOLORED:2};class Np{static MAX_PATTERN_SIZE=3e3;constructor(t,e,s,a){this.color=t[1],this.operatorList=t[2],this.matrix=t[3],this.bbox=t[4],this.xstep=t[5],this.ystep=t[6],this.paintType=t[7],this.tilingType=t[8],this.ctx=e,this.canvasGraphicsFactory=s,this.baseTransform=a}createPatternCanvas(t,e){const{bbox:s,operatorList:a,paintType:l,tilingType:c,color:d,canvasGraphicsFactory:h}=this;let{xstep:f,ystep:g}=this;f=Math.abs(f),g=Math.abs(g),Nu("TilingType: "+c);const m=s[0],x=s[1],v=s[2],E=s[3],S=v-m,C=E-x,T=new Float32Array(2);gt.singularValueDecompose2dScale(this.matrix,T);const[_,k]=T;gt.singularValueDecompose2dScale(this.baseTransform,T);const R=_*T[0],D=k*T[1];let L=S,O=C,B=!1,F=!1;const W=Math.ceil(f*R),Z=Math.ceil(g*D),rt=Math.ceil(S*R),dt=Math.ceil(C*D);W>=rt?L=f:B=!0,Z>=dt?O=g:F=!0;const lt=this.getSizeAndScale(L,this.ctx.canvas.width,R),ut=this.getSizeAndScale(O,this.ctx.canvas.height,D),P=t.cachedCanvases.getCanvas("pattern",lt.size,ut.size),V=P.context,K=h.createCanvasGraphics(V,e);if(K.groupLevel=t.groupLevel,this.setFillAndStrokeStyleToContext(K,l,d),V.translate(-lt.scale*m,-ut.scale*x),K.transform(0,lt.scale,0,0,ut.scale,0,0),V.save(),K.dependencyTracker?.save(),this.clipBbox(K,m,x,v,E),K.baseTransform=de(K.ctx),K.executeOperatorList(a),K.endDrawing(),K.dependencyTracker?.restore(),V.restore(),B||F){const ct=P.canvas;B&&(L=f),F&&(O=g);const bt=this.getSizeAndScale(L,this.ctx.canvas.width,R),z=this.getSizeAndScale(O,this.ctx.canvas.height,D),H=bt.size,q=z.size,tt=t.cachedCanvases.getCanvas("pattern-workaround",H,q),st=tt.context,ot=B?Math.floor(S/f):0,at=F?Math.floor(C/g):0;for(let kt=0;kt<=ot;kt++)for(let et=0;et<=at;et++)st.drawImage(ct,H*kt,q*et,H,q,0,0,H,q);return{canvas:tt.canvas,scaleX:bt.scale,scaleY:z.scale,offsetX:m,offsetY:x}}return{canvas:P.canvas,scaleX:lt.scale,scaleY:ut.scale,offsetX:m,offsetY:x}}getSizeAndScale(t,e,s){const a=Math.max(Np.MAX_PATTERN_SIZE,e);let l=Math.ceil(t*s);return l>=a?l=a:s=l/t,{scale:s,size:l}}clipBbox(t,e,s,a,l){const c=a-e,d=l-s;t.ctx.rect(e,s,c,d),gt.axialAlignedBoundingBox([e,s,a,l],de(t.ctx),t.current.minMax),t.clip(),t.endPath()}setFillAndStrokeStyleToContext(t,e,s){const a=t.ctx,l=t.current;switch(e){case bx.COLORED:const{fillStyle:c,strokeStyle:d}=this.ctx;a.fillStyle=l.fillColor=c,a.strokeStyle=l.strokeColor=d;break;case bx.UNCOLORED:a.fillStyle=a.strokeStyle=s,l.fillColor=l.strokeColor=s;break;default:throw new zD(`Unsupported paint type: ${e}`)}}isModifyingCurrentTransform(){return!1}getPattern(t,e,s,a,l){let c=s;a!==$e.SHADING&&(c=gt.transform(c,e.baseTransform),this.matrix&&(c=gt.transform(c,this.matrix)));const d=this.createPatternCanvas(e,l);let h=new DOMMatrix(c);h=h.translate(d.offsetX,d.offsetY),h=h.scale(1/d.scaleX,1/d.scaleY);const f=t.createPattern(d.canvas,"repeat");return f.setTransform(h),f}}function bR({src:r,srcPos:t=0,dest:e,width:s,height:a,nonBlackColor:l=4294967295,inverseDecode:c=!1}){const d=je.isLittleEndian?4278190080:255,[h,f]=c?[l,d]:[d,l],g=s>>3,m=s&7,x=r.length;e=new Uint32Array(e.buffer);let v=0;for(let E=0;E<a;E++){for(const C=t+g;t<C;t++){const T=t<x?r[t]:255;e[v++]=T&128?f:h,e[v++]=T&64?f:h,e[v++]=T&32?f:h,e[v++]=T&16?f:h,e[v++]=T&8?f:h,e[v++]=T&4?f:h,e[v++]=T&2?f:h,e[v++]=T&1?f:h}if(m===0)continue;const S=t<x?r[t++]:255;for(let C=0;C<m;C++)e[v++]=S&1<<7-C?f:h}return{srcPos:t,destPos:v}}const yx=16,xx=100,yR=15,vx=10,on=16,Df=new DOMMatrix,An=new Float32Array(2),Tr=new Float32Array([1/0,1/0,-1/0,-1/0]);function xR(r,t){if(r._removeMirroring)throw new Error("Context is already forwarding operations.");r.__originalSave=r.save,r.__originalRestore=r.restore,r.__originalRotate=r.rotate,r.__originalScale=r.scale,r.__originalTranslate=r.translate,r.__originalTransform=r.transform,r.__originalSetTransform=r.setTransform,r.__originalResetTransform=r.resetTransform,r.__originalClip=r.clip,r.__originalMoveTo=r.moveTo,r.__originalLineTo=r.lineTo,r.__originalBezierCurveTo=r.bezierCurveTo,r.__originalRect=r.rect,r.__originalClosePath=r.closePath,r.__originalBeginPath=r.beginPath,r._removeMirroring=()=>{r.save=r.__originalSave,r.restore=r.__originalRestore,r.rotate=r.__originalRotate,r.scale=r.__originalScale,r.translate=r.__originalTranslate,r.transform=r.__originalTransform,r.setTransform=r.__originalSetTransform,r.resetTransform=r.__originalResetTransform,r.clip=r.__originalClip,r.moveTo=r.__originalMoveTo,r.lineTo=r.__originalLineTo,r.bezierCurveTo=r.__originalBezierCurveTo,r.rect=r.__originalRect,r.closePath=r.__originalClosePath,r.beginPath=r.__originalBeginPath,delete r._removeMirroring},r.save=function(){t.save(),this.__originalSave()},r.restore=function(){t.restore(),this.__originalRestore()},r.translate=function(e,s){t.translate(e,s),this.__originalTranslate(e,s)},r.scale=function(e,s){t.scale(e,s),this.__originalScale(e,s)},r.transform=function(e,s,a,l,c,d){t.transform(e,s,a,l,c,d),this.__originalTransform(e,s,a,l,c,d)},r.setTransform=function(e,s,a,l,c,d){t.setTransform(e,s,a,l,c,d),this.__originalSetTransform(e,s,a,l,c,d)},r.resetTransform=function(){t.resetTransform(),this.__originalResetTransform()},r.rotate=function(e){t.rotate(e),this.__originalRotate(e)},r.clip=function(e){t.clip(e),this.__originalClip(e)},r.moveTo=function(e,s){t.moveTo(e,s),this.__originalMoveTo(e,s)},r.lineTo=function(e,s){t.lineTo(e,s),this.__originalLineTo(e,s)},r.bezierCurveTo=function(e,s,a,l,c,d){t.bezierCurveTo(e,s,a,l,c,d),this.__originalBezierCurveTo(e,s,a,l,c,d)},r.rect=function(e,s,a,l){t.rect(e,s,a,l),this.__originalRect(e,s,a,l)},r.closePath=function(){t.closePath(),this.__originalClosePath()},r.beginPath=function(){t.beginPath(),this.__originalBeginPath()}}class vR{constructor(t){this.canvasFactory=t,this.cache=Object.create(null)}getCanvas(t,e,s){let a;return this.cache[t]!==void 0?(a=this.cache[t],this.canvasFactory.reset(a,e,s)):(a=this.canvasFactory.create(e,s),this.cache[t]=a),a}delete(t){delete this.cache[t]}clear(){for(const t in this.cache){const e=this.cache[t];this.canvasFactory.destroy(e),delete this.cache[t]}}}function iu(r,t,e,s,a,l,c,d,h,f){const[g,m,x,v,E,S]=de(r);if(m===0&&x===0){const _=c*g+E,k=Math.round(_),R=d*v+S,D=Math.round(R),L=(c+h)*g+E,O=Math.abs(Math.round(L)-k)||1,B=(d+f)*v+S,F=Math.abs(Math.round(B)-D)||1;return r.setTransform(Math.sign(g),0,0,Math.sign(v),k,D),r.drawImage(t,e,s,a,l,0,0,O,F),r.setTransform(g,m,x,v,E,S),[O,F]}if(g===0&&v===0){const _=d*x+E,k=Math.round(_),R=c*m+S,D=Math.round(R),L=(d+f)*x+E,O=Math.abs(Math.round(L)-k)||1,B=(c+h)*m+S,F=Math.abs(Math.round(B)-D)||1;return r.setTransform(0,Math.sign(m),Math.sign(x),0,k,D),r.drawImage(t,e,s,a,l,0,0,F,O),r.setTransform(g,m,x,v,E,S),[F,O]}r.drawImage(t,e,s,a,l,c,d,h,f);const C=Math.hypot(g,m),T=Math.hypot(x,v);return[C*h,T*f]}class Ax{alphaIsShape=!1;fontSize=0;fontSizeScale=1;textMatrix=null;textMatrixScale=1;fontMatrix=Wf;leading=0;x=0;y=0;lineX=0;lineY=0;charSpacing=0;wordSpacing=0;textHScale=1;textRenderingMode=Fe.FILL;textRise=0;fillColor="#000000";strokeColor="#000000";patternFill=!1;patternStroke=!1;fillAlpha=1;strokeAlpha=1;lineWidth=1;activeSMask=null;transferMaps="none";constructor(t,e,s){s?.(this),this.clipBox=new Float32Array([0,0,t,e]),this.minMax=Tr.slice()}clone(){const t=Object.create(this);return t.clipBox=this.clipBox.slice(),t.minMax=this.minMax.slice(),t}getPathBoundingBox(t=$e.FILL,e=null){const s=this.minMax.slice();if(t===$e.STROKE){e||ie("Stroke bounding box must include transform."),gt.singularValueDecompose2dScale(e,An);const a=An[0]*this.lineWidth/2,l=An[1]*this.lineWidth/2;s[0]-=a,s[1]-=l,s[2]+=a,s[3]+=l}return s}updateClipFromPath(){const t=gt.intersect(this.clipBox,this.getPathBoundingBox());this.startNewPathAndClipBox(t||[0,0,0,0])}isEmptyClip(){return this.minMax[0]===1/0}startNewPathAndClipBox(t){this.clipBox.set(t,0),this.minMax.set(Tr,0)}getClippedPathBoundingBox(t=$e.FILL,e=null){return gt.intersect(this.clipBox,this.getPathBoundingBox(t,e))}}function wx(r,t){if(t instanceof ImageData){r.putImageData(t,0,0);return}const e=t.height,s=t.width,a=e%on,l=(e-a)/on,c=a===0?l:l+1,d=r.createImageData(s,on);let h=0,f;const g=t.data,m=d.data;let x,v,E,S;if(t.kind===Zo.GRAYSCALE_1BPP){const C=g.byteLength,T=new Uint32Array(m.buffer,0,m.byteLength>>2),_=T.length,k=s+7>>3,R=4294967295,D=je.isLittleEndian?4278190080:255;for(x=0;x<c;x++){for(E=x<l?on:a,f=0,v=0;v<E;v++){const L=C-h;let O=0;const B=L>k?s:L*8-7,F=B&-8;let W=0,Z=0;for(;O<F;O+=8)Z=g[h++],T[f++]=Z&128?R:D,T[f++]=Z&64?R:D,T[f++]=Z&32?R:D,T[f++]=Z&16?R:D,T[f++]=Z&8?R:D,T[f++]=Z&4?R:D,T[f++]=Z&2?R:D,T[f++]=Z&1?R:D;for(;O<B;O++)W===0&&(Z=g[h++],W=128),T[f++]=Z&W?R:D,W>>=1}for(;f<_;)T[f++]=0;r.putImageData(d,0,x*on)}}else if(t.kind===Zo.RGBA_32BPP){for(v=0,S=s*on*4,x=0;x<l;x++)m.set(g.subarray(h,h+S)),h+=S,r.putImageData(d,0,v),v+=on;x<c&&(S=s*a*4,m.set(g.subarray(h,h+S)),r.putImageData(d,0,v))}else if(t.kind===Zo.RGB_24BPP)for(E=on,S=s*E,x=0;x<c;x++){for(x>=l&&(E=a,S=s*E),f=0,v=S;v--;)m[f++]=g[h++],m[f++]=g[h++],m[f++]=g[h++],m[f++]=255;r.putImageData(d,0,x*on)}else throw new Error(`bad image kind: ${t.kind}`)}function Sx(r,t){if(t.bitmap){r.drawImage(t.bitmap,0,0);return}const e=t.height,s=t.width,a=e%on,l=(e-a)/on,c=a===0?l:l+1,d=r.createImageData(s,on);let h=0;const f=t.data,g=d.data;for(let m=0;m<c;m++){const x=m<l?on:a;({srcPos:h}=bR({src:f,srcPos:h,dest:g,width:s,height:x,nonBlackColor:0})),r.putImageData(d,0,m*on)}}function Uo(r,t){const e=["strokeStyle","fillStyle","fillRule","globalAlpha","lineWidth","lineCap","lineJoin","miterLimit","globalCompositeOperation","font","filter"];for(const s of e)r[s]!==void 0&&(t[s]=r[s]);r.setLineDash!==void 0&&(t.setLineDash(r.getLineDash()),t.lineDashOffset=r.lineDashOffset)}function su(r){r.strokeStyle=r.fillStyle="#000000",r.fillRule="nonzero",r.globalAlpha=1,r.lineWidth=1,r.lineCap="butt",r.lineJoin="miter",r.miterLimit=10,r.globalCompositeOperation="source-over",r.font="10px sans-serif",r.setLineDash!==void 0&&(r.setLineDash([]),r.lineDashOffset=0);const{filter:t}=r;t!=="none"&&t!==""&&(r.filter="none")}function Ex(r,t){if(t)return!0;gt.singularValueDecompose2dScale(r,An);const e=Math.fround(Wn.pixelRatio*da.PDF_TO_CSS_UNITS);return An[0]<=e&&An[1]<=e}const AR=["butt","round","square"],wR=["miter","round","bevel"],SR={},Tx={};class _r{constructor(t,e,s,a,l,{optionalContentConfig:c,markedContentStack:d=null},h,f,g){this.ctx=t,this.current=new Ax(this.ctx.canvas.width,this.ctx.canvas.height),this.stateStack=[],this.pendingClip=null,this.pendingEOFill=!1,this.res=null,this.xobjs=null,this.commonObjs=e,this.objs=s,this.canvasFactory=a,this.filterFactory=l,this.groupStack=[],this.baseTransform=null,this.baseTransformStack=[],this.groupLevel=0,this.smaskStack=[],this.smaskCounter=0,this.tempSMask=null,this.suspendedCtx=null,this.contentVisible=!0,this.markedContentStack=d||[],this.optionalContentConfig=c,this.cachedCanvases=new vR(this.canvasFactory),this.cachedPatterns=new Map,this.annotationCanvasMap=h,this.viewportScale=1,this.outputScaleX=1,this.outputScaleY=1,this.pageColors=f,this._cachedScaleForStroking=[-1,0],this._cachedGetSinglePixelWidth=null,this._cachedBitmapsMap=new Map,this.dependencyTracker=g??null}getObject(t,e,s=null){return typeof e=="string"?(this.dependencyTracker?.recordNamedDependency(t,e),e.startsWith("g_")?this.commonObjs.get(e):this.objs.get(e)):s}beginDrawing({transform:t,viewport:e,transparency:s=!1,background:a=null}){const l=this.ctx.canvas.width,c=this.ctx.canvas.height,d=this.ctx.fillStyle;if(this.ctx.fillStyle=a||"#ffffff",this.ctx.fillRect(0,0,l,c),this.ctx.fillStyle=d,s){const h=this.cachedCanvases.getCanvas("transparent",l,c);this.compositeCtx=this.ctx,this.transparentCanvas=h.canvas,this.ctx=h.context,this.ctx.save(),this.ctx.transform(...de(this.compositeCtx))}this.ctx.save(),su(this.ctx),t&&(this.ctx.transform(...t),this.outputScaleX=t[0],this.outputScaleY=t[0]),this.ctx.transform(...e.transform),this.viewportScale=e.scale,this.baseTransform=de(this.ctx)}executeOperatorList(t,e,s,a,l){const c=t.argsArray,d=t.fnArray;let h=e||0;const f=c.length;if(f===h)return h;const g=f-h>vx&&typeof s=="function",m=g?Date.now()+yR:0;let x=0;const v=this.commonObjs,E=this.objs;let S,C;for(;;){if(a!==void 0&&h===a.nextBreakPoint)return a.breakIt(h,s),h;if(!l||l(h))if(S=d[h],C=c[h]??null,S!==Pr.dependency)C===null?this[S](h):this[S](h,...C);else for(const T of C){this.dependencyTracker?.recordNamedData(T,h);const _=T.startsWith("g_")?v:E;if(!_.has(T))return _.get(T,s),h}if(h++,h===f)return h;if(g&&++x>vx){if(Date.now()>m)return s(),h;x=0}}}#t(){for(;this.stateStack.length||this.inSMaskMode;)this.restore();this.current.activeSMask=null,this.ctx.restore(),this.transparentCanvas&&(this.ctx=this.compositeCtx,this.ctx.save(),this.ctx.setTransform(1,0,0,1,0,0),this.ctx.drawImage(this.transparentCanvas,0,0),this.ctx.restore(),this.transparentCanvas=null)}endDrawing(){this.#t(),this.cachedCanvases.clear(),this.cachedPatterns.clear();for(const t of this._cachedBitmapsMap.values()){for(const e of t.values())typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement&&(e.width=e.height=0);t.clear()}this._cachedBitmapsMap.clear(),this.#e()}#e(){if(this.pageColors){const t=this.filterFactory.addHCMFilter(this.pageColors.foreground,this.pageColors.background);if(t!=="none"){const e=this.ctx.filter;this.ctx.filter=t,this.ctx.drawImage(this.ctx.canvas,0,0),this.ctx.filter=e}}}_scaleImage(t,e){const s=t.width??t.displayWidth,a=t.height??t.displayHeight;let l=Math.max(Math.hypot(e[0],e[1]),1),c=Math.max(Math.hypot(e[2],e[3]),1),d=s,h=a,f="prescale1",g,m;for(;l>2&&d>1||c>2&&h>1;){let x=d,v=h;l>2&&d>1&&(x=d>=16384?Math.floor(d/2)-1||1:Math.ceil(d/2),l/=d/x),c>2&&h>1&&(v=h>=16384?Math.floor(h/2)-1||1:Math.ceil(h)/2,c/=h/v),g=this.cachedCanvases.getCanvas(f,x,v),m=g.context,m.clearRect(0,0,x,v),m.drawImage(t,0,0,d,h,0,0,x,v),t=g.canvas,d=x,h=v,f=f==="prescale1"?"prescale2":"prescale1"}return{img:t,paintWidth:d,paintHeight:h}}_createMaskCanvas(t,e){const s=this.ctx,{width:a,height:l}=e,c=this.current.fillColor,d=this.current.patternFill,h=de(s);let f,g,m,x;if((e.bitmap||e.data)&&e.count>1){const W=e.bitmap||e.data.buffer;g=JSON.stringify(d?h:[h.slice(0,4),c]),f=this._cachedBitmapsMap.get(W),f||(f=new Map,this._cachedBitmapsMap.set(W,f));const Z=f.get(g);if(Z&&!d){const rt=Math.round(Math.min(h[0],h[2])+h[4]),dt=Math.round(Math.min(h[1],h[3])+h[5]);return this.dependencyTracker?.recordDependencies(t,Bn.transformAndFill),{canvas:Z,offsetX:rt,offsetY:dt}}m=Z}m||(x=this.cachedCanvases.getCanvas("maskCanvas",a,l),Sx(x.context,e));let v=gt.transform(h,[1/a,0,0,-1/l,0,0]);v=gt.transform(v,[1,0,0,1,0,-l]);const E=Tr.slice();gt.axialAlignedBoundingBox([0,0,a,l],v,E);const[S,C,T,_]=E,k=Math.round(T-S)||1,R=Math.round(_-C)||1,D=this.cachedCanvases.getCanvas("fillCanvas",k,R),L=D.context,O=S,B=C;L.translate(-O,-B),L.transform(...v),m||(m=this._scaleImage(x.canvas,ni(L)),m=m.img,f&&d&&f.set(g,m)),L.imageSmoothingEnabled=Ex(de(L),e.interpolate),iu(L,m,0,0,m.width,m.height,0,0,a,l),L.globalCompositeOperation="source-in";const F=gt.transform(ni(L),[1,0,0,1,-O,-B]);return L.fillStyle=d?c.getPattern(s,this,F,$e.FILL,t):c,L.fillRect(0,0,a,l),f&&!d&&(this.cachedCanvases.delete("fillCanvas"),f.set(g,D.canvas)),this.dependencyTracker?.recordDependencies(t,Bn.transformAndFill),{canvas:D.canvas,offsetX:Math.round(O),offsetY:Math.round(B)}}setLineWidth(t,e){this.dependencyTracker?.recordSimpleData("lineWidth",t),e!==this.current.lineWidth&&(this._cachedScaleForStroking[0]=-1),this.current.lineWidth=e,this.ctx.lineWidth=e}setLineCap(t,e){this.dependencyTracker?.recordSimpleData("lineCap",t),this.ctx.lineCap=AR[e]}setLineJoin(t,e){this.dependencyTracker?.recordSimpleData("lineJoin",t),this.ctx.lineJoin=wR[e]}setMiterLimit(t,e){this.dependencyTracker?.recordSimpleData("miterLimit",t),this.ctx.miterLimit=e}setDash(t,e,s){this.dependencyTracker?.recordSimpleData("dash",t);const a=this.ctx;a.setLineDash!==void 0&&(a.setLineDash(e),a.lineDashOffset=s)}setRenderingIntent(t,e){}setFlatness(t,e){}setGState(t,e){for(const[s,a]of e)switch(s){case"LW":this.setLineWidth(t,a);break;case"LC":this.setLineCap(t,a);break;case"LJ":this.setLineJoin(t,a);break;case"ML":this.setMiterLimit(t,a);break;case"D":this.setDash(t,a[0],a[1]);break;case"RI":this.setRenderingIntent(t,a);break;case"FL":this.setFlatness(t,a);break;case"Font":this.setFont(t,a[0],a[1]);break;case"CA":this.dependencyTracker?.recordSimpleData("strokeAlpha",t),this.current.strokeAlpha=a;break;case"ca":this.dependencyTracker?.recordSimpleData("fillAlpha",t),this.ctx.globalAlpha=this.current.fillAlpha=a;break;case"BM":this.dependencyTracker?.recordSimpleData("globalCompositeOperation",t),this.ctx.globalCompositeOperation=a;break;case"SMask":this.dependencyTracker?.recordSimpleData("SMask",t),this.current.activeSMask=a?this.tempSMask:null,this.tempSMask=null,this.checkSMaskState();break;case"TR":this.dependencyTracker?.recordSimpleData("filter",t),this.ctx.filter=this.current.transferMaps=this.filterFactory.addFilter(a);break}}get inSMaskMode(){return!!this.suspendedCtx}checkSMaskState(){const t=this.inSMaskMode;this.current.activeSMask&&!t?this.beginSMaskMode():!this.current.activeSMask&&t&&this.endSMaskMode()}beginSMaskMode(t){if(this.inSMaskMode)throw new Error("beginSMaskMode called while already in smask mode");const e=this.ctx.canvas.width,s=this.ctx.canvas.height,a="smaskGroupAt"+this.groupLevel,l=this.cachedCanvases.getCanvas(a,e,s);this.suspendedCtx=this.ctx;const c=this.ctx=l.context;c.setTransform(this.suspendedCtx.getTransform()),Uo(this.suspendedCtx,c),xR(c,this.suspendedCtx),this.setGState(t,[["BM","source-over"]])}endSMaskMode(){if(!this.inSMaskMode)throw new Error("endSMaskMode called while not in smask mode");this.ctx._removeMirroring(),Uo(this.ctx,this.suspendedCtx),this.ctx=this.suspendedCtx,this.suspendedCtx=null}compose(t){if(!this.current.activeSMask)return;t?(t[0]=Math.floor(t[0]),t[1]=Math.floor(t[1]),t[2]=Math.ceil(t[2]),t[3]=Math.ceil(t[3])):t=[0,0,this.ctx.canvas.width,this.ctx.canvas.height];const e=this.current.activeSMask,s=this.suspendedCtx;this.composeSMask(s,e,this.ctx,t),this.ctx.save(),this.ctx.setTransform(1,0,0,1,0,0),this.ctx.clearRect(0,0,this.ctx.canvas.width,this.ctx.canvas.height),this.ctx.restore()}composeSMask(t,e,s,a){const l=a[0],c=a[1],d=a[2]-l,h=a[3]-c;d===0||h===0||(this.genericComposeSMask(e.context,s,d,h,e.subtype,e.backdrop,e.transferMap,l,c,e.offsetX,e.offsetY),t.save(),t.globalAlpha=1,t.globalCompositeOperation="source-over",t.setTransform(1,0,0,1,0,0),t.drawImage(s.canvas,0,0),t.restore())}genericComposeSMask(t,e,s,a,l,c,d,h,f,g,m){let x=t.canvas,v=h-g,E=f-m;if(c)if(v<0||E<0||v+s>x.width||E+a>x.height){const C=this.cachedCanvases.getCanvas("maskExtension",s,a),T=C.context;T.drawImage(x,-v,-E),T.globalCompositeOperation="destination-atop",T.fillStyle=c,T.fillRect(0,0,s,a),T.globalCompositeOperation="source-over",x=C.canvas,v=E=0}else{t.save(),t.globalAlpha=1,t.setTransform(1,0,0,1,0,0);const C=new Path2D;C.rect(v,E,s,a),t.clip(C),t.globalCompositeOperation="destination-atop",t.fillStyle=c,t.fillRect(v,E,s,a),t.restore()}e.save(),e.globalAlpha=1,e.setTransform(1,0,0,1,0,0),l==="Alpha"&&d?e.filter=this.filterFactory.addAlphaFilter(d):l==="Luminosity"&&(e.filter=this.filterFactory.addLuminosityFilter(d));const S=new Path2D;S.rect(h,f,s,a),e.clip(S),e.globalCompositeOperation="destination-in",e.drawImage(x,v,E,s,a,h,f,s,a),e.restore()}save(t){this.inSMaskMode&&Uo(this.ctx,this.suspendedCtx),this.ctx.save();const e=this.current;this.stateStack.push(e),this.current=e.clone(),this.dependencyTracker?.save(t)}restore(t){if(this.dependencyTracker?.restore(t),this.stateStack.length===0){this.inSMaskMode&&this.endSMaskMode();return}this.current=this.stateStack.pop(),this.ctx.restore(),this.inSMaskMode&&Uo(this.suspendedCtx,this.ctx),this.checkSMaskState(),this.pendingClip=null,this._cachedScaleForStroking[0]=-1,this._cachedGetSinglePixelWidth=null}transform(t,e,s,a,l,c,d){this.dependencyTracker?.recordIncrementalData("transform",t),this.ctx.transform(e,s,a,l,c,d),this._cachedScaleForStroking[0]=-1,this._cachedGetSinglePixelWidth=null}constructPath(t,e,s,a){let[l]=s;if(!a){l||=s[0]=new Path2D,this[e](t,l);return}if(this.dependencyTracker!==null){const c=e===Pr.stroke?this.current.lineWidth/2:0;this.dependencyTracker.resetBBox(t).recordBBox(t,this.ctx,a[0]-c,a[2]+c,a[1]-c,a[3]+c).recordDependencies(t,["transform"])}if(!(l instanceof Path2D)){const c=s[0]=new Path2D;for(let d=0,h=l.length;d<h;)switch(l[d++]){case Kc.moveTo:c.moveTo(l[d++],l[d++]);break;case Kc.lineTo:c.lineTo(l[d++],l[d++]);break;case Kc.curveTo:c.bezierCurveTo(l[d++],l[d++],l[d++],l[d++],l[d++],l[d++]);break;case Kc.closePath:c.closePath();break;default:Rt(`Unrecognized drawing path operator: ${l[d-1]}`);break}l=c}gt.axialAlignedBoundingBox(a,de(this.ctx),this.current.minMax),this[e](t,l),this._pathStartIdx=t}closePath(t){this.ctx.closePath()}stroke(t,e,s=!0){const a=this.ctx,l=this.current.strokeColor;if(a.globalAlpha=this.current.strokeAlpha,this.contentVisible)if(typeof l=="object"&&l?.getPattern){const c=l.isModifyingCurrentTransform()?a.getTransform():null;if(a.save(),a.strokeStyle=l.getPattern(a,this,ni(a),$e.STROKE,t),c){const d=new Path2D;d.addPath(e,a.getTransform().invertSelf().multiplySelf(c)),e=d}this.rescaleAndStroke(e,!1),a.restore()}else this.rescaleAndStroke(e,!0);this.dependencyTracker?.recordDependencies(t,Bn.stroke),s&&this.consumePath(t,e,this.current.getClippedPathBoundingBox($e.STROKE,de(this.ctx))),a.globalAlpha=this.current.fillAlpha}closeStroke(t,e){this.stroke(t,e)}fill(t,e,s=!0){const a=this.ctx,l=this.current.fillColor,c=this.current.patternFill;let d=!1;if(c){const f=l.isModifyingCurrentTransform()?a.getTransform():null;if(this.dependencyTracker?.save(t),a.save(),a.fillStyle=l.getPattern(a,this,ni(a),$e.FILL,t),f){const g=new Path2D;g.addPath(e,a.getTransform().invertSelf().multiplySelf(f)),e=g}d=!0}const h=this.current.getClippedPathBoundingBox();this.contentVisible&&h!==null&&(this.pendingEOFill?(a.fill(e,"evenodd"),this.pendingEOFill=!1):a.fill(e)),this.dependencyTracker?.recordDependencies(t,Bn.fill),d&&(a.restore(),this.dependencyTracker?.restore(t)),s&&this.consumePath(t,e,h)}eoFill(t,e){this.pendingEOFill=!0,this.fill(t,e)}fillStroke(t,e){this.fill(t,e,!1),this.stroke(t,e,!1),this.consumePath(t,e)}eoFillStroke(t,e){this.pendingEOFill=!0,this.fillStroke(t,e)}closeFillStroke(t,e){this.fillStroke(t,e)}closeEOFillStroke(t,e){this.pendingEOFill=!0,this.fillStroke(t,e)}endPath(t,e){this.consumePath(t,e)}rawFillPath(t,e){this.ctx.fill(e),this.dependencyTracker?.recordDependencies(t,Bn.rawFillPath).recordOperation(t)}clip(t){this.dependencyTracker?.recordFutureForcedDependency("clipMode",t),this.pendingClip=SR}eoClip(t){this.dependencyTracker?.recordFutureForcedDependency("clipMode",t),this.pendingClip=Tx}beginText(t){this.current.textMatrix=null,this.current.textMatrixScale=1,this.current.x=this.current.lineX=0,this.current.y=this.current.lineY=0,this.dependencyTracker?.recordOpenMarker(t).resetIncrementalData("sameLineText").resetIncrementalData("moveText",t)}endText(t){const e=this.pendingTextPaths,s=this.ctx;if(this.dependencyTracker){const{dependencyTracker:a}=this;e!==void 0&&a.recordFutureForcedDependency("textClip",a.getOpenMarker()).recordFutureForcedDependency("textClip",t),a.recordCloseMarker(t)}if(e!==void 0){const a=new Path2D,l=s.getTransform().invertSelf();for(const{transform:c,x:d,y:h,fontSize:f,path:g}of e)g&&a.addPath(g,new DOMMatrix(c).preMultiplySelf(l).translate(d,h).scale(f,-f));s.clip(a)}delete this.pendingTextPaths}setCharSpacing(t,e){this.dependencyTracker?.recordSimpleData("charSpacing",t),this.current.charSpacing=e}setWordSpacing(t,e){this.dependencyTracker?.recordSimpleData("wordSpacing",t),this.current.wordSpacing=e}setHScale(t,e){this.dependencyTracker?.recordSimpleData("hScale",t),this.current.textHScale=e/100}setLeading(t,e){this.dependencyTracker?.recordSimpleData("leading",t),this.current.leading=-e}setFont(t,e,s){this.dependencyTracker?.recordSimpleData("font",t).recordSimpleDataFromNamed("fontObj",e,t);const a=this.commonObjs.get(e),l=this.current;if(!a)throw new Error(`Can't find font for ${e}`);if(l.fontMatrix=a.fontMatrix||Wf,(l.fontMatrix[0]===0||l.fontMatrix[3]===0)&&Rt("Invalid font matrix for font "+e),s<0?(s=-s,l.fontDirection=-1):l.fontDirection=1,this.current.font=a,this.current.fontSize=s,a.isType3Font)return;const c=a.loadedName||"sans-serif",d=a.systemFontInfo?.css||`"${c}", ${a.fallbackName}`;let h="normal";a.black?h="900":a.bold&&(h="bold");const f=a.italic?"italic":"normal";let g=s;s<yx?g=yx:s>xx&&(g=xx),this.current.fontSizeScale=s/g,this.ctx.font=`${f} ${h} ${g}px ${d}`}setTextRenderingMode(t,e){this.dependencyTracker?.recordSimpleData("textRenderingMode",t),this.current.textRenderingMode=e}setTextRise(t,e){this.dependencyTracker?.recordSimpleData("textRise",t),this.current.textRise=e}moveText(t,e,s){this.dependencyTracker?.resetIncrementalData("sameLineText").recordIncrementalData("moveText",t),this.current.x=this.current.lineX+=e,this.current.y=this.current.lineY+=s}setLeadingMoveText(t,e,s){this.setLeading(t,-s),this.moveText(t,e,s)}setTextMatrix(t,e){this.dependencyTracker?.recordSimpleData("textMatrix",t);const{current:s}=this;s.textMatrix=e,s.textMatrixScale=Math.hypot(e[0],e[1]),s.x=s.lineX=0,s.y=s.lineY=0}nextLine(t){this.moveText(t,0,this.current.leading),this.dependencyTracker?.recordIncrementalData("moveText",this.dependencyTracker.getSimpleIndex("leading")??t)}#i(t,e,s){const a=new Path2D;return a.addPath(t,new DOMMatrix(s).invertSelf().multiplySelf(e)),a}paintChar(t,e,s,a,l,c){const d=this.ctx,h=this.current,f=h.font,g=h.textRenderingMode,m=h.fontSize/h.fontSizeScale,x=g&Fe.FILL_STROKE_MASK,v=!!(g&Fe.ADD_TO_PATH_FLAG),E=h.patternFill&&!f.missingFile,S=h.patternStroke&&!f.missingFile;let C;if((f.disableFontFace||v||E||S)&&!f.missingFile&&(C=f.getPathGenerator(this.commonObjs,e)),C&&(f.disableFontFace||E||S)){d.save(),d.translate(s,a),d.scale(m,-m),this.dependencyTracker?.recordCharacterBBox(t,d,f);let T;if(x===Fe.FILL||x===Fe.FILL_STROKE)if(l){T=d.getTransform(),d.setTransform(...l);const _=this.#i(C,T,l);d.fill(_)}else d.fill(C);if(x===Fe.STROKE||x===Fe.FILL_STROKE)if(c){T||=d.getTransform(),d.setTransform(...c);const{a:_,b:k,c:R,d:D}=T,L=gt.inverseTransform(c),O=gt.transform([_,k,R,D,0,0],L);gt.singularValueDecompose2dScale(O,An),d.lineWidth*=Math.max(An[0],An[1])/m,d.stroke(this.#i(C,T,c))}else d.lineWidth/=m,d.stroke(C);d.restore()}else(x===Fe.FILL||x===Fe.FILL_STROKE)&&(d.fillText(e,s,a),this.dependencyTracker?.recordCharacterBBox(t,d,f,m,s,a,()=>d.measureText(e))),(x===Fe.STROKE||x===Fe.FILL_STROKE)&&(this.dependencyTracker&&this.dependencyTracker?.recordCharacterBBox(t,d,f,m,s,a,()=>d.measureText(e)).recordDependencies(t,Bn.stroke),d.strokeText(e,s,a));v&&((this.pendingTextPaths||=[]).push({transform:de(d),x:s,y:a,fontSize:m,path:C}),this.dependencyTracker?.recordCharacterBBox(t,d,f,m,s,a))}get isFontSubpixelAAEnabled(){const{context:t}=this.cachedCanvases.getCanvas("isFontSubpixelAAEnabled",10,10);t.scale(1.5,1),t.fillText("I",0,10);const e=t.getImageData(0,0,10,10).data;let s=!1;for(let a=3;a<e.length;a+=4)if(e[a]>0&&e[a]<255){s=!0;break}return jt(this,"isFontSubpixelAAEnabled",s)}showText(t,e){this.dependencyTracker&&(this.dependencyTracker.recordDependencies(t,Bn.showText).resetBBox(t),this.current.textRenderingMode&Fe.ADD_TO_PATH_FLAG&&this.dependencyTracker.recordFutureForcedDependency("textClip",t).inheritPendingDependenciesAsFutureForcedDependencies());const s=this.current,a=s.font;if(a.isType3Font){this.showType3Text(t,e),this.dependencyTracker?.recordShowTextOperation(t);return}const l=s.fontSize;if(l===0){this.dependencyTracker?.recordOperation(t);return}const c=this.ctx,d=s.fontSizeScale,h=s.charSpacing,f=s.wordSpacing,g=s.fontDirection,m=s.textHScale*g,x=e.length,v=a.vertical,E=v?1:-1,S=a.defaultVMetrics,C=l*s.fontMatrix[0],T=s.textRenderingMode===Fe.FILL&&!a.disableFontFace&&!s.patternFill;c.save(),s.textMatrix&&c.transform(...s.textMatrix),c.translate(s.x,s.y+s.textRise),g>0?c.scale(m,-1):c.scale(m,1);let _,k;if(s.patternFill){c.save();const B=s.fillColor.getPattern(c,this,ni(c),$e.FILL,t);_=de(c),c.restore(),c.fillStyle=B}if(s.patternStroke){c.save();const B=s.strokeColor.getPattern(c,this,ni(c),$e.STROKE,t);k=de(c),c.restore(),c.strokeStyle=B}let R=s.lineWidth;const D=s.textMatrixScale;if(D===0||R===0){const B=s.textRenderingMode&Fe.FILL_STROKE_MASK;(B===Fe.STROKE||B===Fe.FILL_STROKE)&&(R=this.getSinglePixelWidth())}else R/=D;if(d!==1&&(c.scale(d,d),R/=d),c.lineWidth=R,a.isInvalidPDFjsFont){const B=[];let F=0;for(const Z of e)B.push(Z.unicode),F+=Z.width;const W=B.join("");if(c.fillText(W,0,0),this.dependencyTracker!==null){const Z=c.measureText(W);this.dependencyTracker.recordBBox(t,this.ctx,-Z.actualBoundingBoxLeft,Z.actualBoundingBoxRight,-Z.actualBoundingBoxAscent,Z.actualBoundingBoxDescent).recordShowTextOperation(t)}s.x+=F*C*m,c.restore(),this.compose();return}let L=0,O;for(O=0;O<x;++O){const B=e[O];if(typeof B=="number"){L+=E*B*l/1e3;continue}let F=!1;const W=(B.isSpace?f:0)+h,Z=B.fontChar,rt=B.accent;let dt,lt,ut=B.width;if(v){const K=B.vmetric||S,ct=-(B.vmetric?K[1]:ut*.5)*C,bt=K[2]*C;ut=K?-K[0]:ut,dt=ct/d,lt=(L+bt)/d}else dt=L/d,lt=0;let P;if(a.remeasure&&ut>0){P=c.measureText(Z);const K=P.width*1e3/l*d;if(ut<K&&this.isFontSubpixelAAEnabled){const ct=ut/K;F=!0,c.save(),c.scale(ct,1),dt/=ct}else ut!==K&&(dt+=(ut-K)/2e3*l/d)}if(this.contentVisible&&(B.isInFont||a.missingFile)){if(T&&!rt)c.fillText(Z,dt,lt),this.dependencyTracker?.recordCharacterBBox(t,c,P?{bbox:null}:a,l/d,dt,lt,()=>P??c.measureText(Z));else if(this.paintChar(t,Z,dt,lt,_,k),rt){const K=dt+l*rt.offset.x/d,ct=lt-l*rt.offset.y/d;this.paintChar(t,rt.fontChar,K,ct,_,k)}}const V=v?ut*C-W*g:ut*C+W*g;L+=V,F&&c.restore()}v?s.y-=L:s.x+=L*m,c.restore(),this.compose(),this.dependencyTracker?.recordShowTextOperation(t)}showType3Text(t,e){const s=this.ctx,a=this.current,l=a.font,c=a.fontSize,d=a.fontDirection,h=l.vertical?1:-1,f=a.charSpacing,g=a.wordSpacing,m=a.textHScale*d,x=a.fontMatrix||Wf,v=e.length,E=a.textRenderingMode===Fe.INVISIBLE;let S,C,T,_;if(E||c===0)return;this._cachedScaleForStroking[0]=-1,this._cachedGetSinglePixelWidth=null,s.save(),a.textMatrix&&s.transform(...a.textMatrix),s.translate(a.x,a.y+a.textRise),s.scale(m,d);const k=this.dependencyTracker;for(this.dependencyTracker=k?new Eu(k,t):null,S=0;S<v;++S){if(C=e[S],typeof C=="number"){_=h*C*c/1e3,this.ctx.translate(_,0),a.x+=_*m;continue}const R=(C.isSpace?g:0)+f,D=l.charProcOperatorList[C.operatorListId];D?this.contentVisible&&(this.save(),s.scale(c,c),s.transform(...x),this.executeOperatorList(D),this.restore()):Rt(`Type3 character "${C.operatorListId}" is not available.`);const L=[C.width,0];gt.applyTransform(L,x),T=L[0]*c+R,s.translate(T,0),a.x+=T*m}s.restore(),k&&(this.dependencyTracker=k)}setCharWidth(t,e,s){}setCharWidthAndBounds(t,e,s,a,l,c,d){const h=new Path2D;h.rect(a,l,c-a,d-l),this.ctx.clip(h),this.dependencyTracker?.recordBBox(t,this.ctx,a,c,l,d).recordClipBox(t,this.ctx,a,c,l,d),this.endPath(t)}getColorN_Pattern(t,e){let s;if(e[0]==="TilingPattern"){const a=this.baseTransform||de(this.ctx),l={createCanvasGraphics:(c,d)=>new _r(c,this.commonObjs,this.objs,this.canvasFactory,this.filterFactory,{optionalContentConfig:this.optionalContentConfig,markedContentStack:this.markedContentStack},void 0,void 0,this.dependencyTracker?new Eu(this.dependencyTracker,d,!0):null)};s=new Np(e,this.ctx,l,a)}else s=this._getPattern(t,e[1],e[2]);return s}setStrokeColorN(t,...e){this.dependencyTracker?.recordSimpleData("strokeColor",t),this.current.strokeColor=this.getColorN_Pattern(t,e),this.current.patternStroke=!0}setFillColorN(t,...e){this.dependencyTracker?.recordSimpleData("fillColor",t),this.current.fillColor=this.getColorN_Pattern(t,e),this.current.patternFill=!0}setStrokeRGBColor(t,e){this.dependencyTracker?.recordSimpleData("strokeColor",t),this.ctx.strokeStyle=this.current.strokeColor=e,this.current.patternStroke=!1}setStrokeTransparent(t){this.dependencyTracker?.recordSimpleData("strokeColor",t),this.ctx.strokeStyle=this.current.strokeColor="transparent",this.current.patternStroke=!1}setFillRGBColor(t,e){this.dependencyTracker?.recordSimpleData("fillColor",t),this.ctx.fillStyle=this.current.fillColor=e,this.current.patternFill=!1}setFillTransparent(t){this.dependencyTracker?.recordSimpleData("fillColor",t),this.ctx.fillStyle=this.current.fillColor="transparent",this.current.patternFill=!1}_getPattern(t,e,s=null){let a;return this.cachedPatterns.has(e)?a=this.cachedPatterns.get(e):(a=mR(this.getObject(t,e)),this.cachedPatterns.set(e,a)),s&&(a.matrix=s),a}shadingFill(t,e){if(!this.contentVisible)return;const s=this.ctx;this.save(t);const a=this._getPattern(t,e);s.fillStyle=a.getPattern(s,this,ni(s),$e.SHADING,t);const l=ni(s);if(l){const{width:c,height:d}=s.canvas,h=Tr.slice();gt.axialAlignedBoundingBox([0,0,c,d],l,h);const[f,g,m,x]=h;this.ctx.fillRect(f,g,m-f,x-g)}else this.ctx.fillRect(-1e10,-1e10,2e10,2e10);this.dependencyTracker?.resetBBox(t).recordFullPageBBox(t).recordDependencies(t,Bn.transform).recordDependencies(t,Bn.fill).recordOperation(t),this.compose(this.current.getClippedPathBoundingBox()),this.restore(t)}beginInlineImage(){ie("Should not call beginInlineImage")}beginImageData(){ie("Should not call beginImageData")}paintFormXObjectBegin(t,e,s){if(this.contentVisible&&(this.save(t),this.baseTransformStack.push(this.baseTransform),e&&this.transform(t,...e),this.baseTransform=de(this.ctx),s)){gt.axialAlignedBoundingBox(s,this.baseTransform,this.current.minMax);const[a,l,c,d]=s,h=new Path2D;h.rect(a,l,c-a,d-l),this.ctx.clip(h),this.dependencyTracker?.recordClipBox(t,this.ctx,a,c,l,d),this.endPath(t)}}paintFormXObjectEnd(t){this.contentVisible&&(this.restore(t),this.baseTransform=this.baseTransformStack.pop())}beginGroup(t,e){if(!this.contentVisible)return;this.save(t),this.inSMaskMode&&(this.endSMaskMode(),this.current.activeSMask=null);const s=this.ctx;e.isolated||Nu("TODO: Support non-isolated groups."),e.knockout&&Rt("Knockout groups not supported.");const a=de(s);if(e.matrix&&s.transform(...e.matrix),!e.bbox)throw new Error("Bounding box is required.");let l=Tr.slice();gt.axialAlignedBoundingBox(e.bbox,de(s),l);const c=[0,0,s.canvas.width,s.canvas.height];l=gt.intersect(l,c)||[0,0,0,0];const d=Math.floor(l[0]),h=Math.floor(l[1]),f=Math.max(Math.ceil(l[2])-d,1),g=Math.max(Math.ceil(l[3])-h,1);this.current.startNewPathAndClipBox([0,0,f,g]);let m="groupAt"+this.groupLevel;e.smask&&(m+="_smask_"+this.smaskCounter++%2);const x=this.cachedCanvases.getCanvas(m,f,g),v=x.context;v.translate(-d,-h),v.transform(...a);let E=new Path2D;const[S,C,T,_]=e.bbox;if(E.rect(S,C,T-S,_-C),e.matrix){const k=new Path2D;k.addPath(E,new DOMMatrix(e.matrix)),E=k}v.clip(E),e.smask&&this.smaskStack.push({canvas:x.canvas,context:v,offsetX:d,offsetY:h,subtype:e.smask.subtype,backdrop:e.smask.backdrop,transferMap:e.smask.transferMap||null,startTransformInverse:null}),(!e.smask||this.dependencyTracker)&&(s.setTransform(1,0,0,1,0,0),s.translate(d,h),s.save()),Uo(s,v),this.ctx=v,this.dependencyTracker?.inheritSimpleDataAsFutureForcedDependencies(["fillAlpha","strokeAlpha","globalCompositeOperation"]).pushBaseTransform(s),this.setGState(t,[["BM","source-over"],["ca",1],["CA",1]]),this.groupStack.push(s),this.groupLevel++}endGroup(t,e){if(!this.contentVisible)return;this.groupLevel--;const s=this.ctx,a=this.groupStack.pop();if(this.ctx=a,this.ctx.imageSmoothingEnabled=!1,this.dependencyTracker?.popBaseTransform(),e.smask)this.tempSMask=this.smaskStack.pop(),this.restore(t),this.dependencyTracker&&this.ctx.restore();else{this.ctx.restore();const l=de(this.ctx);this.restore(t),this.ctx.save(),this.ctx.setTransform(...l);const c=Tr.slice();gt.axialAlignedBoundingBox([0,0,s.canvas.width,s.canvas.height],l,c),this.ctx.drawImage(s.canvas,0,0),this.ctx.restore(),this.compose(c)}}beginAnnotation(t,e,s,a,l,c){if(this.#t(),su(this.ctx),this.ctx.save(),this.save(t),this.baseTransform&&this.ctx.setTransform(...this.baseTransform),s){const d=s[2]-s[0],h=s[3]-s[1];if(c&&this.annotationCanvasMap){a=a.slice(),a[4]-=s[0],a[5]-=s[1],s=s.slice(),s[0]=s[1]=0,s[2]=d,s[3]=h,gt.singularValueDecompose2dScale(de(this.ctx),An);const{viewportScale:f}=this,g=Math.ceil(d*this.outputScaleX*f),m=Math.ceil(h*this.outputScaleY*f);this.annotationCanvas=this.canvasFactory.create(g,m);const{canvas:x,context:v}=this.annotationCanvas;this.annotationCanvasMap.set(e,x),this.annotationCanvas.savedCtx=this.ctx,this.ctx=v,this.ctx.save(),this.ctx.setTransform(An[0],0,0,-An[1],0,h*An[1]),su(this.ctx)}else{su(this.ctx),this.endPath(t);const f=new Path2D;f.rect(s[0],s[1],d,h),this.ctx.clip(f)}}this.current=new Ax(this.ctx.canvas.width,this.ctx.canvas.height),this.transform(t,...a),this.transform(t,...l)}endAnnotation(t){this.annotationCanvas&&(this.ctx.restore(),this.#e(),this.ctx=this.annotationCanvas.savedCtx,delete this.annotationCanvas.savedCtx,delete this.annotationCanvas)}paintImageMaskXObject(t,e){if(!this.contentVisible)return;const s=e.count;e=this.getObject(t,e.data,e),e.count=s;const a=this.ctx,l=this._createMaskCanvas(t,e),c=l.canvas;a.save(),a.setTransform(1,0,0,1,0,0),a.drawImage(c,l.offsetX,l.offsetY),this.dependencyTracker?.resetBBox(t).recordBBox(t,this.ctx,l.offsetX,l.offsetX+c.width,l.offsetY,l.offsetY+c.height).recordOperation(t),a.restore(),this.compose()}paintImageMaskXObjectRepeat(t,e,s,a=0,l=0,c,d){if(!this.contentVisible)return;e=this.getObject(t,e.data,e);const h=this.ctx;h.save();const f=de(h);h.transform(s,a,l,c,0,0);const g=this._createMaskCanvas(t,e);h.setTransform(1,0,0,1,g.offsetX-f[4],g.offsetY-f[5]),this.dependencyTracker?.resetBBox(t);for(let m=0,x=d.length;m<x;m+=2){const v=gt.transform(f,[s,a,l,c,d[m],d[m+1]]);h.drawImage(g.canvas,v[4],v[5]),this.dependencyTracker?.recordBBox(t,this.ctx,v[4],v[4]+g.canvas.width,v[5],v[5]+g.canvas.height)}h.restore(),this.compose(),this.dependencyTracker?.recordOperation(t)}paintImageMaskXObjectGroup(t,e){if(!this.contentVisible)return;const s=this.ctx,a=this.current.fillColor,l=this.current.patternFill;this.dependencyTracker?.resetBBox(t).recordDependencies(t,Bn.transformAndFill);for(const c of e){const{data:d,width:h,height:f,transform:g}=c,m=this.cachedCanvases.getCanvas("maskCanvas",h,f),x=m.context;x.save();const v=this.getObject(t,d,c);Sx(x,v),x.globalCompositeOperation="source-in",x.fillStyle=l?a.getPattern(x,this,ni(s),$e.FILL,t):a,x.fillRect(0,0,h,f),x.restore(),s.save(),s.transform(...g),s.scale(1,-1),iu(s,m.canvas,0,0,h,f,0,-1,1,1),this.dependencyTracker?.recordBBox(t,s,0,h,0,f),s.restore()}this.compose(),this.dependencyTracker?.recordOperation(t)}paintImageXObject(t,e){if(!this.contentVisible)return;const s=this.getObject(t,e);if(!s){Rt("Dependent image isn't ready yet");return}this.paintInlineImageXObject(t,s)}paintImageXObjectRepeat(t,e,s,a,l){if(!this.contentVisible)return;const c=this.getObject(t,e);if(!c){Rt("Dependent image isn't ready yet");return}const d=c.width,h=c.height,f=[];for(let g=0,m=l.length;g<m;g+=2)f.push({transform:[s,0,0,a,l[g],l[g+1]],x:0,y:0,w:d,h});this.paintInlineImageXObjectGroup(t,c,f)}applyTransferMapsToCanvas(t){return this.current.transferMaps!=="none"&&(t.filter=this.current.transferMaps,t.drawImage(t.canvas,0,0),t.filter="none"),t.canvas}applyTransferMapsToBitmap(t){if(this.current.transferMaps==="none")return t.bitmap;const{bitmap:e,width:s,height:a}=t,l=this.cachedCanvases.getCanvas("inlineImage",s,a),c=l.context;return c.filter=this.current.transferMaps,c.drawImage(e,0,0),c.filter="none",l.canvas}paintInlineImageXObject(t,e){if(!this.contentVisible)return;const s=e.width,a=e.height,l=this.ctx;this.save(t);const{filter:c}=l;c!=="none"&&c!==""&&(l.filter="none"),l.scale(1/s,-1/a);let d;if(e.bitmap)d=this.applyTransferMapsToBitmap(e);else if(typeof HTMLElement=="function"&&e instanceof HTMLElement||!e.data)d=e;else{const g=this.cachedCanvases.getCanvas("inlineImage",s,a).context;wx(g,e),d=this.applyTransferMapsToCanvas(g)}const h=this._scaleImage(d,ni(l));l.imageSmoothingEnabled=Ex(de(l),e.interpolate),this.dependencyTracker?.resetBBox(t).recordBBox(t,l,0,s,-a,0).recordDependencies(t,Bn.imageXObject).recordOperation(t),iu(l,h.img,0,0,h.paintWidth,h.paintHeight,0,-a,s,a),this.compose(),this.restore(t)}paintInlineImageXObjectGroup(t,e,s){if(!this.contentVisible)return;const a=this.ctx;let l;if(e.bitmap)l=e.bitmap;else{const c=e.width,d=e.height,f=this.cachedCanvases.getCanvas("inlineImage",c,d).context;wx(f,e),l=this.applyTransferMapsToCanvas(f)}this.dependencyTracker?.resetBBox(t);for(const c of s)a.save(),a.transform(...c.transform),a.scale(1,-1),iu(a,l,c.x,c.y,c.w,c.h,0,-1,1,1),this.dependencyTracker?.recordBBox(t,a,0,1,-1,0),a.restore();this.dependencyTracker?.recordOperation(t),this.compose()}paintSolidColorImageMask(t){this.contentVisible&&(this.dependencyTracker?.resetBBox(t).recordBBox(t,this.ctx,0,1,0,1).recordDependencies(t,Bn.fill).recordOperation(t),this.ctx.fillRect(0,0,1,1),this.compose())}markPoint(t,e){}markPointProps(t,e,s){}beginMarkedContent(t,e){this.dependencyTracker?.beginMarkedContent(t),this.markedContentStack.push({visible:!0})}beginMarkedContentProps(t,e,s){this.dependencyTracker?.beginMarkedContent(t),e==="OC"?this.markedContentStack.push({visible:this.optionalContentConfig.isVisible(s)}):this.markedContentStack.push({visible:!0}),this.contentVisible=this.isContentVisible()}endMarkedContent(t){this.dependencyTracker?.endMarkedContent(t),this.markedContentStack.pop(),this.contentVisible=this.isContentVisible()}beginCompat(t){}endCompat(t){}consumePath(t,e,s){const a=this.current.isEmptyClip();this.pendingClip&&this.current.updateClipFromPath(),this.pendingClip||this.compose(s);const l=this.ctx;this.pendingClip?(a||(this.pendingClip===Tx?l.clip(e,"evenodd"):l.clip(e)),this.pendingClip=null,this.dependencyTracker?.bboxToClipBoxDropOperation(t).recordFutureForcedDependency("clipPath",t)):this.dependencyTracker?.recordOperation(t),this.current.startNewPathAndClipBox(this.current.clipBox)}getSinglePixelWidth(){if(!this._cachedGetSinglePixelWidth){const t=de(this.ctx);if(t[1]===0&&t[2]===0)this._cachedGetSinglePixelWidth=1/Math.min(Math.abs(t[0]),Math.abs(t[3]));else{const e=Math.abs(t[0]*t[3]-t[2]*t[1]),s=Math.hypot(t[0],t[2]),a=Math.hypot(t[1],t[3]);this._cachedGetSinglePixelWidth=Math.max(s,a)/e}}return this._cachedGetSinglePixelWidth}getScaleForStroking(){if(this._cachedScaleForStroking[0]===-1){const{lineWidth:t}=this.current,{a:e,b:s,c:a,d:l}=this.ctx.getTransform();let c,d;if(s===0&&a===0){const h=Math.abs(e),f=Math.abs(l);if(h===f)if(t===0)c=d=1/h;else{const g=h*t;c=d=g<1?1/g:1}else if(t===0)c=1/h,d=1/f;else{const g=h*t,m=f*t;c=g<1?1/g:1,d=m<1?1/m:1}}else{const h=Math.abs(e*l-s*a),f=Math.hypot(e,s),g=Math.hypot(a,l);if(t===0)c=g/h,d=f/h;else{const m=t*h;c=g>m?g/m:1,d=f>m?f/m:1}}this._cachedScaleForStroking[0]=c,this._cachedScaleForStroking[1]=d}return this._cachedScaleForStroking}rescaleAndStroke(t,e){const{ctx:s,current:{lineWidth:a}}=this,[l,c]=this.getScaleForStroking();if(l===c){s.lineWidth=(a||1)*l,s.stroke(t);return}const d=s.getLineDash();e&&s.save(),s.scale(l,c),Df.a=1/l,Df.d=1/c;const h=new Path2D;if(h.addPath(t,Df),d.length>0){const f=Math.max(l,c);s.setLineDash(d.map(g=>g/f)),s.lineDashOffset/=f}s.lineWidth=a||1,s.stroke(h),e&&s.restore()}isContentVisible(){for(let t=this.markedContentStack.length-1;t>=0;t--)if(!this.markedContentStack[t].visible)return!1;return!0}}for(const r in Pr)_r.prototype[r]!==void 0&&(_r.prototype[Pr[r]]=_r.prototype[r]);class kr{#t;#e;#i;static strings=["fontFamily","fontWeight","italicAngle"];static write(t){const e=new TextEncoder,s={};let a=0;for(const f of kr.strings){const g=e.encode(t[f]);s[f]=g,a+=4+g.length}const l=new ArrayBuffer(a),c=new Uint8Array(l),d=new DataView(l);let h=0;for(const f of kr.strings){const g=s[f],m=g.length;d.setUint32(h,m),c.set(g,h+4),h+=4+m}return Ht(h===l.byteLength,"CssFontInfo.write: Buffer overflow"),l}constructor(t){this.#t=t,this.#e=new DataView(this.#t),this.#i=new TextDecoder}#n(t){Ht(t<kr.strings.length,"Invalid string index");let e=0;for(let a=0;a<t;a++)e+=this.#e.getUint32(e)+4;const s=this.#e.getUint32(e);return this.#i.decode(new Uint8Array(this.#t,e+4,s))}get fontFamily(){return this.#n(0)}get fontWeight(){return this.#n(1)}get italicAngle(){return this.#n(2)}}class Mr{#t;#e;#i;static strings=["css","loadedName","baseFontName","src"];static write(t){const e=new TextEncoder,s={};let a=0;for(const x of Mr.strings){const v=e.encode(t[x]);s[x]=v,a+=4+v.length}a+=4;let l,c,d=1+a;t.style&&(l=e.encode(t.style.style),c=e.encode(t.style.weight),d+=4+l.length+4+c.length);const h=new ArrayBuffer(d),f=new Uint8Array(h),g=new DataView(h);let m=0;g.setUint8(m++,t.guessFallback?1:0),g.setUint32(m,0),m+=4,a=0;for(const x of Mr.strings){const v=s[x],E=v.length;a+=4+E,g.setUint32(m,E),f.set(v,m+4),m+=4+E}return g.setUint32(m-a-4,a),t.style&&(g.setUint32(m,l.length),f.set(l,m+4),m+=4+l.length,g.setUint32(m,c.length),f.set(c,m+4),m+=4+c.length),Ht(m<=h.byteLength,"SubstitionInfo.write: Buffer overflow"),h.transferToFixedLength(m)}constructor(t){this.#t=t,this.#e=new DataView(this.#t),this.#i=new TextDecoder}get guessFallback(){return this.#e.getUint8(0)!==0}#n(t){Ht(t<Mr.strings.length,"Invalid string index");let e=5;for(let a=0;a<t;a++)e+=this.#e.getUint32(e)+4;const s=this.#e.getUint32(e);return this.#i.decode(new Uint8Array(this.#t,e+4,s))}get css(){return this.#n(0)}get loadedName(){return this.#n(1)}get baseFontName(){return this.#n(2)}get src(){return this.#n(3)}get style(){let t=1;t+=4+this.#e.getUint32(t);const e=this.#e.getUint32(t),s=this.#i.decode(new Uint8Array(this.#t,t+4,e));t+=4+e;const a=this.#e.getUint32(t),l=this.#i.decode(new Uint8Array(this.#t,t+4,a));return{style:s,weight:l}}}class te{static bools=["black","bold","disableFontFace","fontExtraProperties","isInvalidPDFjsFont","isType3Font","italic","missingFile","remeasure","vertical"];static numbers=["ascent","defaultWidth","descent"];static strings=["fallbackName","loadedName","mimetype","name"];static#t=Math.ceil(this.bools.length*2/8);static#e=this.#t+this.numbers.length*8;static#i=this.#e+1+8;static#n=this.#i+1+48;static#r=this.#n+1+6;#s;#a;#o;constructor({data:t,extra:e}){this.#s=t,this.#a=new TextDecoder,this.#o=new DataView(this.#s),e&&Object.assign(this,e)}#c(t){Ht(t<te.bools.length,"Invalid boolean index");const e=Math.floor(t/4),s=t*2%8,a=this.#o.getUint8(e)>>s&3;return a===0?void 0:a===2}get black(){return this.#c(0)}get bold(){return this.#c(1)}get disableFontFace(){return this.#c(2)}get fontExtraProperties(){return this.#c(3)}get isInvalidPDFjsFont(){return this.#c(4)}get isType3Font(){return this.#c(5)}get italic(){return this.#c(6)}get missingFile(){return this.#c(7)}get remeasure(){return this.#c(8)}get vertical(){return this.#c(9)}#l(t){return Ht(t<te.numbers.length,"Invalid number index"),this.#o.getFloat64(te.#t+t*8)}get ascent(){return this.#l(0)}get defaultWidth(){return this.#l(1)}get descent(){return this.#l(2)}get bbox(){let t=te.#e;if(this.#o.getUint8(t)===0)return;t+=1;const s=[];for(let a=0;a<4;a++)s.push(this.#o.getInt16(t,!0)),t+=2;return s}get fontMatrix(){let t=te.#i;if(this.#o.getUint8(t)===0)return;t+=1;const s=[];for(let a=0;a<6;a++)s.push(this.#o.getFloat64(t,!0)),t+=8;return s}get defaultVMetrics(){let t=te.#n;if(this.#o.getUint8(t)===0)return;t+=1;const s=[];for(let a=0;a<3;a++)s.push(this.#o.getInt16(t,!0)),t+=2;return s}#h(t){Ht(t<te.strings.length,"Invalid string index");let e=te.#r+4;for(let l=0;l<t;l++)e+=this.#o.getUint32(e)+4;const s=this.#o.getUint32(e),a=new Uint8Array(s);return a.set(new Uint8Array(this.#s,e+4,s)),this.#a.decode(a)}get fallbackName(){return this.#h(0)}get loadedName(){return this.#h(1)}get mimetype(){return this.#h(2)}get name(){return this.#h(3)}get data(){let t=te.#r;const e=this.#o.getUint32(t);t+=4+e;const s=this.#o.getUint32(t);t+=4+s;const a=this.#o.getUint32(t);t+=4+a;const l=this.#o.getUint32(t);if(l!==0)return new Uint8Array(this.#s,t+4,l)}clearData(){let t=te.#r;const e=this.#o.getUint32(t);t+=4+e;const s=this.#o.getUint32(t);t+=4+s;const a=this.#o.getUint32(t);t+=4+a;const l=this.#o.getUint32(t);new Uint8Array(this.#s,t+4,l).fill(0),this.#o.setUint32(t,0)}get cssFontInfo(){let t=te.#r;const e=this.#o.getUint32(t);t+=4+e;const s=this.#o.getUint32(t);t+=4+s;const a=this.#o.getUint32(t);if(a===0)return null;const l=new Uint8Array(a);return l.set(new Uint8Array(this.#s,t+4,a)),new kr(l.buffer)}get systemFontInfo(){let t=te.#r;const e=this.#o.getUint32(t);t+=4+e;const s=this.#o.getUint32(t);if(s===0)return null;const a=new Uint8Array(s);return a.set(new Uint8Array(this.#s,t+4,s)),new Mr(a.buffer)}static write(t){const e=t.systemFontInfo?Mr.write(t.systemFontInfo):null,s=t.cssFontInfo?kr.write(t.cssFontInfo):null,a=new TextEncoder,l={};let c=0;for(const S of te.strings)l[S]=a.encode(t[S]),c+=4+l[S].length;const d=te.#r+4+c+4+(e?e.byteLength:0)+4+(s?s.byteLength:0)+4+(t.data?t.data.length:0),h=new ArrayBuffer(d),f=new Uint8Array(h),g=new DataView(h);let m=0;const x=te.bools.length;let v=0,E=0;for(let S=0;S<x;S++){const C=t[te.bools[S]];v|=(C===void 0?0:C?2:1)<<E,E+=2,(E===8||S===x-1)&&(g.setUint8(m++,v),v=0,E=0)}Ht(m===te.#t,"FontInfo.write: Boolean properties offset mismatch");for(const S of te.numbers)g.setFloat64(m,t[S]),m+=8;if(Ht(m===te.#e,"FontInfo.write: Number properties offset mismatch"),t.bbox){g.setUint8(m++,4);for(const S of t.bbox)g.setInt16(m,S,!0),m+=2}else g.setUint8(m++,0),m+=8;if(Ht(m===te.#i,"FontInfo.write: BBox properties offset mismatch"),t.fontMatrix){g.setUint8(m++,6);for(const S of t.fontMatrix)g.setFloat64(m,S,!0),m+=8}else g.setUint8(m++,0),m+=48;if(Ht(m===te.#n,"FontInfo.write: FontMatrix properties offset mismatch"),t.defaultVMetrics){g.setUint8(m++,1);for(const S of t.defaultVMetrics)g.setInt16(m,S,!0),m+=2}else g.setUint8(m++,0),m+=6;Ht(m===te.#r,"FontInfo.write: DefaultVMetrics properties offset mismatch"),g.setUint32(te.#r,0),m+=4;for(const S of te.strings){const C=l[S],T=C.length;g.setUint32(m,T),f.set(C,m+4),m+=4+T}if(g.setUint32(te.#r,m-te.#r-4),!e)g.setUint32(m,0),m+=4;else{const S=e.byteLength;g.setUint32(m,S),Ht(m+4+S<=h.byteLength,"FontInfo.write: Buffer overflow at systemFontInfo"),f.set(new Uint8Array(e),m+4),m+=4+S}if(!s)g.setUint32(m,0),m+=4;else{const S=s.byteLength;g.setUint32(m,S),Ht(m+4+S<=h.byteLength,"FontInfo.write: Buffer overflow at cssFontInfo"),f.set(new Uint8Array(s),m+4),m+=4+S}return t.data===void 0?(g.setUint32(m,0),m+=4):(g.setUint32(m,t.data.length),f.set(t.data,m+4),m+=4+t.data.length),Ht(m<=h.byteLength,"FontInfo.write: Buffer overflow"),h.transferToFixedLength(m)}}class Ss{static#t=null;static#e="";static get workerPort(){return this.#t}static set workerPort(t){if(!(typeof Worker<"u"&&t instanceof Worker)&&t!==null)throw new Error("Invalid `workerPort` type.");this.#t=t}static get workerSrc(){return this.#e}static set workerSrc(t){if(typeof t!="string")throw new Error("Invalid `workerSrc` type.");this.#e=t}}class ER{#t;#e;constructor({parsedData:t,rawData:e}){this.#t=t,this.#e=e}getRaw(){return this.#e}get(t){return this.#t.get(t)??null}[Symbol.iterator](){return this.#t.entries()}}const vr=Symbol("INTERNAL");class TR{#t=!1;#e=!1;#i=!1;#n=!0;constructor(t,{name:e,intent:s,usage:a,rbGroups:l}){this.#t=!!(t&xn.DISPLAY),this.#e=!!(t&xn.PRINT),this.name=e,this.intent=s,this.usage=a,this.rbGroups=l}get visible(){if(this.#i)return this.#n;if(!this.#n)return!1;const{print:t,view:e}=this.usage;return this.#t?e?.viewState!=="OFF":this.#e?t?.printState!=="OFF":!0}_setVisible(t,e,s=!1){t!==vr&&ie("Internal method `_setVisible` called."),this.#i=s,this.#n=e}}class CR{#t=null;#e=new Map;#i=null;#n=null;constructor(t,e=xn.DISPLAY){if(this.renderingIntent=e,this.name=null,this.creator=null,t!==null){this.name=t.name,this.creator=t.creator,this.#n=t.order;for(const s of t.groups)this.#e.set(s.id,new TR(e,s));if(t.baseState==="OFF")for(const s of this.#e.values())s._setVisible(vr,!1);for(const s of t.on)this.#e.get(s)._setVisible(vr,!0);for(const s of t.off)this.#e.get(s)._setVisible(vr,!1);this.#i=this.getHash()}}#r(t){const e=t.length;if(e<2)return!0;const s=t[0];for(let a=1;a<e;a++){const l=t[a];let c;if(Array.isArray(l))c=this.#r(l);else if(this.#e.has(l))c=this.#e.get(l).visible;else return Rt(`Optional content group not found: ${l}`),!0;switch(s){case"And":if(!c)return!1;break;case"Or":if(c)return!0;break;case"Not":return!c;default:return!0}}return s==="And"}isVisible(t){if(this.#e.size===0)return!0;if(!t)return Nu("Optional content group not defined."),!0;if(t.type==="OCG")return this.#e.has(t.id)?this.#e.get(t.id).visible:(Rt(`Optional content group not found: ${t.id}`),!0);if(t.type==="OCMD"){if(t.expression)return this.#r(t.expression);if(!t.policy||t.policy==="AnyOn"){for(const e of t.ids){if(!this.#e.has(e))return Rt(`Optional content group not found: ${e}`),!0;if(this.#e.get(e).visible)return!0}return!1}else if(t.policy==="AllOn"){for(const e of t.ids){if(!this.#e.has(e))return Rt(`Optional content group not found: ${e}`),!0;if(!this.#e.get(e).visible)return!1}return!0}else if(t.policy==="AnyOff"){for(const e of t.ids){if(!this.#e.has(e))return Rt(`Optional content group not found: ${e}`),!0;if(!this.#e.get(e).visible)return!0}return!1}else if(t.policy==="AllOff"){for(const e of t.ids){if(!this.#e.has(e))return Rt(`Optional content group not found: ${e}`),!0;if(this.#e.get(e).visible)return!1}return!0}return Rt(`Unknown optional content policy ${t.policy}.`),!0}return Rt(`Unknown group type ${t.type}.`),!0}setVisibility(t,e=!0,s=!0){const a=this.#e.get(t);if(!a){Rt(`Optional content group not found: ${t}`);return}if(s&&e&&a.rbGroups.length)for(const l of a.rbGroups)for(const c of l)c!==t&&this.#e.get(c)?._setVisible(vr,!1,!0);a._setVisible(vr,!!e,!0),this.#t=null}setOCGState({state:t,preserveRB:e}){let s;for(const a of t){switch(a){case"ON":case"OFF":case"Toggle":s=a;continue}const l=this.#e.get(a);if(l)switch(s){case"ON":this.setVisibility(a,!0,e);break;case"OFF":this.setVisibility(a,!1,e);break;case"Toggle":this.setVisibility(a,!l.visible,e);break}}this.#t=null}get hasInitialVisibility(){return this.#i===null||this.getHash()===this.#i}getOrder(){return this.#e.size?this.#n?this.#n.slice():[...this.#e.keys()]:null}getGroup(t){return this.#e.get(t)||null}getHash(){if(this.#t!==null)return this.#t;const t=new Jv;for(const[e,s]of this.#e)t.update(`${e}:${s.visible}`);return this.#t=t.hexdigest()}[Symbol.iterator](){return this.#e.entries()}}class _R{constructor(t,{disableRange:e=!1,disableStream:s=!1}){Ht(t,'PDFDataTransportStream - missing required "pdfDataRangeTransport" argument.');const{length:a,initialData:l,progressiveDone:c,contentDispositionFilename:d}=t;if(this._queuedChunks=[],this._progressiveDone=c,this._contentDispositionFilename=d,l?.length>0){const h=l instanceof Uint8Array&&l.byteLength===l.buffer.byteLength?l.buffer:new Uint8Array(l).buffer;this._queuedChunks.push(h)}this._pdfDataRangeTransport=t,this._isStreamingSupported=!s,this._isRangeSupported=!e,this._contentLength=a,this._fullRequestReader=null,this._rangeReaders=[],t.addRangeListener((h,f)=>{this._onReceiveData({begin:h,chunk:f})}),t.addProgressListener((h,f)=>{this._onProgress({loaded:h,total:f})}),t.addProgressiveReadListener(h=>{this._onReceiveData({chunk:h})}),t.addProgressiveDoneListener(()=>{this._onProgressiveDone()}),t.transportReady()}_onReceiveData({begin:t,chunk:e}){const s=e instanceof Uint8Array&&e.byteLength===e.buffer.byteLength?e.buffer:new Uint8Array(e).buffer;if(t===void 0)this._fullRequestReader?this._fullRequestReader._enqueue(s):this._queuedChunks.push(s);else{const a=this._rangeReaders.some(function(l){return l._begin!==t?!1:(l._enqueue(s),!0)});Ht(a,"_onReceiveData - no `PDFDataTransportStreamRangeReader` instance found.")}}get _progressiveDataLength(){return this._fullRequestReader?._loaded??0}_onProgress(t){t.total===void 0?this._rangeReaders[0]?.onProgress?.({loaded:t.loaded}):this._fullRequestReader?.onProgress?.({loaded:t.loaded,total:t.total})}_onProgressiveDone(){this._fullRequestReader?.progressiveDone(),this._progressiveDone=!0}_removeRangeReader(t){const e=this._rangeReaders.indexOf(t);e>=0&&this._rangeReaders.splice(e,1)}getFullReader(){Ht(!this._fullRequestReader,"PDFDataTransportStream.getFullReader can only be called once.");const t=this._queuedChunks;return this._queuedChunks=null,new kR(this,t,this._progressiveDone,this._contentDispositionFilename)}getRangeReader(t,e){if(e<=this._progressiveDataLength)return null;const s=new MR(this,t,e);return this._pdfDataRangeTransport.requestDataRange(t,e),this._rangeReaders.push(s),s}cancelAllRequests(t){this._fullRequestReader?.cancel(t);for(const e of this._rangeReaders.slice(0))e.cancel(t);this._pdfDataRangeTransport.abort()}}class kR{constructor(t,e,s=!1,a=null){this._stream=t,this._done=s||!1,this._filename=zu(a)?a:null,this._queuedChunks=e||[],this._loaded=0;for(const l of this._queuedChunks)this._loaded+=l.byteLength;this._requests=[],this._headersReady=Promise.resolve(),t._fullRequestReader=this,this.onProgress=null}_enqueue(t){this._done||(this._requests.length>0?this._requests.shift().resolve({value:t,done:!1}):this._queuedChunks.push(t),this._loaded+=t.byteLength)}get headersReady(){return this._headersReady}get filename(){return this._filename}get isRangeSupported(){return this._stream._isRangeSupported}get isStreamingSupported(){return this._stream._isStreamingSupported}get contentLength(){return this._stream._contentLength}async read(){if(this._queuedChunks.length>0)return{value:this._queuedChunks.shift(),done:!1};if(this._done)return{value:void 0,done:!0};const t=Promise.withResolvers();return this._requests.push(t),t.promise}cancel(t){this._done=!0;for(const e of this._requests)e.resolve({value:void 0,done:!0});this._requests.length=0}progressiveDone(){this._done||(this._done=!0)}}class MR{constructor(t,e,s){this._stream=t,this._begin=e,this._end=s,this._queuedChunk=null,this._requests=[],this._done=!1,this.onProgress=null}_enqueue(t){if(!this._done){if(this._requests.length===0)this._queuedChunk=t;else{this._requests.shift().resolve({value:t,done:!1});for(const s of this._requests)s.resolve({value:void 0,done:!0});this._requests.length=0}this._done=!0,this._stream._removeRangeReader(this)}}get isStreamingSupported(){return!1}async read(){if(this._queuedChunk){const e=this._queuedChunk;return this._queuedChunk=null,{value:e,done:!1}}if(this._done)return{value:void 0,done:!0};const t=Promise.withResolvers();return this._requests.push(t),t.promise}cancel(t){this._done=!0;for(const e of this._requests)e.resolve({value:void 0,done:!0});this._requests.length=0,this._stream._removeRangeReader(this)}}function DR(r){let t=!0,e=s("filename\\*","i").exec(r);if(e){e=e[1];let g=d(e);return g=unescape(g),g=h(g),g=f(g),l(g)}if(e=c(r),e){const g=f(e);return l(g)}if(e=s("filename","i").exec(r),e){e=e[1];let g=d(e);return g=f(g),l(g)}function s(g,m){return new RegExp("(?:^|;)\\s*"+g+'\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)',m)}function a(g,m){if(g){if(!/^[\x00-\xFF]+$/.test(m))return m;try{const x=new TextDecoder(g,{fatal:!0}),v=hl(m);m=x.decode(v),t=!1}catch{}}return m}function l(g){return t&&/[\x80-\xff]/.test(g)&&(g=a("utf-8",g),t&&(g=a("iso-8859-1",g))),g}function c(g){const m=[];let x;const v=s("filename\\*((?!0\\d)\\d+)(\\*?)","ig");for(;(x=v.exec(g))!==null;){let[,S,C,T]=x;if(S=parseInt(S,10),S in m){if(S===0)break;continue}m[S]=[C,T]}const E=[];for(let S=0;S<m.length&&S in m;++S){let[C,T]=m[S];T=d(T),C&&(T=unescape(T),S===0&&(T=h(T))),E.push(T)}return E.join("")}function d(g){if(g.startsWith('"')){const m=g.slice(1).split('\\"');for(let x=0;x<m.length;++x){const v=m[x].indexOf('"');v!==-1&&(m[x]=m[x].slice(0,v),m.length=x+1),m[x]=m[x].replaceAll(/\\(.)/g,"$1")}g=m.join('"')}return g}function h(g){const m=g.indexOf("'");if(m===-1)return g;const x=g.slice(0,m),E=g.slice(m+1).replace(/^[^']*'/,"");return a(x,E)}function f(g){return!g.startsWith("=?")||/[\x00-\x19\x80-\xff]/.test(g)?g:g.replaceAll(/=\?([\w-]*)\?([QqBb])\?((?:[^?]|\?(?!=))*)\?=/g,function(m,x,v,E){if(v==="q"||v==="Q")return E=E.replaceAll("_"," "),E=E.replaceAll(/=([0-9a-fA-F]{2})/g,function(S,C){return String.fromCharCode(parseInt(C,16))}),a(x,E);try{E=atob(E)}catch{}return a(x,E)})}return""}function o1(r,t){const e=new Headers;if(!r||!t||typeof t!="object")return e;for(const s in t){const a=t[s];a!==void 0&&e.append(s,a)}return e}function Pu(r){return URL.parse(r)?.origin??null}function l1({responseHeaders:r,isHttp:t,rangeChunkSize:e,disableRange:s}){const a={allowRangeRequests:!1,suggestedLength:void 0},l=parseInt(r.get("Content-Length"),10);return!Number.isInteger(l)||(a.suggestedLength=l,l<=2*e)||s||!t||r.get("Accept-Ranges")!=="bytes"||(r.get("Content-Encoding")||"identity")!=="identity"||(a.allowRangeRequests=!0),a}function c1(r){const t=r.get("Content-Disposition");if(t){let e=DR(t);if(e.includes("%"))try{e=decodeURIComponent(e)}catch{}if(zu(e))return e}return null}function bl(r,t){return new al(`Unexpected server response (${r}) while retrieving PDF "${t}".`,r,r===404||r===0&&t.startsWith("file:"))}function u1(r){return r===200||r===206}function d1(r,t,e){return{method:"GET",headers:r,signal:e.signal,mode:"cors",credentials:t?"include":"same-origin",redirect:"follow"}}function h1(r){return r instanceof Uint8Array?r.buffer:r instanceof ArrayBuffer?r:(Rt(`getArrayBuffer - unexpected data format: ${r}`),new Uint8Array(r).buffer)}class RR{_responseOrigin=null;constructor(t){this.source=t,this.isHttp=/^https?:/i.test(t.url),this.headers=o1(this.isHttp,t.httpHeaders),this._fullRequestReader=null,this._rangeRequestReaders=[]}get _progressiveDataLength(){return this._fullRequestReader?._loaded??0}getFullReader(){return Ht(!this._fullRequestReader,"PDFFetchStream.getFullReader can only be called once."),this._fullRequestReader=new LR(this),this._fullRequestReader}getRangeReader(t,e){if(e<=this._progressiveDataLength)return null;const s=new OR(this,t,e);return this._rangeRequestReaders.push(s),s}cancelAllRequests(t){this._fullRequestReader?.cancel(t);for(const e of this._rangeRequestReaders.slice(0))e.cancel(t)}}class LR{constructor(t){this._stream=t,this._reader=null,this._loaded=0,this._filename=null;const e=t.source;this._withCredentials=e.withCredentials||!1,this._contentLength=e.length,this._headersCapability=Promise.withResolvers(),this._disableRange=e.disableRange||!1,this._rangeChunkSize=e.rangeChunkSize,!this._rangeChunkSize&&!this._disableRange&&(this._disableRange=!0),this._abortController=new AbortController,this._isStreamingSupported=!e.disableStream,this._isRangeSupported=!e.disableRange;const s=new Headers(t.headers),a=e.url;fetch(a,d1(s,this._withCredentials,this._abortController)).then(l=>{if(t._responseOrigin=Pu(l.url),!u1(l.status))throw bl(l.status,a);this._reader=l.body.getReader(),this._headersCapability.resolve();const c=l.headers,{allowRangeRequests:d,suggestedLength:h}=l1({responseHeaders:c,isHttp:t.isHttp,rangeChunkSize:this._rangeChunkSize,disableRange:this._disableRange});this._isRangeSupported=d,this._contentLength=h||this._contentLength,this._filename=c1(c),!this._isStreamingSupported&&this._isRangeSupported&&this.cancel(new Bi("Streaming is disabled."))}).catch(this._headersCapability.reject),this.onProgress=null}get headersReady(){return this._headersCapability.promise}get filename(){return this._filename}get contentLength(){return this._contentLength}get isRangeSupported(){return this._isRangeSupported}get isStreamingSupported(){return this._isStreamingSupported}async read(){await this._headersCapability.promise;const{value:t,done:e}=await this._reader.read();return e?{value:t,done:e}:(this._loaded+=t.byteLength,this.onProgress?.({loaded:this._loaded,total:this._contentLength}),{value:h1(t),done:!1})}cancel(t){this._reader?.cancel(t),this._abortController.abort()}}class OR{constructor(t,e,s){this._stream=t,this._reader=null,this._loaded=0;const a=t.source;this._withCredentials=a.withCredentials||!1,this._readCapability=Promise.withResolvers(),this._isStreamingSupported=!a.disableStream,this._abortController=new AbortController;const l=new Headers(t.headers);l.append("Range",`bytes=${e}-${s-1}`);const c=a.url;fetch(c,d1(l,this._withCredentials,this._abortController)).then(d=>{const h=Pu(d.url);if(h!==t._responseOrigin)throw new Error(`Expected range response-origin "${h}" to match "${t._responseOrigin}".`);if(!u1(d.status))throw bl(d.status,c);this._readCapability.resolve(),this._reader=d.body.getReader()}).catch(this._readCapability.reject),this.onProgress=null}get isStreamingSupported(){return this._isStreamingSupported}async read(){await this._readCapability.promise;const{value:t,done:e}=await this._reader.read();return e?{value:t,done:e}:(this._loaded+=t.byteLength,this.onProgress?.({loaded:this._loaded}),{value:h1(t),done:!1})}cancel(t){this._reader?.cancel(t),this._abortController.abort()}}const Rf=200,Lf=206;function jR(r){const t=r.response;return typeof t!="string"?t:hl(t).buffer}class NR{_responseOrigin=null;constructor({url:t,httpHeaders:e,withCredentials:s}){this.url=t,this.isHttp=/^https?:/i.test(t),this.headers=o1(this.isHttp,e),this.withCredentials=s||!1,this.currXhrId=0,this.pendingRequests=Object.create(null)}request(t){const e=new XMLHttpRequest,s=this.currXhrId++,a=this.pendingRequests[s]={xhr:e};e.open("GET",this.url),e.withCredentials=this.withCredentials;for(const[l,c]of this.headers)e.setRequestHeader(l,c);return this.isHttp&&"begin"in t&&"end"in t?(e.setRequestHeader("Range",`bytes=${t.begin}-${t.end-1}`),a.expectedStatus=Lf):a.expectedStatus=Rf,e.responseType="arraybuffer",Ht(t.onError,"Expected `onError` callback to be provided."),e.onerror=()=>{t.onError(e.status)},e.onreadystatechange=this.onStateChange.bind(this,s),e.onprogress=this.onProgress.bind(this,s),a.onHeadersReceived=t.onHeadersReceived,a.onDone=t.onDone,a.onError=t.onError,a.onProgress=t.onProgress,e.send(null),s}onProgress(t,e){const s=this.pendingRequests[t];s&&s.onProgress?.(e)}onStateChange(t,e){const s=this.pendingRequests[t];if(!s)return;const a=s.xhr;if(a.readyState>=2&&s.onHeadersReceived&&(s.onHeadersReceived(),delete s.onHeadersReceived),a.readyState!==4||!(t in this.pendingRequests))return;if(delete this.pendingRequests[t],a.status===0&&this.isHttp){s.onError(a.status);return}const l=a.status||Rf;if(!(l===Rf&&s.expectedStatus===Lf)&&l!==s.expectedStatus){s.onError(a.status);return}const d=jR(a);if(l===Lf){const h=a.getResponseHeader("Content-Range"),f=/bytes (\d+)-(\d+)\/(\d+)/.exec(h);f?s.onDone({begin:parseInt(f[1],10),chunk:d}):(Rt('Missing or invalid "Content-Range" header.'),s.onError(0))}else d?s.onDone({begin:0,chunk:d}):s.onError(a.status)}getRequestXhr(t){return this.pendingRequests[t].xhr}isPendingRequest(t){return t in this.pendingRequests}abortRequest(t){const e=this.pendingRequests[t].xhr;delete this.pendingRequests[t],e.abort()}}class BR{constructor(t){this._source=t,this._manager=new NR(t),this._rangeChunkSize=t.rangeChunkSize,this._fullRequestReader=null,this._rangeRequestReaders=[]}_onRangeRequestReaderClosed(t){const e=this._rangeRequestReaders.indexOf(t);e>=0&&this._rangeRequestReaders.splice(e,1)}getFullReader(){return Ht(!this._fullRequestReader,"PDFNetworkStream.getFullReader can only be called once."),this._fullRequestReader=new zR(this._manager,this._source),this._fullRequestReader}getRangeReader(t,e){const s=new PR(this._manager,t,e);return s.onClosed=this._onRangeRequestReaderClosed.bind(this),this._rangeRequestReaders.push(s),s}cancelAllRequests(t){this._fullRequestReader?.cancel(t);for(const e of this._rangeRequestReaders.slice(0))e.cancel(t)}}class zR{constructor(t,e){this._manager=t,this._url=e.url,this._fullRequestId=t.request({onHeadersReceived:this._onHeadersReceived.bind(this),onDone:this._onDone.bind(this),onError:this._onError.bind(this),onProgress:this._onProgress.bind(this)}),this._headersCapability=Promise.withResolvers(),this._disableRange=e.disableRange||!1,this._contentLength=e.length,this._rangeChunkSize=e.rangeChunkSize,!this._rangeChunkSize&&!this._disableRange&&(this._disableRange=!0),this._isStreamingSupported=!1,this._isRangeSupported=!1,this._cachedChunks=[],this._requests=[],this._done=!1,this._storedError=void 0,this._filename=null,this.onProgress=null}_onHeadersReceived(){const t=this._fullRequestId,e=this._manager.getRequestXhr(t);this._manager._responseOrigin=Pu(e.responseURL);const s=e.getAllResponseHeaders(),a=new Headers(s?s.trimStart().replace(/[^\S ]+$/,"").split(/[\r\n]+/).map(d=>{const[h,...f]=d.split(": ");return[h,f.join(": ")]}):[]),{allowRangeRequests:l,suggestedLength:c}=l1({responseHeaders:a,isHttp:this._manager.isHttp,rangeChunkSize:this._rangeChunkSize,disableRange:this._disableRange});l&&(this._isRangeSupported=!0),this._contentLength=c||this._contentLength,this._filename=c1(a),this._isRangeSupported&&this._manager.abortRequest(t),this._headersCapability.resolve()}_onDone(t){if(t&&(this._requests.length>0?this._requests.shift().resolve({value:t.chunk,done:!1}):this._cachedChunks.push(t.chunk)),this._done=!0,!(this._cachedChunks.length>0)){for(const e of this._requests)e.resolve({value:void 0,done:!0});this._requests.length=0}}_onError(t){this._storedError=bl(t,this._url),this._headersCapability.reject(this._storedError);for(const e of this._requests)e.reject(this._storedError);this._requests.length=0,this._cachedChunks.length=0}_onProgress(t){this.onProgress?.({loaded:t.loaded,total:t.lengthComputable?t.total:this._contentLength})}get filename(){return this._filename}get isRangeSupported(){return this._isRangeSupported}get isStreamingSupported(){return this._isStreamingSupported}get contentLength(){return this._contentLength}get headersReady(){return this._headersCapability.promise}async read(){if(await this._headersCapability.promise,this._storedError)throw this._storedError;if(this._cachedChunks.length>0)return{value:this._cachedChunks.shift(),done:!1};if(this._done)return{value:void 0,done:!0};const t=Promise.withResolvers();return this._requests.push(t),t.promise}cancel(t){this._done=!0,this._headersCapability.reject(t);for(const e of this._requests)e.resolve({value:void 0,done:!0});this._requests.length=0,this._manager.isPendingRequest(this._fullRequestId)&&this._manager.abortRequest(this._fullRequestId),this._fullRequestReader=null}}class PR{constructor(t,e,s){this._manager=t,this._url=t.url,this._requestId=t.request({begin:e,end:s,onHeadersReceived:this._onHeadersReceived.bind(this),onDone:this._onDone.bind(this),onError:this._onError.bind(this),onProgress:this._onProgress.bind(this)}),this._requests=[],this._queuedChunk=null,this._done=!1,this._storedError=void 0,this.onProgress=null,this.onClosed=null}_onHeadersReceived(){const t=Pu(this._manager.getRequestXhr(this._requestId)?.responseURL);t!==this._manager._responseOrigin&&(this._storedError=new Error(`Expected range response-origin "${t}" to match "${this._manager._responseOrigin}".`),this._onError(0))}_close(){this.onClosed?.(this)}_onDone(t){const e=t.chunk;this._requests.length>0?this._requests.shift().resolve({value:e,done:!1}):this._queuedChunk=e,this._done=!0;for(const s of this._requests)s.resolve({value:void 0,done:!0});this._requests.length=0,this._close()}_onError(t){this._storedError??=bl(t,this._url);for(const e of this._requests)e.reject(this._storedError);this._requests.length=0,this._queuedChunk=null}_onProgress(t){this.isStreamingSupported||this.onProgress?.({loaded:t.loaded})}get isStreamingSupported(){return!1}async read(){if(this._storedError)throw this._storedError;if(this._queuedChunk!==null){const e=this._queuedChunk;return this._queuedChunk=null,{value:e,done:!1}}if(this._done)return{value:void 0,done:!0};const t=Promise.withResolvers();return this._requests.push(t),t.promise}cancel(t){this._done=!0;for(const e of this._requests)e.resolve({value:void 0,done:!0});this._requests.length=0,this._manager.isPendingRequest(this._requestId)&&this._manager.abortRequest(this._requestId),this._close()}}const IR=/^[a-z][a-z0-9\-+.]+:/i;function FR(r){if(IR.test(r))return new URL(r);const t=process.getBuiltinModule("url");return new URL(t.pathToFileURL(r))}class $R{constructor(t){this.source=t,this.url=FR(t.url),Ht(this.url.protocol==="file:","PDFNodeStream only supports file:// URLs."),this._fullRequestReader=null,this._rangeRequestReaders=[]}get _progressiveDataLength(){return this._fullRequestReader?._loaded??0}getFullReader(){return Ht(!this._fullRequestReader,"PDFNodeStream.getFullReader can only be called once."),this._fullRequestReader=new HR(this),this._fullRequestReader}getRangeReader(t,e){if(e<=this._progressiveDataLength)return null;const s=new UR(this,t,e);return this._rangeRequestReaders.push(s),s}cancelAllRequests(t){this._fullRequestReader?.cancel(t);for(const e of this._rangeRequestReaders.slice(0))e.cancel(t)}}class HR{constructor(t){this._url=t.url,this._done=!1,this._storedError=null,this.onProgress=null;const e=t.source;this._contentLength=e.length,this._loaded=0,this._filename=null,this._disableRange=e.disableRange||!1,this._rangeChunkSize=e.rangeChunkSize,!this._rangeChunkSize&&!this._disableRange&&(this._disableRange=!0),this._isStreamingSupported=!e.disableStream,this._isRangeSupported=!e.disableRange,this._readableStream=null,this._readCapability=Promise.withResolvers(),this._headersCapability=Promise.withResolvers();const s=process.getBuiltinModule("fs");s.promises.lstat(this._url).then(a=>{this._contentLength=a.size,this._setReadableStream(s.createReadStream(this._url)),this._headersCapability.resolve()},a=>{a.code==="ENOENT"&&(a=bl(0,this._url.href)),this._storedError=a,this._headersCapability.reject(a)})}get headersReady(){return this._headersCapability.promise}get filename(){return this._filename}get contentLength(){return this._contentLength}get isRangeSupported(){return this._isRangeSupported}get isStreamingSupported(){return this._isStreamingSupported}async read(){if(await this._readCapability.promise,this._done)return{value:void 0,done:!0};if(this._storedError)throw this._storedError;const t=this._readableStream.read();return t===null?(this._readCapability=Promise.withResolvers(),this.read()):(this._loaded+=t.length,this.onProgress?.({loaded:this._loaded,total:this._contentLength}),{value:new Uint8Array(t).buffer,done:!1})}cancel(t){if(!this._readableStream){this._error(t);return}this._readableStream.destroy(t)}_error(t){this._storedError=t,this._readCapability.resolve()}_setReadableStream(t){this._readableStream=t,t.on("readable",()=>{this._readCapability.resolve()}),t.on("end",()=>{t.destroy(),this._done=!0,this._readCapability.resolve()}),t.on("error",e=>{this._error(e)}),!this._isStreamingSupported&&this._isRangeSupported&&this._error(new Bi("streaming is disabled")),this._storedError&&this._readableStream.destroy(this._storedError)}}class UR{constructor(t,e,s){this._url=t.url,this._done=!1,this._storedError=null,this.onProgress=null,this._loaded=0,this._readableStream=null,this._readCapability=Promise.withResolvers();const a=t.source;this._isStreamingSupported=!a.disableStream;const l=process.getBuiltinModule("fs");this._setReadableStream(l.createReadStream(this._url,{start:e,end:s-1}))}get isStreamingSupported(){return this._isStreamingSupported}async read(){if(await this._readCapability.promise,this._done)return{value:void 0,done:!0};if(this._storedError)throw this._storedError;const t=this._readableStream.read();return t===null?(this._readCapability=Promise.withResolvers(),this.read()):(this._loaded+=t.length,this.onProgress?.({loaded:this._loaded}),{value:new Uint8Array(t).buffer,done:!1})}cancel(t){if(!this._readableStream){this._error(t);return}this._readableStream.destroy(t)}_error(t){this._storedError=t,this._readCapability.resolve()}_setReadableStream(t){this._readableStream=t,t.on("readable",()=>{this._readCapability.resolve()}),t.on("end",()=>{t.destroy(),this._done=!0,this._readCapability.resolve()}),t.on("error",e=>{this._error(e)}),this._storedError&&this._readableStream.destroy(this._storedError)}}const Go=Symbol("INITIAL_DATA");class f1{#t=Object.create(null);#e(t){return this.#t[t]||={...Promise.withResolvers(),data:Go}}get(t,e=null){if(e){const a=this.#e(t);return a.promise.then(()=>e(a.data)),null}const s=this.#t[t];if(!s||s.data===Go)throw new Error(`Requesting object that isn't resolved yet ${t}.`);return s.data}has(t){const e=this.#t[t];return!!e&&e.data!==Go}delete(t){const e=this.#t[t];return!e||e.data===Go?!1:(delete this.#t[t],!0)}resolve(t,e=null){const s=this.#e(t);s.data=e,s.resolve()}clear(){for(const t in this.#t){const{data:e}=this.#t[t];e?.bitmap?.close()}this.#t=Object.create(null)}*[Symbol.iterator](){for(const t in this.#t){const{data:e}=this.#t[t];e!==Go&&(yield[t,e])}}}const GR=1e5,Cx=30;let ol=class zn{#t=Promise.withResolvers();#e=null;#i=!1;#n=!!globalThis.FontInspector?.enabled;#r=null;#s=null;#a=0;#o=0;#c=null;#l=null;#h=0;#d=0;#f=Object.create(null);#m=[];#p=null;#u=[];#g=new WeakMap;#b=null;static#x=new Map;static#y=new Map;static#T=new WeakMap;static#S=null;static#v=new Set;constructor({textContentSource:t,container:e,viewport:s}){if(t instanceof ReadableStream)this.#p=t;else if(typeof t=="object")this.#p=new ReadableStream({start(h){h.enqueue(t),h.close()}});else throw new Error('No "textContentSource" parameter specified.');this.#e=this.#l=e,this.#d=s.scale*Wn.pixelRatio,this.#h=s.rotation,this.#s={div:null,properties:null,ctx:null};const{pageWidth:a,pageHeight:l,pageX:c,pageY:d}=s.rawDims;this.#b=[1,0,0,-1,-c,d+l],this.#o=a,this.#a=l,zn.#M(),_s(e,s),this.#t.promise.finally(()=>{zn.#v.delete(this),this.#s=null,this.#f=null}).catch(()=>{})}static get fontFamilyMap(){const{isWindows:t,isFirefox:e}=je.platform;return jt(this,"fontFamilyMap",new Map([["sans-serif",`${t&&e?"Calibri, ":""}sans-serif`],["monospace",`${t&&e?"Lucida Console, ":""}monospace`]]))}render(){const t=()=>{this.#c.read().then(({value:e,done:s})=>{if(s){this.#t.resolve();return}this.#r??=e.lang,Object.assign(this.#f,e.styles),this.#_(e.items),t()},this.#t.reject)};return this.#c=this.#p.getReader(),zn.#v.add(this),t(),this.#t.promise}update({viewport:t,onBefore:e=null}){const s=t.scale*Wn.pixelRatio,a=t.rotation;if(a!==this.#h&&(e?.(),this.#h=a,_s(this.#l,{rotation:a})),s!==this.#d){e?.(),this.#d=s;const l={div:null,properties:null,ctx:zn.#D(this.#r)};for(const c of this.#u)l.properties=this.#g.get(c),l.div=c,this.#E(l)}}cancel(){const t=new Bi("TextLayer task cancelled.");this.#c?.cancel(t).catch(()=>{}),this.#c=null,this.#t.reject(t)}get textDivs(){return this.#u}get textContentItemsStr(){return this.#m}#_(t){if(this.#i)return;this.#s.ctx??=zn.#D(this.#r);const e=this.#u,s=this.#m;for(const a of t){if(e.length>GR){Rt("Ignoring additional textDivs for performance reasons."),this.#i=!0;return}if(a.str===void 0){if(a.type==="beginMarkedContentProps"||a.type==="beginMarkedContent"){const l=this.#e;this.#e=document.createElement("span"),this.#e.classList.add("markedContent"),a.id&&this.#e.setAttribute("id",`${a.id}`),l.append(this.#e)}else a.type==="endMarkedContent"&&(this.#e=this.#e.parentNode);continue}s.push(a.str),this.#w(a)}}#w(t){const e=document.createElement("span"),s={angle:0,canvasWidth:0,hasText:t.str!=="",hasEOL:t.hasEOL,fontSize:0};this.#u.push(e);const a=gt.transform(this.#b,t.transform);let l=Math.atan2(a[1],a[0]);const c=this.#f[t.fontName];c.vertical&&(l+=Math.PI/2);let d=this.#n&&c.fontSubstitution||c.fontFamily;d=zn.fontFamilyMap.get(d)||d;const h=Math.hypot(a[2],a[3]),f=h*zn.#z(d,c,this.#r);let g,m;l===0?(g=a[4],m=a[5]-f):(g=a[4]+f*Math.sin(l),m=a[5]-f*Math.cos(l));const x="calc(var(--total-scale-factor) *",v=e.style;this.#e===this.#l?(v.left=`${(100*g/this.#o).toFixed(2)}%`,v.top=`${(100*m/this.#a).toFixed(2)}%`):(v.left=`${x}${g.toFixed(2)}px)`,v.top=`${x}${m.toFixed(2)}px)`),v.fontSize=`${x}${(zn.#S*h).toFixed(2)}px)`,v.fontFamily=d,s.fontSize=h,e.setAttribute("role","presentation"),e.textContent=t.str,e.dir=t.dir,this.#n&&(e.dataset.fontName=c.fontSubstitutionLoadedName||t.fontName),l!==0&&(s.angle=l*(180/Math.PI));let E=!1;if(t.str.length>1)E=!0;else if(t.str!==" "&&t.transform[0]!==t.transform[3]){const S=Math.abs(t.transform[0]),C=Math.abs(t.transform[3]);S!==C&&Math.max(S,C)/Math.min(S,C)>1.5&&(E=!0)}if(E&&(s.canvasWidth=c.vertical?t.height:t.width),this.#g.set(e,s),this.#s.div=e,this.#s.properties=s,this.#E(this.#s),s.hasText&&this.#e.append(e),s.hasEOL){const S=document.createElement("br");S.setAttribute("role","presentation"),this.#e.append(S)}}#E(t){const{div:e,properties:s,ctx:a}=t,{style:l}=e;let c="";if(zn.#S>1&&(c=`scale(${1/zn.#S})`),s.canvasWidth!==0&&s.hasText){const{fontFamily:d}=l,{canvasWidth:h,fontSize:f}=s;zn.#k(a,f*this.#d,d);const{width:g}=a.measureText(e.textContent);g>0&&(c=`scaleX(${h*this.#d/g}) ${c}`)}s.angle!==0&&(c=`rotate(${s.angle}deg) ${c}`),c.length>0&&(l.transform=c)}static cleanup(){if(!(this.#v.size>0)){this.#x.clear();for(const{canvas:t}of this.#y.values())t.remove();this.#y.clear()}}static#D(t=null){let e=this.#y.get(t||="");if(!e){const s=document.createElement("canvas");s.className="hiddenCanvasElement",s.lang=t,document.body.append(s),e=s.getContext("2d",{alpha:!1,willReadFrequently:!0}),this.#y.set(t,e),this.#T.set(e,{size:0,family:""})}return e}static#k(t,e,s){const a=this.#T.get(t);e===a.size&&s===a.family||(t.font=`${e}px ${s}`,a.size=e,a.family=s)}static#M(){if(this.#S!==null)return;const t=document.createElement("div");t.style.opacity=0,t.style.lineHeight=1,t.style.fontSize="1px",t.style.position="absolute",t.textContent="X",document.body.append(t),this.#S=t.getBoundingClientRect().height,t.remove()}static#z(t,e,s){const a=this.#x.get(t);if(a)return a;const l=this.#D(s);l.canvas.width=l.canvas.height=Cx,this.#k(l,Cx,t);const c=l.measureText(""),d=c.fontBoundingBoxAscent,h=Math.abs(c.fontBoundingBoxDescent);l.canvas.width=l.canvas.height=0;let f=.8;return d?f=d/(d+h):(je.platform.isFirefox&&Rt("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."),e.ascent?f=e.ascent:e.descent&&(f=1+e.descent)),this.#x.set(t,f),f}};const VR=100;function Bp(r={}){typeof r=="string"||r instanceof URL?r={url:r}:(r instanceof ArrayBuffer||ArrayBuffer.isView(r))&&(r={data:r});const t=new zp,{docId:e}=t,s=r.url?JD(r.url):null,a=r.data?tR(r.data):null,l=r.httpHeaders||null,c=r.withCredentials===!0,d=r.password??null,h=r.range instanceof Pp?r.range:null,f=Number.isInteger(r.rangeChunkSize)&&r.rangeChunkSize>0?r.rangeChunkSize:2**16;let g=r.worker instanceof Ir?r.worker:null;const m=r.verbosity,x=typeof r.docBaseUrl=="string"&&!pl(r.docBaseUrl)?r.docBaseUrl:null,v=Jc(r.cMapUrl),E=r.cMapPacked!==!1,S=r.CMapReaderFactory||(Xe?oR:hx),C=Jc(r.iccUrl),T=Jc(r.standardFontDataUrl),_=r.StandardFontDataFactory||(Xe?lR:fx),k=Jc(r.wasmUrl),R=r.WasmFactory||(Xe?cR:px),D=r.stopAtErrors!==!0,L=Number.isInteger(r.maxImageSize)&&r.maxImageSize>-1?r.maxImageSize:-1,O=r.isEvalSupported!==!1,B=typeof r.isOffscreenCanvasSupported=="boolean"?r.isOffscreenCanvasSupported:!Xe,F=typeof r.isImageDecoderSupported=="boolean"?r.isImageDecoderSupported:!Xe&&(je.platform.isFirefox||!globalThis.chrome),W=Number.isInteger(r.canvasMaxAreaInBytes)?r.canvasMaxAreaInBytes:-1,Z=typeof r.disableFontFace=="boolean"?r.disableFontFace:Xe,rt=r.fontExtraProperties===!0,dt=r.enableXfa===!0,lt=r.ownerDocument||globalThis.document,ut=r.disableRange===!0,P=r.disableStream===!0,V=r.disableAutoFetch===!0,K=r.pdfBug===!0,ct=r.CanvasFactory||(Xe?rR:iR),bt=r.FilterFactory||(Xe?aR:sR),z=r.enableHWA===!0,H=r.useWasm!==!1,q=h?h.length:r.length??NaN,tt=typeof r.useSystemFonts=="boolean"?r.useSystemFonts:!Xe&&!Z,st=typeof r.useWorkerFetch=="boolean"?r.useWorkerFetch:!!(S===hx&&_===fx&&R===px&&v&&T&&k&&Xo(v,document.baseURI)&&Xo(T,document.baseURI)&&Xo(k,document.baseURI)),ot=null;jD(m);const at={canvasFactory:new ct({ownerDocument:lt,enableHWA:z}),filterFactory:new bt({docId:e,ownerDocument:lt}),cMapReaderFactory:st?null:new S({baseUrl:v,isCompressed:E}),standardFontDataFactory:st?null:new _({baseUrl:T}),wasmFactory:st?null:new R({baseUrl:k})};g||(g=Ir.create({verbosity:m,port:Ss.workerPort}),t._worker=g);const kt={docId:e,apiVersion:"5.4.296",data:a,password:d,disableAutoFetch:V,rangeChunkSize:f,length:q,docBaseUrl:x,enableXfa:dt,evaluatorOptions:{maxImageSize:L,disableFontFace:Z,ignoreErrors:D,isEvalSupported:O,isOffscreenCanvasSupported:B,isImageDecoderSupported:F,canvasMaxAreaInBytes:W,fontExtraProperties:rt,useSystemFonts:tt,useWasm:H,useWorkerFetch:st,cMapUrl:v,iccUrl:C,standardFontDataUrl:T,wasmUrl:k}},et={ownerDocument:lt,pdfBug:K,styleElement:ot,loadingParams:{disableAutoFetch:V,enableXfa:dt}};return g.promise.then(function(){if(t.destroyed)throw new Error("Loading aborted");if(g.destroyed)throw new Error("Worker was destroyed");const xt=g.messageHandler.sendWithPromise("GetDocRequest",kt,a?[a.buffer]:null);let ht;if(h)ht=new _R(h,{disableRange:ut,disableStream:P});else if(!a){if(!s)throw new Error("getDocument - no `url` parameter provided.");const Ct=Xo(s)?RR:Xe?$R:BR;ht=new Ct({url:s,length:q,httpHeaders:l,withCredentials:c,rangeChunkSize:f,disableRange:ut,disableStream:P})}return xt.then(Ct=>{if(t.destroyed)throw new Error("Loading aborted");if(g.destroyed)throw new Error("Worker was destroyed");const At=new Wo(e,Ct,g.port),yt=new XR(At,t,ht,et,at,z);t._transport=yt,At.send("Ready",null)})}).catch(t._capability.reject),t}class zp{static#t=0;_capability=Promise.withResolvers();_transport=null;_worker=null;docId=`d${zp.#t++}`;destroyed=!1;onPassword=null;onProgress=null;get promise(){return this._capability.promise}async destroy(){this.destroyed=!0;try{this._worker?.port&&(this._worker._pendingDestroy=!0),await this._transport?.destroy()}catch(t){throw this._worker?.port&&delete this._worker._pendingDestroy,t}this._transport=null,this._worker?.destroy(),this._worker=null}async getData(){return this._transport.getData()}}let Pp=class{#t=Promise.withResolvers();#e=[];#i=[];#n=[];#r=[];constructor(t,e,s=!1,a=null){this.length=t,this.initialData=e,this.progressiveDone=s,this.contentDispositionFilename=a}addRangeListener(t){this.#r.push(t)}addProgressListener(t){this.#n.push(t)}addProgressiveReadListener(t){this.#i.push(t)}addProgressiveDoneListener(t){this.#e.push(t)}onDataRange(t,e){for(const s of this.#r)s(t,e)}onDataProgress(t,e){this.#t.promise.then(()=>{for(const s of this.#n)s(t,e)})}onDataProgressiveRead(t){this.#t.promise.then(()=>{for(const e of this.#i)e(t)})}onDataProgressiveDone(){this.#t.promise.then(()=>{for(const t of this.#e)t()})}transportReady(){this.#t.resolve()}requestDataRange(t,e){ie("Abstract method PDFDataRangeTransport.requestDataRange")}abort(){}};class qR{constructor(t,e){this._pdfInfo=t,this._transport=e}get annotationStorage(){return this._transport.annotationStorage}get canvasFactory(){return this._transport.canvasFactory}get filterFactory(){return this._transport.filterFactory}get numPages(){return this._pdfInfo.numPages}get fingerprints(){return this._pdfInfo.fingerprints}get isPureXfa(){return jt(this,"isPureXfa",!!this._transport._htmlForXfa)}get allXfaHtml(){return this._transport._htmlForXfa}getPage(t){return this._transport.getPage(t)}getPageIndex(t){return this._transport.getPageIndex(t)}getDestinations(){return this._transport.getDestinations()}getDestination(t){return this._transport.getDestination(t)}getPageLabels(){return this._transport.getPageLabels()}getPageLayout(){return this._transport.getPageLayout()}getPageMode(){return this._transport.getPageMode()}getViewerPreferences(){return this._transport.getViewerPreferences()}getOpenAction(){return this._transport.getOpenAction()}getAttachments(){return this._transport.getAttachments()}getAnnotationsByType(t,e){return this._transport.getAnnotationsByType(t,e)}getJSActions(){return this._transport.getDocJSActions()}getOutline(){return this._transport.getOutline()}getOptionalContentConfig({intent:t="display"}={}){const{renderingIntent:e}=this._transport.getRenderingIntent(t);return this._transport.getOptionalContentConfig(e)}getPermissions(){return this._transport.getPermissions()}getMetadata(){return this._transport.getMetadata()}getMarkInfo(){return this._transport.getMarkInfo()}getData(){return this._transport.getData()}saveDocument(){return this._transport.saveDocument()}getDownloadInfo(){return this._transport.downloadInfoCapability.promise}cleanup(t=!1){return this._transport.startCleanup(t||this.isPureXfa)}destroy(){return this.loadingTask.destroy()}cachedPageNumber(t){return this._transport.cachedPageNumber(t)}get loadingParams(){return this._transport.loadingParams}get loadingTask(){return this._transport.loadingTask}getFieldObjects(){return this._transport.getFieldObjects()}hasJSActions(){return this._transport.hasJSActions()}getCalculationOrderIds(){return this._transport.getCalculationOrderIds()}}class YR{#t=!1;constructor(t,e,s,a=!1){this._pageIndex=t,this._pageInfo=e,this._transport=s,this._stats=a?new ax:null,this._pdfBug=a,this.commonObjs=s.commonObjs,this.objs=new f1,this._intentStates=new Map,this.destroyed=!1,this.recordedBBoxes=null}get pageNumber(){return this._pageIndex+1}get rotate(){return this._pageInfo.rotate}get ref(){return this._pageInfo.ref}get userUnit(){return this._pageInfo.userUnit}get view(){return this._pageInfo.view}getViewport({scale:t,rotation:e=this.rotate,offsetX:s=0,offsetY:a=0,dontFlip:l=!1}={}){return new fl({viewBox:this.view,userUnit:this.userUnit,scale:t,rotation:e,offsetX:s,offsetY:a,dontFlip:l})}getAnnotations({intent:t="display"}={}){const{renderingIntent:e}=this._transport.getRenderingIntent(t);return this._transport.getAnnotations(this._pageIndex,e)}getJSActions(){return this._transport.getPageJSActions(this._pageIndex)}get filterFactory(){return this._transport.filterFactory}get isPureXfa(){return jt(this,"isPureXfa",!!this._transport._htmlForXfa)}async getXfa(){return this._transport._htmlForXfa?.children[this._pageIndex]||null}render({canvasContext:t,canvas:e=t.canvas,viewport:s,intent:a="display",annotationMode:l=oi.ENABLE,transform:c=null,background:d=null,optionalContentConfigPromise:h=null,annotationCanvasMap:f=null,pageColors:g=null,printAnnotationStorage:m=null,isEditing:x=!1,recordOperations:v=!1,operationsFilter:E=null}){this._stats?.time("Overall");const S=this._transport.getRenderingIntent(a,l,m,x),{renderingIntent:C,cacheKey:T}=S;this.#t=!1,h||=this._transport.getOptionalContentConfig(C);let _=this._intentStates.get(T);_||(_=Object.create(null),this._intentStates.set(T,_)),_.streamReaderCancelTimeout&&(clearTimeout(_.streamReaderCancelTimeout),_.streamReaderCancelTimeout=null);const k=!!(C&xn.PRINT);_.displayReadyCapability||(_.displayReadyCapability=Promise.withResolvers(),_.operatorList={fnArray:[],argsArray:[],lastChunk:!1,separateAnnots:null},this._stats?.time("Page Request"),this._pumpOperatorList(S));const R=!!(this._pdfBug&&globalThis.StepperManager?.enabled),D=!this.recordedBBoxes&&(v||R),L=F=>{if(_.renderTasks.delete(O),D){const W=O.gfx?.dependencyTracker.take();W&&(O.stepper&&O.stepper.setOperatorBBoxes(W,O.gfx.dependencyTracker.takeDebugMetadata()),v&&(this.recordedBBoxes=W))}k&&(this.#t=!0),this.#e(),F?(O.capability.reject(F),this._abortOperatorList({intentState:_,reason:F instanceof Error?F:new Error(F)})):O.capability.resolve(),this._stats&&(this._stats.timeEnd("Rendering"),this._stats.timeEnd("Overall"),globalThis.Stats?.enabled&&globalThis.Stats.add(this.pageNumber,this._stats))},O=new Cr({callback:L,params:{canvas:e,canvasContext:t,dependencyTracker:D?new dR(e,_.operatorList.length,R):null,viewport:s,transform:c,background:d},objs:this.objs,commonObjs:this.commonObjs,annotationCanvasMap:f,operatorList:_.operatorList,pageIndex:this._pageIndex,canvasFactory:this._transport.canvasFactory,filterFactory:this._transport.filterFactory,useRequestAnimationFrame:!k,pdfBug:this._pdfBug,pageColors:g,enableHWA:this._transport.enableHWA,operationsFilter:E});(_.renderTasks||=new Set).add(O);const B=O.task;return Promise.all([_.displayReadyCapability.promise,h]).then(([F,W])=>{if(this.destroyed){L();return}if(this._stats?.time("Rendering"),!(W.renderingIntent&C))throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");O.initializeGraphics({transparency:F,optionalContentConfig:W}),O.operatorListChanged()}).catch(L),B}getOperatorList({intent:t="display",annotationMode:e=oi.ENABLE,printAnnotationStorage:s=null,isEditing:a=!1}={}){function l(){d.operatorList.lastChunk&&(d.opListReadCapability.resolve(d.operatorList),d.renderTasks.delete(h))}const c=this._transport.getRenderingIntent(t,e,s,a,!0);let d=this._intentStates.get(c.cacheKey);d||(d=Object.create(null),this._intentStates.set(c.cacheKey,d));let h;return d.opListReadCapability||(h=Object.create(null),h.operatorListChanged=l,d.opListReadCapability=Promise.withResolvers(),(d.renderTasks||=new Set).add(h),d.operatorList={fnArray:[],argsArray:[],lastChunk:!1,separateAnnots:null},this._stats?.time("Page Request"),this._pumpOperatorList(c)),d.opListReadCapability.promise}streamTextContent({includeMarkedContent:t=!1,disableNormalization:e=!1}={}){return this._transport.messageHandler.sendWithStream("GetTextContent",{pageIndex:this._pageIndex,includeMarkedContent:t===!0,disableNormalization:e===!0},{highWaterMark:100,size(a){return a.items.length}})}getTextContent(t={}){if(this._transport._htmlForXfa)return this.getXfa().then(s=>rl.textContent(s));const e=this.streamTextContent(t);return new Promise(function(s,a){function l(){c.read().then(function({value:h,done:f}){if(f){s(d);return}d.lang??=h.lang,Object.assign(d.styles,h.styles),d.items.push(...h.items),l()},a)}const c=e.getReader(),d={items:[],styles:Object.create(null),lang:null};l()})}getStructTree(){return this._transport.getStructTree(this._pageIndex)}_destroy(){this.destroyed=!0;const t=[];for(const e of this._intentStates.values())if(this._abortOperatorList({intentState:e,reason:new Error("Page was destroyed."),force:!0}),!e.opListReadCapability)for(const s of e.renderTasks)t.push(s.completed),s.cancel();return this.objs.clear(),this.#t=!1,Promise.all(t)}cleanup(t=!1){this.#t=!0;const e=this.#e();return t&&e&&(this._stats&&=new ax),e}#e(){if(!this.#t||this.destroyed)return!1;for(const{renderTasks:t,operatorList:e}of this._intentStates.values())if(t.size>0||!e.lastChunk)return!1;return this._intentStates.clear(),this.objs.clear(),this.#t=!1,!0}_startRenderPage(t,e){const s=this._intentStates.get(e);s&&(this._stats?.timeEnd("Page Request"),s.displayReadyCapability?.resolve(t))}_renderPageChunk(t,e){for(let s=0,a=t.length;s<a;s++)e.operatorList.fnArray.push(t.fnArray[s]),e.operatorList.argsArray.push(t.argsArray[s]);e.operatorList.lastChunk=t.lastChunk,e.operatorList.separateAnnots=t.separateAnnots;for(const s of e.renderTasks)s.operatorListChanged();t.lastChunk&&this.#e()}_pumpOperatorList({renderingIntent:t,cacheKey:e,annotationStorageSerializable:s,modifiedIds:a}){const{map:l,transfer:c}=s,h=this._transport.messageHandler.sendWithStream("GetOperatorList",{pageIndex:this._pageIndex,intent:t,cacheKey:e,annotationStorage:l,modifiedIds:a},c).getReader(),f=this._intentStates.get(e);f.streamReader=h;const g=()=>{h.read().then(({value:m,done:x})=>{if(x){f.streamReader=null;return}this._transport.destroyed||(this._renderPageChunk(m,f),g())},m=>{if(f.streamReader=null,!this._transport.destroyed){if(f.operatorList){f.operatorList.lastChunk=!0;for(const x of f.renderTasks)x.operatorListChanged();this.#e()}if(f.displayReadyCapability)f.displayReadyCapability.reject(m);else if(f.opListReadCapability)f.opListReadCapability.reject(m);else throw m}})};g()}_abortOperatorList({intentState:t,reason:e,force:s=!1}){if(t.streamReader){if(t.streamReaderCancelTimeout&&(clearTimeout(t.streamReaderCancelTimeout),t.streamReaderCancelTimeout=null),!s){if(t.renderTasks.size>0)return;if(e instanceof Bu){let a=VR;e.extraDelay>0&&e.extraDelay<1e3&&(a+=e.extraDelay),t.streamReaderCancelTimeout=setTimeout(()=>{t.streamReaderCancelTimeout=null,this._abortOperatorList({intentState:t,reason:e,force:!0})},a);return}}if(t.streamReader.cancel(new Bi(e.message)).catch(()=>{}),t.streamReader=null,!this._transport.destroyed){for(const[a,l]of this._intentStates)if(l===t){this._intentStates.delete(a);break}this.cleanup()}}}get stats(){return this._stats}}var vs,Gn,Ni,na,Tu,ia,sa,We,hu,p1,g1,Qo,Lr,fu;const ce=class ce{constructor({name:t=null,port:e=null,verbosity:s=ND()}={}){ti(this,We);ti(this,vs,Promise.withResolvers());ti(this,Gn,null);ti(this,Ni,null);ti(this,na,null);if(this.name=t,this.destroyed=!1,this.verbosity=s,e){if(le(ce,sa).has(e))throw new Error("Cannot use more than one PDFWorker per port.");le(ce,sa).set(e,this),ei(this,We,p1).call(this,e)}else ei(this,We,g1).call(this)}get promise(){return le(this,vs).promise}get port(){return le(this,Ni)}get messageHandler(){return le(this,Gn)}destroy(){this.destroyed=!0,le(this,na)?.terminate(),an(this,na,null),le(ce,sa).delete(le(this,Ni)),an(this,Ni,null),le(this,Gn)?.destroy(),an(this,Gn,null)}static create(t){const e=le(this,sa).get(t?.port);if(e){if(e._pendingDestroy)throw new Error("PDFWorker.create - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");return e}return new ce(t)}static get workerSrc(){if(Ss.workerSrc)return Ss.workerSrc;throw new Error('No "GlobalWorkerOptions.workerSrc" specified.')}static get _setupFakeWorkerGlobal(){return jt(this,"_setupFakeWorkerGlobal",(async()=>le(this,Lr,fu)?le(this,Lr,fu):(await import(this.workerSrc)).WorkerMessageHandler)())}};vs=new WeakMap,Gn=new WeakMap,Ni=new WeakMap,na=new WeakMap,Tu=new WeakMap,ia=new WeakMap,sa=new WeakMap,We=new WeakSet,hu=function(){le(this,vs).resolve(),le(this,Gn).send("configure",{verbosity:this.verbosity})},p1=function(t){an(this,Ni,t),an(this,Gn,new Wo("main","worker",t)),le(this,Gn).on("ready",()=>{}),ei(this,We,hu).call(this)},g1=function(){if(le(ce,ia)||le(ce,Lr,fu)){ei(this,We,Qo).call(this);return}let{workerSrc:t}=ce;try{ce._isSameOrigin(window.location,t)||(t=ce._createCDNWrapper(new URL(t,window.location).href));const e=new Worker(t,{type:"module"}),s=new Wo("main","worker",e),a=()=>{l.abort(),s.destroy(),e.terminate(),this.destroyed?le(this,vs).reject(new Error("Worker was destroyed")):ei(this,We,Qo).call(this)},l=new AbortController;e.addEventListener("error",()=>{le(this,na)||a()},{signal:l.signal}),s.on("test",d=>{if(l.abort(),this.destroyed||!d){a();return}an(this,Gn,s),an(this,Ni,e),an(this,na,e),ei(this,We,hu).call(this)}),s.on("ready",d=>{if(l.abort(),this.destroyed){a();return}try{c()}catch{ei(this,We,Qo).call(this)}});const c=()=>{const d=new Uint8Array;s.send("test",d,[d.buffer])};c();return}catch{Nu("The worker has been disabled.")}ei(this,We,Qo).call(this)},Qo=function(){le(ce,ia)||(Rt("Setting up fake worker."),an(ce,ia,!0)),ce._setupFakeWorkerGlobal.then(t=>{if(this.destroyed){le(this,vs).reject(new Error("Worker was destroyed"));return}const e=new nR;an(this,Ni,e);const s=`fake${Ub(ce,Tu)._++}`,a=new Wo(s+"_worker",s,e);t.setup(a,e),an(this,Gn,new Wo(s,s+"_worker",e)),ei(this,We,hu).call(this)}).catch(t=>{le(this,vs).reject(new Error(`Setting up fake worker failed: "${t.message}".`))})},Lr=new WeakSet,fu=function(){try{return globalThis.pdfjsWorker?.WorkerMessageHandler||null}catch{return null}},ti(ce,Lr),ti(ce,Tu,0),ti(ce,ia,!1),ti(ce,sa,new WeakMap),Xe&&(an(ce,ia,!0),Ss.workerSrc||="./pdf.worker.mjs"),ce._isSameOrigin=(t,e)=>{const s=URL.parse(t);if(!s?.origin||s.origin==="null")return!1;const a=new URL(e,s);return s.origin===a.origin},ce._createCDNWrapper=t=>{const e=`await import("${t}");`;return URL.createObjectURL(new Blob([e],{type:"text/javascript"}))},ce.fromPort=t=>{if(GD("`PDFWorker.fromPort` - please use `PDFWorker.create` instead."),!t?.port)throw new Error("PDFWorker.fromPort - invalid method signature.");return ce.create(t)};let Ir=ce;class XR{#t=new Map;#e=new Map;#i=new Map;#n=new Map;#r=null;constructor(t,e,s,a,l,c){this.messageHandler=t,this.loadingTask=e,this.commonObjs=new f1,this.fontLoader=new KD({ownerDocument:a.ownerDocument,styleElement:a.styleElement}),this.loadingParams=a.loadingParams,this._params=a,this.canvasFactory=l.canvasFactory,this.filterFactory=l.filterFactory,this.cMapReaderFactory=l.cMapReaderFactory,this.standardFontDataFactory=l.standardFontDataFactory,this.wasmFactory=l.wasmFactory,this.destroyed=!1,this.destroyCapability=null,this._networkStream=s,this._fullReader=null,this._lastProgress=null,this.downloadInfoCapability=Promise.withResolvers(),this.enableHWA=c,this.setupMessageHandler()}#s(t,e=null){const s=this.#t.get(t);if(s)return s;const a=this.messageHandler.sendWithPromise(t,e);return this.#t.set(t,a),a}get annotationStorage(){return jt(this,"annotationStorage",new Lp)}getRenderingIntent(t,e=oi.ENABLE,s=null,a=!1,l=!1){let c=xn.DISPLAY,d=Kf;switch(t){case"any":c=xn.ANY;break;case"display":break;case"print":c=xn.PRINT;break;default:Rt(`getRenderingIntent - invalid intent: ${t}`)}const h=c&xn.PRINT&&s instanceof t1?s:this.annotationStorage;switch(e){case oi.DISABLE:c+=xn.ANNOTATIONS_DISABLE;break;case oi.ENABLE:break;case oi.ENABLE_FORMS:c+=xn.ANNOTATIONS_FORMS;break;case oi.ENABLE_STORAGE:c+=xn.ANNOTATIONS_STORAGE,d=h.serializable;break;default:Rt(`getRenderingIntent - invalid annotationMode: ${e}`)}a&&(c+=xn.IS_EDITING),l&&(c+=xn.OPLIST);const{ids:f,hash:g}=h.modifiedIds,m=[c,d.hash,g];return{renderingIntent:c,cacheKey:m.join("_"),annotationStorageSerializable:d,modifiedIds:f}}destroy(){if(this.destroyCapability)return this.destroyCapability.promise;this.destroyed=!0,this.destroyCapability=Promise.withResolvers(),this.#r?.reject(new Error("Worker was destroyed during onPassword callback"));const t=[];for(const s of this.#e.values())t.push(s._destroy());this.#e.clear(),this.#i.clear(),this.#n.clear(),this.hasOwnProperty("annotationStorage")&&this.annotationStorage.resetModified();const e=this.messageHandler.sendWithPromise("Terminate",null);return t.push(e),Promise.all(t).then(()=>{this.commonObjs.clear(),this.fontLoader.clear(),this.#t.clear(),this.filterFactory.destroy(),ol.cleanup(),this._networkStream?.cancelAllRequests(new Bi("Worker was terminated.")),this.messageHandler?.destroy(),this.messageHandler=null,this.destroyCapability.resolve()},this.destroyCapability.reject),this.destroyCapability.promise}setupMessageHandler(){const{messageHandler:t,loadingTask:e}=this;t.on("GetReader",(s,a)=>{Ht(this._networkStream,"GetReader - no `IPDFStream` instance available."),this._fullReader=this._networkStream.getFullReader(),this._fullReader.onProgress=l=>{this._lastProgress={loaded:l.loaded,total:l.total}},a.onPull=()=>{this._fullReader.read().then(function({value:l,done:c}){if(c){a.close();return}Ht(l instanceof ArrayBuffer,"GetReader - expected an ArrayBuffer."),a.enqueue(new Uint8Array(l),1,[l])}).catch(l=>{a.error(l)})},a.onCancel=l=>{this._fullReader.cancel(l),a.ready.catch(c=>{if(!this.destroyed)throw c})}}),t.on("ReaderHeadersReady",async s=>{await this._fullReader.headersReady;const{isStreamingSupported:a,isRangeSupported:l,contentLength:c}=this._fullReader;return(!a||!l)&&(this._lastProgress&&e.onProgress?.(this._lastProgress),this._fullReader.onProgress=d=>{e.onProgress?.({loaded:d.loaded,total:d.total})}),{isStreamingSupported:a,isRangeSupported:l,contentLength:c}}),t.on("GetRangeReader",(s,a)=>{Ht(this._networkStream,"GetRangeReader - no `IPDFStream` instance available.");const l=this._networkStream.getRangeReader(s.begin,s.end);if(!l){a.close();return}a.onPull=()=>{l.read().then(function({value:c,done:d}){if(d){a.close();return}Ht(c instanceof ArrayBuffer,"GetRangeReader - expected an ArrayBuffer."),a.enqueue(new Uint8Array(c),1,[c])}).catch(c=>{a.error(c)})},a.onCancel=c=>{l.cancel(c),a.ready.catch(d=>{if(!this.destroyed)throw d})}}),t.on("GetDoc",({pdfInfo:s})=>{this._numPages=s.numPages,this._htmlForXfa=s.htmlForXfa,delete s.htmlForXfa,e._capability.resolve(new qR(s,this))}),t.on("DocException",s=>{e._capability.reject(rn(s))}),t.on("PasswordRequest",s=>{this.#r=Promise.withResolvers();try{if(!e.onPassword)throw rn(s);const a=l=>{l instanceof Error?this.#r.reject(l):this.#r.resolve({password:l})};e.onPassword(a,s.code)}catch(a){this.#r.reject(a)}return this.#r.promise}),t.on("DataLoaded",s=>{e.onProgress?.({loaded:s.length,total:s.length}),this.downloadInfoCapability.resolve(s)}),t.on("StartRenderPage",s=>{if(this.destroyed)return;this.#e.get(s.pageIndex)._startRenderPage(s.transparency,s.cacheKey)}),t.on("commonobj",([s,a,l])=>{if(this.destroyed||this.commonObjs.has(s))return null;switch(a){case"Font":if("error"in l){const g=l.error;Rt(`Error during font loading: ${g}`),this.commonObjs.resolve(s,g);break}const c=new te(l),d=this._params.pdfBug&&globalThis.FontInspector?.enabled?(g,m)=>globalThis.FontInspector.fontAdded(g,m):null,h=new ZD(c,d,l.extra,l.charProcOperatorList);this.fontLoader.bind(h).catch(()=>t.sendWithPromise("FontFallback",{id:s})).finally(()=>{!h.fontExtraProperties&&h.data&&h.clearData(),this.commonObjs.resolve(s,h)});break;case"CopyLocalImage":const{imageRef:f}=l;Ht(f,"The imageRef must be defined.");for(const g of this.#e.values())for(const[,m]of g.objs)if(m?.ref===f)return m.dataLen?(this.commonObjs.resolve(s,structuredClone(m)),m.dataLen):null;break;case"FontPath":case"Image":case"Pattern":this.commonObjs.resolve(s,l);break;default:throw new Error(`Got unknown common object type ${a}`)}return null}),t.on("obj",([s,a,l,c])=>{if(this.destroyed)return;const d=this.#e.get(a);if(!d.objs.has(s)){if(d._intentStates.size===0){c?.bitmap?.close();return}switch(l){case"Image":case"Pattern":d.objs.resolve(s,c);break;default:throw new Error(`Got unknown object type ${l}`)}}}),t.on("DocProgress",s=>{this.destroyed||e.onProgress?.({loaded:s.loaded,total:s.total})}),t.on("FetchBinaryData",async s=>{if(this.destroyed)throw new Error("Worker was destroyed.");const a=this[s.type];if(!a)throw new Error(`${s.type} not initialized, see the \`useWorkerFetch\` parameter.`);return a.fetch(s)})}getData(){return this.messageHandler.sendWithPromise("GetData",null)}saveDocument(){this.annotationStorage.size<=0&&Rt("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");const{map:t,transfer:e}=this.annotationStorage.serializable;return this.messageHandler.sendWithPromise("SaveDocument",{isPureXfa:!!this._htmlForXfa,numPages:this._numPages,annotationStorage:t,filename:this._fullReader?.filename??null},e).finally(()=>{this.annotationStorage.resetModified()})}getPage(t){if(!Number.isInteger(t)||t<=0||t>this._numPages)return Promise.reject(new Error("Invalid page request."));const e=t-1,s=this.#i.get(e);if(s)return s;const a=this.messageHandler.sendWithPromise("GetPage",{pageIndex:e}).then(l=>{if(this.destroyed)throw new Error("Transport destroyed");l.refStr&&this.#n.set(l.refStr,t);const c=new YR(e,l,this,this._params.pdfBug);return this.#e.set(e,c),c});return this.#i.set(e,a),a}getPageIndex(t){return Zf(t)?this.messageHandler.sendWithPromise("GetPageIndex",{num:t.num,gen:t.gen}):Promise.reject(new Error("Invalid pageIndex request."))}getAnnotations(t,e){return this.messageHandler.sendWithPromise("GetAnnotations",{pageIndex:t,intent:e})}getFieldObjects(){return this.#s("GetFieldObjects")}hasJSActions(){return this.#s("HasJSActions")}getCalculationOrderIds(){return this.messageHandler.sendWithPromise("GetCalculationOrderIds",null)}getDestinations(){return this.messageHandler.sendWithPromise("GetDestinations",null)}getDestination(t){return typeof t!="string"?Promise.reject(new Error("Invalid destination request.")):this.messageHandler.sendWithPromise("GetDestination",{id:t})}getPageLabels(){return this.messageHandler.sendWithPromise("GetPageLabels",null)}getPageLayout(){return this.messageHandler.sendWithPromise("GetPageLayout",null)}getPageMode(){return this.messageHandler.sendWithPromise("GetPageMode",null)}getViewerPreferences(){return this.messageHandler.sendWithPromise("GetViewerPreferences",null)}getOpenAction(){return this.messageHandler.sendWithPromise("GetOpenAction",null)}getAttachments(){return this.messageHandler.sendWithPromise("GetAttachments",null)}getAnnotationsByType(t,e){return this.messageHandler.sendWithPromise("GetAnnotationsByType",{types:t,pageIndexesToSkip:e})}getDocJSActions(){return this.#s("GetDocJSActions")}getPageJSActions(t){return this.messageHandler.sendWithPromise("GetPageJSActions",{pageIndex:t})}getStructTree(t){return this.messageHandler.sendWithPromise("GetStructTree",{pageIndex:t})}getOutline(){return this.messageHandler.sendWithPromise("GetOutline",null)}getOptionalContentConfig(t){return this.#s("GetOptionalContentConfig").then(e=>new CR(e,t))}getPermissions(){return this.messageHandler.sendWithPromise("GetPermissions",null)}getMetadata(){const t="GetMetadata",e=this.#t.get(t);if(e)return e;const s=this.messageHandler.sendWithPromise(t,null).then(a=>({info:a[0],metadata:a[1]?new ER(a[1]):null,contentDispositionFilename:this._fullReader?.filename??null,contentLength:this._fullReader?.contentLength??null}));return this.#t.set(t,s),s}getMarkInfo(){return this.messageHandler.sendWithPromise("GetMarkInfo",null)}async startCleanup(t=!1){if(!this.destroyed){await this.messageHandler.sendWithPromise("Cleanup",null);for(const e of this.#e.values())if(!e.cleanup())throw new Error(`startCleanup: Page ${e.pageNumber} is currently rendering.`);this.commonObjs.clear(),t||this.fontLoader.clear(),this.#t.clear(),this.filterFactory.destroy(!0),ol.cleanup()}}cachedPageNumber(t){if(!Zf(t))return null;const e=t.gen===0?`${t.num}R`:`${t.num}R${t.gen}`;return this.#n.get(e)??null}}class WR{#t=null;onContinue=null;onError=null;constructor(t){this.#t=t}get promise(){return this.#t.capability.promise}cancel(t=0){this.#t.cancel(null,t)}get separateAnnots(){const{separateAnnots:t}=this.#t.operatorList;if(!t)return!1;const{annotationCanvasMap:e}=this.#t;return t.form||t.canvas&&e?.size>0}}class Cr{#t=null;static#e=new WeakSet;constructor({callback:t,params:e,objs:s,commonObjs:a,annotationCanvasMap:l,operatorList:c,pageIndex:d,canvasFactory:h,filterFactory:f,useRequestAnimationFrame:g=!1,pdfBug:m=!1,pageColors:x=null,enableHWA:v=!1,operationsFilter:E=null}){this.callback=t,this.params=e,this.objs=s,this.commonObjs=a,this.annotationCanvasMap=l,this.operatorListIdx=null,this.operatorList=c,this._pageIndex=d,this.canvasFactory=h,this.filterFactory=f,this._pdfBug=m,this.pageColors=x,this.running=!1,this.graphicsReadyCallback=null,this.graphicsReady=!1,this._useRequestAnimationFrame=g===!0&&typeof window<"u",this.cancelled=!1,this.capability=Promise.withResolvers(),this.task=new WR(this),this._cancelBound=this.cancel.bind(this),this._continueBound=this._continue.bind(this),this._scheduleNextBound=this._scheduleNext.bind(this),this._nextBound=this._next.bind(this),this._canvas=e.canvas,this._canvasContext=e.canvas?null:e.canvasContext,this._enableHWA=v,this._dependencyTracker=e.dependencyTracker,this._operationsFilter=E}get completed(){return this.capability.promise.catch(function(){})}initializeGraphics({transparency:t=!1,optionalContentConfig:e}){if(this.cancelled)return;if(this._canvas){if(Cr.#e.has(this._canvas))throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");Cr.#e.add(this._canvas)}this._pdfBug&&globalThis.StepperManager?.enabled&&(this.stepper=globalThis.StepperManager.create(this._pageIndex),this.stepper.init(this.operatorList),this.stepper.nextBreakPoint=this.stepper.getNextBreakPoint());const{viewport:s,transform:a,background:l,dependencyTracker:c}=this.params,d=this._canvasContext||this._canvas.getContext("2d",{alpha:!1,willReadFrequently:!this._enableHWA});this.gfx=new _r(d,this.commonObjs,this.objs,this.canvasFactory,this.filterFactory,{optionalContentConfig:e},this.annotationCanvasMap,this.pageColors,c),this.gfx.beginDrawing({transform:a,viewport:s,transparency:t,background:l}),this.operatorListIdx=0,this.graphicsReady=!0,this.graphicsReadyCallback?.()}cancel(t=null,e=0){this.running=!1,this.cancelled=!0,this.gfx?.endDrawing(),this.#t&&(window.cancelAnimationFrame(this.#t),this.#t=null),Cr.#e.delete(this._canvas),t||=new Bu(`Rendering cancelled, page ${this._pageIndex+1}`,e),this.callback(t),this.task.onError?.(t)}operatorListChanged(){if(!this.graphicsReady){this.graphicsReadyCallback||=this._continueBound;return}this.gfx.dependencyTracker?.growOperationsCount(this.operatorList.fnArray.length),this.stepper?.updateOperatorList(this.operatorList),!this.running&&this._continue()}_continue(){this.running=!0,!this.cancelled&&(this.task.onContinue?this.task.onContinue(this._scheduleNextBound):this._scheduleNext())}_scheduleNext(){this._useRequestAnimationFrame?this.#t=window.requestAnimationFrame(()=>{this.#t=null,this._nextBound().catch(this._cancelBound)}):Promise.resolve().then(this._nextBound).catch(this._cancelBound)}async _next(){this.cancelled||(this.operatorListIdx=this.gfx.executeOperatorList(this.operatorList,this.operatorListIdx,this._continueBound,this.stepper,this._operationsFilter),this.operatorListIdx===this.operatorList.argsArray.length&&(this.running=!1,this.operatorList.lastChunk&&(this.gfx.endDrawing(),Cr.#e.delete(this._canvas),this.callback())))}}const Ip="5.4.296",m1="f56dc8601";class vn{#t=null;#e=null;#i;#n=null;#r=!1;#s=!1;#a=null;#o;#c=null;#l=null;static#h=null;static get _keyboardManager(){return jt(this,"_keyboardManager",new gl([[["Escape","mac+Escape"],vn.prototype._hideDropdownFromKeyboard],[[" ","mac+ "],vn.prototype._colorSelectFromKeyboard],[["ArrowDown","ArrowRight","mac+ArrowDown","mac+ArrowRight"],vn.prototype._moveToNext],[["ArrowUp","ArrowLeft","mac+ArrowUp","mac+ArrowLeft"],vn.prototype._moveToPrevious],[["Home","mac+Home"],vn.prototype._moveToBeginning],[["End","mac+End"],vn.prototype._moveToEnd]]))}constructor({editor:t=null,uiManager:e=null}){t?(this.#s=!1,this.#a=t):this.#s=!0,this.#l=t?._uiManager||e,this.#o=this.#l._eventBus,this.#i=t?.color?.toUpperCase()||this.#l?.highlightColors.values().next().value||"#FFFF98",vn.#h||=Object.freeze({blue:"pdfjs-editor-colorpicker-blue",green:"pdfjs-editor-colorpicker-green",pink:"pdfjs-editor-colorpicker-pink",red:"pdfjs-editor-colorpicker-red",yellow:"pdfjs-editor-colorpicker-yellow"})}renderButton(){const t=this.#t=document.createElement("button");t.className="colorPicker",t.tabIndex="0",t.setAttribute("data-l10n-id","pdfjs-editor-colorpicker-button"),t.ariaHasPopup="true",this.#a&&(t.ariaControls=`${this.#a.id}_colorpicker_dropdown`);const e=this.#l._signal;t.addEventListener("click",this.#p.bind(this),{signal:e}),t.addEventListener("keydown",this.#m.bind(this),{signal:e});const s=this.#e=document.createElement("span");return s.className="swatch",s.ariaHidden="true",s.style.backgroundColor=this.#i,t.append(s),t}renderMainDropdown(){const t=this.#n=this.#d();return t.ariaOrientation="horizontal",t.ariaLabelledBy="highlightColorPickerLabel",t}#d(){const t=document.createElement("div"),e=this.#l._signal;t.addEventListener("contextmenu",wn,{signal:e}),t.className="dropdown",t.role="listbox",t.ariaMultiSelectable="false",t.ariaOrientation="vertical",t.setAttribute("data-l10n-id","pdfjs-editor-colorpicker-dropdown"),this.#a&&(t.id=`${this.#a.id}_colorpicker_dropdown`);for(const[s,a]of this.#l.highlightColors){const l=document.createElement("button");l.tabIndex="0",l.role="option",l.setAttribute("data-color",a),l.title=s,l.setAttribute("data-l10n-id",vn.#h[s]);const c=document.createElement("span");l.append(c),c.className="swatch",c.style.backgroundColor=a,l.ariaSelected=a===this.#i,l.addEventListener("click",this.#f.bind(this,a),{signal:e}),t.append(l)}return t.addEventListener("keydown",this.#m.bind(this),{signal:e}),t}#f(t,e){e.stopPropagation(),this.#o.dispatch("switchannotationeditorparams",{source:this,type:Ft.HIGHLIGHT_COLOR,value:t}),this.updateColor(t)}_colorSelectFromKeyboard(t){if(t.target===this.#t){this.#p(t);return}const e=t.target.getAttribute("data-color");e&&this.#f(e,t)}_moveToNext(t){if(!this.#g){this.#p(t);return}if(t.target===this.#t){this.#n.firstChild?.focus();return}t.target.nextSibling?.focus()}_moveToPrevious(t){if(t.target===this.#n?.firstChild||t.target===this.#t){this.#g&&this._hideDropdownFromKeyboard();return}this.#g||this.#p(t),t.target.previousSibling?.focus()}_moveToBeginning(t){if(!this.#g){this.#p(t);return}this.#n.firstChild?.focus()}_moveToEnd(t){if(!this.#g){this.#p(t);return}this.#n.lastChild?.focus()}#m(t){vn._keyboardManager.exec(this,t)}#p(t){if(this.#g){this.hideDropdown();return}if(this.#r=t.detail===0,this.#c||(this.#c=new AbortController,window.addEventListener("pointerdown",this.#u.bind(this),{signal:this.#l.combinedSignal(this.#c)})),this.#t.ariaExpanded="true",this.#n){this.#n.classList.remove("hidden");return}const e=this.#n=this.#d();this.#t.append(e)}#u(t){this.#n?.contains(t.target)||this.hideDropdown()}hideDropdown(){this.#n?.classList.add("hidden"),this.#t.ariaExpanded="false",this.#c?.abort(),this.#c=null}get#g(){return this.#n&&!this.#n.classList.contains("hidden")}_hideDropdownFromKeyboard(){if(!this.#s){if(!this.#g){this.#a?.unselect();return}this.hideDropdown(),this.#t.focus({preventScroll:!0,focusVisible:this.#r})}}updateColor(t){if(this.#e&&(this.#e.style.backgroundColor=t),!this.#n)return;const e=this.#l.highlightColors.values();for(const s of this.#n.children)s.ariaSelected=e.next().value===t.toUpperCase()}destroy(){this.#t?.remove(),this.#t=null,this.#e=null,this.#n?.remove(),this.#n=null}}class ll{#t=null;#e=null;#i=null;static#n=null;constructor(t){this.#e=t,this.#i=t._uiManager,ll.#n||=Object.freeze({freetext:"pdfjs-editor-color-picker-free-text-input",ink:"pdfjs-editor-color-picker-ink-input"})}renderButton(){if(this.#t)return this.#t;const{editorType:t,colorType:e,colorValue:s}=this.#e,a=this.#t=document.createElement("input");return a.type="color",a.value=s||"#000000",a.className="basicColorPicker",a.tabIndex=0,a.setAttribute("data-l10n-id",ll.#n[t]),a.addEventListener("input",()=>{this.#i.updateParams(e,a.value)},{signal:this.#i._signal}),a}update(t){this.#t&&(this.#t.value=t)}destroy(){this.#t?.remove(),this.#t=null}hideDropdown(){}}function _x(r){return Math.floor(Math.max(0,Math.min(1,r))*255).toString(16).padStart(2,"0")}function Vo(r){return Math.max(0,Math.min(255,255*r))}class kx{static CMYK_G([t,e,s,a]){return["G",1-Math.min(1,.3*t+.59*s+.11*e+a)]}static G_CMYK([t]){return["CMYK",0,0,0,1-t]}static G_RGB([t]){return["RGB",t,t,t]}static G_rgb([t]){return t=Vo(t),[t,t,t]}static G_HTML([t]){const e=_x(t);return`#${e}${e}${e}`}static RGB_G([t,e,s]){return["G",.3*t+.59*e+.11*s]}static RGB_rgb(t){return t.map(Vo)}static RGB_HTML(t){return`#${t.map(_x).join("")}`}static T_HTML(){return"#00000000"}static T_rgb(){return[null]}static CMYK_RGB([t,e,s,a]){return["RGB",1-Math.min(1,t+a),1-Math.min(1,s+a),1-Math.min(1,e+a)]}static CMYK_rgb([t,e,s,a]){return[Vo(1-Math.min(1,t+a)),Vo(1-Math.min(1,s+a)),Vo(1-Math.min(1,e+a))]}static CMYK_HTML(t){const e=this.CMYK_RGB(t).slice(1);return this.RGB_HTML(e)}static RGB_CMYK([t,e,s]){const a=1-t,l=1-e,c=1-s,d=Math.min(a,l,c);return["CMYK",a,l,c,d]}}class QR{create(t,e,s=!1){if(t<=0||e<=0)throw new Error("Invalid SVG dimensions");const a=this._createSVG("svg:svg");return a.setAttribute("version","1.1"),s||(a.setAttribute("width",`${t}px`),a.setAttribute("height",`${e}px`)),a.setAttribute("preserveAspectRatio","none"),a.setAttribute("viewBox",`0 0 ${t} ${e}`),a}createElement(t){if(typeof t!="string")throw new Error("Invalid SVG element type");return this._createSVG(t)}_createSVG(t){ie("Abstract method `_createSVG` called.")}}class cl extends QR{_createSVG(t){return document.createElementNS(Oi,t)}}const KR=9,ha=new WeakSet,ZR=new Date().getTimezoneOffset()*60*1e3;class Mx{static create(t){switch(t.data.annotationType){case xe.LINK:return new Fp(t);case xe.TEXT:return new tL(t);case xe.WIDGET:switch(t.data.fieldType){case"Tx":return new eL(t);case"Btn":return t.data.radioButton?new b1(t):t.data.checkBox?new iL(t):new sL(t);case"Ch":return new aL(t);case"Sig":return new nL(t)}return new ba(t);case xe.POPUP:return new ep(t);case xe.FREETEXT:return new y1(t);case xe.LINE:return new oL(t);case xe.SQUARE:return new lL(t);case xe.CIRCLE:return new cL(t);case xe.POLYLINE:return new x1(t);case xe.CARET:return new dL(t);case xe.INK:return new $p(t);case xe.POLYGON:return new uL(t);case xe.HIGHLIGHT:return new v1(t);case xe.UNDERLINE:return new hL(t);case xe.SQUIGGLY:return new fL(t);case xe.STRIKEOUT:return new pL(t);case xe.STAMP:return new A1(t);case xe.FILEATTACHMENT:return new gL(t);default:return new fe(t)}}}class fe{#t=null;#e=!1;#i=null;constructor(t,{isRenderable:e=!1,ignoreBorder:s=!1,createQuadrilaterals:a=!1}={}){this.isRenderable=e,this.data=t.data,this.layer=t.layer,this.linkService=t.linkService,this.downloadManager=t.downloadManager,this.imageResourcesPath=t.imageResourcesPath,this.renderForms=t.renderForms,this.svgFactory=t.svgFactory,this.annotationStorage=t.annotationStorage,this.enableComment=t.enableComment,this.enableScripting=t.enableScripting,this.hasJSActions=t.hasJSActions,this._fieldObjects=t.fieldObjects,this.parent=t.parent,e&&(this.container=this._createContainer(s)),a&&this._createQuadrilaterals()}static _hasPopupData({contentsObj:t,richText:e}){return!!(t?.str||e?.str)}get _isEditable(){return this.data.isEditable}get hasPopupData(){return fe._hasPopupData(this.data)||this.enableComment&&!!this.commentText}get commentData(){const{data:t}=this,e=this.annotationStorage?.getEditor(t.id);return e?e.getData():t}get hasCommentButton(){return this.enableComment&&this.hasPopupElement}get commentButtonPosition(){const t=this.annotationStorage?.getEditor(this.data.id);if(t)return t.commentButtonPositionInPage;const{quadPoints:e,inkLists:s,rect:a}=this.data;let l=-1/0,c=-1/0;if(e?.length>=8){for(let d=0;d<e.length;d+=8)e[d+1]>c?(c=e[d+1],l=e[d+2]):e[d+1]===c&&(l=Math.max(l,e[d+2]));return[l,c]}if(s?.length>=1){for(const d of s)for(let h=0,f=d.length;h<f;h+=2)d[h+1]>c?(c=d[h+1],l=d[h]):d[h+1]===c&&(l=Math.max(l,d[h]));if(l!==1/0)return[l,c]}return a?[a[2],a[3]]:null}_normalizePoint(t){const{page:{view:e},viewport:{rawDims:{pageWidth:s,pageHeight:a,pageX:l,pageY:c}}}=this.parent;return t[1]=e[3]-t[1]+e[1],t[0]=100*(t[0]-l)/s,t[1]=100*(t[1]-c)/a,t}get commentText(){const{data:t}=this;return this.annotationStorage.getRawValue(`${sl}${t.id}`)?.popup?.contents||t.contentsObj?.str||""}set commentText(t){const{data:e}=this,s={deleted:!t,contents:t||""};this.annotationStorage.updateEditor(e.id,{popup:s})||this.annotationStorage.setValue(`${sl}${e.id}`,{id:e.id,annotationType:e.annotationType,pageIndex:this.parent.page._pageIndex,popup:s,popupRef:e.popupRef,modificationDate:new Date}),t||this.removePopup()}removePopup(){(this.#i?.popup||this.popup)?.remove(),this.#i=this.popup=null}updateEdited(t){if(!this.container)return;t.rect&&(this.#t||={rect:this.data.rect.slice(0)});const{rect:e,popup:s}=t;e&&this.#n(e);let a=this.#i?.popup||this.popup;!a&&s?.text&&(this._createPopup(s),a=this.#i.popup),a&&(a.updateEdited(t),s?.deleted&&(a.remove(),this.#i=null,this.popup=null))}resetEdited(){this.#t&&(this.#n(this.#t.rect),this.#i?.popup.resetEdited(),this.#t=null)}#n(t){const{container:{style:e},data:{rect:s,rotation:a},parent:{viewport:{rawDims:{pageWidth:l,pageHeight:c,pageX:d,pageY:h}}}}=this;s?.splice(0,4,...t),e.left=`${100*(t[0]-d)/l}%`,e.top=`${100*(c-t[3]+h)/c}%`,a===0?(e.width=`${100*(t[2]-t[0])/l}%`,e.height=`${100*(t[3]-t[1])/c}%`):this.setRotation(a)}_createContainer(t){const{data:e,parent:{page:s,viewport:a}}=this,l=document.createElement("section");l.setAttribute("data-annotation-id",e.id),!(this instanceof ba)&&!(this instanceof Fp)&&(l.tabIndex=0);const{style:c}=l;if(c.zIndex=this.parent.zIndex,this.parent.zIndex+=2,e.alternativeText&&(l.title=e.alternativeText),e.noRotate&&l.classList.add("norotate"),!e.rect||this instanceof ep){const{rotation:S}=e;return!e.hasOwnCanvas&&S!==0&&this.setRotation(S,l),l}const{width:d,height:h}=this;if(!t&&e.borderStyle.width>0){c.borderWidth=`${e.borderStyle.width}px`;const S=e.borderStyle.horizontalCornerRadius,C=e.borderStyle.verticalCornerRadius;if(S>0||C>0){const _=`calc(${S}px * var(--total-scale-factor)) / calc(${C}px * var(--total-scale-factor))`;c.borderRadius=_}else if(this instanceof b1){const _=`calc(${d}px * var(--total-scale-factor)) / calc(${h}px * var(--total-scale-factor))`;c.borderRadius=_}switch(e.borderStyle.style){case xr.SOLID:c.borderStyle="solid";break;case xr.DASHED:c.borderStyle="dashed";break;case xr.BEVELED:Rt("Unimplemented border style: beveled");break;case xr.INSET:Rt("Unimplemented border style: inset");break;case xr.UNDERLINE:c.borderBottomStyle="solid";break}const T=e.borderColor||null;T?(this.#e=!0,c.borderColor=gt.makeHexColor(T[0]|0,T[1]|0,T[2]|0)):c.borderWidth=0}const f=gt.normalizeRect([e.rect[0],s.view[3]-e.rect[1]+s.view[1],e.rect[2],s.view[3]-e.rect[3]+s.view[1]]),{pageWidth:g,pageHeight:m,pageX:x,pageY:v}=a.rawDims;c.left=`${100*(f[0]-x)/g}%`,c.top=`${100*(f[1]-v)/m}%`;const{rotation:E}=e;return e.hasOwnCanvas||E===0?(c.width=`${100*d/g}%`,c.height=`${100*h/m}%`):this.setRotation(E,l),l}setRotation(t,e=this.container){if(!this.data.rect)return;const{pageWidth:s,pageHeight:a}=this.parent.viewport.rawDims;let{width:l,height:c}=this;t%180!==0&&([l,c]=[c,l]),e.style.width=`${100*l/s}%`,e.style.height=`${100*c/a}%`,e.setAttribute("data-main-rotation",(360-t)%360)}get _commonActions(){const t=(e,s,a)=>{const l=a.detail[e],c=l[0],d=l.slice(1);a.target.style[s]=kx[`${c}_HTML`](d),this.annotationStorage.setValue(this.data.id,{[s]:kx[`${c}_rgb`](d)})};return jt(this,"_commonActions",{display:e=>{const{display:s}=e.detail,a=s%2===1;this.container.style.visibility=a?"hidden":"visible",this.annotationStorage.setValue(this.data.id,{noView:a,noPrint:s===1||s===2})},print:e=>{this.annotationStorage.setValue(this.data.id,{noPrint:!e.detail.print})},hidden:e=>{const{hidden:s}=e.detail;this.container.style.visibility=s?"hidden":"visible",this.annotationStorage.setValue(this.data.id,{noPrint:s,noView:s})},focus:e=>{setTimeout(()=>e.target.focus({preventScroll:!1}),0)},userName:e=>{e.target.title=e.detail.userName},readonly:e=>{e.target.disabled=e.detail.readonly},required:e=>{this._setRequired(e.target,e.detail.required)},bgColor:e=>{t("bgColor","backgroundColor",e)},fillColor:e=>{t("fillColor","backgroundColor",e)},fgColor:e=>{t("fgColor","color",e)},textColor:e=>{t("textColor","color",e)},borderColor:e=>{t("borderColor","borderColor",e)},strokeColor:e=>{t("strokeColor","borderColor",e)},rotation:e=>{const s=e.detail.rotation;this.setRotation(s),this.annotationStorage.setValue(this.data.id,{rotation:s})}})}_dispatchEventFromSandbox(t,e){const s=this._commonActions;for(const a of Object.keys(e.detail))(t[a]||s[a])?.(e)}_setDefaultPropertiesFromJS(t){if(!this.enableScripting)return;const e=this.annotationStorage.getRawValue(this.data.id);if(!e)return;const s=this._commonActions;for(const[a,l]of Object.entries(e)){const c=s[a];if(c){const d={detail:{[a]:l},target:t};c(d),delete e[a]}}}_createQuadrilaterals(){if(!this.container)return;const{quadPoints:t}=this.data;if(!t)return;const[e,s,a,l]=this.data.rect.map(S=>Math.fround(S));if(t.length===8){const[S,C,T,_]=t.subarray(2,6);if(a===S&&l===C&&e===T&&s===_)return}const{style:c}=this.container;let d;if(this.#e){const{borderColor:S,borderWidth:C}=c;c.borderWidth=0,d=["url('data:image/svg+xml;utf8,",'<svg xmlns="http://www.w3.org/2000/svg"',' preserveAspectRatio="none" viewBox="0 0 1 1">',`<g fill="transparent" stroke="${S}" stroke-width="${C}">`],this.container.classList.add("hasBorder")}const h=a-e,f=l-s,{svgFactory:g}=this,m=g.createElement("svg");m.classList.add("quadrilateralsContainer"),m.setAttribute("width",0),m.setAttribute("height",0),m.role="none";const x=g.createElement("defs");m.append(x);const v=g.createElement("clipPath"),E=`clippath_${this.data.id}`;v.setAttribute("id",E),v.setAttribute("clipPathUnits","objectBoundingBox"),x.append(v);for(let S=2,C=t.length;S<C;S+=8){const T=t[S],_=t[S+1],k=t[S+2],R=t[S+3],D=g.createElement("rect"),L=(k-e)/h,O=(l-_)/f,B=(T-k)/h,F=(_-R)/f;D.setAttribute("x",L),D.setAttribute("y",O),D.setAttribute("width",B),D.setAttribute("height",F),v.append(D),d?.push(`<rect vector-effect="non-scaling-stroke" x="${L}" y="${O}" width="${B}" height="${F}"/>`)}this.#e&&(d.push("</g></svg>')"),c.backgroundImage=d.join("")),this.container.append(m),this.container.style.clipPath=`url(#${E})`}_createPopup(t=null){const{data:e}=this;let s,a;t?(s={str:t.text},a=t.date):(s=e.contentsObj,a=e.modificationDate);const l=this.#i=new ep({data:{color:e.color,titleObj:e.titleObj,modificationDate:a,contentsObj:s,richText:e.richText,parentRect:e.rect,borderStyle:0,id:`popup_${e.id}`,rotation:e.rotation,noRotate:!0},linkService:this.linkService,parent:this.parent,elements:[this]});this.parent._commentManager||this.parent.div.append(l.render())}get hasPopupElement(){return!!(this.#i||this.popup||this.data.popupRef)}get extraPopupElement(){return this.#i}render(){ie("Abstract method `AnnotationElement.render` called")}_getElementsByName(t,e=null){const s=[];if(this._fieldObjects){const a=this._fieldObjects[t];if(a)for(const{page:l,id:c,exportValues:d}of a){if(l===-1||c===e)continue;const h=typeof d=="string"?d:null,f=document.querySelector(`[data-element-id="${c}"]`);if(f&&!ha.has(f)){Rt(`_getElementsByName - element not allowed: ${c}`);continue}s.push({id:c,exportValue:h,domElement:f})}return s}for(const a of document.getElementsByName(t)){const{exportValue:l}=a,c=a.getAttribute("data-element-id");c!==e&&ha.has(a)&&s.push({id:c,exportValue:l,domElement:a})}return s}show(){this.container&&(this.container.hidden=!1),this.popup?.maybeShow()}hide(){this.container&&(this.container.hidden=!0),this.popup?.forceHide()}getElementsToTriggerPopup(){return this.container}addHighlightArea(){const t=this.getElementsToTriggerPopup();if(Array.isArray(t))for(const e of t)e.classList.add("highlightArea");else t.classList.add("highlightArea")}_editOnDoubleClick(){if(!this._isEditable)return;const{annotationEditorType:t,data:{id:e}}=this;this.container.addEventListener("dblclick",()=>{this.linkService.eventBus?.dispatch("switchannotationeditormode",{source:this,mode:t,editId:e,mustEnterInEditMode:!0})})}get width(){return this.data.rect[2]-this.data.rect[0]}get height(){return this.data.rect[3]-this.data.rect[1]}}class JR extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0}),this.editor=t.editor}render(){return this.container.className="editorAnnotation",this.container}createOrUpdatePopup(){const{editor:t}=this;t.hasComment&&(this._createPopup(t.comment),this.extraPopupElement.popup.renderCommentButton())}get hasCommentButton(){return this.enableComment&&this.editor.hasComment}get commentButtonPosition(){return this.editor.commentButtonPositionInPage}get commentText(){return this.editor.comment.text}set commentText(t){this.editor.comment=t,t||this.removePopup()}get commentData(){return this.editor.getData()}remove(){this.container.remove(),this.container=null,this.removePopup()}}class Fp extends fe{constructor(t,e=null){super(t,{isRenderable:!0,ignoreBorder:!!e?.ignoreBorder,createQuadrilaterals:!0}),this.isTooltipOnly=t.data.isTooltipOnly}render(){const{data:t,linkService:e}=this,s=document.createElement("a");s.setAttribute("data-element-id",t.id);let a=!1;return t.url?(e.addLinkAttributes(s,t.url,t.newWindow),a=!0):t.action?(this._bindNamedAction(s,t.action,t.overlaidText),a=!0):t.attachment?(this.#e(s,t.attachment,t.overlaidText,t.attachmentDest),a=!0):t.setOCGState?(this.#i(s,t.setOCGState,t.overlaidText),a=!0):t.dest?(this._bindLink(s,t.dest,t.overlaidText),a=!0):(t.actions&&(t.actions.Action||t.actions["Mouse Up"]||t.actions["Mouse Down"])&&this.enableScripting&&this.hasJSActions&&(this._bindJSAction(s,t),a=!0),t.resetForm?(this._bindResetFormAction(s,t.resetForm),a=!0):this.isTooltipOnly&&!a&&(this._bindLink(s,""),a=!0)),this.container.classList.add("linkAnnotation"),a&&this.container.append(s),this.container}#t(){this.container.setAttribute("data-internal-link","")}_bindLink(t,e,s=""){t.href=this.linkService.getDestinationHash(e),t.onclick=()=>(e&&this.linkService.goToDestination(e),!1),(e||e==="")&&this.#t(),s&&(t.title=s)}_bindNamedAction(t,e,s=""){t.href=this.linkService.getAnchorUrl(""),t.onclick=()=>(this.linkService.executeNamedAction(e),!1),s&&(t.title=s),this.#t()}#e(t,e,s="",a=null){t.href=this.linkService.getAnchorUrl(""),e.description?t.title=e.description:s&&(t.title=s),t.onclick=()=>(this.downloadManager?.openOrDownloadData(e.content,e.filename,a),!1),this.#t()}#i(t,e,s=""){t.href=this.linkService.getAnchorUrl(""),t.onclick=()=>(this.linkService.executeSetOCGState(e),!1),s&&(t.title=s),this.#t()}_bindJSAction(t,e){t.href=this.linkService.getAnchorUrl("");const s=new Map([["Action","onclick"],["Mouse Up","onmouseup"],["Mouse Down","onmousedown"]]);for(const a of Object.keys(e.actions)){const l=s.get(a);l&&(t[l]=()=>(this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:e.id,name:a}}),!1))}e.overlaidText&&(t.title=e.overlaidText),t.onclick||(t.onclick=()=>!1),this.#t()}_bindResetFormAction(t,e){const s=t.onclick;if(s||(t.href=this.linkService.getAnchorUrl("")),this.#t(),!this._fieldObjects){Rt('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'),s||(t.onclick=()=>!1);return}t.onclick=()=>{s?.();const{fields:a,refs:l,include:c}=e,d=[];if(a.length!==0||l.length!==0){const g=new Set(l);for(const m of a){const x=this._fieldObjects[m]||[];for(const{id:v}of x)g.add(v)}for(const m of Object.values(this._fieldObjects))for(const x of m)g.has(x.id)===c&&d.push(x)}else for(const g of Object.values(this._fieldObjects))d.push(...g);const h=this.annotationStorage,f=[];for(const g of d){const{id:m}=g;switch(f.push(m),g.type){case"text":{const v=g.defaultValue||"";h.setValue(m,{value:v});break}case"checkbox":case"radiobutton":{const v=g.defaultValue===g.exportValues;h.setValue(m,{value:v});break}case"combobox":case"listbox":{const v=g.defaultValue||"";h.setValue(m,{value:v});break}default:continue}const x=document.querySelector(`[data-element-id="${m}"]`);if(x){if(!ha.has(x)){Rt(`_bindResetFormAction - element not allowed: ${m}`);continue}}else continue;x.dispatchEvent(new Event("resetform"))}return this.enableScripting&&this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:"app",ids:f,name:"ResetForm"}}),!1}}}class tL extends fe{constructor(t){super(t,{isRenderable:!0})}render(){this.container.classList.add("textAnnotation");const t=document.createElement("img");return t.src=this.imageResourcesPath+"annotation-"+this.data.name.toLowerCase()+".svg",t.setAttribute("data-l10n-id","pdfjs-text-annotation-type"),t.setAttribute("data-l10n-args",JSON.stringify({type:this.data.name})),!this.data.popupRef&&this.hasPopupData&&this._createPopup(),this.container.append(t),this.container}}class ba extends fe{render(){return this.container}showElementAndHideCanvas(t){this.data.hasOwnCanvas&&(t.previousSibling?.nodeName==="CANVAS"&&(t.previousSibling.hidden=!0),t.hidden=!1)}_getKeyModifier(t){return je.platform.isMac?t.metaKey:t.ctrlKey}_setEventListener(t,e,s,a,l){s.includes("mouse")?t.addEventListener(s,c=>{this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:this.data.id,name:a,value:l(c),shift:c.shiftKey,modifier:this._getKeyModifier(c)}})}):t.addEventListener(s,c=>{if(s==="blur"){if(!e.focused||!c.relatedTarget)return;e.focused=!1}else if(s==="focus"){if(e.focused)return;e.focused=!0}l&&this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:this.data.id,name:a,value:l(c)}})})}_setEventListeners(t,e,s,a){for(const[l,c]of s)(c==="Action"||this.data.actions?.[c])&&((c==="Focus"||c==="Blur")&&(e||={focused:!1}),this._setEventListener(t,e,l,c,a),c==="Focus"&&!this.data.actions?.Blur?this._setEventListener(t,e,"blur","Blur",null):c==="Blur"&&!this.data.actions?.Focus&&this._setEventListener(t,e,"focus","Focus",null))}_setBackgroundColor(t){const e=this.data.backgroundColor||null;t.style.backgroundColor=e===null?"transparent":gt.makeHexColor(e[0],e[1],e[2])}_setTextStyle(t){const e=["left","center","right"],{fontColor:s}=this.data.defaultAppearanceData,a=this.data.defaultAppearanceData.fontSize||KR,l=t.style;let c;const d=2,h=f=>Math.round(10*f)/10;if(this.data.multiLine){const f=Math.abs(this.data.rect[3]-this.data.rect[1]-d),g=Math.round(f/(Tf*a))||1,m=f/g;c=Math.min(a,h(m/Tf))}else{const f=Math.abs(this.data.rect[3]-this.data.rect[1]-d);c=Math.min(a,h(f/Tf))}l.fontSize=`calc(${c}px * var(--total-scale-factor))`,l.color=gt.makeHexColor(s[0],s[1],s[2]),this.data.textAlignment!==null&&(l.textAlign=e[this.data.textAlignment])}_setRequired(t,e){e?t.setAttribute("required",!0):t.removeAttribute("required"),t.setAttribute("aria-required",e)}}class eL extends ba{constructor(t){const e=t.renderForms||t.data.hasOwnCanvas||!t.data.hasAppearance&&!!t.data.fieldValue;super(t,{isRenderable:e})}setPropertyOnSiblings(t,e,s,a){const l=this.annotationStorage;for(const c of this._getElementsByName(t.name,t.id))c.domElement&&(c.domElement[e]=s),l.setValue(c.id,{[a]:s})}render(){const t=this.annotationStorage,e=this.data.id;this.container.classList.add("textWidgetAnnotation");let s=null;if(this.renderForms){const a=t.getValue(e,{value:this.data.fieldValue});let l=a.value||"";const c=t.getValue(e,{charLimit:this.data.maxLen}).charLimit;c&&l.length>c&&(l=l.slice(0,c));let d=a.formattedValue||this.data.textContent?.join(`
`)||null;d&&this.data.comb&&(d=d.replaceAll(/\s+/g,""));const h={userValue:l,formattedValue:d,lastCommittedValue:null,commitKey:1,focused:!1};this.data.multiLine?(s=document.createElement("textarea"),s.textContent=d??l,this.data.doNotScroll&&(s.style.overflowY="hidden")):(s=document.createElement("input"),s.type=this.data.password?"password":"text",s.setAttribute("value",d??l),this.data.doNotScroll&&(s.style.overflowX="hidden")),this.data.hasOwnCanvas&&(s.hidden=!0),ha.add(s),s.setAttribute("data-element-id",e),s.disabled=this.data.readOnly,s.name=this.data.fieldName,s.tabIndex=0;const{datetimeFormat:f,datetimeType:g,timeStep:m}=this.data,x=!!g&&this.enableScripting;f&&(s.title=f),this._setRequired(s,this.data.required),c&&(s.maxLength=c),s.addEventListener("input",E=>{t.setValue(e,{value:E.target.value}),this.setPropertyOnSiblings(s,"value",E.target.value,"value"),h.formattedValue=null}),s.addEventListener("resetform",E=>{const S=this.data.defaultFieldValue??"";s.value=h.userValue=S,h.formattedValue=null});let v=E=>{const{formattedValue:S}=h;S!=null&&(E.target.value=S),E.target.scrollLeft=0};if(this.enableScripting&&this.hasJSActions){s.addEventListener("focus",S=>{if(h.focused)return;const{target:C}=S;if(x&&(C.type=g,m&&(C.step=m)),h.userValue){const T=h.userValue;if(x)if(g==="time"){const _=new Date(T),k=[_.getHours(),_.getMinutes(),_.getSeconds()];C.value=k.map(R=>R.toString().padStart(2,"0")).join(":")}else C.value=new Date(T-ZR).toISOString().split(g==="date"?"T":".",1)[0];else C.value=T}h.lastCommittedValue=C.value,h.commitKey=1,this.data.actions?.Focus||(h.focused=!0)}),s.addEventListener("updatefromsandbox",S=>{this.showElementAndHideCanvas(S.target);const C={value(T){h.userValue=T.detail.value??"",x||t.setValue(e,{value:h.userValue.toString()}),T.target.value=h.userValue},formattedValue(T){const{formattedValue:_}=T.detail;h.formattedValue=_,_!=null&&T.target!==document.activeElement&&(T.target.value=_);const k={formattedValue:_};x&&(k.value=_),t.setValue(e,k)},selRange(T){T.target.setSelectionRange(...T.detail.selRange)},charLimit:T=>{const{charLimit:_}=T.detail,{target:k}=T;if(_===0){k.removeAttribute("maxLength");return}k.setAttribute("maxLength",_);let R=h.userValue;!R||R.length<=_||(R=R.slice(0,_),k.value=h.userValue=R,t.setValue(e,{value:R}),this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:e,name:"Keystroke",value:R,willCommit:!0,commitKey:1,selStart:k.selectionStart,selEnd:k.selectionEnd}}))}};this._dispatchEventFromSandbox(C,S)}),s.addEventListener("keydown",S=>{h.commitKey=1;let C=-1;if(S.key==="Escape"?C=0:S.key==="Enter"&&!this.data.multiLine?C=2:S.key==="Tab"&&(h.commitKey=3),C===-1)return;const{value:T}=S.target;h.lastCommittedValue!==T&&(h.lastCommittedValue=T,h.userValue=T,this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:e,name:"Keystroke",value:T,willCommit:!0,commitKey:C,selStart:S.target.selectionStart,selEnd:S.target.selectionEnd}}))});const E=v;v=null,s.addEventListener("blur",S=>{if(!h.focused||!S.relatedTarget)return;this.data.actions?.Blur||(h.focused=!1);const{target:C}=S;let{value:T}=C;if(x){if(T&&g==="time"){const _=T.split(":").map(k=>parseInt(k,10));T=new Date(2e3,0,1,_[0],_[1],_[2]||0).valueOf(),C.step=""}else T.includes("T")||(T=`${T}T00:00`),T=new Date(T).valueOf();C.type="text"}h.userValue=T,h.lastCommittedValue!==T&&this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:e,name:"Keystroke",value:T,willCommit:!0,commitKey:h.commitKey,selStart:S.target.selectionStart,selEnd:S.target.selectionEnd}}),E(S)}),this.data.actions?.Keystroke&&s.addEventListener("beforeinput",S=>{h.lastCommittedValue=null;const{data:C,target:T}=S,{value:_,selectionStart:k,selectionEnd:R}=T;let D=k,L=R;switch(S.inputType){case"deleteWordBackward":{const O=_.substring(0,k).match(/\w*[^\w]*$/);O&&(D-=O[0].length);break}case"deleteWordForward":{const O=_.substring(k).match(/^[^\w]*\w*/);O&&(L+=O[0].length);break}case"deleteContentBackward":k===R&&(D-=1);break;case"deleteContentForward":k===R&&(L+=1);break}S.preventDefault(),this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:e,name:"Keystroke",value:_,change:C||"",willCommit:!1,selStart:D,selEnd:L}})}),this._setEventListeners(s,h,[["focus","Focus"],["blur","Blur"],["mousedown","Mouse Down"],["mouseenter","Mouse Enter"],["mouseleave","Mouse Exit"],["mouseup","Mouse Up"]],S=>S.target.value)}if(v&&s.addEventListener("blur",v),this.data.comb){const S=(this.data.rect[2]-this.data.rect[0])/c;s.classList.add("comb"),s.style.letterSpacing=`calc(${S}px * var(--total-scale-factor) - 1ch)`}}else s=document.createElement("div"),s.textContent=this.data.fieldValue,s.style.verticalAlign="middle",s.style.display="table-cell",this.data.hasOwnCanvas&&(s.hidden=!0);return this._setTextStyle(s),this._setBackgroundColor(s),this._setDefaultPropertiesFromJS(s),this.container.append(s),this.container}}class nL extends ba{constructor(t){super(t,{isRenderable:!!t.data.hasOwnCanvas})}}class iL extends ba{constructor(t){super(t,{isRenderable:t.renderForms})}render(){const t=this.annotationStorage,e=this.data,s=e.id;let a=t.getValue(s,{value:e.exportValue===e.fieldValue}).value;typeof a=="string"&&(a=a!=="Off",t.setValue(s,{value:a})),this.container.classList.add("buttonWidgetAnnotation","checkBox");const l=document.createElement("input");return ha.add(l),l.setAttribute("data-element-id",s),l.disabled=e.readOnly,this._setRequired(l,this.data.required),l.type="checkbox",l.name=e.fieldName,a&&l.setAttribute("checked",!0),l.setAttribute("exportValue",e.exportValue),l.tabIndex=0,l.addEventListener("change",c=>{const{name:d,checked:h}=c.target;for(const f of this._getElementsByName(d,s)){const g=h&&f.exportValue===e.exportValue;f.domElement&&(f.domElement.checked=g),t.setValue(f.id,{value:g})}t.setValue(s,{value:h})}),l.addEventListener("resetform",c=>{const d=e.defaultFieldValue||"Off";c.target.checked=d===e.exportValue}),this.enableScripting&&this.hasJSActions&&(l.addEventListener("updatefromsandbox",c=>{const d={value(h){h.target.checked=h.detail.value!=="Off",t.setValue(s,{value:h.target.checked})}};this._dispatchEventFromSandbox(d,c)}),this._setEventListeners(l,null,[["change","Validate"],["change","Action"],["focus","Focus"],["blur","Blur"],["mousedown","Mouse Down"],["mouseenter","Mouse Enter"],["mouseleave","Mouse Exit"],["mouseup","Mouse Up"]],c=>c.target.checked)),this._setBackgroundColor(l),this._setDefaultPropertiesFromJS(l),this.container.append(l),this.container}}class b1 extends ba{constructor(t){super(t,{isRenderable:t.renderForms})}render(){this.container.classList.add("buttonWidgetAnnotation","radioButton");const t=this.annotationStorage,e=this.data,s=e.id;let a=t.getValue(s,{value:e.fieldValue===e.buttonValue}).value;if(typeof a=="string"&&(a=a!==e.buttonValue,t.setValue(s,{value:a})),a)for(const c of this._getElementsByName(e.fieldName,s))t.setValue(c.id,{value:!1});const l=document.createElement("input");if(ha.add(l),l.setAttribute("data-element-id",s),l.disabled=e.readOnly,this._setRequired(l,this.data.required),l.type="radio",l.name=e.fieldName,a&&l.setAttribute("checked",!0),l.tabIndex=0,l.addEventListener("change",c=>{const{name:d,checked:h}=c.target;for(const f of this._getElementsByName(d,s))t.setValue(f.id,{value:!1});t.setValue(s,{value:h})}),l.addEventListener("resetform",c=>{const d=e.defaultFieldValue;c.target.checked=d!=null&&d===e.buttonValue}),this.enableScripting&&this.hasJSActions){const c=e.buttonValue;l.addEventListener("updatefromsandbox",d=>{const h={value:f=>{const g=c===f.detail.value;for(const m of this._getElementsByName(f.target.name)){const x=g&&m.id===s;m.domElement&&(m.domElement.checked=x),t.setValue(m.id,{value:x})}}};this._dispatchEventFromSandbox(h,d)}),this._setEventListeners(l,null,[["change","Validate"],["change","Action"],["focus","Focus"],["blur","Blur"],["mousedown","Mouse Down"],["mouseenter","Mouse Enter"],["mouseleave","Mouse Exit"],["mouseup","Mouse Up"]],d=>d.target.checked)}return this._setBackgroundColor(l),this._setDefaultPropertiesFromJS(l),this.container.append(l),this.container}}class sL extends Fp{constructor(t){super(t,{ignoreBorder:t.data.hasAppearance})}render(){const t=super.render();t.classList.add("buttonWidgetAnnotation","pushButton");const e=t.lastChild;return this.enableScripting&&this.hasJSActions&&e&&(this._setDefaultPropertiesFromJS(e),e.addEventListener("updatefromsandbox",s=>{this._dispatchEventFromSandbox({},s)})),t}}class aL extends ba{constructor(t){super(t,{isRenderable:t.renderForms})}render(){this.container.classList.add("choiceWidgetAnnotation");const t=this.annotationStorage,e=this.data.id,s=t.getValue(e,{value:this.data.fieldValue}),a=document.createElement("select");ha.add(a),a.setAttribute("data-element-id",e),a.disabled=this.data.readOnly,this._setRequired(a,this.data.required),a.name=this.data.fieldName,a.tabIndex=0;let l=this.data.combo&&this.data.options.length>0;this.data.combo||(a.size=this.data.options.length,this.data.multiSelect&&(a.multiple=!0)),a.addEventListener("resetform",g=>{const m=this.data.defaultFieldValue;for(const x of a.options)x.selected=x.value===m});for(const g of this.data.options){const m=document.createElement("option");m.textContent=g.displayValue,m.value=g.exportValue,s.value.includes(g.exportValue)&&(m.setAttribute("selected",!0),l=!1),a.append(m)}let c=null;if(l){const g=document.createElement("option");g.value=" ",g.setAttribute("hidden",!0),g.setAttribute("selected",!0),a.prepend(g),c=()=>{g.remove(),a.removeEventListener("input",c),c=null},a.addEventListener("input",c)}const d=g=>{const m=g?"value":"textContent",{options:x,multiple:v}=a;return v?Array.prototype.filter.call(x,E=>E.selected).map(E=>E[m]):x.selectedIndex===-1?null:x[x.selectedIndex][m]};let h=d(!1);const f=g=>{const m=g.target.options;return Array.prototype.map.call(m,x=>({displayValue:x.textContent,exportValue:x.value}))};return this.enableScripting&&this.hasJSActions?(a.addEventListener("updatefromsandbox",g=>{const m={value(x){c?.();const v=x.detail.value,E=new Set(Array.isArray(v)?v:[v]);for(const S of a.options)S.selected=E.has(S.value);t.setValue(e,{value:d(!0)}),h=d(!1)},multipleSelection(x){a.multiple=!0},remove(x){const v=a.options,E=x.detail.remove;v[E].selected=!1,a.remove(E),v.length>0&&Array.prototype.findIndex.call(v,C=>C.selected)===-1&&(v[0].selected=!0),t.setValue(e,{value:d(!0),items:f(x)}),h=d(!1)},clear(x){for(;a.length!==0;)a.remove(0);t.setValue(e,{value:null,items:[]}),h=d(!1)},insert(x){const{index:v,displayValue:E,exportValue:S}=x.detail.insert,C=a.children[v],T=document.createElement("option");T.textContent=E,T.value=S,C?C.before(T):a.append(T),t.setValue(e,{value:d(!0),items:f(x)}),h=d(!1)},items(x){const{items:v}=x.detail;for(;a.length!==0;)a.remove(0);for(const E of v){const{displayValue:S,exportValue:C}=E,T=document.createElement("option");T.textContent=S,T.value=C,a.append(T)}a.options.length>0&&(a.options[0].selected=!0),t.setValue(e,{value:d(!0),items:f(x)}),h=d(!1)},indices(x){const v=new Set(x.detail.indices);for(const E of x.target.options)E.selected=v.has(E.index);t.setValue(e,{value:d(!0)}),h=d(!1)},editable(x){x.target.disabled=!x.detail.editable}};this._dispatchEventFromSandbox(m,g)}),a.addEventListener("input",g=>{const m=d(!0),x=d(!1);t.setValue(e,{value:m}),g.preventDefault(),this.linkService.eventBus?.dispatch("dispatcheventinsandbox",{source:this,detail:{id:e,name:"Keystroke",value:h,change:x,changeEx:m,willCommit:!1,commitKey:1,keyDown:!1}})}),this._setEventListeners(a,null,[["focus","Focus"],["blur","Blur"],["mousedown","Mouse Down"],["mouseenter","Mouse Enter"],["mouseleave","Mouse Exit"],["mouseup","Mouse Up"],["input","Action"],["input","Validate"]],g=>g.target.value)):a.addEventListener("input",function(g){t.setValue(e,{value:d(!0)})}),this.data.combo&&this._setTextStyle(a),this._setBackgroundColor(a),this._setDefaultPropertiesFromJS(a),this.container.append(a),this.container}}class ep extends fe{constructor(t){const{data:e,elements:s,parent:a}=t,l=!!a._commentManager;if(super(t,{isRenderable:!l&&fe._hasPopupData(e)}),this.elements=s,l&&fe._hasPopupData(e)){const c=this.popup=this.#t();for(const d of s)d.popup=c}else this.popup=null}#t(){return new rL({container:this.container,color:this.data.color,titleObj:this.data.titleObj,modificationDate:this.data.modificationDate||this.data.creationDate,contentsObj:this.data.contentsObj,richText:this.data.richText,rect:this.data.rect,parentRect:this.data.parentRect||null,parent:this.parent,elements:this.elements,open:this.data.open,commentManager:this.parent._commentManager})}render(){const{container:t}=this;t.classList.add("popupAnnotation"),t.role="comment";const e=this.popup=this.#t(),s=[];for(const a of this.elements)a.popup=e,a.container.ariaHasPopup="dialog",s.push(a.data.id),a.addHighlightArea();return this.container.setAttribute("aria-controls",s.map(a=>`${_p}${a}`).join(",")),this.container}}class rL{#t=null;#e=this.#G.bind(this);#i=this.#I.bind(this);#n=this.#O.bind(this);#r=this.#A.bind(this);#s=null;#a=null;#o=null;#c=null;#l=null;#h=null;#d=null;#f=!1;#m=null;#p=null;#u=null;#g=null;#b=null;#x=null;#y=null;#T=null;#S=null;#v=null;#_=!1;#w=null;#E=null;constructor({container:t,color:e,elements:s,titleObj:a,modificationDate:l,contentsObj:c,richText:d,parent:h,rect:f,parentRect:g,open:m,commentManager:x=null}){this.#a=t,this.#S=a,this.#o=c,this.#T=d,this.#h=h,this.#s=e,this.#y=f,this.#d=g,this.#l=s,this.#t=x,this.#w=s[0],this.#c=wu.toDateObject(l),this.trigger=s.flatMap(v=>v.getElementsToTriggerPopup()),x?this.renderCommentButton():(this.#D(),this.#a.hidden=!0,m&&this.#A())}#D(){if(this.#p)return;this.#p=new AbortController;const{signal:t}=this.#p;for(const e of this.trigger)e.addEventListener("click",this.#r,{signal:t}),e.addEventListener("pointerenter",this.#n,{signal:t}),e.addEventListener("pointerleave",this.#i,{signal:t}),e.classList.add("popupTriggerArea");for(const e of this.#l)e.container?.addEventListener("keydown",this.#e,{signal:t})}#k(){const t=this.#l.find(e=>e.hasCommentButton);t&&(this.#b=t._normalizePoint(t.commentButtonPosition))}renderCommentButton(){if(this.#g||(this.#b||this.#k(),!this.#b))return;const{signal:t}=this.#p=new AbortController,e=!!this.#w.extraPopupElement,s=()=>{this.#t.toggleCommentPopup(this,!0,void 0,!e)},a=()=>{this.#t.toggleCommentPopup(this,!1,!0,!e)},l=()=>{this.#t.toggleCommentPopup(this,!1,!1)};if(e){this.#g=this.#w.container;for(const c of this.trigger)c.ariaHasPopup="dialog",c.ariaControls="commentPopup",c.addEventListener("keydown",this.#e,{signal:t}),c.addEventListener("click",s,{signal:t}),c.addEventListener("pointerenter",a,{signal:t}),c.addEventListener("pointerleave",l,{signal:t}),c.classList.add("popupTriggerArea")}else{const c=this.#g=document.createElement("button");c.className="annotationCommentButton";const d=this.#w.container;c.style.zIndex=d.style.zIndex+1,c.tabIndex=0,c.ariaHasPopup="dialog",c.ariaControls="commentPopup",c.setAttribute("data-l10n-id","pdfjs-show-comment-button"),this.#z(),this.#M(),c.addEventListener("keydown",this.#e,{signal:t}),c.addEventListener("click",s,{signal:t}),c.addEventListener("pointerenter",a,{signal:t}),c.addEventListener("pointerleave",l,{signal:t}),d.after(c)}}#M(){if(this.#w.extraPopupElement&&!this.#w.editor)return;this.renderCommentButton();const[t,e]=this.#b,{style:s}=this.#g;s.left=`calc(${t}%)`,s.top=`calc(${e}% - var(--comment-button-dim))`}#z(){this.#w.extraPopupElement||(this.renderCommentButton(),this.#g.style.backgroundColor=this.commentButtonColor||"")}get commentButtonColor(){const{color:t,opacity:e}=this.#w.commentData;return t?this.#h._commentManager.makeCommentColor(t,e):null}focusCommentButton(){setTimeout(()=>{this.#g?.focus()},0)}getData(){const{richText:t,color:e,opacity:s,creationDate:a,modificationDate:l}=this.#w.commentData;return{contentsObj:{str:this.comment},richText:t,color:e,opacity:s,creationDate:a,modificationDate:l}}get elementBeforePopup(){return this.#g}get comment(){return this.#E||=this.#w.commentText,this.#E}set comment(t){t!==this.comment&&(this.#w.commentText=this.#E=t)}get parentBoundingClientRect(){return this.#w.layer.getBoundingClientRect()}setCommentButtonStates({selected:t,hasPopup:e}){this.#g&&(this.#g.classList.toggle("selected",t),this.#g.ariaExpanded=e)}setSelectedCommentButton(t){this.#g.classList.toggle("selected",t)}get commentPopupPosition(){if(this.#x)return this.#x;const{x:t,y:e,height:s}=this.#g.getBoundingClientRect(),{x:a,y:l,width:c,height:d}=this.#w.layer.getBoundingClientRect();return[(t-a)/c,(e+s-l)/d]}set commentPopupPosition(t){this.#x=t}hasDefaultPopupPosition(){return this.#x===null}get commentButtonPosition(){return this.#b}get commentButtonWidth(){return this.#g.getBoundingClientRect().width/this.parentBoundingClientRect.width}editComment(t){const[e,s]=this.#x||this.commentButtonPosition.map(f=>f/100),a=this.parentBoundingClientRect,{x:l,y:c,width:d,height:h}=a;this.#t.showDialog(null,this,l+e*d,c+s*h,{...t,parentDimensions:a})}render(){if(this.#m)return;const t=this.#m=document.createElement("div");if(t.className="popup",this.#s){const s=t.style.outlineColor=gt.makeHexColor(...this.#s);t.style.backgroundColor=`color-mix(in srgb, ${s} 30%, white)`}const e=document.createElement("span");if(e.className="header",this.#S?.str){const s=document.createElement("span");s.className="title",e.append(s),{dir:s.dir,str:s.textContent}=this.#S}if(t.append(e),this.#c){const s=document.createElement("time");s.className="popupDate",s.setAttribute("data-l10n-id","pdfjs-annotation-date-time-string"),s.setAttribute("data-l10n-args",JSON.stringify({dateObj:this.#c.valueOf()})),s.dateTime=this.#c.toISOString(),e.append(s)}Mp({html:this.#L||this.#o.str,dir:this.#o?.dir,className:"popupContent"},t),this.#a.append(t)}get#L(){const t=this.#T,e=this.#o;return t?.str&&(!e?.str||e.str===t.str)&&this.#T.html||null}get#j(){return this.#L?.attributes?.style?.fontSize||0}get#P(){return this.#L?.attributes?.style?.color||null}#N(t){const e=[],s={str:t,html:{name:"div",attributes:{dir:"auto"},children:[{name:"p",children:e}]}},a={style:{color:this.#P,fontSize:this.#j?`calc(${this.#j}px * var(--total-scale-factor))`:""}};for(const l of t.split(`
`))e.push({name:"span",value:l,attributes:a});return s}#G(t){t.altKey||t.shiftKey||t.ctrlKey||t.metaKey||(t.key==="Enter"||t.key==="Escape"&&this.#f)&&this.#A()}updateEdited({rect:t,popup:e,deleted:s}){if(this.#t){s?(this.remove(),this.#E=null):e&&(e.deleted?this.remove():(this.#z(),this.#E=e.text)),t&&(this.#b=null,this.#k(),this.#M());return}if(s||e?.deleted){this.remove();return}this.#D(),this.#v||={contentsObj:this.#o,richText:this.#T},t&&(this.#u=null),e&&e.text&&(this.#T=this.#N(e.text),this.#c=wu.toDateObject(e.date),this.#o=null),this.#m?.remove(),this.#m=null}resetEdited(){this.#v&&({contentsObj:this.#o,richText:this.#T}=this.#v,this.#v=null,this.#m?.remove(),this.#m=null,this.#u=null)}remove(){if(this.#p?.abort(),this.#p=null,this.#m?.remove(),this.#m=null,this.#_=!1,this.#f=!1,this.#g?.remove(),this.#g=null,this.trigger)for(const t of this.trigger)t.classList.remove("popupTriggerArea")}#C(){if(this.#u!==null)return;const{page:{view:t},viewport:{rawDims:{pageWidth:e,pageHeight:s,pageX:a,pageY:l}}}=this.#h;let c=!!this.#d,d=c?this.#d:this.#y;for(const E of this.#l)if(!d||gt.intersect(E.data.rect,d)!==null){d=E.data.rect,c=!0;break}const h=gt.normalizeRect([d[0],t[3]-d[1]+t[1],d[2],t[3]-d[3]+t[1]]),g=c?d[2]-d[0]+5:0,m=h[0]+g,x=h[1];this.#u=[100*(m-a)/e,100*(x-l)/s];const{style:v}=this.#a;v.left=`${this.#u[0]}%`,v.top=`${this.#u[1]}%`}#A(){if(this.#t){this.#t.toggleCommentPopup(this,!1);return}this.#f=!this.#f,this.#f?(this.#O(),this.#a.addEventListener("click",this.#r),this.#a.addEventListener("keydown",this.#e)):(this.#I(),this.#a.removeEventListener("click",this.#r),this.#a.removeEventListener("keydown",this.#e))}#O(){this.#m||this.render(),this.isVisible?this.#f&&this.#a.classList.add("focused"):(this.#C(),this.#a.hidden=!1,this.#a.style.zIndex=parseInt(this.#a.style.zIndex)+1e3)}#I(){this.#a.classList.remove("focused"),!(this.#f||!this.isVisible)&&(this.#a.hidden=!0,this.#a.style.zIndex=parseInt(this.#a.style.zIndex)-1e3)}forceHide(){this.#_=this.isVisible,this.#_&&(this.#a.hidden=!0)}maybeShow(){this.#t||(this.#D(),this.#_&&(this.#m||this.#O(),this.#_=!1,this.#a.hidden=!1))}get isVisible(){return this.#t?!1:this.#a.hidden===!1}}class y1 extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0}),this.textContent=t.data.textContent,this.textPosition=t.data.textPosition,this.annotationEditorType=Dt.FREETEXT}render(){if(this.container.classList.add("freeTextAnnotation"),this.textContent){const t=document.createElement("div");t.classList.add("annotationTextContent"),t.setAttribute("role","comment");for(const e of this.textContent){const s=document.createElement("span");s.textContent=e,t.append(s)}this.container.append(t)}return!this.data.popupRef&&this.hasPopupData&&this._createPopup(),this._editOnDoubleClick(),this.container}}class oL extends fe{#t=null;constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0})}render(){this.container.classList.add("lineAnnotation");const{data:t,width:e,height:s}=this,a=this.svgFactory.create(e,s,!0),l=this.#t=this.svgFactory.createElement("svg:line");return l.setAttribute("x1",t.rect[2]-t.lineCoordinates[0]),l.setAttribute("y1",t.rect[3]-t.lineCoordinates[1]),l.setAttribute("x2",t.rect[2]-t.lineCoordinates[2]),l.setAttribute("y2",t.rect[3]-t.lineCoordinates[3]),l.setAttribute("stroke-width",t.borderStyle.width||1),l.setAttribute("stroke","transparent"),l.setAttribute("fill","transparent"),a.append(l),this.container.append(a),!t.popupRef&&this.hasPopupData&&this._createPopup(),this.container}getElementsToTriggerPopup(){return this.#t}addHighlightArea(){this.container.classList.add("highlightArea")}}class lL extends fe{#t=null;constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0})}render(){this.container.classList.add("squareAnnotation");const{data:t,width:e,height:s}=this,a=this.svgFactory.create(e,s,!0),l=t.borderStyle.width,c=this.#t=this.svgFactory.createElement("svg:rect");return c.setAttribute("x",l/2),c.setAttribute("y",l/2),c.setAttribute("width",e-l),c.setAttribute("height",s-l),c.setAttribute("stroke-width",l||1),c.setAttribute("stroke","transparent"),c.setAttribute("fill","transparent"),a.append(c),this.container.append(a),!t.popupRef&&this.hasPopupData&&this._createPopup(),this.container}getElementsToTriggerPopup(){return this.#t}addHighlightArea(){this.container.classList.add("highlightArea")}}class cL extends fe{#t=null;constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0})}render(){this.container.classList.add("circleAnnotation");const{data:t,width:e,height:s}=this,a=this.svgFactory.create(e,s,!0),l=t.borderStyle.width,c=this.#t=this.svgFactory.createElement("svg:ellipse");return c.setAttribute("cx",e/2),c.setAttribute("cy",s/2),c.setAttribute("rx",e/2-l/2),c.setAttribute("ry",s/2-l/2),c.setAttribute("stroke-width",l||1),c.setAttribute("stroke","transparent"),c.setAttribute("fill","transparent"),a.append(c),this.container.append(a),!t.popupRef&&this.hasPopupData&&this._createPopup(),this.container}getElementsToTriggerPopup(){return this.#t}addHighlightArea(){this.container.classList.add("highlightArea")}}class x1 extends fe{#t=null;constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0}),this.containerClassName="polylineAnnotation",this.svgElementName="svg:polyline"}render(){this.container.classList.add(this.containerClassName);const{data:{rect:t,vertices:e,borderStyle:s,popupRef:a},width:l,height:c}=this;if(!e)return this.container;const d=this.svgFactory.create(l,c,!0);let h=[];for(let g=0,m=e.length;g<m;g+=2){const x=e[g]-t[0],v=t[3]-e[g+1];h.push(`${x},${v}`)}h=h.join(" ");const f=this.#t=this.svgFactory.createElement(this.svgElementName);return f.setAttribute("points",h),f.setAttribute("stroke-width",s.width||1),f.setAttribute("stroke","transparent"),f.setAttribute("fill","transparent"),d.append(f),this.container.append(d),!a&&this.hasPopupData&&this._createPopup(),this.container}getElementsToTriggerPopup(){return this.#t}addHighlightArea(){this.container.classList.add("highlightArea")}}class uL extends x1{constructor(t){super(t),this.containerClassName="polygonAnnotation",this.svgElementName="svg:polygon"}}class dL extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0})}render(){return this.container.classList.add("caretAnnotation"),!this.data.popupRef&&this.hasPopupData&&this._createPopup(),this.container}}class $p extends fe{#t=null;#e=[];constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0}),this.containerClassName="inkAnnotation",this.svgElementName="svg:polyline",this.annotationEditorType=this.data.it==="InkHighlight"?Dt.HIGHLIGHT:Dt.INK}#i(t,e){switch(t){case 90:return{transform:`rotate(90) translate(${-e[0]},${e[1]}) scale(1,-1)`,width:e[3]-e[1],height:e[2]-e[0]};case 180:return{transform:`rotate(180) translate(${-e[2]},${e[1]}) scale(1,-1)`,width:e[2]-e[0],height:e[3]-e[1]};case 270:return{transform:`rotate(270) translate(${-e[2]},${e[3]}) scale(1,-1)`,width:e[3]-e[1],height:e[2]-e[0]};default:return{transform:`translate(${-e[0]},${e[3]}) scale(1,-1)`,width:e[2]-e[0],height:e[3]-e[1]}}}render(){this.container.classList.add(this.containerClassName);const{data:{rect:t,rotation:e,inkLists:s,borderStyle:a,popupRef:l}}=this,{transform:c,width:d,height:h}=this.#i(e,t),f=this.svgFactory.create(d,h,!0),g=this.#t=this.svgFactory.createElement("svg:g");f.append(g),g.setAttribute("stroke-width",a.width||1),g.setAttribute("stroke-linecap","round"),g.setAttribute("stroke-linejoin","round"),g.setAttribute("stroke-miterlimit",10),g.setAttribute("stroke","transparent"),g.setAttribute("fill","transparent"),g.setAttribute("transform",c);for(let m=0,x=s.length;m<x;m++){const v=this.svgFactory.createElement(this.svgElementName);this.#e.push(v),v.setAttribute("points",s[m].join(",")),g.append(v)}return!l&&this.hasPopupData&&this._createPopup(),this.container.append(f),this._editOnDoubleClick(),this.container}updateEdited(t){super.updateEdited(t);const{thickness:e,points:s,rect:a}=t,l=this.#t;if(e>=0&&l.setAttribute("stroke-width",e||1),s)for(let c=0,d=this.#e.length;c<d;c++)this.#e[c].setAttribute("points",s[c].join(","));if(a){const{transform:c,width:d,height:h}=this.#i(this.data.rotation,a);l.parentElement.setAttribute("viewBox",`0 0 ${d} ${h}`),l.setAttribute("transform",c)}}getElementsToTriggerPopup(){return this.#e}addHighlightArea(){this.container.classList.add("highlightArea")}}class v1 extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0,createQuadrilaterals:!0}),this.annotationEditorType=Dt.HIGHLIGHT}render(){const{data:{overlaidText:t,popupRef:e}}=this;if(!e&&this.hasPopupData&&this._createPopup(),this.container.classList.add("highlightAnnotation"),this._editOnDoubleClick(),t){const s=document.createElement("mark");s.classList.add("overlaidText"),s.textContent=t,this.container.append(s)}return this.container}}class hL extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0,createQuadrilaterals:!0})}render(){const{data:{overlaidText:t,popupRef:e}}=this;if(!e&&this.hasPopupData&&this._createPopup(),this.container.classList.add("underlineAnnotation"),t){const s=document.createElement("u");s.classList.add("overlaidText"),s.textContent=t,this.container.append(s)}return this.container}}class fL extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0,createQuadrilaterals:!0})}render(){const{data:{overlaidText:t,popupRef:e}}=this;if(!e&&this.hasPopupData&&this._createPopup(),this.container.classList.add("squigglyAnnotation"),t){const s=document.createElement("u");s.classList.add("overlaidText"),s.textContent=t,this.container.append(s)}return this.container}}class pL extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0,createQuadrilaterals:!0})}render(){const{data:{overlaidText:t,popupRef:e}}=this;if(!e&&this.hasPopupData&&this._createPopup(),this.container.classList.add("strikeoutAnnotation"),t){const s=document.createElement("s");s.classList.add("overlaidText"),s.textContent=t,this.container.append(s)}return this.container}}class A1 extends fe{constructor(t){super(t,{isRenderable:!0,ignoreBorder:!0}),this.annotationEditorType=Dt.STAMP}render(){return this.container.classList.add("stampAnnotation"),this.container.setAttribute("role","img"),!this.data.popupRef&&this.hasPopupData&&this._createPopup(),this._editOnDoubleClick(),this.container}}class gL extends fe{#t=null;constructor(t){super(t,{isRenderable:!0});const{file:e}=this.data;this.filename=e.filename,this.content=e.content,this.linkService.eventBus?.dispatch("fileattachmentannotation",{source:this,...e})}render(){this.container.classList.add("fileAttachmentAnnotation");const{container:t,data:e}=this;let s;e.hasAppearance||e.fillAlpha===0?s=document.createElement("div"):(s=document.createElement("img"),s.src=`${this.imageResourcesPath}annotation-${/paperclip/i.test(e.name)?"paperclip":"pushpin"}.svg`,e.fillAlpha&&e.fillAlpha<1&&(s.style=`filter: opacity(${Math.round(e.fillAlpha*100)}%);`)),s.addEventListener("dblclick",this.#e.bind(this)),this.#t=s;const{isMac:a}=je.platform;return t.addEventListener("keydown",l=>{l.key==="Enter"&&(a?l.metaKey:l.ctrlKey)&&this.#e()}),!e.popupRef&&this.hasPopupData?this._createPopup():s.classList.add("popupTriggerArea"),t.append(s),t}getElementsToTriggerPopup(){return this.#t}addHighlightArea(){this.container.classList.add("highlightArea")}#e(){this.downloadManager?.openOrDownloadData(this.content,this.filename)}}let Hp=class w1{#t=null;#e=null;#i=null;#n=new Map;#r=null;#s=null;constructor({div:t,accessibilityManager:e,annotationCanvasMap:s,annotationEditorUIManager:a,page:l,viewport:c,structTreeLayer:d,commentManager:h,linkService:f,annotationStorage:g}){this.div=t,this.#t=e,this.#e=s,this.#r=d||null,this.#s=f||null,this.#i=g||new Lp,this.page=l,this.viewport=c,this.zIndex=0,this._annotationEditorUIManager=a,this._commentManager=h||null}hasEditableAnnotations(){return this.#n.size>0}async#a(t,e,s){const a=t.firstChild||t,l=a.id=`${_p}${e}`,c=await this.#r?.getAriaAttributes(l);if(c)for(const[d,h]of c)a.setAttribute(d,h);s?s.at(-1).container.after(t):(this.div.append(t),this.#t?.moveElementInDOM(this.div,t,a,!1))}async render(t){const{annotations:e}=t,s=this.div;_s(s,this.viewport);const a=new Map,l={data:null,layer:s,linkService:this.#s,downloadManager:t.downloadManager,imageResourcesPath:t.imageResourcesPath||"",renderForms:t.renderForms!==!1,svgFactory:new cl,annotationStorage:this.#i,enableComment:t.enableComment===!0,enableScripting:t.enableScripting===!0,hasJSActions:t.hasJSActions,fieldObjects:t.fieldObjects,parent:this,elements:null};for(const c of e){if(c.noHTML)continue;const d=c.annotationType===xe.POPUP;if(d){const g=a.get(c.id);if(!g)continue;l.elements=g}else if(c.rect[2]===c.rect[0]||c.rect[3]===c.rect[1])continue;l.data=c;const h=Mx.create(l);if(!h.isRenderable)continue;if(!d&&c.popupRef){const g=a.get(c.popupRef);g?g.push(h):a.set(c.popupRef,[h])}const f=h.render();c.hidden&&(f.style.visibility="hidden"),await this.#a(f,c.id,l.elements),h.extraPopupElement?.popup?.renderCommentButton(),h._isEditable&&(this.#n.set(h.data.id,h),this._annotationEditorUIManager?.renderAnnotationElement(h))}this.#o()}async addLinkAnnotations(t){const e={data:null,layer:this.div,linkService:this.#s,svgFactory:new cl,parent:this};for(const s of t){s.borderStyle||=w1._defaultBorderStyle,e.data=s;const a=Mx.create(e);if(!a.isRenderable)continue;const l=a.render();await this.#a(l,s.id,null)}}update({viewport:t}){const e=this.div;this.viewport=t,_s(e,{rotation:t.rotation}),this.#o(),e.hidden=!1}#o(){if(!this.#e)return;const t=this.div;for(const[e,s]of this.#e){const a=t.querySelector(`[data-annotation-id="${e}"]`);if(!a)continue;s.className="annotationContent";const{firstChild:l}=a;l?l.nodeName==="CANVAS"?l.replaceWith(s):l.classList.contains("annotationContent")?l.after(s):l.before(s):a.append(s);const c=this.#n.get(e);c&&(c._hasNoCanvas?(this._annotationEditorUIManager?.setMissingCanvas(e,a.id,s),c._hasNoCanvas=!1):c.canvas=s)}this.#e.clear()}getEditableAnnotations(){return Array.from(this.#n.values())}getEditableAnnotation(t){return this.#n.get(t)}addFakeAnnotation(t){const{div:e}=this,{id:s,rotation:a}=t,l=new JR({data:{id:s,rect:t.getPDFRect(),rotation:a},editor:t,layer:e,parent:this,enableComment:!!this._commentManager,linkService:this.#s,annotationStorage:this.#i}),c=l.render();return e.append(c),this.#t?.moveElementInDOM(e,c,c,!1),l.createOrUpdatePopup(),l}static get _defaultBorderStyle(){return jt(this,"_defaultBorderStyle",Object.freeze({width:1,rawWidth:1,style:xr.SOLID,dashArray:[3],horizontalCornerRadius:0,verticalCornerRadius:0}))}};const au=/\r\n?|\n/g;class Re extends St{#t="";#e=`${this.id}-editor`;#i=null;#n;_colorPicker=null;static _freeTextDefaultContent="";static _internalPadding=0;static _defaultColor=null;static _defaultFontSize=10;static get _keyboardManager(){const t=Re.prototype,e=l=>l.isEmpty(),s=zi.TRANSLATE_SMALL,a=zi.TRANSLATE_BIG;return jt(this,"_keyboardManager",new gl([[["ctrl+s","mac+meta+s","ctrl+p","mac+meta+p"],t.commitOrRemove,{bubbles:!0}],[["ctrl+Enter","mac+meta+Enter","Escape","mac+Escape"],t.commitOrRemove],[["ArrowLeft","mac+ArrowLeft"],t._translateEmpty,{args:[-s,0],checker:e}],[["ctrl+ArrowLeft","mac+shift+ArrowLeft"],t._translateEmpty,{args:[-a,0],checker:e}],[["ArrowRight","mac+ArrowRight"],t._translateEmpty,{args:[s,0],checker:e}],[["ctrl+ArrowRight","mac+shift+ArrowRight"],t._translateEmpty,{args:[a,0],checker:e}],[["ArrowUp","mac+ArrowUp"],t._translateEmpty,{args:[0,-s],checker:e}],[["ctrl+ArrowUp","mac+shift+ArrowUp"],t._translateEmpty,{args:[0,-a],checker:e}],[["ArrowDown","mac+ArrowDown"],t._translateEmpty,{args:[0,s],checker:e}],[["ctrl+ArrowDown","mac+shift+ArrowDown"],t._translateEmpty,{args:[0,a],checker:e}]]))}static _type="freetext";static _editorType=Dt.FREETEXT;constructor(t){super({...t,name:"freeTextEditor"}),this.color=t.color||Re._defaultColor||St._defaultLineColor,this.#n=t.fontSize||Re._defaultFontSize,this.annotationElementId||this._uiManager.a11yAlert("pdfjs-editor-freetext-added-alert")}static initialize(t,e){St.initialize(t,e);const s=getComputedStyle(document.documentElement);this._internalPadding=parseFloat(s.getPropertyValue("--freetext-padding"))}static updateDefaultParams(t,e){switch(t){case Ft.FREETEXT_SIZE:Re._defaultFontSize=e;break;case Ft.FREETEXT_COLOR:Re._defaultColor=e;break}}updateParams(t,e){switch(t){case Ft.FREETEXT_SIZE:this.#r(e);break;case Ft.FREETEXT_COLOR:this.#s(e);break}}static get defaultPropertiesToUpdate(){return[[Ft.FREETEXT_SIZE,Re._defaultFontSize],[Ft.FREETEXT_COLOR,Re._defaultColor||St._defaultLineColor]]}get propertiesToUpdate(){return[[Ft.FREETEXT_SIZE,this.#n],[Ft.FREETEXT_COLOR,this.color]]}get toolbarButtons(){return this._colorPicker||=new ll(this),[["colorPicker",this._colorPicker]]}get colorType(){return Ft.FREETEXT_COLOR}#r(t){const e=a=>{this.editorDiv.style.fontSize=`calc(${a}px * var(--total-scale-factor))`,this.translate(0,-(a-this.#n)*this.parentScale),this.#n=a,this.#o()},s=this.#n;this.addCommands({cmd:e.bind(this,t),undo:e.bind(this,s),post:this._uiManager.updateUI.bind(this._uiManager,this),mustExec:!0,type:Ft.FREETEXT_SIZE,overwriteIfSameType:!0,keepUndo:!0})}onUpdatedColor(){this.editorDiv.style.color=this.color,this._colorPicker?.update(this.color),super.onUpdatedColor()}#s(t){const e=a=>{this.color=a,this.onUpdatedColor()},s=this.color;this.addCommands({cmd:e.bind(this,t),undo:e.bind(this,s),post:this._uiManager.updateUI.bind(this._uiManager,this),mustExec:!0,type:Ft.FREETEXT_COLOR,overwriteIfSameType:!0,keepUndo:!0})}_translateEmpty(t,e){this._uiManager.translateSelectedEditors(t,e,!0)}getInitialTranslation(){const t=this.parentScale;return[-Re._internalPadding*t,-(Re._internalPadding+this.#n)*t]}rebuild(){this.parent&&(super.rebuild(),this.div!==null&&(this.isAttachedToDOM||this.parent.add(this)))}enableEditMode(){if(!super.enableEditMode())return!1;this.overlayDiv.classList.remove("enabled"),this.editorDiv.contentEditable=!0,this._isDraggable=!1,this.div.removeAttribute("aria-activedescendant"),this.#i=new AbortController;const t=this._uiManager.combinedSignal(this.#i);return this.editorDiv.addEventListener("keydown",this.editorDivKeydown.bind(this),{signal:t}),this.editorDiv.addEventListener("focus",this.editorDivFocus.bind(this),{signal:t}),this.editorDiv.addEventListener("blur",this.editorDivBlur.bind(this),{signal:t}),this.editorDiv.addEventListener("input",this.editorDivInput.bind(this),{signal:t}),this.editorDiv.addEventListener("paste",this.editorDivPaste.bind(this),{signal:t}),!0}disableEditMode(){return super.disableEditMode()?(this.overlayDiv.classList.add("enabled"),this.editorDiv.contentEditable=!1,this.div.setAttribute("aria-activedescendant",this.#e),this._isDraggable=!0,this.#i?.abort(),this.#i=null,this.div.focus({preventScroll:!0}),this.isEditing=!1,this.parent.div.classList.add("freetextEditing"),!0):!1}focusin(t){this._focusEventsAllowed&&(super.focusin(t),t.target!==this.editorDiv&&this.editorDiv.focus())}onceAdded(t){this.width||(this.enableEditMode(),t&&this.editorDiv.focus(),this._initialOptions?.isCentered&&this.center(),this._initialOptions=null)}isEmpty(){return!this.editorDiv||this.editorDiv.innerText.trim()===""}remove(){this.isEditing=!1,this.parent&&(this.parent.setEditingState(!0),this.parent.div.classList.add("freetextEditing")),super.remove()}#a(){const t=[];this.editorDiv.normalize();let e=null;for(const s of this.editorDiv.childNodes)e?.nodeType===Node.TEXT_NODE&&s.nodeName==="BR"||(t.push(Re.#c(s)),e=s);return t.join(`
`)}#o(){const[t,e]=this.parentDimensions;let s;if(this.isAttachedToDOM)s=this.div.getBoundingClientRect();else{const{currentLayer:a,div:l}=this,c=l.style.display,d=l.classList.contains("hidden");l.classList.remove("hidden"),l.style.display="hidden",a.div.append(this.div),s=l.getBoundingClientRect(),l.remove(),l.style.display=c,l.classList.toggle("hidden",d)}this.rotation%180===this.parentRotation%180?(this.width=s.width/t,this.height=s.height/e):(this.width=s.height/t,this.height=s.width/e),this.fixAndSetPosition()}commit(){if(!this.isInEditMode())return;super.commit(),this.disableEditMode();const t=this.#t,e=this.#t=this.#a().trimEnd();if(t===e)return;const s=a=>{if(this.#t=a,!a){this.remove();return}this.#l(),this._uiManager.rebuild(this),this.#o()};this.addCommands({cmd:()=>{s(e)},undo:()=>{s(t)},mustExec:!1}),this.#o()}shouldGetKeyboardEvents(){return this.isInEditMode()}enterInEditMode(){this.enableEditMode(),this.editorDiv.focus()}keydown(t){t.target===this.div&&t.key==="Enter"&&(this.enterInEditMode(),t.preventDefault())}editorDivKeydown(t){Re._keyboardManager.exec(this,t)}editorDivFocus(t){this.isEditing=!0}editorDivBlur(t){this.isEditing=!1}editorDivInput(t){this.parent.div.classList.toggle("freetextEditing",this.isEmpty())}disableEditing(){this.editorDiv.setAttribute("role","comment"),this.editorDiv.removeAttribute("aria-multiline")}enableEditing(){this.editorDiv.setAttribute("role","textbox"),this.editorDiv.setAttribute("aria-multiline",!0)}get canChangeContent(){return!0}render(){if(this.div)return this.div;let t,e;(this._isCopy||this.annotationElementId)&&(t=this.x,e=this.y),super.render(),this.editorDiv=document.createElement("div"),this.editorDiv.className="internal",this.editorDiv.setAttribute("id",this.#e),this.editorDiv.setAttribute("data-l10n-id","pdfjs-free-text2"),this.editorDiv.setAttribute("data-l10n-attrs","default-content"),this.enableEditing(),this.editorDiv.contentEditable=!0;const{style:s}=this.editorDiv;if(s.fontSize=`calc(${this.#n}px * var(--total-scale-factor))`,s.color=this.color,this.div.append(this.editorDiv),this.overlayDiv=document.createElement("div"),this.overlayDiv.classList.add("overlay","enabled"),this.div.append(this.overlayDiv),this._isCopy||this.annotationElementId){const[a,l]=this.parentDimensions;if(this.annotationElementId){const{position:c}=this._initialData;let[d,h]=this.getInitialTranslation();[d,h]=this.pageTranslationToScreen(d,h);const[f,g]=this.pageDimensions,[m,x]=this.pageTranslation;let v,E;switch(this.rotation){case 0:v=t+(c[0]-m)/f,E=e+this.height-(c[1]-x)/g;break;case 90:v=t+(c[0]-m)/f,E=e-(c[1]-x)/g,[d,h]=[h,-d];break;case 180:v=t-this.width+(c[0]-m)/f,E=e-(c[1]-x)/g,[d,h]=[-d,-h];break;case 270:v=t+(c[0]-m-this.height*g)/f,E=e+(c[1]-x-this.width*f)/g,[d,h]=[-h,d];break}this.setAt(v*a,E*l,d,h)}else this._moveAfterPaste(t,e);this.#l(),this._isDraggable=!0,this.editorDiv.contentEditable=!1}else this._isDraggable=!1,this.editorDiv.contentEditable=!0;return this.div}static#c(t){return(t.nodeType===Node.TEXT_NODE?t.nodeValue:t.innerText).replaceAll(au,"")}editorDivPaste(t){const e=t.clipboardData||window.clipboardData,{types:s}=e;if(s.length===1&&s[0]==="text/plain")return;t.preventDefault();const a=Re.#d(e.getData("text")||"").replaceAll(au,`
`);if(!a)return;const l=window.getSelection();if(!l.rangeCount)return;this.editorDiv.normalize(),l.deleteFromDocument();const c=l.getRangeAt(0);if(!a.includes(`
`)){c.insertNode(document.createTextNode(a)),this.editorDiv.normalize(),l.collapseToStart();return}const{startContainer:d,startOffset:h}=c,f=[],g=[];if(d.nodeType===Node.TEXT_NODE){const v=d.parentElement;if(g.push(d.nodeValue.slice(h).replaceAll(au,"")),v!==this.editorDiv){let E=f;for(const S of this.editorDiv.childNodes){if(S===v){E=g;continue}E.push(Re.#c(S))}}f.push(d.nodeValue.slice(0,h).replaceAll(au,""))}else if(d===this.editorDiv){let v=f,E=0;for(const S of this.editorDiv.childNodes)E++===h&&(v=g),v.push(Re.#c(S))}this.#t=`${f.join(`
`)}${a}${g.join(`
`)}`,this.#l();const m=new Range;let x=Math.sumPrecise(f.map(v=>v.length));for(const{firstChild:v}of this.editorDiv.childNodes)if(v.nodeType===Node.TEXT_NODE){const E=v.nodeValue.length;if(x<=E){m.setStart(v,x),m.setEnd(v,x);break}x-=E}l.removeAllRanges(),l.addRange(m)}#l(){if(this.editorDiv.replaceChildren(),!!this.#t)for(const t of this.#t.split(`
`)){const e=document.createElement("div");e.append(t?document.createTextNode(t):document.createElement("br")),this.editorDiv.append(e)}}#h(){return this.#t.replaceAll(" "," ")}static#d(t){return t.replaceAll(" "," ")}get contentDiv(){return this.editorDiv}getPDFRect(){const t=Re._internalPadding*this.parentScale;return this.getRect(t,t)}static async deserialize(t,e,s){let a=null;if(t instanceof y1){const{data:{defaultAppearanceData:{fontSize:c,fontColor:d},rect:h,rotation:f,id:g,popupRef:m,richText:x,contentsObj:v,creationDate:E,modificationDate:S},textContent:C,textPosition:T,parent:{page:{pageNumber:_}}}=t;if(!C||C.length===0)return null;a=t={annotationType:Dt.FREETEXT,color:Array.from(d),fontSize:c,value:C.join(`
`),position:T,pageIndex:_-1,rect:h.slice(0),rotation:f,annotationElementId:g,id:g,deleted:!1,popupRef:m,comment:v?.str||null,richText:x,creationDate:E,modificationDate:S}}const l=await super.deserialize(t,e,s);return l.#n=t.fontSize,l.color=gt.makeHexColor(...t.color),l.#t=Re.#d(t.value),l._initialData=a,t.comment&&l.setCommentData(t),l}serialize(t=!1){if(this.isEmpty())return null;if(this.deleted)return this.serializeDeleted();const e=St._colorManager.convert(this.isAttachedToDOM?getComputedStyle(this.editorDiv).color:this.color),s=Object.assign(super.serialize(t),{color:e,fontSize:this.#n,value:this.#h()});return this.addComment(s),t?(s.isCopy=!0,s):this.annotationElementId&&!this.#f(s)?null:(s.id=this.annotationElementId,s)}#f(t){const{value:e,fontSize:s,color:a,pageIndex:l}=this._initialData;return this.hasEditedComment||this._hasBeenMoved||t.value!==e||t.fontSize!==s||t.color.some((c,d)=>c!==a[d])||t.pageIndex!==l}renderAnnotationElement(t){const e=super.renderAnnotationElement(t);if(!e)return null;const{style:s}=e;s.fontSize=`calc(${this.#n}px * var(--total-scale-factor))`,s.color=this.color,e.replaceChildren();for(const a of this.#t.split(`
`)){const l=document.createElement("div");l.append(a?document.createTextNode(a):document.createElement("br")),e.append(l)}return t.updateEdited({rect:this.getPDFRect(),popup:this._uiManager.hasCommentManager()||this.hasEditedComment?this.comment:{text:this.#t}}),e}resetAnnotationElement(t){super.resetAnnotationElement(t),t.resetEdited()}}class pt{static PRECISION=1e-4;toSVGPath(){ie("Abstract method `toSVGPath` must be implemented.")}get box(){ie("Abstract getter `box` must be implemented.")}serialize(t,e){ie("Abstract method `serialize` must be implemented.")}static _rescale(t,e,s,a,l,c){c||=new Float32Array(t.length);for(let d=0,h=t.length;d<h;d+=2)c[d]=e+t[d]*a,c[d+1]=s+t[d+1]*l;return c}static _rescaleAndSwap(t,e,s,a,l,c){c||=new Float32Array(t.length);for(let d=0,h=t.length;d<h;d+=2)c[d]=e+t[d+1]*a,c[d+1]=s+t[d]*l;return c}static _translate(t,e,s,a){a||=new Float32Array(t.length);for(let l=0,c=t.length;l<c;l+=2)a[l]=e+t[l],a[l+1]=s+t[l+1];return a}static svgRound(t){return Math.round(t*1e4)}static _normalizePoint(t,e,s,a,l){switch(l){case 90:return[1-e/s,t/a];case 180:return[1-t/s,1-e/a];case 270:return[e/s,1-t/a];default:return[t/s,e/a]}}static _normalizePagePoint(t,e,s){switch(s){case 90:return[1-e,t];case 180:return[1-t,1-e];case 270:return[e,1-t];default:return[t,e]}}static createBezierPoints(t,e,s,a,l,c){return[(t+5*s)/6,(e+5*a)/6,(5*s+l)/6,(5*a+c)/6,(s+l)/2,(a+c)/2]}}class ea{#t;#e=[];#i;#n;#r=[];#s=new Float32Array(18);#a;#o;#c;#l;#h;#d;#f=[];static#m=8;static#p=2;static#u=ea.#m+ea.#p;constructor({x:t,y:e},s,a,l,c,d=0){this.#t=s,this.#d=l*a,this.#n=c,this.#s.set([NaN,NaN,NaN,NaN,t,e],6),this.#i=d,this.#l=ea.#m*a,this.#c=ea.#u*a,this.#h=a,this.#f.push(t,e)}isEmpty(){return isNaN(this.#s[8])}#g(){const t=this.#s.subarray(4,6),e=this.#s.subarray(16,18),[s,a,l,c]=this.#t;return[(this.#a+(t[0]-e[0])/2-s)/l,(this.#o+(t[1]-e[1])/2-a)/c,(this.#a+(e[0]-t[0])/2-s)/l,(this.#o+(e[1]-t[1])/2-a)/c]}add({x:t,y:e}){this.#a=t,this.#o=e;const[s,a,l,c]=this.#t;let[d,h,f,g]=this.#s.subarray(8,12);const m=t-f,x=e-g,v=Math.hypot(m,x);if(v<this.#c)return!1;const E=v-this.#l,S=E/v,C=S*m,T=S*x;let _=d,k=h;d=f,h=g,f+=C,g+=T,this.#f?.push(t,e);const R=-T/E,D=C/E,L=R*this.#d,O=D*this.#d;return this.#s.set(this.#s.subarray(2,8),0),this.#s.set([f+L,g+O],4),this.#s.set(this.#s.subarray(14,18),12),this.#s.set([f-L,g-O],16),isNaN(this.#s[6])?(this.#r.length===0&&(this.#s.set([d+L,h+O],2),this.#r.push(NaN,NaN,NaN,NaN,(d+L-s)/l,(h+O-a)/c),this.#s.set([d-L,h-O],14),this.#e.push(NaN,NaN,NaN,NaN,(d-L-s)/l,(h-O-a)/c)),this.#s.set([_,k,d,h,f,g],6),!this.isEmpty()):(this.#s.set([_,k,d,h,f,g],6),Math.abs(Math.atan2(k-h,_-d)-Math.atan2(T,C))<Math.PI/2?([d,h,f,g]=this.#s.subarray(2,6),this.#r.push(NaN,NaN,NaN,NaN,((d+f)/2-s)/l,((h+g)/2-a)/c),[d,h,_,k]=this.#s.subarray(14,18),this.#e.push(NaN,NaN,NaN,NaN,((_+d)/2-s)/l,((k+h)/2-a)/c),!0):([_,k,d,h,f,g]=this.#s.subarray(0,6),this.#r.push(((_+5*d)/6-s)/l,((k+5*h)/6-a)/c,((5*d+f)/6-s)/l,((5*h+g)/6-a)/c,((d+f)/2-s)/l,((h+g)/2-a)/c),[f,g,d,h,_,k]=this.#s.subarray(12,18),this.#e.push(((_+5*d)/6-s)/l,((k+5*h)/6-a)/c,((5*d+f)/6-s)/l,((5*h+g)/6-a)/c,((d+f)/2-s)/l,((h+g)/2-a)/c),!0))}toSVGPath(){if(this.isEmpty())return"";const t=this.#r,e=this.#e;if(isNaN(this.#s[6])&&!this.isEmpty())return this.#b();const s=[];s.push(`M${t[4]} ${t[5]}`);for(let a=6;a<t.length;a+=6)isNaN(t[a])?s.push(`L${t[a+4]} ${t[a+5]}`):s.push(`C${t[a]} ${t[a+1]} ${t[a+2]} ${t[a+3]} ${t[a+4]} ${t[a+5]}`);this.#y(s);for(let a=e.length-6;a>=6;a-=6)isNaN(e[a])?s.push(`L${e[a+4]} ${e[a+5]}`):s.push(`C${e[a]} ${e[a+1]} ${e[a+2]} ${e[a+3]} ${e[a+4]} ${e[a+5]}`);return this.#x(s),s.join(" ")}#b(){const[t,e,s,a]=this.#t,[l,c,d,h]=this.#g();return`M${(this.#s[2]-t)/s} ${(this.#s[3]-e)/a} L${(this.#s[4]-t)/s} ${(this.#s[5]-e)/a} L${l} ${c} L${d} ${h} L${(this.#s[16]-t)/s} ${(this.#s[17]-e)/a} L${(this.#s[14]-t)/s} ${(this.#s[15]-e)/a} Z`}#x(t){const e=this.#e;t.push(`L${e[4]} ${e[5]} Z`)}#y(t){const[e,s,a,l]=this.#t,c=this.#s.subarray(4,6),d=this.#s.subarray(16,18),[h,f,g,m]=this.#g();t.push(`L${(c[0]-e)/a} ${(c[1]-s)/l} L${h} ${f} L${g} ${m} L${(d[0]-e)/a} ${(d[1]-s)/l}`)}newFreeDrawOutline(t,e,s,a,l,c){return new S1(t,e,s,a,l,c)}getOutlines(){const t=this.#r,e=this.#e,s=this.#s,[a,l,c,d]=this.#t,h=new Float32Array((this.#f?.length??0)+2);for(let m=0,x=h.length-2;m<x;m+=2)h[m]=(this.#f[m]-a)/c,h[m+1]=(this.#f[m+1]-l)/d;if(h[h.length-2]=(this.#a-a)/c,h[h.length-1]=(this.#o-l)/d,isNaN(s[6])&&!this.isEmpty())return this.#T(h);const f=new Float32Array(this.#r.length+24+this.#e.length);let g=t.length;for(let m=0;m<g;m+=2){if(isNaN(t[m])){f[m]=f[m+1]=NaN;continue}f[m]=t[m],f[m+1]=t[m+1]}g=this.#v(f,g);for(let m=e.length-6;m>=6;m-=6)for(let x=0;x<6;x+=2){if(isNaN(e[m+x])){f[g]=f[g+1]=NaN,g+=2;continue}f[g]=e[m+x],f[g+1]=e[m+x+1],g+=2}return this.#S(f,g),this.newFreeDrawOutline(f,h,this.#t,this.#h,this.#i,this.#n)}#T(t){const e=this.#s,[s,a,l,c]=this.#t,[d,h,f,g]=this.#g(),m=new Float32Array(36);return m.set([NaN,NaN,NaN,NaN,(e[2]-s)/l,(e[3]-a)/c,NaN,NaN,NaN,NaN,(e[4]-s)/l,(e[5]-a)/c,NaN,NaN,NaN,NaN,d,h,NaN,NaN,NaN,NaN,f,g,NaN,NaN,NaN,NaN,(e[16]-s)/l,(e[17]-a)/c,NaN,NaN,NaN,NaN,(e[14]-s)/l,(e[15]-a)/c],0),this.newFreeDrawOutline(m,t,this.#t,this.#h,this.#i,this.#n)}#S(t,e){const s=this.#e;return t.set([NaN,NaN,NaN,NaN,s[4],s[5]],e),e+=6}#v(t,e){const s=this.#s.subarray(4,6),a=this.#s.subarray(16,18),[l,c,d,h]=this.#t,[f,g,m,x]=this.#g();return t.set([NaN,NaN,NaN,NaN,(s[0]-l)/d,(s[1]-c)/h,NaN,NaN,NaN,NaN,f,g,NaN,NaN,NaN,NaN,m,x,NaN,NaN,NaN,NaN,(a[0]-l)/d,(a[1]-c)/h],e),e+=24}}class S1 extends pt{#t;#e=new Float32Array(4);#i;#n;#r;#s;#a;constructor(t,e,s,a,l,c){super(),this.#a=t,this.#r=e,this.#t=s,this.#s=a,this.#i=l,this.#n=c,this.firstPoint=[NaN,NaN],this.lastPoint=[NaN,NaN],this.#o(c);const[d,h,f,g]=this.#e;for(let m=0,x=t.length;m<x;m+=2)t[m]=(t[m]-d)/f,t[m+1]=(t[m+1]-h)/g;for(let m=0,x=e.length;m<x;m+=2)e[m]=(e[m]-d)/f,e[m+1]=(e[m+1]-h)/g}toSVGPath(){const t=[`M${this.#a[4]} ${this.#a[5]}`];for(let e=6,s=this.#a.length;e<s;e+=6){if(isNaN(this.#a[e])){t.push(`L${this.#a[e+4]} ${this.#a[e+5]}`);continue}t.push(`C${this.#a[e]} ${this.#a[e+1]} ${this.#a[e+2]} ${this.#a[e+3]} ${this.#a[e+4]} ${this.#a[e+5]}`)}return t.push("Z"),t.join(" ")}serialize([t,e,s,a],l){const c=s-t,d=a-e;let h,f;switch(l){case 0:h=pt._rescale(this.#a,t,a,c,-d),f=pt._rescale(this.#r,t,a,c,-d);break;case 90:h=pt._rescaleAndSwap(this.#a,t,e,c,d),f=pt._rescaleAndSwap(this.#r,t,e,c,d);break;case 180:h=pt._rescale(this.#a,s,e,-c,d),f=pt._rescale(this.#r,s,e,-c,d);break;case 270:h=pt._rescaleAndSwap(this.#a,s,a,-c,-d),f=pt._rescaleAndSwap(this.#r,s,a,-c,-d);break}return{outline:Array.from(h),points:[Array.from(f)]}}#o(t){const e=this.#a;let s=e[4],a=e[5];const l=[s,a,s,a];let c=s,d=a,h=s,f=a;const g=t?Math.max:Math.min,m=new Float32Array(4);for(let v=6,E=e.length;v<E;v+=6){const S=e[v+4],C=e[v+5];isNaN(e[v])?(gt.pointBoundingBox(S,C,l),d>C?(c=S,d=C):d===C&&(c=g(c,S)),f<C?(h=S,f=C):f===C&&(h=g(h,S))):(m[0]=m[1]=1/0,m[2]=m[3]=-1/0,gt.bezierBoundingBox(s,a,...e.slice(v,v+6),m),gt.rectBoundingBox(m[0],m[1],m[2],m[3],l),d>m[1]?(c=m[0],d=m[1]):d===m[1]&&(c=g(c,m[0])),f<m[3]?(h=m[2],f=m[3]):f===m[3]&&(h=g(h,m[2]))),s=S,a=C}const x=this.#e;x[0]=l[0]-this.#i,x[1]=l[1]-this.#i,x[2]=l[2]-l[0]+2*this.#i,x[3]=l[3]-l[1]+2*this.#i,this.firstPoint=[c,d],this.lastPoint=[h,f]}get box(){return this.#e}newOutliner(t,e,s,a,l,c=0){return new ea(t,e,s,a,l,c)}getNewOutline(t,e){const[s,a,l,c]=this.#e,[d,h,f,g]=this.#t,m=l*f,x=c*g,v=s*f+d,E=a*g+h,S=this.newOutliner({x:this.#r[0]*m+v,y:this.#r[1]*x+E},this.#t,this.#s,t,this.#n,e??this.#i);for(let C=2;C<this.#r.length;C+=2)S.add({x:this.#r[C]*m+v,y:this.#r[C+1]*x+E});return S.getOutlines()}}class np{#t;#e;#i;#n=[];#r=[];constructor(t,e=0,s=0,a=!0){const l=[1/0,1/0,-1/0,-1/0],c=10**-4;for(const{x:S,y:C,width:T,height:_}of t){const k=Math.floor((S-e)/c)*c,R=Math.ceil((S+T+e)/c)*c,D=Math.floor((C-e)/c)*c,L=Math.ceil((C+_+e)/c)*c,O=[k,D,L,!0],B=[R,D,L,!1];this.#n.push(O,B),gt.rectBoundingBox(k,D,R,L,l)}const d=l[2]-l[0]+2*s,h=l[3]-l[1]+2*s,f=l[0]-s,g=l[1]-s;let m=a?-1/0:1/0,x=1/0;const v=this.#n.at(a?-1:-2),E=[v[0],v[2]];for(const S of this.#n){const[C,T,_,k]=S;!k&&a?T<x?(x=T,m=C):T===x&&(m=Math.max(m,C)):k&&!a&&(T<x?(x=T,m=C):T===x&&(m=Math.min(m,C))),S[0]=(C-f)/d,S[1]=(T-g)/h,S[2]=(_-g)/h}this.#t=new Float32Array([f,g,d,h]),this.#e=[m,x],this.#i=E}getOutlines(){this.#n.sort((e,s)=>e[0]-s[0]||e[1]-s[1]||e[2]-s[2]);const t=[];for(const e of this.#n)e[3]?(t.push(...this.#l(e)),this.#o(e)):(this.#c(e),t.push(...this.#l(e)));return this.#s(t)}#s(t){const e=[],s=new Set;for(const c of t){const[d,h,f]=c;e.push([d,h,c],[d,f,c])}e.sort((c,d)=>c[1]-d[1]||c[0]-d[0]);for(let c=0,d=e.length;c<d;c+=2){const h=e[c][2],f=e[c+1][2];h.push(f),f.push(h),s.add(h),s.add(f)}const a=[];let l;for(;s.size>0;){const c=s.values().next().value;let[d,h,f,g,m]=c;s.delete(c);let x=d,v=h;for(l=[d,f],a.push(l);;){let E;if(s.has(g))E=g;else if(s.has(m))E=m;else break;s.delete(E),[d,h,f,g,m]=E,x!==d&&(l.push(x,v,d,v===h?h:f),x=d),v=v===h?f:h}l.push(x,v)}return new mL(a,this.#t,this.#e,this.#i)}#a(t){const e=this.#r;let s=0,a=e.length-1;for(;s<=a;){const l=s+a>>1,c=e[l][0];if(c===t)return l;c<t?s=l+1:a=l-1}return a+1}#o([,t,e]){const s=this.#a(t);this.#r.splice(s,0,[t,e])}#c([,t,e]){const s=this.#a(t);for(let a=s;a<this.#r.length;a++){const[l,c]=this.#r[a];if(l!==t)break;if(l===t&&c===e){this.#r.splice(a,1);return}}for(let a=s-1;a>=0;a--){const[l,c]=this.#r[a];if(l!==t)break;if(l===t&&c===e){this.#r.splice(a,1);return}}}#l(t){const[e,s,a]=t,l=[[e,s,a]],c=this.#a(a);for(let d=0;d<c;d++){const[h,f]=this.#r[d];for(let g=0,m=l.length;g<m;g++){const[,x,v]=l[g];if(!(f<=x||v<=h)){if(x>=h){if(v>f)l[g][1]=f;else{if(m===1)return[];l.splice(g,1),g--,m--}continue}l[g][2]=h,v>f&&l.push([e,f,v])}}}return l}}class mL extends pt{#t;#e;constructor(t,e,s,a){super(),this.#e=t,this.#t=e,this.firstPoint=s,this.lastPoint=a}toSVGPath(){const t=[];for(const e of this.#e){let[s,a]=e;t.push(`M${s} ${a}`);for(let l=2;l<e.length;l+=2){const c=e[l],d=e[l+1];c===s?(t.push(`V${d}`),a=d):d===a&&(t.push(`H${c}`),s=c)}t.push("Z")}return t.join(" ")}serialize([t,e,s,a],l){const c=[],d=s-t,h=a-e;for(const f of this.#e){const g=new Array(f.length);for(let m=0;m<f.length;m+=2)g[m]=t+f[m]*d,g[m+1]=a-f[m+1]*h;c.push(g)}return c}get box(){return this.#t}get classNamesForOutlining(){return["highlightOutline"]}}class ip extends ea{newFreeDrawOutline(t,e,s,a,l,c){return new bL(t,e,s,a,l,c)}}class bL extends S1{newOutliner(t,e,s,a,l,c=0){return new ip(t,e,s,a,l,c)}}class ve extends St{#t=null;#e=0;#i;#n=null;#r=null;#s=null;#a=null;#o=0;#c=null;#l=null;#h=null;#d=!1;#f=null;#m=null;#p=null;#u="";#g;#b="";static _defaultColor=null;static _defaultOpacity=1;static _defaultThickness=12;static _type="highlight";static _editorType=Dt.HIGHLIGHT;static _freeHighlightId=-1;static _freeHighlight=null;static _freeHighlightClipId="";static get _keyboardManager(){const t=ve.prototype;return jt(this,"_keyboardManager",new gl([[["ArrowLeft","mac+ArrowLeft"],t._moveCaret,{args:[0]}],[["ArrowRight","mac+ArrowRight"],t._moveCaret,{args:[1]}],[["ArrowUp","mac+ArrowUp"],t._moveCaret,{args:[2]}],[["ArrowDown","mac+ArrowDown"],t._moveCaret,{args:[3]}]]))}constructor(t){super({...t,name:"highlightEditor"}),this.color=t.color||ve._defaultColor,this.#g=t.thickness||ve._defaultThickness,this.opacity=t.opacity||ve._defaultOpacity,this.#i=t.boxes||null,this.#b=t.methodOfCreation||"",this.#u=t.text||"",this._isDraggable=!1,this.defaultL10nId="pdfjs-editor-highlight-editor",t.highlightId>-1?(this.#d=!0,this.#y(t),this.#w()):this.#i&&(this.#t=t.anchorNode,this.#e=t.anchorOffset,this.#a=t.focusNode,this.#o=t.focusOffset,this.#x(),this.#w(),this.rotate(this.rotation)),this.annotationElementId||this._uiManager.a11yAlert("pdfjs-editor-highlight-added-alert")}get telemetryInitialData(){return{action:"added",type:this.#d?"free_highlight":"highlight",color:this._uiManager.getNonHCMColorName(this.color),thickness:this.#g,methodOfCreation:this.#b}}get telemetryFinalData(){return{type:"highlight",color:this._uiManager.getNonHCMColorName(this.color)}}static computeTelemetryFinalData(t){return{numberOfColors:t.get("color").size}}#x(){const t=new np(this.#i,.001);this.#l=t.getOutlines(),[this.x,this.y,this.width,this.height]=this.#l.box;const e=new np(this.#i,.0025,.001,this._uiManager.direction==="ltr");this.#s=e.getOutlines();const{firstPoint:s}=this.#l;this.#f=[(s[0]-this.x)/this.width,(s[1]-this.y)/this.height];const{lastPoint:a}=this.#s;this.#m=[(a[0]-this.x)/this.width,(a[1]-this.y)/this.height]}#y({highlightOutlines:t,highlightId:e,clipPathId:s}){this.#l=t;const a=1.5;if(this.#s=t.getNewOutline(this.#g/2+a,.0025),e>=0)this.#h=e,this.#n=s,this.parent.drawLayer.finalizeDraw(e,{bbox:t.box,path:{d:t.toSVGPath()}}),this.#p=this.parent.drawLayer.drawOutline({rootClass:{highlightOutline:!0,free:!0},bbox:this.#s.box,path:{d:this.#s.toSVGPath()}},!0);else if(this.parent){const m=this.parent.viewport.rotation;this.parent.drawLayer.updateProperties(this.#h,{bbox:ve.#E(this.#l.box,(m-this.rotation+360)%360),path:{d:t.toSVGPath()}}),this.parent.drawLayer.updateProperties(this.#p,{bbox:ve.#E(this.#s.box,m),path:{d:this.#s.toSVGPath()}})}const[l,c,d,h]=t.box;switch(this.rotation){case 0:this.x=l,this.y=c,this.width=d,this.height=h;break;case 90:{const[m,x]=this.parentDimensions;this.x=c,this.y=1-l,this.width=d*x/m,this.height=h*m/x;break}case 180:this.x=1-l,this.y=1-c,this.width=d,this.height=h;break;case 270:{const[m,x]=this.parentDimensions;this.x=1-c,this.y=l,this.width=d*x/m,this.height=h*m/x;break}}const{firstPoint:f}=t;this.#f=[(f[0]-l)/d,(f[1]-c)/h];const{lastPoint:g}=this.#s;this.#m=[(g[0]-l)/d,(g[1]-c)/h]}static initialize(t,e){St.initialize(t,e),ve._defaultColor||=e.highlightColors?.values().next().value||"#fff066"}static updateDefaultParams(t,e){switch(t){case Ft.HIGHLIGHT_COLOR:ve._defaultColor=e;break;case Ft.HIGHLIGHT_THICKNESS:ve._defaultThickness=e;break}}translateInPage(t,e){}get toolbarPosition(){return this.#m}get commentButtonPosition(){return this.#f}updateParams(t,e){switch(t){case Ft.HIGHLIGHT_COLOR:this.#T(e);break;case Ft.HIGHLIGHT_THICKNESS:this.#S(e);break}}static get defaultPropertiesToUpdate(){return[[Ft.HIGHLIGHT_COLOR,ve._defaultColor],[Ft.HIGHLIGHT_THICKNESS,ve._defaultThickness]]}get propertiesToUpdate(){return[[Ft.HIGHLIGHT_COLOR,this.color||ve._defaultColor],[Ft.HIGHLIGHT_THICKNESS,this.#g||ve._defaultThickness],[Ft.HIGHLIGHT_FREE,this.#d]]}onUpdatedColor(){this.parent?.drawLayer.updateProperties(this.#h,{root:{fill:this.color,"fill-opacity":this.opacity}}),this.#r?.updateColor(this.color),super.onUpdatedColor()}#T(t){const e=(l,c)=>{this.color=l,this.opacity=c,this.onUpdatedColor()},s=this.color,a=this.opacity;this.addCommands({cmd:e.bind(this,t,ve._defaultOpacity),undo:e.bind(this,s,a),post:this._uiManager.updateUI.bind(this._uiManager,this),mustExec:!0,type:Ft.HIGHLIGHT_COLOR,overwriteIfSameType:!0,keepUndo:!0}),this._reportTelemetry({action:"color_changed",color:this._uiManager.getNonHCMColorName(t)},!0)}#S(t){const e=this.#g,s=a=>{this.#g=a,this.#v(a)};this.addCommands({cmd:s.bind(this,t),undo:s.bind(this,e),post:this._uiManager.updateUI.bind(this._uiManager,this),mustExec:!0,type:Ft.INK_THICKNESS,overwriteIfSameType:!0,keepUndo:!0}),this._reportTelemetry({action:"thickness_changed",thickness:t},!0)}get toolbarButtons(){return this._uiManager.highlightColors?[["colorPicker",this.#r=new vn({editor:this})]]:super.toolbarButtons}disableEditing(){super.disableEditing(),this.div.classList.toggle("disabled",!0)}enableEditing(){super.enableEditing(),this.div.classList.toggle("disabled",!1)}fixAndSetPosition(){return super.fixAndSetPosition(this.#M())}getBaseTranslation(){return[0,0]}getRect(t,e){return super.getRect(t,e,this.#M())}onceAdded(t){this.annotationElementId||this.parent.addUndoableEditor(this),t&&this.div.focus()}remove(){this.#_(),this._reportTelemetry({action:"deleted"}),super.remove()}rebuild(){this.parent&&(super.rebuild(),this.div!==null&&(this.#w(),this.isAttachedToDOM||this.parent.add(this)))}setParent(t){let e=!1;this.parent&&!t?this.#_():t&&(this.#w(t),e=!this.parent&&this.div?.classList.contains("selectedEditor")),super.setParent(t),this.show(this._isVisible),e&&this.select()}#v(t){this.#d&&(this.#y({highlightOutlines:this.#l.getNewOutline(t/2)}),this.fixAndSetPosition(),this.setDims(this.width,this.height))}#_(){this.#h===null||!this.parent||(this.parent.drawLayer.remove(this.#h),this.#h=null,this.parent.drawLayer.remove(this.#p),this.#p=null)}#w(t=this.parent){this.#h===null&&({id:this.#h,clipPathId:this.#n}=t.drawLayer.draw({bbox:this.#l.box,root:{viewBox:"0 0 1 1",fill:this.color,"fill-opacity":this.opacity},rootClass:{highlight:!0,free:this.#d},path:{d:this.#l.toSVGPath()}},!1,!0),this.#p=t.drawLayer.drawOutline({rootClass:{highlightOutline:!0,free:this.#d},bbox:this.#s.box,path:{d:this.#s.toSVGPath()}},this.#d),this.#c&&(this.#c.style.clipPath=this.#n))}static#E([t,e,s,a],l){switch(l){case 90:return[1-e-a,t,a,s];case 180:return[1-t-s,1-e-a,s,a];case 270:return[e,1-t-s,a,s]}return[t,e,s,a]}rotate(t){const{drawLayer:e}=this.parent;let s;this.#d?(t=(t-this.rotation+360)%360,s=ve.#E(this.#l.box,t)):s=ve.#E([this.x,this.y,this.width,this.height],t),e.updateProperties(this.#h,{bbox:s,root:{"data-main-rotation":t}}),e.updateProperties(this.#p,{bbox:ve.#E(this.#s.box,t),root:{"data-main-rotation":t}})}render(){if(this.div)return this.div;const t=super.render();this.#u&&(t.setAttribute("aria-label",this.#u),t.setAttribute("role","mark")),this.#d?t.classList.add("free"):this.div.addEventListener("keydown",this.#D.bind(this),{signal:this._uiManager._signal});const e=this.#c=document.createElement("div");return t.append(e),e.setAttribute("aria-hidden","true"),e.className="internal",e.style.clipPath=this.#n,this.setDims(this.width,this.height),Zv(this,this.#c,["pointerover","pointerleave"]),this.enableEditing(),t}pointerover(){this.isSelected||this.parent?.drawLayer.updateProperties(this.#p,{rootClass:{hovered:!0}})}pointerleave(){this.isSelected||this.parent?.drawLayer.updateProperties(this.#p,{rootClass:{hovered:!1}})}#D(t){ve._keyboardManager.exec(this,t)}_moveCaret(t){switch(this.parent.unselect(this),t){case 0:case 2:this.#k(!0);break;case 1:case 3:this.#k(!1);break}}#k(t){if(!this.#t)return;const e=window.getSelection();t?e.setPosition(this.#t,this.#e):e.setPosition(this.#a,this.#o)}select(){super.select(),this.#p&&this.parent?.drawLayer.updateProperties(this.#p,{rootClass:{hovered:!1,selected:!0}})}unselect(){super.unselect(),this.#p&&(this.parent?.drawLayer.updateProperties(this.#p,{rootClass:{selected:!1}}),this.#d||this.#k(!1))}get _mustFixPosition(){return!this.#d}show(t=this._isVisible){super.show(t),this.parent&&(this.parent.drawLayer.updateProperties(this.#h,{rootClass:{hidden:!t}}),this.parent.drawLayer.updateProperties(this.#p,{rootClass:{hidden:!t}}))}#M(){return this.#d?this.rotation:0}#z(){if(this.#d)return null;const[t,e]=this.pageDimensions,[s,a]=this.pageTranslation,l=this.#i,c=new Float32Array(l.length*8);let d=0;for(const{x:h,y:f,width:g,height:m}of l){const x=h*t+s,v=(1-f)*e+a;c[d]=c[d+4]=x,c[d+1]=c[d+3]=v,c[d+2]=c[d+6]=x+g*t,c[d+5]=c[d+7]=v-m*e,d+=8}return c}#L(t){return this.#l.serialize(t,this.#M())}static startHighlighting(t,e,{target:s,x:a,y:l}){const{x:c,y:d,width:h,height:f}=s.getBoundingClientRect(),g=new AbortController,m=t.combinedSignal(g),x=v=>{g.abort(),this.#P(t,v)};window.addEventListener("blur",x,{signal:m}),window.addEventListener("pointerup",x,{signal:m}),window.addEventListener("pointerdown",he,{capture:!0,passive:!1,signal:m}),window.addEventListener("contextmenu",wn,{signal:m}),s.addEventListener("pointermove",this.#j.bind(this,t),{signal:m}),this._freeHighlight=new ip({x:a,y:l},[c,d,h,f],t.scale,this._defaultThickness/2,e,.001),{id:this._freeHighlightId,clipPathId:this._freeHighlightClipId}=t.drawLayer.draw({bbox:[0,0,1,1],root:{viewBox:"0 0 1 1",fill:this._defaultColor,"fill-opacity":this._defaultOpacity},rootClass:{highlight:!0,free:!0},path:{d:this._freeHighlight.toSVGPath()}},!0,!0)}static#j(t,e){this._freeHighlight.add(e)&&t.drawLayer.updateProperties(this._freeHighlightId,{path:{d:this._freeHighlight.toSVGPath()}})}static#P(t,e){this._freeHighlight.isEmpty()?t.drawLayer.remove(this._freeHighlightId):t.createAndAddNewEditor(e,!1,{highlightId:this._freeHighlightId,highlightOutlines:this._freeHighlight.getOutlines(),clipPathId:this._freeHighlightClipId,methodOfCreation:"main_toolbar"}),this._freeHighlightId=-1,this._freeHighlight=null,this._freeHighlightClipId=""}static async deserialize(t,e,s){let a=null;if(t instanceof v1){const{data:{quadPoints:E,rect:S,rotation:C,id:T,color:_,opacity:k,popupRef:R,richText:D,contentsObj:L,creationDate:O,modificationDate:B},parent:{page:{pageNumber:F}}}=t;a=t={annotationType:Dt.HIGHLIGHT,color:Array.from(_),opacity:k,quadPoints:E,boxes:null,pageIndex:F-1,rect:S.slice(0),rotation:C,annotationElementId:T,id:T,deleted:!1,popupRef:R,richText:D,comment:L?.str||null,creationDate:O,modificationDate:B}}else if(t instanceof $p){const{data:{inkLists:E,rect:S,rotation:C,id:T,color:_,borderStyle:{rawWidth:k},popupRef:R,richText:D,contentsObj:L,creationDate:O,modificationDate:B},parent:{page:{pageNumber:F}}}=t;a=t={annotationType:Dt.HIGHLIGHT,color:Array.from(_),thickness:k,inkLists:E,boxes:null,pageIndex:F-1,rect:S.slice(0),rotation:C,annotationElementId:T,id:T,deleted:!1,popupRef:R,richText:D,comment:L?.str||null,creationDate:O,modificationDate:B}}const{color:l,quadPoints:c,inkLists:d,opacity:h}=t,f=await super.deserialize(t,e,s);f.color=gt.makeHexColor(...l),f.opacity=h||1,d&&(f.#g=t.thickness),f._initialData=a,t.comment&&f.setCommentData(t);const[g,m]=f.pageDimensions,[x,v]=f.pageTranslation;if(c){const E=f.#i=[];for(let S=0;S<c.length;S+=8)E.push({x:(c[S]-x)/g,y:1-(c[S+1]-v)/m,width:(c[S+2]-c[S])/g,height:(c[S+1]-c[S+5])/m});f.#x(),f.#w(),f.rotate(f.rotation)}else if(d){f.#d=!0;const E=d[0],S={x:E[0]-x,y:m-(E[1]-v)},C=new ip(S,[0,0,g,m],1,f.#g/2,!0,.001);for(let k=0,R=E.length;k<R;k+=2)S.x=E[k]-x,S.y=m-(E[k+1]-v),C.add(S);const{id:T,clipPathId:_}=e.drawLayer.draw({bbox:[0,0,1,1],root:{viewBox:"0 0 1 1",fill:f.color,"fill-opacity":f._defaultOpacity},rootClass:{highlight:!0,free:!0},path:{d:C.toSVGPath()}},!0,!0);f.#y({highlightOutlines:C.getOutlines(),highlightId:T,clipPathId:_}),f.#w(),f.rotate(f.parentRotation)}return f}serialize(t=!1){if(this.isEmpty()||t)return null;if(this.deleted)return this.serializeDeleted();const e=St._colorManager.convert(this._uiManager.getNonHCMColor(this.color)),s=super.serialize(t);return Object.assign(s,{color:e,opacity:this.opacity,thickness:this.#g,quadPoints:this.#z(),outlines:this.#L(s.rect)}),this.addComment(s),this.annotationElementId&&!this.#N(s)?null:(s.id=this.annotationElementId,s)}#N(t){const{color:e}=this._initialData;return this.hasEditedComment||t.color.some((s,a)=>s!==e[a])}renderAnnotationElement(t){return this.deleted?(t.hide(),null):(t.updateEdited({rect:this.getPDFRect(),popup:this.comment}),null)}static canCreateNewEmptyEditor(){return!1}}class E1{#t=Object.create(null);updateProperty(t,e){this[t]=e,this.updateSVGProperty(t,e)}updateProperties(t){if(t)for(const[e,s]of Object.entries(t))e.startsWith("_")||this.updateProperty(e,s)}updateSVGProperty(t,e){this.#t[t]=e}toSVGProperties(){const t=this.#t;return this.#t=Object.create(null),{root:t}}reset(){this.#t=Object.create(null)}updateAll(t=this){this.updateProperties(t)}clone(){ie("Not implemented")}}class _t extends St{#t=null;#e;_colorPicker=null;_drawId=null;static _currentDrawId=-1;static _currentParent=null;static#i=null;static#n=null;static#r=null;static#s=NaN;static#a=null;static#o=null;static#c=NaN;static _INNER_MARGIN=3;constructor(t){super(t),this.#e=t.mustBeCommitted||!1,this._addOutlines(t)}onUpdatedColor(){this._colorPicker?.update(this.color),super.onUpdatedColor()}_addOutlines(t){t.drawOutlines&&(this.#l(t),this.#f())}#l({drawOutlines:t,drawId:e,drawingOptions:s}){this.#t=t,this._drawingOptions||=s,this.annotationElementId||this._uiManager.a11yAlert(`pdfjs-editor-${this.editorType}-added-alert`),e>=0?(this._drawId=e,this.parent.drawLayer.finalizeDraw(e,t.defaultProperties)):this._drawId=this.#h(t,this.parent),this.#u(t.box)}#h(t,e){const{id:s}=e.drawLayer.draw(_t._mergeSVGProperties(this._drawingOptions.toSVGProperties(),t.defaultSVGProperties),!1,!1);return s}static _mergeSVGProperties(t,e){const s=new Set(Object.keys(t));for(const[a,l]of Object.entries(e))s.has(a)?Object.assign(t[a],l):t[a]=l;return t}static getDefaultDrawingOptions(t){ie("Not implemented")}static get typesMap(){ie("Not implemented")}static get isDrawer(){return!0}static get supportMultipleDrawings(){return!1}static updateDefaultParams(t,e){const s=this.typesMap.get(t);s&&this._defaultDrawingOptions.updateProperty(s,e),this._currentParent&&(_t.#i.updateProperty(s,e),this._currentParent.drawLayer.updateProperties(this._currentDrawId,this._defaultDrawingOptions.toSVGProperties()))}updateParams(t,e){const s=this.constructor.typesMap.get(t);s&&this._updateProperty(t,s,e)}static get defaultPropertiesToUpdate(){const t=[],e=this._defaultDrawingOptions;for(const[s,a]of this.typesMap)t.push([s,e[a]]);return t}get propertiesToUpdate(){const t=[],{_drawingOptions:e}=this;for(const[s,a]of this.constructor.typesMap)t.push([s,e[a]]);return t}_updateProperty(t,e,s){const a=this._drawingOptions,l=a[e],c=d=>{a.updateProperty(e,d);const h=this.#t.updateProperty(e,d);h&&this.#u(h),this.parent?.drawLayer.updateProperties(this._drawId,a.toSVGProperties()),t===this.colorType&&this.onUpdatedColor()};this.addCommands({cmd:c.bind(this,s),undo:c.bind(this,l),post:this._uiManager.updateUI.bind(this._uiManager,this),mustExec:!0,type:t,overwriteIfSameType:!0,keepUndo:!0})}_onResizing(){this.parent?.drawLayer.updateProperties(this._drawId,_t._mergeSVGProperties(this.#t.getPathResizingSVGProperties(this.#p()),{bbox:this.#g()}))}_onResized(){this.parent?.drawLayer.updateProperties(this._drawId,_t._mergeSVGProperties(this.#t.getPathResizedSVGProperties(this.#p()),{bbox:this.#g()}))}_onTranslating(t,e){this.parent?.drawLayer.updateProperties(this._drawId,{bbox:this.#g()})}_onTranslated(){this.parent?.drawLayer.updateProperties(this._drawId,_t._mergeSVGProperties(this.#t.getPathTranslatedSVGProperties(this.#p(),this.parentDimensions),{bbox:this.#g()}))}_onStartDragging(){this.parent?.drawLayer.updateProperties(this._drawId,{rootClass:{moving:!0}})}_onStopDragging(){this.parent?.drawLayer.updateProperties(this._drawId,{rootClass:{moving:!1}})}commit(){super.commit(),this.disableEditMode(),this.disableEditing()}disableEditing(){super.disableEditing(),this.div.classList.toggle("disabled",!0)}enableEditing(){super.enableEditing(),this.div.classList.toggle("disabled",!1)}getBaseTranslation(){return[0,0]}get isResizable(){return!0}onceAdded(t){this.annotationElementId||this.parent.addUndoableEditor(this),this._isDraggable=!0,this.#e&&(this.#e=!1,this.commit(),this.parent.setSelected(this),t&&this.isOnScreen&&this.div.focus())}remove(){this.#d(),super.remove()}rebuild(){this.parent&&(super.rebuild(),this.div!==null&&(this.#f(),this.#u(this.#t.box),this.isAttachedToDOM||this.parent.add(this)))}setParent(t){let e=!1;this.parent&&!t?(this._uiManager.removeShouldRescale(this),this.#d()):t&&(this._uiManager.addShouldRescale(this),this.#f(t),e=!this.parent&&this.div?.classList.contains("selectedEditor")),super.setParent(t),e&&this.select()}#d(){this._drawId===null||!this.parent||(this.parent.drawLayer.remove(this._drawId),this._drawId=null,this._drawingOptions.reset())}#f(t=this.parent){if(!(this._drawId!==null&&this.parent===t)){if(this._drawId!==null){this.parent.drawLayer.updateParent(this._drawId,t.drawLayer);return}this._drawingOptions.updateAll(),this._drawId=this.#h(this.#t,t)}}#m([t,e,s,a]){const{parentDimensions:[l,c],rotation:d}=this;switch(d){case 90:return[e,1-t,s*(c/l),a*(l/c)];case 180:return[1-t,1-e,s,a];case 270:return[1-e,t,s*(c/l),a*(l/c)];default:return[t,e,s,a]}}#p(){const{x:t,y:e,width:s,height:a,parentDimensions:[l,c],rotation:d}=this;switch(d){case 90:return[1-e,t,s*(l/c),a*(c/l)];case 180:return[1-t,1-e,s,a];case 270:return[e,1-t,s*(l/c),a*(c/l)];default:return[t,e,s,a]}}#u(t){[this.x,this.y,this.width,this.height]=this.#m(t),this.div&&(this.fixAndSetPosition(),this.setDims()),this._onResized()}#g(){const{x:t,y:e,width:s,height:a,rotation:l,parentRotation:c,parentDimensions:[d,h]}=this;switch((l*4+c)/90){case 1:return[1-e-a,t,a,s];case 2:return[1-t-s,1-e-a,s,a];case 3:return[e,1-t-s,a,s];case 4:return[t,e-s*(d/h),a*(h/d),s*(d/h)];case 5:return[1-e,t,s*(d/h),a*(h/d)];case 6:return[1-t-a*(h/d),1-e,a*(h/d),s*(d/h)];case 7:return[e-s*(d/h),1-t-a*(h/d),s*(d/h),a*(h/d)];case 8:return[t-s,e-a,s,a];case 9:return[1-e,t-s,a,s];case 10:return[1-t,1-e,s,a];case 11:return[e-a,1-t,a,s];case 12:return[t-a*(h/d),e,a*(h/d),s*(d/h)];case 13:return[1-e-s*(d/h),t-a*(h/d),s*(d/h),a*(h/d)];case 14:return[1-t,1-e-s*(d/h),a*(h/d),s*(d/h)];case 15:return[e,1-t,s*(d/h),a*(h/d)];default:return[t,e,s,a]}}rotate(){this.parent&&this.parent.drawLayer.updateProperties(this._drawId,_t._mergeSVGProperties({bbox:this.#g()},this.#t.updateRotation((this.parentRotation-this.rotation+360)%360)))}onScaleChanging(){this.parent&&this.#u(this.#t.updateParentDimensions(this.parentDimensions,this.parent.scale))}static onScaleChangingWhenDrawing(){}render(){if(this.div)return this.div;let t,e;this._isCopy&&(t=this.x,e=this.y);const s=super.render();s.classList.add("draw");const a=document.createElement("div");return s.append(a),a.setAttribute("aria-hidden","true"),a.className="internal",this.setDims(),this._uiManager.addShouldRescale(this),this.disableEditing(),this._isCopy&&this._moveAfterPaste(t,e),s}static createDrawerInstance(t,e,s,a,l){ie("Not implemented")}static startDrawing(t,e,s,a){const{target:l,offsetX:c,offsetY:d,pointerId:h,pointerType:f}=a;if(_t.#a&&_t.#a!==f)return;const{viewport:{rotation:g}}=t,{width:m,height:x}=l.getBoundingClientRect(),v=_t.#n=new AbortController,E=t.combinedSignal(v);if(_t.#s||=h,_t.#a??=f,window.addEventListener("pointerup",S=>{_t.#s===S.pointerId?this._endDraw(S):_t.#o?.delete(S.pointerId)},{signal:E}),window.addEventListener("pointercancel",S=>{_t.#s===S.pointerId?this._currentParent.endDrawingSession():_t.#o?.delete(S.pointerId)},{signal:E}),window.addEventListener("pointerdown",S=>{_t.#a===S.pointerType&&((_t.#o||=new Set).add(S.pointerId),_t.#i.isCancellable()&&(_t.#i.removeLastElement(),_t.#i.isEmpty()?this._currentParent.endDrawingSession(!0):this._endDraw(null)))},{capture:!0,passive:!1,signal:E}),window.addEventListener("contextmenu",wn,{signal:E}),l.addEventListener("pointermove",this._drawMove.bind(this),{signal:E}),l.addEventListener("touchmove",S=>{S.timeStamp===_t.#c&&he(S)},{signal:E}),t.toggleDrawing(),e._editorUndoBar?.hide(),_t.#i){t.drawLayer.updateProperties(this._currentDrawId,_t.#i.startNew(c,d,m,x,g));return}e.updateUIForDefaultProperties(this),_t.#i=this.createDrawerInstance(c,d,m,x,g),_t.#r=this.getDefaultDrawingOptions(),this._currentParent=t,{id:this._currentDrawId}=t.drawLayer.draw(this._mergeSVGProperties(_t.#r.toSVGProperties(),_t.#i.defaultSVGProperties),!0,!1)}static _drawMove(t){if(_t.#c=-1,!_t.#i)return;const{offsetX:e,offsetY:s,pointerId:a}=t;if(_t.#s===a){if(_t.#o?.size>=1){this._endDraw(t);return}this._currentParent.drawLayer.updateProperties(this._currentDrawId,_t.#i.add(e,s)),_t.#c=t.timeStamp,he(t)}}static _cleanup(t){t&&(this._currentDrawId=-1,this._currentParent=null,_t.#i=null,_t.#r=null,_t.#a=null,_t.#c=NaN),_t.#n&&(_t.#n.abort(),_t.#n=null,_t.#s=NaN,_t.#o=null)}static _endDraw(t){const e=this._currentParent;if(e){if(e.toggleDrawing(!0),this._cleanup(!1),t?.target===e.div&&e.drawLayer.updateProperties(this._currentDrawId,_t.#i.end(t.offsetX,t.offsetY)),this.supportMultipleDrawings){const s=_t.#i,a=this._currentDrawId,l=s.getLastElement();e.addCommands({cmd:()=>{e.drawLayer.updateProperties(a,s.setLastElement(l))},undo:()=>{e.drawLayer.updateProperties(a,s.removeLastElement())},mustExec:!1,type:Ft.DRAW_STEP});return}this.endDrawing(!1)}}static endDrawing(t){const e=this._currentParent;if(!e)return null;if(e.toggleDrawing(!0),e.cleanUndoStack(Ft.DRAW_STEP),!_t.#i.isEmpty()){const{pageDimensions:[s,a],scale:l}=e,c=e.createAndAddNewEditor({offsetX:0,offsetY:0},!1,{drawId:this._currentDrawId,drawOutlines:_t.#i.getOutlines(s*l,a*l,l,this._INNER_MARGIN),drawingOptions:_t.#r,mustBeCommitted:!t});return this._cleanup(!0),c}return e.drawLayer.remove(this._currentDrawId),this._cleanup(!0),null}createDrawingOptions(t){}static deserializeDraw(t,e,s,a,l,c){ie("Not implemented")}static async deserialize(t,e,s){const{rawDims:{pageWidth:a,pageHeight:l,pageX:c,pageY:d}}=e.viewport,h=this.deserializeDraw(c,d,a,l,this._INNER_MARGIN,t),f=await super.deserialize(t,e,s);return f.createDrawingOptions(t),f.#l({drawOutlines:h}),f.#f(),f.onScaleChanging(),f.rotate(),f}serializeDraw(t){const[e,s]=this.pageTranslation,[a,l]=this.pageDimensions;return this.#t.serialize([e,s,a,l],t)}renderAnnotationElement(t){return t.updateEdited({rect:this.getPDFRect()}),null}static canCreateNewEmptyEditor(){return!1}}class yL{#t=new Float64Array(6);#e;#i;#n;#r;#s;#a="";#o=0;#c=new yl;#l;#h;constructor(t,e,s,a,l,c){this.#l=s,this.#h=a,this.#n=l,this.#r=c,[t,e]=this.#d(t,e);const d=this.#e=[NaN,NaN,NaN,NaN,t,e];this.#s=[t,e],this.#i=[{line:d,points:this.#s}],this.#t.set(d,0)}updateProperty(t,e){t==="stroke-width"&&(this.#r=e)}#d(t,e){return pt._normalizePoint(t,e,this.#l,this.#h,this.#n)}isEmpty(){return!this.#i||this.#i.length===0}isCancellable(){return this.#s.length<=10}add(t,e){[t,e]=this.#d(t,e);const[s,a,l,c]=this.#t.subarray(2,6),d=t-l,h=e-c;return Math.hypot(this.#l*d,this.#h*h)<=2?null:(this.#s.push(t,e),isNaN(s)?(this.#t.set([l,c,t,e],2),this.#e.push(NaN,NaN,NaN,NaN,t,e),{path:{d:this.toSVGPath()}}):(isNaN(this.#t[0])&&this.#e.splice(6,6),this.#t.set([s,a,l,c,t,e],0),this.#e.push(...pt.createBezierPoints(s,a,l,c,t,e)),{path:{d:this.toSVGPath()}}))}end(t,e){const s=this.add(t,e);return s||(this.#s.length===2?{path:{d:this.toSVGPath()}}:null)}startNew(t,e,s,a,l){this.#l=s,this.#h=a,this.#n=l,[t,e]=this.#d(t,e);const c=this.#e=[NaN,NaN,NaN,NaN,t,e];this.#s=[t,e];const d=this.#i.at(-1);return d&&(d.line=new Float32Array(d.line),d.points=new Float32Array(d.points)),this.#i.push({line:c,points:this.#s}),this.#t.set(c,0),this.#o=0,this.toSVGPath(),null}getLastElement(){return this.#i.at(-1)}setLastElement(t){return this.#i?(this.#i.push(t),this.#e=t.line,this.#s=t.points,this.#o=0,{path:{d:this.toSVGPath()}}):this.#c.setLastElement(t)}removeLastElement(){if(!this.#i)return this.#c.removeLastElement();this.#i.pop(),this.#a="";for(let t=0,e=this.#i.length;t<e;t++){const{line:s,points:a}=this.#i[t];this.#e=s,this.#s=a,this.#o=0,this.toSVGPath()}return{path:{d:this.#a}}}toSVGPath(){const t=pt.svgRound(this.#e[4]),e=pt.svgRound(this.#e[5]);if(this.#s.length===2)return this.#a=`${this.#a} M ${t} ${e} Z`,this.#a;if(this.#s.length<=6){const a=this.#a.lastIndexOf("M");this.#a=`${this.#a.slice(0,a)} M ${t} ${e}`,this.#o=6}if(this.#s.length===4){const a=pt.svgRound(this.#e[10]),l=pt.svgRound(this.#e[11]);return this.#a=`${this.#a} L ${a} ${l}`,this.#o=12,this.#a}const s=[];this.#o===0&&(s.push(`M ${t} ${e}`),this.#o=6);for(let a=this.#o,l=this.#e.length;a<l;a+=6){const[c,d,h,f,g,m]=this.#e.slice(a,a+6).map(pt.svgRound);s.push(`C${c} ${d} ${h} ${f} ${g} ${m}`)}return this.#a+=s.join(" "),this.#o=this.#e.length,this.#a}getOutlines(t,e,s,a){const l=this.#i.at(-1);return l.line=new Float32Array(l.line),l.points=new Float32Array(l.points),this.#c.build(this.#i,t,e,s,this.#n,this.#r,a),this.#t=null,this.#e=null,this.#i=null,this.#a=null,this.#c}get defaultSVGProperties(){return{root:{viewBox:"0 0 10000 10000"},rootClass:{draw:!0},bbox:[0,0,1,1]}}}class yl extends pt{#t;#e=0;#i;#n;#r;#s;#a;#o;#c;build(t,e,s,a,l,c,d){this.#r=e,this.#s=s,this.#a=a,this.#o=l,this.#c=c,this.#i=d??0,this.#n=t,this.#d()}get thickness(){return this.#c}setLastElement(t){return this.#n.push(t),{path:{d:this.toSVGPath()}}}removeLastElement(){return this.#n.pop(),{path:{d:this.toSVGPath()}}}toSVGPath(){const t=[];for(const{line:e}of this.#n){if(t.push(`M${pt.svgRound(e[4])} ${pt.svgRound(e[5])}`),e.length===6){t.push("Z");continue}if(e.length===12&&isNaN(e[6])){t.push(`L${pt.svgRound(e[10])} ${pt.svgRound(e[11])}`);continue}for(let s=6,a=e.length;s<a;s+=6){const[l,c,d,h,f,g]=e.subarray(s,s+6).map(pt.svgRound);t.push(`C${l} ${c} ${d} ${h} ${f} ${g}`)}}return t.join("")}serialize([t,e,s,a],l){const c=[],d=[],[h,f,g,m]=this.#h();let x,v,E,S,C,T,_,k,R;switch(this.#o){case 0:R=pt._rescale,x=t,v=e+a,E=s,S=-a,C=t+h*s,T=e+(1-f-m)*a,_=t+(h+g)*s,k=e+(1-f)*a;break;case 90:R=pt._rescaleAndSwap,x=t,v=e,E=s,S=a,C=t+f*s,T=e+h*a,_=t+(f+m)*s,k=e+(h+g)*a;break;case 180:R=pt._rescale,x=t+s,v=e,E=-s,S=a,C=t+(1-h-g)*s,T=e+f*a,_=t+(1-h)*s,k=e+(f+m)*a;break;case 270:R=pt._rescaleAndSwap,x=t+s,v=e+a,E=-s,S=-a,C=t+(1-f-m)*s,T=e+(1-h-g)*a,_=t+(1-f)*s,k=e+(1-h)*a;break}for(const{line:D,points:L}of this.#n)c.push(R(D,x,v,E,S,l?new Array(D.length):null)),d.push(R(L,x,v,E,S,l?new Array(L.length):null));return{lines:c,points:d,rect:[C,T,_,k]}}static deserialize(t,e,s,a,l,{paths:{lines:c,points:d},rotation:h,thickness:f}){const g=[];let m,x,v,E,S;switch(h){case 0:S=pt._rescale,m=-t/s,x=e/a+1,v=1/s,E=-1/a;break;case 90:S=pt._rescaleAndSwap,m=-e/a,x=-t/s,v=1/a,E=1/s;break;case 180:S=pt._rescale,m=t/s+1,x=-e/a,v=-1/s,E=1/a;break;case 270:S=pt._rescaleAndSwap,m=e/a+1,x=t/s+1,v=-1/a,E=-1/s;break}if(!c){c=[];for(const T of d){const _=T.length;if(_===2){c.push(new Float32Array([NaN,NaN,NaN,NaN,T[0],T[1]]));continue}if(_===4){c.push(new Float32Array([NaN,NaN,NaN,NaN,T[0],T[1],NaN,NaN,NaN,NaN,T[2],T[3]]));continue}const k=new Float32Array(3*(_-2));c.push(k);let[R,D,L,O]=T.subarray(0,4);k.set([NaN,NaN,NaN,NaN,R,D],0);for(let B=4;B<_;B+=2){const F=T[B],W=T[B+1];k.set(pt.createBezierPoints(R,D,L,O,F,W),(B-2)*3),[R,D,L,O]=[L,O,F,W]}}}for(let T=0,_=c.length;T<_;T++)g.push({line:S(c[T].map(k=>k??NaN),m,x,v,E),points:S(d[T].map(k=>k??NaN),m,x,v,E)});const C=new this.prototype.constructor;return C.build(g,s,a,1,h,f,l),C}#l(t=this.#c){const e=this.#i+t/2*this.#a;return this.#o%180===0?[e/this.#r,e/this.#s]:[e/this.#s,e/this.#r]}#h(){const[t,e,s,a]=this.#t,[l,c]=this.#l(0);return[t+l,e+c,s-2*l,a-2*c]}#d(){const t=this.#t=new Float32Array([1/0,1/0,-1/0,-1/0]);for(const{line:a}of this.#n){if(a.length<=12){for(let d=4,h=a.length;d<h;d+=6)gt.pointBoundingBox(a[d],a[d+1],t);continue}let l=a[4],c=a[5];for(let d=6,h=a.length;d<h;d+=6){const[f,g,m,x,v,E]=a.subarray(d,d+6);gt.bezierBoundingBox(l,c,f,g,m,x,v,E,t),l=v,c=E}}const[e,s]=this.#l();t[0]=Ve(t[0]-e,0,1),t[1]=Ve(t[1]-s,0,1),t[2]=Ve(t[2]+e,0,1),t[3]=Ve(t[3]+s,0,1),t[2]-=t[0],t[3]-=t[1]}get box(){return this.#t}updateProperty(t,e){return t==="stroke-width"?this.#f(e):null}#f(t){const[e,s]=this.#l();this.#c=t;const[a,l]=this.#l(),[c,d]=[a-e,l-s],h=this.#t;return h[0]-=c,h[1]-=d,h[2]+=2*c,h[3]+=2*d,h}updateParentDimensions([t,e],s){const[a,l]=this.#l();this.#r=t,this.#s=e,this.#a=s;const[c,d]=this.#l(),h=c-a,f=d-l,g=this.#t;return g[0]-=h,g[1]-=f,g[2]+=2*h,g[3]+=2*f,g}updateRotation(t){return this.#e=t,{path:{transform:this.rotationTransform}}}get viewBox(){return this.#t.map(pt.svgRound).join(" ")}get defaultProperties(){const[t,e]=this.#t;return{root:{viewBox:this.viewBox},path:{"transform-origin":`${pt.svgRound(t)} ${pt.svgRound(e)}`}}}get rotationTransform(){const[,,t,e]=this.#t;let s=0,a=0,l=0,c=0,d=0,h=0;switch(this.#e){case 90:a=e/t,l=-t/e,d=t;break;case 180:s=-1,c=-1,d=t,h=e;break;case 270:a=-e/t,l=t/e,h=e;break;default:return""}return`matrix(${s} ${a} ${l} ${c} ${pt.svgRound(d)} ${pt.svgRound(h)})`}getPathResizingSVGProperties([t,e,s,a]){const[l,c]=this.#l(),[d,h,f,g]=this.#t;if(Math.abs(f-l)<=pt.PRECISION||Math.abs(g-c)<=pt.PRECISION){const S=t+s/2-(d+f/2),C=e+a/2-(h+g/2);return{path:{"transform-origin":`${pt.svgRound(t)} ${pt.svgRound(e)}`,transform:`${this.rotationTransform} translate(${S} ${C})`}}}const m=(s-2*l)/(f-2*l),x=(a-2*c)/(g-2*c),v=f/s,E=g/a;return{path:{"transform-origin":`${pt.svgRound(d)} ${pt.svgRound(h)}`,transform:`${this.rotationTransform} scale(${v} ${E}) translate(${pt.svgRound(l)} ${pt.svgRound(c)}) scale(${m} ${x}) translate(${pt.svgRound(-l)} ${pt.svgRound(-c)})`}}}getPathResizedSVGProperties([t,e,s,a]){const[l,c]=this.#l(),d=this.#t,[h,f,g,m]=d;if(d[0]=t,d[1]=e,d[2]=s,d[3]=a,Math.abs(g-l)<=pt.PRECISION||Math.abs(m-c)<=pt.PRECISION){const C=t+s/2-(h+g/2),T=e+a/2-(f+m/2);for(const{line:_,points:k}of this.#n)pt._translate(_,C,T,_),pt._translate(k,C,T,k);return{root:{viewBox:this.viewBox},path:{"transform-origin":`${pt.svgRound(t)} ${pt.svgRound(e)}`,transform:this.rotationTransform||null,d:this.toSVGPath()}}}const x=(s-2*l)/(g-2*l),v=(a-2*c)/(m-2*c),E=-x*(h+l)+t+l,S=-v*(f+c)+e+c;if(x!==1||v!==1||E!==0||S!==0)for(const{line:C,points:T}of this.#n)pt._rescale(C,E,S,x,v,C),pt._rescale(T,E,S,x,v,T);return{root:{viewBox:this.viewBox},path:{"transform-origin":`${pt.svgRound(t)} ${pt.svgRound(e)}`,transform:this.rotationTransform||null,d:this.toSVGPath()}}}getPathTranslatedSVGProperties([t,e],s){const[a,l]=s,c=this.#t,d=t-c[0],h=e-c[1];if(this.#r===a&&this.#s===l)for(const{line:f,points:g}of this.#n)pt._translate(f,d,h,f),pt._translate(g,d,h,g);else{const f=this.#r/a,g=this.#s/l;this.#r=a,this.#s=l;for(const{line:m,points:x}of this.#n)pt._rescale(m,d,h,f,g,m),pt._rescale(x,d,h,f,g,x);c[2]*=f,c[3]*=g}return c[0]=t,c[1]=e,{root:{viewBox:this.viewBox},path:{d:this.toSVGPath(),"transform-origin":`${pt.svgRound(t)} ${pt.svgRound(e)}`}}}get defaultSVGProperties(){const t=this.#t;return{root:{viewBox:this.viewBox},rootClass:{draw:!0},path:{d:this.toSVGPath(),"transform-origin":`${pt.svgRound(t[0])} ${pt.svgRound(t[1])}`,transform:this.rotationTransform||null},bbox:t}}}class Iu extends E1{constructor(t){super(),this._viewParameters=t,super.updateProperties({fill:"none",stroke:St._defaultLineColor,"stroke-opacity":1,"stroke-width":1,"stroke-linecap":"round","stroke-linejoin":"round","stroke-miterlimit":10})}updateSVGProperty(t,e){t==="stroke-width"&&(e??=this["stroke-width"],e*=this._viewParameters.realScale),super.updateSVGProperty(t,e)}clone(){const t=new Iu(this._viewParameters);return t.updateAll(this),t}}class Up extends _t{static _type="ink";static _editorType=Dt.INK;static _defaultDrawingOptions=null;constructor(t){super({...t,name:"inkEditor"}),this._willKeepAspectRatio=!0,this.defaultL10nId="pdfjs-editor-ink-editor"}static initialize(t,e){St.initialize(t,e),this._defaultDrawingOptions=new Iu(e.viewParameters)}static getDefaultDrawingOptions(t){const e=this._defaultDrawingOptions.clone();return e.updateProperties(t),e}static get supportMultipleDrawings(){return!0}static get typesMap(){return jt(this,"typesMap",new Map([[Ft.INK_THICKNESS,"stroke-width"],[Ft.INK_COLOR,"stroke"],[Ft.INK_OPACITY,"stroke-opacity"]]))}static createDrawerInstance(t,e,s,a,l){return new yL(t,e,s,a,l,this._defaultDrawingOptions["stroke-width"])}static deserializeDraw(t,e,s,a,l,c){return yl.deserialize(t,e,s,a,l,c)}static async deserialize(t,e,s){let a=null;if(t instanceof $p){const{data:{inkLists:c,rect:d,rotation:h,id:f,color:g,opacity:m,borderStyle:{rawWidth:x},popupRef:v,richText:E,contentsObj:S,creationDate:C,modificationDate:T},parent:{page:{pageNumber:_}}}=t;a=t={annotationType:Dt.INK,color:Array.from(g),thickness:x,opacity:m,paths:{points:c},boxes:null,pageIndex:_-1,rect:d.slice(0),rotation:h,annotationElementId:f,id:f,deleted:!1,popupRef:v,richText:E,comment:S?.str||null,creationDate:C,modificationDate:T}}const l=await super.deserialize(t,e,s);return l._initialData=a,t.comment&&l.setCommentData(t),l}get toolbarButtons(){return this._colorPicker||=new ll(this),[["colorPicker",this._colorPicker]]}get colorType(){return Ft.INK_COLOR}get color(){return this._drawingOptions.stroke}get opacity(){return this._drawingOptions["stroke-opacity"]}onScaleChanging(){if(!this.parent)return;super.onScaleChanging();const{_drawId:t,_drawingOptions:e,parent:s}=this;e.updateSVGProperty("stroke-width"),s.drawLayer.updateProperties(t,e.toSVGProperties())}static onScaleChangingWhenDrawing(){const t=this._currentParent;t&&(super.onScaleChangingWhenDrawing(),this._defaultDrawingOptions.updateSVGProperty("stroke-width"),t.drawLayer.updateProperties(this._currentDrawId,this._defaultDrawingOptions.toSVGProperties()))}createDrawingOptions({color:t,thickness:e,opacity:s}){this._drawingOptions=Up.getDefaultDrawingOptions({stroke:gt.makeHexColor(...t),"stroke-width":e,"stroke-opacity":s})}serialize(t=!1){if(this.isEmpty())return null;if(this.deleted)return this.serializeDeleted();const{lines:e,points:s}=this.serializeDraw(t),{_drawingOptions:{stroke:a,"stroke-opacity":l,"stroke-width":c}}=this,d=Object.assign(super.serialize(t),{color:St._colorManager.convert(a),opacity:l,thickness:c,paths:{lines:e,points:s}});return this.addComment(d),t?(d.isCopy=!0,d):this.annotationElementId&&!this.#t(d)?null:(d.id=this.annotationElementId,d)}#t(t){const{color:e,thickness:s,opacity:a,pageIndex:l}=this._initialData;return this.hasEditedComment||this._hasBeenMoved||this._hasBeenResized||t.color.some((c,d)=>c!==e[d])||t.thickness!==s||t.opacity!==a||t.pageIndex!==l}renderAnnotationElement(t){if(this.deleted)return t.hide(),null;const{points:e,rect:s}=this.serializeDraw(!1);return t.updateEdited({rect:s,thickness:this._drawingOptions["stroke-width"],points:e,popup:this.comment}),null}}class sp extends yl{toSVGPath(){let t=super.toSVGPath();return t.endsWith("Z")||(t+="Z"),t}}const ru=8,qo=3;class Zs{static#t={maxDim:512,sigmaSFactor:.02,sigmaR:25,kernelSize:16};static#e(t,e,s,a){return s-=t,a-=e,s===0?a>0?0:4:s===1?a+6:2-a}static#i=new Int32Array([0,1,-1,1,-1,0,-1,-1,0,-1,1,-1,1,0,1,1]);static#n(t,e,s,a,l,c,d){const h=this.#e(s,a,l,c);for(let f=0;f<8;f++){const g=(-f+h-d+16)%8,m=this.#i[2*g],x=this.#i[2*g+1];if(t[(s+m)*e+(a+x)]!==0)return g}return-1}static#r(t,e,s,a,l,c,d){const h=this.#e(s,a,l,c);for(let f=0;f<8;f++){const g=(f+h+d+16)%8,m=this.#i[2*g],x=this.#i[2*g+1];if(t[(s+m)*e+(a+x)]!==0)return g}return-1}static#s(t,e,s,a){const l=t.length,c=new Int32Array(l);for(let g=0;g<l;g++)c[g]=t[g]<=a?1:0;for(let g=1;g<s-1;g++)c[g*e]=c[g*e+e-1]=0;for(let g=0;g<e;g++)c[g]=c[e*s-1-g]=0;let d=1,h;const f=[];for(let g=1;g<s-1;g++){h=1;for(let m=1;m<e-1;m++){const x=g*e+m,v=c[x];if(v===0)continue;let E=g,S=m;if(v===1&&c[x-1]===0)d+=1,S-=1;else if(v>=1&&c[x+1]===0)d+=1,S+=1,v>1&&(h=v);else{v!==1&&(h=Math.abs(v));continue}const C=[m,g],T=S===m+1,_={isHole:T,points:C,id:d,parent:0};f.push(_);let k;for(const Z of f)if(Z.id===h){k=Z;break}k?k.isHole?_.parent=T?k.parent:h:_.parent=T?h:k.parent:_.parent=T?h:0;const R=this.#n(c,e,g,m,E,S,0);if(R===-1){c[x]=-d,c[x]!==1&&(h=Math.abs(c[x]));continue}let D=this.#i[2*R],L=this.#i[2*R+1];const O=g+D,B=m+L;E=O,S=B;let F=g,W=m;for(;;){const Z=this.#r(c,e,F,W,E,S,1);D=this.#i[2*Z],L=this.#i[2*Z+1];const rt=F+D,dt=W+L;C.push(dt,rt);const lt=F*e+W;if(c[lt+1]===0?c[lt]=-d:c[lt]===1&&(c[lt]=d),rt===g&&dt===m&&F===O&&W===B){c[x]!==1&&(h=Math.abs(c[x]));break}else E=F,S=W,F=rt,W=dt}}}return f}static#a(t,e,s,a){if(s-e<=4){for(let O=e;O<s-2;O+=2)a.push(t[O],t[O+1]);return}const l=t[e],c=t[e+1],d=t[s-4]-l,h=t[s-3]-c,f=Math.hypot(d,h),g=d/f,m=h/f,x=g*c-m*l,v=h/d,E=1/f,S=Math.atan(v),C=Math.cos(S),T=Math.sin(S),_=E*(Math.abs(C)+Math.abs(T)),k=E*(1-_+_**2),R=Math.max(Math.atan(Math.abs(T+C)*k),Math.atan(Math.abs(T-C)*k));let D=0,L=e;for(let O=e+2;O<s-2;O+=2){const B=Math.abs(x-g*t[O+1]+m*t[O]);B>D&&(L=O,D=B)}D>(f*R)**2?(this.#a(t,e,L+2,a),this.#a(t,L,s,a)):a.push(l,c)}static#o(t){const e=[],s=t.length;return this.#a(t,0,s,e),e.push(t[s-2],t[s-1]),e.length<=4?null:e}static#c(t,e,s,a,l,c){const d=new Float32Array(c**2),h=-2*a**2,f=c>>1;for(let S=0;S<c;S++){const C=(S-f)**2;for(let T=0;T<c;T++)d[S*c+T]=Math.exp((C+(T-f)**2)/h)}const g=new Float32Array(256),m=-2*l**2;for(let S=0;S<256;S++)g[S]=Math.exp(S**2/m);const x=t.length,v=new Uint8Array(x),E=new Uint32Array(256);for(let S=0;S<s;S++)for(let C=0;C<e;C++){const T=S*e+C,_=t[T];let k=0,R=0;for(let L=0;L<c;L++){const O=S+L-f;if(!(O<0||O>=s))for(let B=0;B<c;B++){const F=C+B-f;if(F<0||F>=e)continue;const W=t[O*e+F],Z=d[L*c+B]*g[Math.abs(W-_)];k+=W*Z,R+=Z}}const D=v[T]=Math.round(k/R);E[D]++}return[v,E]}static#l(t){const e=new Uint32Array(256);for(const s of t)e[s]++;return e}static#h(t){const e=t.length,s=new Uint8ClampedArray(e>>2);let a=-1/0,l=1/0;for(let d=0,h=s.length;d<h;d++){const f=s[d]=t[d<<2];a=Math.max(a,f),l=Math.min(l,f)}const c=255/(a-l);for(let d=0,h=s.length;d<h;d++)s[d]=(s[d]-l)*c;return s}static#d(t){let e,s=-1/0,a=-1/0;const l=t.findIndex(h=>h!==0);let c=l,d=l;for(e=l;e<256;e++){const h=t[e];h>s&&(e-c>a&&(a=e-c,d=e-1),s=h,c=e)}for(e=d-1;e>=0&&!(t[e]>t[e+1]);e--);return e}static#f(t){const e=t,{width:s,height:a}=t,{maxDim:l}=this.#t;let c=s,d=a;if(s>l||a>l){let x=s,v=a,E=Math.log2(Math.max(s,a)/l);const S=Math.floor(E);E=E===S?S-1:S;for(let T=0;T<E;T++){c=Math.ceil(x/2),d=Math.ceil(v/2);const _=new OffscreenCanvas(c,d);_.getContext("2d").drawImage(t,0,0,x,v,0,0,c,d),x=c,v=d,t!==e&&t.close(),t=_.transferToImageBitmap()}const C=Math.min(l/c,l/d);c=Math.round(c*C),d=Math.round(d*C)}const f=new OffscreenCanvas(c,d).getContext("2d",{willReadFrequently:!0});f.fillStyle="white",f.fillRect(0,0,c,d),f.filter="grayscale(1)",f.drawImage(t,0,0,t.width,t.height,0,0,c,d);const g=f.getImageData(0,0,c,d).data;return[this.#h(g),c,d]}static extractContoursFromText(t,{fontFamily:e,fontStyle:s,fontWeight:a},l,c,d,h){let f=new OffscreenCanvas(1,1),g=f.getContext("2d",{alpha:!1});const m=200,x=g.font=`${s} ${a} ${m}px ${e}`,{actualBoundingBoxLeft:v,actualBoundingBoxRight:E,actualBoundingBoxAscent:S,actualBoundingBoxDescent:C,fontBoundingBoxAscent:T,fontBoundingBoxDescent:_,width:k}=g.measureText(t),R=1.5,D=Math.ceil(Math.max(Math.abs(v)+Math.abs(E)||0,k)*R),L=Math.ceil(Math.max(Math.abs(S)+Math.abs(C)||m,Math.abs(T)+Math.abs(_)||m)*R);f=new OffscreenCanvas(D,L),g=f.getContext("2d",{alpha:!0,willReadFrequently:!0}),g.font=x,g.filter="grayscale(1)",g.fillStyle="white",g.fillRect(0,0,D,L),g.fillStyle="black",g.fillText(t,D*(R-1)/2,L*(3-R)/2);const O=this.#h(g.getImageData(0,0,D,L).data),B=this.#l(O),F=this.#d(B),W=this.#s(O,D,L,F);return this.processDrawnLines({lines:{curves:W,width:D,height:L},pageWidth:l,pageHeight:c,rotation:d,innerMargin:h,mustSmooth:!0,areContours:!0})}static process(t,e,s,a,l){const[c,d,h]=this.#f(t),[f,g]=this.#c(c,d,h,Math.hypot(d,h)*this.#t.sigmaSFactor,this.#t.sigmaR,this.#t.kernelSize),m=this.#d(g),x=this.#s(f,d,h,m);return this.processDrawnLines({lines:{curves:x,width:d,height:h},pageWidth:e,pageHeight:s,rotation:a,innerMargin:l,mustSmooth:!0,areContours:!0})}static processDrawnLines({lines:t,pageWidth:e,pageHeight:s,rotation:a,innerMargin:l,mustSmooth:c,areContours:d}){a%180!==0&&([e,s]=[s,e]);const{curves:h,width:f,height:g}=t,m=t.thickness??0,x=[],v=Math.min(e/f,s/g),E=v/e,S=v/s,C=[];for(const{points:_}of h){const k=c?this.#o(_):_;if(!k)continue;C.push(k);const R=k.length,D=new Float32Array(R),L=new Float32Array(3*(R===2?2:R-2));if(x.push({line:L,points:D}),R===2){D[0]=k[0]*E,D[1]=k[1]*S,L.set([NaN,NaN,NaN,NaN,D[0],D[1]],0);continue}let[O,B,F,W]=k;O*=E,B*=S,F*=E,W*=S,D.set([O,B,F,W],0),L.set([NaN,NaN,NaN,NaN,O,B],0);for(let Z=4;Z<R;Z+=2){const rt=D[Z]=k[Z]*E,dt=D[Z+1]=k[Z+1]*S;L.set(pt.createBezierPoints(O,B,F,W,rt,dt),(Z-2)*3),[O,B,F,W]=[F,W,rt,dt]}}if(x.length===0)return null;const T=d?new sp:new yl;return T.build(x,e,s,1,a,d?0:m,l),{outline:T,newCurves:C,areContours:d,thickness:m,width:f,height:g}}static async compressSignature({outlines:t,areContours:e,thickness:s,width:a,height:l}){let c=1/0,d=-1/0,h=0;for(const k of t){h+=k.length;for(let R=2,D=k.length;R<D;R++){const L=k[R]-k[R-2];c=Math.min(c,L),d=Math.max(d,L)}}let f;c>=-128&&d<=127?f=Int8Array:c>=-32768&&d<=32767?f=Int16Array:f=Int32Array;const g=t.length,m=ru+qo*g,x=new Uint32Array(m);let v=0;x[v++]=m*Uint32Array.BYTES_PER_ELEMENT+(h-2*g)*f.BYTES_PER_ELEMENT,x[v++]=0,x[v++]=a,x[v++]=l,x[v++]=e?0:1,x[v++]=Math.max(0,Math.floor(s??0)),x[v++]=g,x[v++]=f.BYTES_PER_ELEMENT;for(const k of t)x[v++]=k.length-2,x[v++]=k[0],x[v++]=k[1];const E=new CompressionStream("deflate-raw"),S=E.writable.getWriter();await S.ready,S.write(x);const C=f.prototype.constructor;for(const k of t){const R=new C(k.length-2);for(let D=2,L=k.length;D<L;D++)R[D-2]=k[D]-k[D-2];S.write(R)}S.close();const T=await new Response(E.readable).arrayBuffer(),_=new Uint8Array(T);return Vv(_)}static async decompressSignature(t){try{const e=UD(t),{readable:s,writable:a}=new DecompressionStream("deflate-raw"),l=a.getWriter();await l.ready,l.write(e).then(async()=>{await l.ready,await l.close()}).catch(()=>{});let c=null,d=0;for await(const k of s)c||=new Uint8Array(new Uint32Array(k.buffer,0,4)[0]),c.set(k,d),d+=k.length;const h=new Uint32Array(c.buffer,0,c.length>>2),f=h[1];if(f!==0)throw new Error(`Invalid version: ${f}`);const g=h[2],m=h[3],x=h[4]===0,v=h[5],E=h[6],S=h[7],C=[],T=(ru+qo*E)*Uint32Array.BYTES_PER_ELEMENT;let _;switch(S){case Int8Array.BYTES_PER_ELEMENT:_=new Int8Array(c.buffer,T);break;case Int16Array.BYTES_PER_ELEMENT:_=new Int16Array(c.buffer,T);break;case Int32Array.BYTES_PER_ELEMENT:_=new Int32Array(c.buffer,T);break}d=0;for(let k=0;k<E;k++){const R=h[qo*k+ru],D=new Float32Array(R+2);C.push(D);for(let L=0;L<qo-1;L++)D[L]=h[qo*k+ru+L+1];for(let L=0;L<R;L++)D[L+2]=D[L]+_[d++]}return{areContours:x,thickness:v,outlines:C,width:g,height:m}}catch(e){return Rt(`decompressSignature: ${e}`),null}}}class Gp extends E1{constructor(){super(),super.updateProperties({fill:St._defaultLineColor,"stroke-width":0})}clone(){const t=new Gp;return t.updateAll(this),t}}class Vp extends Iu{constructor(t){super(t),super.updateProperties({stroke:St._defaultLineColor,"stroke-width":1})}clone(){const t=new Vp(this._viewParameters);return t.updateAll(this),t}}class si extends _t{#t=!1;#e=null;#i=null;#n=null;static _type="signature";static _editorType=Dt.SIGNATURE;static _defaultDrawingOptions=null;constructor(t){super({...t,mustBeCommitted:!0,name:"signatureEditor"}),this._willKeepAspectRatio=!0,this.#i=t.signatureData||null,this.#e=null,this.defaultL10nId="pdfjs-editor-signature-editor1"}static initialize(t,e){St.initialize(t,e),this._defaultDrawingOptions=new Gp,this._defaultDrawnSignatureOptions=new Vp(e.viewParameters)}static getDefaultDrawingOptions(t){const e=this._defaultDrawingOptions.clone();return e.updateProperties(t),e}static get supportMultipleDrawings(){return!1}static get typesMap(){return jt(this,"typesMap",new Map)}static get isDrawer(){return!1}get telemetryFinalData(){return{type:"signature",hasDescription:!!this.#e}}static computeTelemetryFinalData(t){const e=t.get("hasDescription");return{hasAltText:e.get(!0)??0,hasNoAltText:e.get(!1)??0}}get isResizable(){return!0}onScaleChanging(){this._drawId!==null&&super.onScaleChanging()}render(){if(this.div)return this.div;let t,e;const{_isCopy:s}=this;if(s&&(this._isCopy=!1,t=this.x,e=this.y),super.render(),this._drawId===null)if(this.#i){const{lines:a,mustSmooth:l,areContours:c,description:d,uuid:h,heightInPage:f}=this.#i,{rawDims:{pageWidth:g,pageHeight:m},rotation:x}=this.parent.viewport,v=Zs.processDrawnLines({lines:a,pageWidth:g,pageHeight:m,rotation:x,innerMargin:si._INNER_MARGIN,mustSmooth:l,areContours:c});this.addSignature(v,f,d,h)}else this.div.setAttribute("data-l10n-args",JSON.stringify({description:""})),this.div.hidden=!0,this._uiManager.getSignature(this);else this.div.setAttribute("data-l10n-args",JSON.stringify({description:this.#e||""}));return s&&(this._isCopy=!0,this._moveAfterPaste(t,e)),this.div}setUuid(t){this.#n=t,this.addEditToolbar()}getUuid(){return this.#n}get description(){return this.#e}set description(t){this.#e=t,this.div&&(this.div.setAttribute("data-l10n-args",JSON.stringify({description:t})),super.addEditToolbar().then(e=>{e?.updateEditSignatureButton(t)}))}getSignaturePreview(){const{newCurves:t,areContours:e,thickness:s,width:a,height:l}=this.#i,c=Math.max(a,l),d=Zs.processDrawnLines({lines:{curves:t.map(h=>({points:h})),thickness:s,width:a,height:l},pageWidth:c,pageHeight:c,rotation:0,innerMargin:0,mustSmooth:!1,areContours:e});return{areContours:e,outline:d.outline}}get toolbarButtons(){return this._uiManager.signatureManager?[["editSignature",this._uiManager.signatureManager]]:super.toolbarButtons}addSignature(t,e,s,a){const{x:l,y:c}=this,{outline:d}=this.#i=t;this.#t=d instanceof sp,this.description=s;let h;this.#t?h=si.getDefaultDrawingOptions():(h=si._defaultDrawnSignatureOptions.clone(),h.updateProperties({"stroke-width":d.thickness})),this._addOutlines({drawOutlines:d,drawingOptions:h});const[,f]=this.pageDimensions;let g=e/f;g=g>=1?.5:g,this.width*=g/this.height,this.width>=1&&(g*=.9/this.width,this.width=.9),this.height=g,this.setDims(),this.x=l,this.y=c,this.center(),this._onResized(),this.onScaleChanging(),this.rotate(),this._uiManager.addToAnnotationStorage(this),this.setUuid(a),this._reportTelemetry({action:"pdfjs.signature.inserted",data:{hasBeenSaved:!!a,hasDescription:!!s}}),this.div.hidden=!1}getFromImage(t){const{rawDims:{pageWidth:e,pageHeight:s},rotation:a}=this.parent.viewport;return Zs.process(t,e,s,a,si._INNER_MARGIN)}getFromText(t,e){const{rawDims:{pageWidth:s,pageHeight:a},rotation:l}=this.parent.viewport;return Zs.extractContoursFromText(t,e,s,a,l,si._INNER_MARGIN)}getDrawnSignature(t){const{rawDims:{pageWidth:e,pageHeight:s},rotation:a}=this.parent.viewport;return Zs.processDrawnLines({lines:t,pageWidth:e,pageHeight:s,rotation:a,innerMargin:si._INNER_MARGIN,mustSmooth:!1,areContours:!1})}createDrawingOptions({areContours:t,thickness:e}){t?this._drawingOptions=si.getDefaultDrawingOptions():(this._drawingOptions=si._defaultDrawnSignatureOptions.clone(),this._drawingOptions.updateProperties({"stroke-width":e}))}serialize(t=!1){if(this.isEmpty())return null;const{lines:e,points:s}=this.serializeDraw(t),{_drawingOptions:{"stroke-width":a}}=this,l=Object.assign(super.serialize(t),{isSignature:!0,areContours:this.#t,color:[0,0,0],thickness:this.#t?0:a});return this.addComment(l),t?(l.paths={lines:e,points:s},l.uuid=this.#n,l.isCopy=!0):l.lines=e,this.#e&&(l.accessibilityData={type:"Figure",alt:this.#e}),l}static deserializeDraw(t,e,s,a,l,c){return c.areContours?sp.deserialize(t,e,s,a,l,c):yl.deserialize(t,e,s,a,l,c)}static async deserialize(t,e,s){const a=await super.deserialize(t,e,s);return a.#t=t.areContours,a.description=t.accessibilityData?.alt||"",a.#n=t.uuid,a}}class xL extends St{#t=null;#e=null;#i=null;#n=null;#r=null;#s="";#a=null;#o=!1;#c=null;#l=!1;#h=!1;static _type="stamp";static _editorType=Dt.STAMP;constructor(t){super({...t,name:"stampEditor"}),this.#n=t.bitmapUrl,this.#r=t.bitmapFile,this.defaultL10nId="pdfjs-editor-stamp-editor"}static initialize(t,e){St.initialize(t,e)}static isHandlingMimeForPasting(t){return Su.includes(t)}static paste(t,e){e.pasteEditor({mode:Dt.STAMP},{bitmapFile:t.getAsFile()})}altTextFinish(){this._uiManager.useNewAltTextFlow&&(this.div.hidden=!1),super.altTextFinish()}get telemetryFinalData(){return{type:"stamp",hasAltText:!!this.altTextData?.altText}}static computeTelemetryFinalData(t){const e=t.get("hasAltText");return{hasAltText:e.get(!0)??0,hasNoAltText:e.get(!1)??0}}#d(t,e=!1){if(!t){this.remove();return}this.#t=t.bitmap,e||(this.#e=t.id,this.#l=t.isSvg),t.file&&(this.#s=t.file.name),this.#p()}#f(){if(this.#i=null,this._uiManager.enableWaiting(!1),!!this.#a){if(this._uiManager.useNewAltTextWhenAddingImage&&this._uiManager.useNewAltTextFlow&&this.#t){this.addEditToolbar().then(()=>{this._editToolbar.hide(),this._uiManager.editAltText(this,!0)});return}if(!this._uiManager.useNewAltTextWhenAddingImage&&this._uiManager.useNewAltTextFlow&&this.#t){this._reportTelemetry({action:"pdfjs.image.image_added",data:{alt_text_modal:!1,alt_text_type:"empty"}});try{this.mlGuessAltText()}catch{}}this.div.focus()}}async mlGuessAltText(t=null,e=!0){if(this.hasAltTextData())return null;const{mlManager:s}=this._uiManager;if(!s)throw new Error("No ML.");if(!await s.isEnabledFor("altText"))throw new Error("ML isn't enabled for alt text.");const{data:a,width:l,height:c}=t||this.copyCanvas(null,null,!0).imageData,d=await s.guess({name:"altText",request:{data:a,width:l,height:c,channels:a.length/(l*c)}});if(!d)throw new Error("No response from the AI service.");if(d.error)throw new Error("Error from the AI service.");if(d.cancel)return null;if(!d.output)throw new Error("No valid response from the AI service.");const h=d.output;return await this.setGuessedAltText(h),e&&!this.hasAltTextData()&&(this.altTextData={alt:h,decorative:!1}),h}#m(){if(this.#e){this._uiManager.enableWaiting(!0),this._uiManager.imageManager.getFromId(this.#e).then(s=>this.#d(s,!0)).finally(()=>this.#f());return}if(this.#n){const s=this.#n;this.#n=null,this._uiManager.enableWaiting(!0),this.#i=this._uiManager.imageManager.getFromUrl(s).then(a=>this.#d(a)).finally(()=>this.#f());return}if(this.#r){const s=this.#r;this.#r=null,this._uiManager.enableWaiting(!0),this.#i=this._uiManager.imageManager.getFromFile(s).then(a=>this.#d(a)).finally(()=>this.#f());return}const t=document.createElement("input");t.type="file",t.accept=Su.join(",");const e=this._uiManager._signal;this.#i=new Promise(s=>{t.addEventListener("change",async()=>{if(!t.files||t.files.length===0)this.remove();else{this._uiManager.enableWaiting(!0);const a=await this._uiManager.imageManager.getFromFile(t.files[0]);this._reportTelemetry({action:"pdfjs.image.image_selected",data:{alt_text_modal:this._uiManager.useNewAltTextFlow}}),this.#d(a)}s()},{signal:e}),t.addEventListener("cancel",()=>{this.remove(),s()},{signal:e})}).finally(()=>this.#f()),t.click()}remove(){this.#e&&(this.#t=null,this._uiManager.imageManager.deleteId(this.#e),this.#a?.remove(),this.#a=null,this.#c&&(clearTimeout(this.#c),this.#c=null)),super.remove()}rebuild(){if(!this.parent){this.#e&&this.#m();return}super.rebuild(),this.div!==null&&(this.#e&&this.#a===null&&this.#m(),this.isAttachedToDOM||this.parent.add(this))}onceAdded(t){this._isDraggable=!0,t&&this.div.focus()}isEmpty(){return!(this.#i||this.#t||this.#n||this.#r||this.#e||this.#o)}get toolbarButtons(){return[["altText",this.createAltText()]]}get isResizable(){return!0}render(){if(this.div)return this.div;let t,e;return this._isCopy&&(t=this.x,e=this.y),super.render(),this.div.hidden=!0,this.createAltText(),this.#o||(this.#t?this.#p():this.#m()),this._isCopy&&this._moveAfterPaste(t,e),this._uiManager.addShouldRescale(this),this.div}setCanvas(t,e){const{id:s,bitmap:a}=this._uiManager.imageManager.getFromCanvas(t,e);e.remove(),s&&this._uiManager.imageManager.isValidId(s)&&(this.#e=s,a&&(this.#t=a),this.#o=!1,this.#p())}_onResized(){this.onScaleChanging()}onScaleChanging(){if(!this.parent)return;this.#c!==null&&clearTimeout(this.#c);const t=200;this.#c=setTimeout(()=>{this.#c=null,this.#g()},t)}#p(){const{div:t}=this;let{width:e,height:s}=this.#t;const[a,l]=this.pageDimensions,c=.75;if(this.width)e=this.width*a,s=this.height*l;else if(e>c*a||s>c*l){const h=Math.min(c*a/e,c*l/s);e*=h,s*=h}this._uiManager.enableWaiting(!1);const d=this.#a=document.createElement("canvas");d.setAttribute("role","img"),this.addContainer(d),this.width=e/a,this.height=s/l,this.setDims(),this._initialOptions?.isCentered?this.center():this.fixAndSetPosition(),this._initialOptions=null,(!this._uiManager.useNewAltTextWhenAddingImage||!this._uiManager.useNewAltTextFlow||this.annotationElementId)&&(t.hidden=!1),this.#g(),this.#h||(this.parent.addUndoableEditor(this),this.#h=!0),this._reportTelemetry({action:"inserted_image"}),this.#s&&this.div.setAttribute("aria-description",this.#s),this.annotationElementId||this._uiManager.a11yAlert("pdfjs-editor-stamp-added-alert")}copyCanvas(t,e,s=!1){t||(t=224);const{width:a,height:l}=this.#t,c=new Wn;let d=this.#t,h=a,f=l,g=null;if(e){if(a>e||l>e){const L=Math.min(e/a,e/l);h=Math.floor(a*L),f=Math.floor(l*L)}g=document.createElement("canvas");const x=g.width=Math.ceil(h*c.sx),v=g.height=Math.ceil(f*c.sy);this.#l||(d=this.#u(x,v));const E=g.getContext("2d");E.filter=this._uiManager.hcmFilter;let S="white",C="#cfcfd8";this._uiManager.hcmFilter!=="none"?C="black":qD.isDarkMode&&(S="#8f8f9d",C="#42414d");const T=15,_=T*c.sx,k=T*c.sy,R=new OffscreenCanvas(_*2,k*2),D=R.getContext("2d");D.fillStyle=S,D.fillRect(0,0,_*2,k*2),D.fillStyle=C,D.fillRect(0,0,_,k),D.fillRect(_,k,_,k),E.fillStyle=E.createPattern(R,"repeat"),E.fillRect(0,0,x,v),E.drawImage(d,0,0,d.width,d.height,0,0,x,v)}let m=null;if(s){let x,v;if(c.symmetric&&d.width<t&&d.height<t)x=d.width,v=d.height;else if(d=this.#t,a>t||l>t){const C=Math.min(t/a,t/l);x=Math.floor(a*C),v=Math.floor(l*C),this.#l||(d=this.#u(x,v))}const S=new OffscreenCanvas(x,v).getContext("2d",{willReadFrequently:!0});S.drawImage(d,0,0,d.width,d.height,0,0,x,v),m={width:x,height:v,data:S.getImageData(0,0,x,v).data}}return{canvas:g,width:h,height:f,imageData:m}}#u(t,e){const{width:s,height:a}=this.#t;let l=s,c=a,d=this.#t;for(;l>2*t||c>2*e;){const h=l,f=c;l>2*t&&(l=l>=16384?Math.floor(l/2)-1:Math.ceil(l/2)),c>2*e&&(c=c>=16384?Math.floor(c/2)-1:Math.ceil(c/2));const g=new OffscreenCanvas(l,c);g.getContext("2d").drawImage(d,0,0,h,f,0,0,l,c),d=g.transferToImageBitmap()}return d}#g(){const[t,e]=this.parentDimensions,{width:s,height:a}=this,l=new Wn,c=Math.ceil(s*t*l.sx),d=Math.ceil(a*e*l.sy),h=this.#a;if(!h||h.width===c&&h.height===d)return;h.width=c,h.height=d;const f=this.#l?this.#t:this.#u(c,d),g=h.getContext("2d");g.filter=this._uiManager.hcmFilter,g.drawImage(f,0,0,f.width,f.height,0,0,c,d)}#b(t){if(t){if(this.#l){const a=this._uiManager.imageManager.getSvgUrl(this.#e);if(a)return a}const e=document.createElement("canvas");return{width:e.width,height:e.height}=this.#t,e.getContext("2d").drawImage(this.#t,0,0),e.toDataURL()}if(this.#l){const[e,s]=this.pageDimensions,a=Math.round(this.width*e*da.PDF_TO_CSS_UNITS),l=Math.round(this.height*s*da.PDF_TO_CSS_UNITS),c=new OffscreenCanvas(a,l);return c.getContext("2d").drawImage(this.#t,0,0,this.#t.width,this.#t.height,0,0,a,l),c.transferToImageBitmap()}return structuredClone(this.#t)}static async deserialize(t,e,s){let a=null,l=!1;if(t instanceof A1){const{data:{rect:S,rotation:C,id:T,structParent:_,popupRef:k,richText:R,contentsObj:D,creationDate:L,modificationDate:O},container:B,parent:{page:{pageNumber:F}},canvas:W}=t;let Z,rt;W?(delete t.canvas,{id:Z,bitmap:rt}=s.imageManager.getFromCanvas(B.id,W),W.remove()):(l=!0,t._hasNoCanvas=!0);const dt=(await e._structTree.getAriaAttributes(`${_p}${T}`))?.get("aria-label")||"";a=t={annotationType:Dt.STAMP,bitmapId:Z,bitmap:rt,pageIndex:F-1,rect:S.slice(0),rotation:C,annotationElementId:T,id:T,deleted:!1,accessibilityData:{decorative:!1,altText:dt},isSvg:!1,structParent:_,popupRef:k,richText:R,comment:D?.str||null,creationDate:L,modificationDate:O}}const c=await super.deserialize(t,e,s),{rect:d,bitmap:h,bitmapUrl:f,bitmapId:g,isSvg:m,accessibilityData:x}=t;l?(s.addMissingCanvas(t.id,c),c.#o=!0):g&&s.imageManager.isValidId(g)?(c.#e=g,h&&(c.#t=h)):c.#n=f,c.#l=m;const[v,E]=c.pageDimensions;return c.width=(d[2]-d[0])/v,c.height=(d[3]-d[1])/E,x&&(c.altTextData=x),c._initialData=a,t.comment&&c.setCommentData(t),c.#h=!!a,c}serialize(t=!1,e=null){if(this.isEmpty())return null;if(this.deleted)return this.serializeDeleted();const s=Object.assign(super.serialize(t),{bitmapId:this.#e,isSvg:this.#l});if(this.addComment(s),t)return s.bitmapUrl=this.#b(!0),s.accessibilityData=this.serializeAltText(!0),s.isCopy=!0,s;const{decorative:a,altText:l}=this.serializeAltText(!1);if(!a&&l&&(s.accessibilityData={type:"Figure",alt:l}),this.annotationElementId){const d=this.#x(s);return d.isSame?null:(d.isSameAltText?delete s.accessibilityData:s.accessibilityData.structParent=this._initialData.structParent??-1,s.id=this.annotationElementId,delete s.bitmapId,s)}if(e===null)return s;e.stamps||=new Map;const c=this.#l?(s.rect[2]-s.rect[0])*(s.rect[3]-s.rect[1]):null;if(!e.stamps.has(this.#e))e.stamps.set(this.#e,{area:c,serialized:s}),s.bitmap=this.#b(!1);else if(this.#l){const d=e.stamps.get(this.#e);c>d.area&&(d.area=c,d.serialized.bitmap.close(),d.serialized.bitmap=this.#b(!1))}return s}#x(t){const{pageIndex:e,accessibilityData:{altText:s}}=this._initialData,a=t.pageIndex===e,l=(t.accessibilityData?.alt||"")===s;return{isSame:!this.hasEditedComment&&!this._hasBeenMoved&&!this._hasBeenResized&&a&&l,isSameAltText:l}}renderAnnotationElement(t){return this.deleted?(t.hide(),null):(t.updateEdited({rect:this.getPDFRect(),popup:this.comment}),null)}}class ri{#t;#e=!1;#i=null;#n=null;#r=null;#s=new Map;#a=!1;#o=!1;#c=!1;#l=null;#h=null;#d=null;#f=null;#m=null;#p=-1;#u;static _initialized=!1;static#g=new Map([Re,Up,xL,ve,si].map(t=>[t._editorType,t]));constructor({uiManager:t,pageIndex:e,div:s,structTreeLayer:a,accessibilityManager:l,annotationLayer:c,drawLayer:d,textLayer:h,viewport:f,l10n:g}){const m=[...ri.#g.values()];if(!ri._initialized){ri._initialized=!0;for(const x of m)x.initialize(g,t)}t.registerEditorTypes(m),this.#u=t,this.pageIndex=e,this.div=s,this.#t=l,this.#i=c,this.viewport=f,this.#d=h,this.drawLayer=d,this._structTree=a,this.#u.addLayer(this)}get isEmpty(){return this.#s.size===0}get isInvisible(){return this.isEmpty&&this.#u.getMode()===Dt.NONE}updateToolbar(t){this.#u.updateToolbar(t)}updateMode(t=this.#u.getMode()){switch(this.#v(),t){case Dt.NONE:this.div.classList.toggle("nonEditing",!0),this.disableTextSelection(),this.togglePointerEvents(!1),this.toggleAnnotationLayerPointerEvents(!0),this.disableClick();return;case Dt.INK:this.disableTextSelection(),this.togglePointerEvents(!0),this.enableClick();break;case Dt.HIGHLIGHT:this.enableTextSelection(),this.togglePointerEvents(!1),this.disableClick();break;default:this.disableTextSelection(),this.togglePointerEvents(!0),this.enableClick()}this.toggleAnnotationLayerPointerEvents(!1);const{classList:e}=this.div;if(e.toggle("nonEditing",!1),t===Dt.POPUP)e.toggle("commentEditing",!0);else{e.toggle("commentEditing",!1);for(const s of ri.#g.values())e.toggle(`${s._type}Editing`,t===s._editorType)}this.div.hidden=!1}hasTextLayer(t){return t===this.#d?.div}setEditingState(t){this.#u.setEditingState(t)}addCommands(t){this.#u.addCommands(t)}cleanUndoStack(t){this.#u.cleanUndoStack(t)}toggleDrawing(t=!1){this.div.classList.toggle("drawing",!t)}togglePointerEvents(t=!1){this.div.classList.toggle("disabled",!t)}toggleAnnotationLayerPointerEvents(t=!1){this.#i?.div.classList.toggle("disabled",!t)}get#b(){return this.#s.size!==0?this.#s.values():this.#u.getEditors(this.pageIndex)}async enable(){this.#c=!0,this.div.tabIndex=0,this.togglePointerEvents(!0),this.div.classList.toggle("nonEditing",!1),this.#m?.abort(),this.#m=null;const t=new Set;for(const s of this.#b)s.enableEditing(),s.show(!0),s.annotationElementId&&(this.#u.removeChangedExistingAnnotation(s),t.add(s.annotationElementId));const e=this.#i;if(e)for(const s of e.getEditableAnnotations()){if(s.hide(),this.#u.isDeletedAnnotationElement(s.data.id)||t.has(s.data.id))continue;const a=await this.deserialize(s);a&&(this.addOrRebuild(a),a.enableEditing())}this.#c=!1,this.#u._eventBus.dispatch("editorsrendered",{source:this,pageNumber:this.pageIndex+1})}disable(){if(this.#o=!0,this.div.tabIndex=-1,this.togglePointerEvents(!1),this.div.classList.toggle("nonEditing",!0),this.#d&&!this.#m){this.#m=new AbortController;const s=this.#u.combinedSignal(this.#m);this.#d.div.addEventListener("pointerdown",a=>{const{clientX:c,clientY:d,timeStamp:h}=a,f=this.#p;if(h-f>500){this.#p=h;return}this.#p=-1;const{classList:g}=this.div;g.toggle("getElements",!0);const m=document.elementsFromPoint(c,d);if(g.toggle("getElements",!1),!this.div.contains(m[0]))return;let x;const v=new RegExp(`^${sl}[0-9]+$`);for(const S of m)if(v.test(S.id)){x=S.id;break}if(!x)return;const E=this.#s.get(x);E?.annotationElementId===null&&(a.stopPropagation(),a.preventDefault(),E.dblclick(a))},{signal:s,capture:!0})}const t=this.#i;if(t){const s=new Map,a=new Map;for(const c of this.#b){if(c.disableEditing(),!c.annotationElementId){c.updateFakeAnnotationElement(t);continue}if(c.serialize()!==null){s.set(c.annotationElementId,c);continue}else a.set(c.annotationElementId,c);this.getEditableAnnotation(c.annotationElementId)?.show(),c.remove()}const l=t.getEditableAnnotations();for(const c of l){const{id:d}=c.data;if(this.#u.isDeletedAnnotationElement(d)){c.updateEdited({deleted:!0});continue}let h=a.get(d);if(h){h.resetAnnotationElement(c),h.show(!1),c.show();continue}h=s.get(d),h&&(this.#u.addChangedExistingAnnotation(h),h.renderAnnotationElement(c)&&h.show(!1)),c.show()}}this.#v(),this.isEmpty&&(this.div.hidden=!0);const{classList:e}=this.div;for(const s of ri.#g.values())e.remove(`${s._type}Editing`);this.disableTextSelection(),this.toggleAnnotationLayerPointerEvents(!0),this.#o=!1}getEditableAnnotation(t){return this.#i?.getEditableAnnotation(t)||null}setActiveEditor(t){this.#u.getActive()!==t&&this.#u.setActiveEditor(t)}enableTextSelection(){if(this.div.tabIndex=-1,this.#d?.div&&!this.#f){this.#f=new AbortController;const t=this.#u.combinedSignal(this.#f);this.#d.div.addEventListener("pointerdown",this.#x.bind(this),{signal:t}),this.#d.div.classList.add("highlighting")}}disableTextSelection(){this.div.tabIndex=0,this.#d?.div&&this.#f&&(this.#f.abort(),this.#f=null,this.#d.div.classList.remove("highlighting"))}#x(t){this.#u.unselectAll();const{target:e}=t;if(e===this.#d.div||(e.getAttribute("role")==="img"||e.classList.contains("endOfContent"))&&this.#d.div.contains(e)){const{isMac:s}=je.platform;if(t.button!==0||t.ctrlKey&&s)return;this.#u.showAllEditors("highlight",!0,!0),this.#d.div.classList.add("free"),this.toggleDrawing(),ve.startHighlighting(this,this.#u.direction==="ltr",{target:this.#d.div,x:t.x,y:t.y}),this.#d.div.addEventListener("pointerup",()=>{this.#d.div.classList.remove("free"),this.toggleDrawing(!0)},{once:!0,signal:this.#u._signal}),t.preventDefault()}}enableClick(){if(this.#n)return;this.#n=new AbortController;const t=this.#u.combinedSignal(this.#n);this.div.addEventListener("pointerdown",this.pointerdown.bind(this),{signal:t});const e=this.pointerup.bind(this);this.div.addEventListener("pointerup",e,{signal:t}),this.div.addEventListener("pointercancel",e,{signal:t})}disableClick(){this.#n?.abort(),this.#n=null}attach(t){this.#s.set(t.id,t);const{annotationElementId:e}=t;e&&this.#u.isDeletedAnnotationElement(e)&&this.#u.removeDeletedAnnotationElement(t)}detach(t){this.#s.delete(t.id),this.#t?.removePointerInTextLayer(t.contentDiv),!this.#o&&t.annotationElementId&&this.#u.addDeletedAnnotationElement(t)}remove(t){this.detach(t),this.#u.removeEditor(t),t.div.remove(),t.isAttachedToDOM=!1}changeParent(t){t.parent!==this&&(t.parent&&t.annotationElementId&&(this.#u.addDeletedAnnotationElement(t.annotationElementId),St.deleteAnnotationElement(t),t.annotationElementId=null),this.attach(t),t.parent?.detach(t),t.setParent(this),t.div&&t.isAttachedToDOM&&(t.div.remove(),this.div.append(t.div)))}add(t){if(!(t.parent===this&&t.isAttachedToDOM)){if(this.changeParent(t),this.#u.addEditor(t),this.attach(t),!t.isAttachedToDOM){const e=t.render();this.div.append(e),t.isAttachedToDOM=!0}t.fixAndSetPosition(),t.onceAdded(!this.#c),this.#u.addToAnnotationStorage(t),t._reportTelemetry(t.telemetryInitialData)}}moveEditorInDOM(t){if(!t.isAttachedToDOM)return;const{activeElement:e}=document;t.div.contains(e)&&!this.#r&&(t._focusEventsAllowed=!1,this.#r=setTimeout(()=>{this.#r=null,t.div.contains(document.activeElement)?t._focusEventsAllowed=!0:(t.div.addEventListener("focusin",()=>{t._focusEventsAllowed=!0},{once:!0,signal:this.#u._signal}),e.focus())},0)),t._structTreeParentId=this.#t?.moveElementInDOM(this.div,t.div,t.contentDiv,!0)}addOrRebuild(t){t.needsToBeRebuilt()?(t.parent||=this,t.rebuild(),t.show()):this.add(t)}addUndoableEditor(t){const e=()=>t._uiManager.rebuild(t),s=()=>{t.remove()};this.addCommands({cmd:e,undo:s,mustExec:!1})}getEditorByUID(t){for(const e of this.#s.values())if(e.uid===t)return e;return null}getNextId(){return this.#u.getId()}get#y(){return ri.#g.get(this.#u.getMode())}combinedSignal(t){return this.#u.combinedSignal(t)}#T(t){const e=this.#y;return e?new e.prototype.constructor(t):null}canCreateNewEmptyEditor(){return this.#y?.canCreateNewEmptyEditor()}async pasteEditor(t,e){this.updateToolbar(t),await this.#u.updateMode(t.mode);const{offsetX:s,offsetY:a}=this.#S(),l=this.getNextId(),c=this.#T({parent:this,id:l,x:s,y:a,uiManager:this.#u,isCentered:!0,...e});c&&this.add(c)}async deserialize(t){return await ri.#g.get(t.annotationType??t.annotationEditorType)?.deserialize(t,this,this.#u)||null}createAndAddNewEditor(t,e,s={}){const a=this.getNextId(),l=this.#T({parent:this,id:a,x:t.offsetX,y:t.offsetY,uiManager:this.#u,isCentered:e,...s});return l&&this.add(l),l}get boundingClientRect(){return this.div.getBoundingClientRect()}#S(){const{x:t,y:e,width:s,height:a}=this.boundingClientRect,l=Math.max(0,t),c=Math.max(0,e),d=Math.min(window.innerWidth,t+s),h=Math.min(window.innerHeight,e+a),f=(l+d)/2-t,g=(c+h)/2-e,[m,x]=this.viewport.rotation%180===0?[f,g]:[g,f];return{offsetX:m,offsetY:x}}addNewEditor(t={}){this.createAndAddNewEditor(this.#S(),!0,t)}setSelected(t){this.#u.setSelected(t)}toggleSelected(t){this.#u.toggleSelected(t)}unselect(t){this.#u.unselect(t)}pointerup(t){const{isMac:e}=je.platform;if(t.button!==0||t.ctrlKey&&e||t.target!==this.div||!this.#a||(this.#a=!1,this.#y?.isDrawer&&this.#y.supportMultipleDrawings))return;if(!this.#e){this.#e=!0;return}const s=this.#u.getMode();if(s===Dt.STAMP||s===Dt.SIGNATURE){this.#u.unselectAll();return}this.createAndAddNewEditor(t,!1)}pointerdown(t){if(this.#u.getMode()===Dt.HIGHLIGHT&&this.enableTextSelection(),this.#a){this.#a=!1;return}const{isMac:e}=je.platform;if(t.button!==0||t.ctrlKey&&e||t.target!==this.div)return;if(this.#a=!0,this.#y?.isDrawer){this.startDrawingSession(t);return}const s=this.#u.getActive();this.#e=!s||s.isEmpty()}startDrawingSession(t){if(this.div.focus({preventScroll:!0}),this.#l){this.#y.startDrawing(this,this.#u,!1,t);return}this.#u.setCurrentDrawingSession(this),this.#l=new AbortController;const e=this.#u.combinedSignal(this.#l);this.div.addEventListener("blur",({relatedTarget:s})=>{s&&!this.div.contains(s)&&(this.#h=null,this.commitOrRemove())},{signal:e}),this.#y.startDrawing(this,this.#u,!1,t)}pause(t){if(t){const{activeElement:e}=document;this.div.contains(e)&&(this.#h=e);return}this.#h&&setTimeout(()=>{this.#h?.focus(),this.#h=null},0)}endDrawingSession(t=!1){return this.#l?(this.#u.setCurrentDrawingSession(null),this.#l.abort(),this.#l=null,this.#h=null,this.#y.endDrawing(t)):null}findNewParent(t,e,s){const a=this.#u.findParent(e,s);return a===null||a===this?!1:(a.changeParent(t),!0)}commitOrRemove(){return this.#l?(this.endDrawingSession(),!0):!1}onScaleChanging(){this.#l&&this.#y.onScaleChangingWhenDrawing(this)}destroy(){this.commitOrRemove(),this.#u.getActive()?.parent===this&&(this.#u.commitOrRemove(),this.#u.setActiveEditor(null)),this.#r&&(clearTimeout(this.#r),this.#r=null);for(const t of this.#s.values())this.#t?.removePointerInTextLayer(t.contentDiv),t.setParent(null),t.isAttachedToDOM=!1,t.div.remove();this.div=null,this.#s.clear(),this.#u.removeLayer(this)}#v(){for(const t of this.#s.values())t.isEmpty()&&t.remove()}render({viewport:t}){this.viewport=t,_s(this.div,t);for(const e of this.#u.getEditors(this.pageIndex))this.add(e),e.rebuild();this.updateMode()}update({viewport:t}){this.#u.commitOrRemove(),this.#v();const e=this.viewport.rotation,s=t.rotation;if(this.viewport=t,_s(this.div,{rotation:s}),e!==s)for(const a of this.#s.values())a.rotate(s)}get pageDimensions(){const{pageWidth:t,pageHeight:e}=this.viewport.rawDims;return[t,e]}get scale(){return this.#u.viewParameters.realScale}}class Le{#t=null;#e=new Map;#i=new Map;static#n=0;constructor({pageIndex:t}){this.pageIndex=t}setParent(t){if(!this.#t){this.#t=t;return}if(this.#t!==t){if(this.#e.size>0)for(const e of this.#e.values())e.remove(),t.append(e);this.#t=t}}static get _svgFactory(){return jt(this,"_svgFactory",new cl)}static#r(t,[e,s,a,l]){const{style:c}=t;c.top=`${100*s}%`,c.left=`${100*e}%`,c.width=`${100*a}%`,c.height=`${100*l}%`}#s(){const t=Le._svgFactory.create(1,1,!0);return this.#t.append(t),t.setAttribute("aria-hidden",!0),t}#a(t,e){const s=Le._svgFactory.createElement("clipPath");t.append(s);const a=`clip_${e}`;s.setAttribute("id",a),s.setAttribute("clipPathUnits","objectBoundingBox");const l=Le._svgFactory.createElement("use");return s.append(l),l.setAttribute("href",`#${e}`),l.classList.add("clip"),a}#o(t,e){for(const[s,a]of Object.entries(e))a===null?t.removeAttribute(s):t.setAttribute(s,a)}draw(t,e=!1,s=!1){const a=Le.#n++,l=this.#s(),c=Le._svgFactory.createElement("defs");l.append(c);const d=Le._svgFactory.createElement("path");c.append(d);const h=`path_p${this.pageIndex}_${a}`;d.setAttribute("id",h),d.setAttribute("vector-effect","non-scaling-stroke"),e&&this.#i.set(a,d);const f=s?this.#a(c,h):null,g=Le._svgFactory.createElement("use");return l.append(g),g.setAttribute("href",`#${h}`),this.updateProperties(l,t),this.#e.set(a,l),{id:a,clipPathId:`url(#${f})`}}drawOutline(t,e){const s=Le.#n++,a=this.#s(),l=Le._svgFactory.createElement("defs");a.append(l);const c=Le._svgFactory.createElement("path");l.append(c);const d=`path_p${this.pageIndex}_${s}`;c.setAttribute("id",d),c.setAttribute("vector-effect","non-scaling-stroke");let h;if(e){const m=Le._svgFactory.createElement("mask");l.append(m),h=`mask_p${this.pageIndex}_${s}`,m.setAttribute("id",h),m.setAttribute("maskUnits","objectBoundingBox");const x=Le._svgFactory.createElement("rect");m.append(x),x.setAttribute("width","1"),x.setAttribute("height","1"),x.setAttribute("fill","white");const v=Le._svgFactory.createElement("use");m.append(v),v.setAttribute("href",`#${d}`),v.setAttribute("stroke","none"),v.setAttribute("fill","black"),v.setAttribute("fill-rule","nonzero"),v.classList.add("mask")}const f=Le._svgFactory.createElement("use");a.append(f),f.setAttribute("href",`#${d}`),h&&f.setAttribute("mask",`url(#${h})`);const g=f.cloneNode();return a.append(g),f.classList.add("mainOutline"),g.classList.add("secondaryOutline"),this.updateProperties(a,t),this.#e.set(s,a),s}finalizeDraw(t,e){this.#i.delete(t),this.updateProperties(t,e)}updateProperties(t,e){if(!e)return;const{root:s,bbox:a,rootClass:l,path:c}=e,d=typeof t=="number"?this.#e.get(t):t;if(d){if(s&&this.#o(d,s),a&&Le.#r(d,a),l){const{classList:h}=d;for(const[f,g]of Object.entries(l))h.toggle(f,g)}if(c){const f=d.firstChild.firstChild;this.#o(f,c)}}}updateParent(t,e){if(e===this)return;const s=this.#e.get(t);s&&(e.#t.append(s),this.#e.delete(t),e.#e.set(t,s))}remove(t){this.#i.delete(t),this.#t!==null&&(this.#e.get(t).remove(),this.#e.delete(t))}destroy(){this.#t=null;for(const t of this.#e.values())t.remove();this.#e.clear(),this.#i.clear()}}globalThis._pdfjsTestingUtils={HighlightOutliner:np};globalThis.pdfjsLib={AbortException:Bi,AnnotationEditorLayer:ri,AnnotationEditorParamsType:Ft,AnnotationEditorType:Dt,AnnotationEditorUIManager:zi,AnnotationLayer:Hp,AnnotationMode:oi,AnnotationType:xe,applyOpacity:Qv,build:m1,ColorPicker:vn,createValidAbsoluteUrl:Ep,CSSConstants:Wv,DOMSVGFactory:cl,DrawLayer:Le,FeatureTest:je,fetchData:Hr,findContrastColor:Kv,getDocument:Bp,getFilenameFromUrl:qv,getPdfFilenameFromUrl:Yv,getRGB:Ur,getUuid:Cp,getXfaPageViewport:Xv,GlobalWorkerOptions:Ss,ImageKind:Zo,InvalidPDFException:Au,isDataScheme:pl,isPdfFile:zu,isValidExplicitDest:e1,MathClamp:Ve,noContextMenu:wn,normalizeUnicode:Gv,OPS:Pr,OutputScale:Wn,PasswordResponses:Hv,PDFDataRangeTransport:Pp,PDFDateString:wu,PDFWorker:Ir,PermissionFlag:$v,PixelsPerInch:da,RenderingCancelledException:Bu,renderRichText:Mp,ResponseException:al,setLayerDimensions:_s,shadow:jt,SignatureExtractor:Zs,stopEvent:he,SupportedImageMimeTypes:Su,TextLayer:ol,TouchManager:ml,updateUrlHash:Tp,Util:gt,VerbosityLevel:dl,version:Ip,XfaLayer:kp};const vL=Object.freeze(Object.defineProperty({__proto__:null,AbortException:Bi,AnnotationEditorLayer:ri,AnnotationEditorParamsType:Ft,AnnotationEditorType:Dt,AnnotationEditorUIManager:zi,AnnotationLayer:Hp,AnnotationMode:oi,AnnotationType:xe,CSSConstants:Wv,ColorPicker:vn,DOMSVGFactory:cl,DrawLayer:Le,FeatureTest:je,GlobalWorkerOptions:Ss,ImageKind:Zo,InvalidPDFException:Au,MathClamp:Ve,OPS:Pr,OutputScale:Wn,PDFDataRangeTransport:Pp,PDFDateString:wu,PDFWorker:Ir,PasswordResponses:Hv,PermissionFlag:$v,PixelsPerInch:da,RenderingCancelledException:Bu,ResponseException:al,SignatureExtractor:Zs,SupportedImageMimeTypes:Su,TextLayer:ol,TouchManager:ml,Util:gt,VerbosityLevel:dl,XfaLayer:kp,applyOpacity:Qv,build:m1,createValidAbsoluteUrl:Ep,fetchData:Hr,findContrastColor:Kv,getDocument:Bp,getFilenameFromUrl:qv,getPdfFilenameFromUrl:Yv,getRGB:Ur,getUuid:Cp,getXfaPageViewport:Xv,isDataScheme:pl,isPdfFile:zu,isValidExplicitDest:e1,noContextMenu:wn,normalizeUnicode:Gv,renderRichText:Mp,setLayerDimensions:_s,shadow:jt,stopEvent:he,updateUrlHash:Tp,version:Ip},Symbol.toStringTag,{value:"Module"}));function T1(r){var t,e,s="";if(typeof r=="string"||typeof r=="number")s+=r;else if(typeof r=="object")if(Array.isArray(r)){var a=r.length;for(t=0;t<a;t++)r[t]&&(e=T1(r[t]))&&(s&&(s+=" "),s+=e)}else for(e in r)r[e]&&(s&&(s+=" "),s+=e);return s}function Fu(){for(var r,t,e=0,s="",a=arguments.length;e<a;e++)(r=arguments[e])&&(t=T1(r))&&(s&&(s+=" "),s+=t);return s}var Dx=Object.prototype.hasOwnProperty;function Rx(r,t,e){for(e of r.keys())if(Dr(e,t))return e}function Dr(r,t){var e,s,a;if(r===t)return!0;if(r&&t&&(e=r.constructor)===t.constructor){if(e===Date)return r.getTime()===t.getTime();if(e===RegExp)return r.toString()===t.toString();if(e===Array){if((s=r.length)===t.length)for(;s--&&Dr(r[s],t[s]););return s===-1}if(e===Set){if(r.size!==t.size)return!1;for(s of r)if(a=s,a&&typeof a=="object"&&(a=Rx(t,a),!a)||!t.has(a))return!1;return!0}if(e===Map){if(r.size!==t.size)return!1;for(s of r)if(a=s[0],a&&typeof a=="object"&&(a=Rx(t,a),!a)||!Dr(s[1],t.get(a)))return!1;return!0}if(e===ArrayBuffer)r=new Uint8Array(r),t=new Uint8Array(t);else if(e===DataView){if((s=r.byteLength)===t.byteLength)for(;s--&&r.getInt8(s)===t.getInt8(s););return s===-1}if(ArrayBuffer.isView(r)){if((s=r.byteLength)===t.byteLength)for(;s--&&r[s]===t[s];);return s===-1}if(!e||typeof r=="object"){s=0;for(e in r)if(Dx.call(r,e)&&++s&&!Dx.call(t,e)||!(e in t)||!Dr(r[e],t[e]))return!1;return Object.keys(t).length===s}}return r!==r&&t!==t}function xl(r){let t=!1;return{promise:new Promise((s,a)=>{r.then(l=>!t&&s(l)).catch(l=>!t&&a(l))}),cancel(){t=!0}}}const AL=["onCopy","onCut","onPaste"],wL=["onCompositionEnd","onCompositionStart","onCompositionUpdate"],SL=["onFocus","onBlur"],EL=["onInput","onInvalid","onReset","onSubmit"],TL=["onLoad","onError"],CL=["onKeyDown","onKeyPress","onKeyUp"],_L=["onAbort","onCanPlay","onCanPlayThrough","onDurationChange","onEmptied","onEncrypted","onEnded","onError","onLoadedData","onLoadedMetadata","onLoadStart","onPause","onPlay","onPlaying","onProgress","onRateChange","onSeeked","onSeeking","onStalled","onSuspend","onTimeUpdate","onVolumeChange","onWaiting"],kL=["onClick","onContextMenu","onDoubleClick","onMouseDown","onMouseEnter","onMouseLeave","onMouseMove","onMouseOut","onMouseOver","onMouseUp"],ML=["onDrag","onDragEnd","onDragEnter","onDragExit","onDragLeave","onDragOver","onDragStart","onDrop"],DL=["onSelect"],RL=["onTouchCancel","onTouchEnd","onTouchMove","onTouchStart"],LL=["onPointerDown","onPointerMove","onPointerUp","onPointerCancel","onGotPointerCapture","onLostPointerCapture","onPointerEnter","onPointerLeave","onPointerOver","onPointerOut"],OL=["onScroll"],jL=["onWheel"],NL=["onAnimationStart","onAnimationEnd","onAnimationIteration"],BL=["onTransitionEnd"],zL=["onToggle"],PL=["onChange"],IL=[...AL,...wL,...SL,...EL,...TL,...CL,..._L,...kL,...ML,...DL,...RL,...LL,...OL,...jL,...NL,...BL,...PL,...zL];function C1(r,t){const e={};for(const s of IL){const a=r[s];a&&(t?e[s]=(l=>a(l,t(s))):e[s]=a)}return e}var FL="Invariant failed";function ne(r,t){if(!r)throw new Error(FL)}var Of,Lx;function $L(){if(Lx)return Of;Lx=1;var r=function(){};return Of=r,Of}var HL=$L();const qe=op(HL),_1=j.createContext(null),UL="noopener noreferrer nofollow";class GL{constructor(){this.externalLinkEnabled=!0,this.externalLinkRel=void 0,this.externalLinkTarget=void 0,this.isInPresentationMode=!1,this.pdfDocument=void 0,this.pdfViewer=void 0}setDocument(t){this.pdfDocument=t}setViewer(t){this.pdfViewer=t}setExternalLinkRel(t){this.externalLinkRel=t}setExternalLinkTarget(t){this.externalLinkTarget=t}setHash(){}setHistory(){}get pagesCount(){return this.pdfDocument?this.pdfDocument.numPages:0}get page(){return ne(this.pdfViewer),this.pdfViewer.currentPageNumber||0}set page(t){ne(this.pdfViewer),this.pdfViewer.currentPageNumber=t}get rotation(){return 0}set rotation(t){}addLinkAttributes(t,e,s){t.href=e,t.rel=this.externalLinkRel||UL,t.target=s?"_blank":this.externalLinkTarget||""}goToDestination(t){return new Promise(e=>{ne(this.pdfDocument),ne(t),typeof t=="string"?this.pdfDocument.getDestination(t).then(e):Array.isArray(t)?e(t):t.then(e)}).then(e=>{ne(Array.isArray(e));const s=e[0];new Promise(a=>{ne(this.pdfDocument),s instanceof Object?this.pdfDocument.getPageIndex(s).then(l=>{a(l)}).catch(()=>{ne(!1)}):typeof s=="number"?a(s):ne(!1)}).then(a=>{const l=a+1;ne(this.pdfViewer),ne(l>=1&&l<=this.pagesCount),this.pdfViewer.scrollPageIntoView({dest:e,pageIndex:a,pageNumber:l})})})}goToPage(t){const e=t-1;ne(this.pdfViewer),ne(t>=1&&t<=this.pagesCount),this.pdfViewer.scrollPageIntoView({pageIndex:e,pageNumber:t})}goToXY(){}cachePageRef(){}getDestinationHash(){return"#"}getAnchorUrl(){return"#"}executeNamedAction(){}executeSetOCGState(){}isPageVisible(){return!0}isPageCached(){return!0}navigateTo(t){this.goToDestination(t)}}function Rr({children:r,type:t}){return y.jsx("div",{className:`react-pdf__message react-pdf__message--${t}`,children:r})}const Ox={NEED_PASSWORD:1,INCORRECT_PASSWORD:2};function VL(r,t){switch(t.type){case"RESOLVE":return{value:t.value,error:void 0};case"REJECT":return{value:!1,error:t.error};case"RESET":return{value:void 0,error:void 0};default:return r}}function Fr(){return j.useReducer(VL,{value:void 0,error:void 0})}const $u=typeof window<"u",k1=$u&&window.location.protocol==="file:";function qL(r){return typeof r<"u"}function Ks(r){return qL(r)&&r!==null}function YL(r){return typeof r=="string"}function XL(r){return r instanceof ArrayBuffer}function WL(r){return ne($u),r instanceof Blob}function ap(r){return YL(r)&&/^data:/.test(r)}function jx(r){ne(ap(r));const[t="",e=""]=r.split(",");return t.split(";").indexOf("base64")!==-1?atob(e):unescape(e)}function QL(){return $u&&window.devicePixelRatio||1}const M1="On Chromium based browsers, you can use --allow-file-access-from-files flag for debugging purposes.";function Nx(){qe(!k1,`Loading PDF as base64 strings/URLs may not work on protocols other than HTTP/HTTPS. ${M1}`)}function KL(){qe(!k1,`Loading PDF.js worker may not work on protocols other than HTTP/HTTPS. ${M1}`)}function fa(r){r?.cancel&&r.cancel()}function rp(r,t){return Object.defineProperty(r,"width",{get(){return this.getViewport({scale:t}).width},configurable:!0}),Object.defineProperty(r,"height",{get(){return this.getViewport({scale:t}).height},configurable:!0}),Object.defineProperty(r,"originalWidth",{get(){return this.getViewport({scale:1}).width},configurable:!0}),Object.defineProperty(r,"originalHeight",{get(){return this.getViewport({scale:1}).height},configurable:!0}),r}function D1(r){return r.name==="AbortException"||r.name==="RenderingCancelledException"}function ZL(r){return new Promise((t,e)=>{const s=new FileReader;s.onload=()=>{if(!s.result)return e(new Error("Error while reading a file."));t(s.result)},s.onerror=a=>{if(!a.target)return e(new Error("Error while reading a file."));const{error:l}=a.target;if(!l)return e(new Error("Error while reading a file."));switch(l.code){case l.NOT_FOUND_ERR:return e(new Error("Error while reading a file: File not found."));case l.SECURITY_ERR:return e(new Error("Error while reading a file: Security error."));case l.ABORT_ERR:return e(new Error("Error while reading a file: Aborted."));default:return e(new Error("Error while reading a file."))}},s.readAsArrayBuffer(r)})}const{PDFDataRangeTransport:JL}=vL,tO=(r,t)=>{switch(t){case Ox.NEED_PASSWORD:{const e=prompt("Enter the password to open this PDF file.");r(e);break}case Ox.INCORRECT_PASSWORD:{const e=prompt("Invalid password. Please try again.");r(e);break}}};function Bx(r){return typeof r=="object"&&r!==null&&("data"in r||"range"in r||"url"in r)}const eO=j.forwardRef(function({children:t,className:e,error:s="Failed to load PDF file.",externalLinkRel:a,externalLinkTarget:l,file:c,inputRef:d,imageResourcesPath:h,loading:f="Loading PDF…",noData:g="No PDF file specified.",onItemClick:m,onLoadError:x,onLoadProgress:v,onLoadSuccess:E,onPassword:S=tO,onSourceError:C,onSourceSuccess:T,options:_,renderMode:k,rotate:R,scale:D,...L},O){const[B,F]=Fr(),{value:W,error:Z}=B,[rt,dt]=Fr(),{value:lt,error:ut}=rt,P=j.useRef(new GL),V=j.useRef([]),K=j.useRef(void 0),ct=j.useRef(void 0);c&&c!==K.current&&Bx(c)&&(qe(!Dr(c,K.current),`File prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "file" prop.`),K.current=c),_&&_!==ct.current&&(qe(!Dr(_,ct.current),`Options prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to "options" prop.`),ct.current=_);const bt=j.useRef({scrollPageIntoView:At=>{const{dest:yt,pageNumber:Et,pageIndex:Vt=Et-1}=At;if(m){m({dest:yt,pageIndex:Vt,pageNumber:Et});return}const Xt=V.current[Vt];if(Xt){Xt.scrollIntoView();return}qe(!1,`An internal link leading to page ${Et} was clicked, but neither <Document> was provided with onItemClick nor it was able to find the page within itself. Either provide onItemClick to <Document> and handle navigating by yourself or ensure that all pages are rendered within <Document>.`)}});j.useImperativeHandle(O,()=>({linkService:P,pages:V,viewer:bt}),[]);function z(){T&&T()}function H(){Z&&(qe(!1,Z.toString()),C&&C(Z))}function q(){F({type:"RESET"})}j.useEffect(q,[c,F]);const tt=j.useCallback(async()=>{if(!c)return null;if(typeof c=="string")return ap(c)?{data:jx(c)}:(Nx(),{url:c});if(c instanceof JL)return{range:c};if(XL(c))return{data:c};if($u&&WL(c))return{data:await ZL(c)};if(ne(typeof c=="object"),ne(Bx(c)),"url"in c&&typeof c.url=="string"){if(ap(c.url)){const{url:At,...yt}=c;return{data:jx(At),...yt}}Nx()}return c},[c]);j.useEffect(()=>{const At=xl(tt());return At.promise.then(yt=>{F({type:"RESOLVE",value:yt})}).catch(yt=>{F({type:"REJECT",error:yt})}),()=>{fa(At)}},[tt,F]),j.useEffect(()=>{if(!(typeof W>"u")){if(W===!1){H();return}z()}},[W]);function st(){lt&&(E&&E(lt),V.current=new Array(lt.numPages),P.current.setDocument(lt))}function ot(){ut&&(qe(!1,ut.toString()),x&&x(ut))}j.useEffect(function(){dt({type:"RESET"})},[dt,W]),j.useEffect(function(){if(!W)return;const yt=_?{...W,..._}:W,Et=Bp(yt);v&&(Et.onProgress=v),S&&(Et.onPassword=S);const Vt=Et;return Vt.promise.then(Xt=>{Vt.destroyed||dt({type:"RESOLVE",value:Xt})}).catch(Xt=>{Vt.destroyed||dt({type:"REJECT",error:Xt})}),()=>{Vt.destroy()}},[_,dt,W]),j.useEffect(()=>{if(!(typeof lt>"u")){if(lt===!1){ot();return}st()}},[lt]),j.useEffect(function(){P.current.setViewer(bt.current),P.current.setExternalLinkRel(a),P.current.setExternalLinkTarget(l)},[a,l]);const at=j.useCallback((At,yt)=>{V.current[At]=yt},[]),kt=j.useCallback(At=>{delete V.current[At]},[]),et=j.useMemo(()=>({imageResourcesPath:h,linkService:P.current,onItemClick:m,pdf:lt,registerPage:at,renderMode:k,rotate:R,scale:D,unregisterPage:kt}),[h,m,lt,at,k,R,D,kt]),xt=j.useMemo(()=>C1(L,()=>lt),[L,lt]);function ht(){function At(Et){return!!Et?.pdf}if(!At(et))throw new Error("pdf is undefined");const yt=typeof t=="function"?t(et):t;return y.jsx(_1.Provider,{value:et,children:yt})}function Ct(){return c?lt==null?y.jsx(Rr,{type:"loading",children:typeof f=="function"?f():f}):lt===!1?y.jsx(Rr,{type:"error",children:typeof s=="function"?s():s}):ht():y.jsx(Rr,{type:"no-data",children:typeof g=="function"?g():g})}return y.jsx("div",{className:Fu("react-pdf__Document",e),ref:d,...xt,children:Ct()})});function R1(){return j.useContext(_1)}function L1(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];var e=r.filter(Boolean);if(e.length<=1){var s=e[0];return s||null}return function(l){for(var c=0,d=e;c<d.length;c++){var h=d[c];typeof h=="function"?h(l):h&&(h.current=l)}}}const O1=j.createContext(null);function Hu(){return j.useContext(O1)}function nO(){const r=R1(),t=Hu();ne(t);const e={...r,...t},{filterAnnotations:s,imageResourcesPath:a,linkService:l,onGetAnnotationsError:c,onGetAnnotationsSuccess:d,onRenderAnnotationLayerError:h,onRenderAnnotationLayerSuccess:f,page:g,pdf:m,renderForms:x,rotate:v,scale:E=1}=e;ne(m),ne(g),ne(l);const[S,C]=Fr(),{value:T,error:_}=S,k=j.useRef(null);qe(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-annotation-layer"),10)===1,"AnnotationLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-annotations");function R(){T&&d&&d(T)}function D(){_&&(qe(!1,_.toString()),c&&c(_))}j.useEffect(function(){C({type:"RESET"})},[C,g]),j.useEffect(function(){if(!g)return;const W=xl(g.getAnnotations()),Z=W;return W.promise.then(rt=>{C({type:"RESOLVE",value:rt})}).catch(rt=>{C({type:"REJECT",error:rt})}),()=>{fa(Z)}},[C,g]),j.useEffect(()=>{if(T!==void 0){if(T===!1){D();return}R()}},[T]);function L(){f&&f()}function O(F){qe(!1,`${F}`),h&&h(F)}const B=j.useMemo(()=>g.getViewport({scale:E,rotation:v}),[g,v,E]);return j.useEffect(function(){if(!m||!g||!l||!T)return;const{current:W}=k;if(!W)return;const Z=B.clone({dontFlip:!0}),rt={accessibilityManager:null,annotationCanvasMap:null,annotationEditorUIManager:null,annotationStorage:m.annotationStorage,commentManager:null,div:W,l10n:null,linkService:l,page:g,structTreeLayer:null,viewport:Z},dt={annotations:s?s({annotations:T}):T,annotationStorage:m.annotationStorage,div:W,imageResourcesPath:a,linkService:l,page:g,renderForms:x,viewport:Z};W.innerHTML="";try{new Hp(rt).render(dt),L()}catch(lt){O(lt)}return()=>{}},[T,s,a,l,g,m,x,B]),y.jsx("div",{className:Fu("react-pdf__Page__annotations","annotationLayer"),ref:k})}const j1={Document:null,DocumentFragment:null,Part:"group",Sect:"group",Div:"group",Aside:"note",NonStruct:"none",P:null,H:"heading",Title:null,FENote:"note",Sub:"group",Lbl:null,Span:null,Em:null,Strong:null,Link:"link",Annot:"note",Form:"form",Ruby:null,RB:null,RT:null,RP:null,Warichu:null,WT:null,WP:null,L:"list",LI:"listitem",LBody:null,Table:"table",TR:"row",TH:"columnheader",TD:"cell",THead:"columnheader",TBody:null,TFoot:null,Caption:null,Figure:"figure",Formula:null,Artifact:null},iO=/^H(\d+)$/;function sO(r){return r in j1}function Uu(r){return"children"in r}function N1(r){return Uu(r)?r.children.length===1&&0 in r.children&&"id"in r.children[0]:!1}function aO(r){const t={};if(Uu(r)){const{role:e}=r,s=e.match(iO);if(s)t.role="heading",t["aria-level"]=Number(s[1]);else if(sO(e)){const a=j1[e];a&&(t.role=a)}}return t}function B1(r){const t={};if(Uu(r)){if(r.alt!==void 0&&(t["aria-label"]=r.alt),r.lang!==void 0&&(t.lang=r.lang),N1(r)){const[e]=r.children;if(e){const s=B1(e);return{...t,...s}}}}else"id"in r&&(t["aria-owns"]=r.id);return t}function rO(r){return r?{...aO(r),...B1(r)}:null}function z1({className:r,node:t}){const e=j.useMemo(()=>rO(t),[t]),s=j.useMemo(()=>!Uu(t)||N1(t)?null:t.children.map((a,l)=>y.jsx(z1,{node:a},l)),[t]);return y.jsx("span",{className:r,...e,children:s})}function oO(){const r=Hu();ne(r);const{onGetStructTreeError:t,onGetStructTreeSuccess:e}=r,[s,a]=Fr(),{value:l,error:c}=s,{customTextRenderer:d,page:h}=r;function f(){l&&e&&e(l)}function g(){c&&(qe(!1,c.toString()),t&&t(c))}return j.useEffect(function(){a({type:"RESET"})},[a,h]),j.useEffect(function(){if(d||!h)return;const x=xl(h.getStructTree()),v=x;return x.promise.then(E=>{a({type:"RESOLVE",value:E})}).catch(E=>{a({type:"REJECT",error:E})}),()=>fa(v)},[d,h,a]),j.useEffect(()=>{if(l!==void 0){if(l===!1){g();return}f()}},[l]),l?y.jsx(z1,{className:"react-pdf__Page__structTree structTree",node:l}):null}const zx=oi;function lO(r){const t=Hu();ne(t);const e={...t,...r},{_className:s,canvasBackground:a,devicePixelRatio:l=QL(),onRenderError:c,onRenderSuccess:d,page:h,renderForms:f,renderTextLayer:g,rotate:m,scale:x}=e,{canvasRef:v}=r;ne(h);const E=j.useRef(null);function S(){h&&d&&d(rp(h,x))}function C(R){D1(R)||(qe(!1,R.toString()),c&&c(R))}const T=j.useMemo(()=>h.getViewport({scale:x*l,rotation:m}),[l,h,m,x]),_=j.useMemo(()=>h.getViewport({scale:x,rotation:m}),[h,m,x]);j.useEffect(function(){if(!h)return;h.cleanup();const{current:D}=E;if(!D)return;D.width=T.width,D.height=T.height,D.style.width=`${Math.floor(_.width)}px`,D.style.height=`${Math.floor(_.height)}px`,D.style.visibility="hidden";const L={annotationMode:f?zx.ENABLE_FORMS:zx.ENABLE,canvas:D,canvasContext:D.getContext("2d",{alpha:!1}),viewport:T};a&&(L.background=a);const O=h.render(L),B=O;return O.promise.then(()=>{D.style.visibility="",S()}).catch(C),()=>fa(B)},[a,h,f,T,_]);const k=j.useCallback(()=>{const{current:R}=E;R&&(R.width=0,R.height=0)},[]);return j.useEffect(()=>k,[k]),y.jsx("canvas",{className:`${s}__canvas`,dir:"ltr",ref:L1(v,E),style:{display:"block",userSelect:"none"},children:g?y.jsx(oO,{}):null})}function cO(r){return"str"in r}function uO(){const r=Hu();ne(r);const{customTextRenderer:t,onGetTextError:e,onGetTextSuccess:s,onRenderTextLayerError:a,onRenderTextLayerSuccess:l,page:c,pageIndex:d,pageNumber:h,rotate:f,scale:g}=r;ne(c);const[m,x]=Fr(),{value:v,error:E}=m,S=j.useRef(null);qe(Number.parseInt(window.getComputedStyle(document.body).getPropertyValue("--react-pdf-text-layer"),10)===1,"TextLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-text-layer");function C(){v&&s&&s(v)}function T(){E&&(qe(!1,E.toString()),e&&e(E))}j.useEffect(function(){x({type:"RESET"})},[c,x]),j.useEffect(function(){if(!c)return;const B=xl(c.getTextContent()),F=B;return B.promise.then(W=>{x({type:"RESOLVE",value:W})}).catch(W=>{x({type:"REJECT",error:W})}),()=>fa(F)},[c,x]),j.useEffect(()=>{if(v!==void 0){if(v===!1){T();return}C()}},[v]);const _=j.useCallback(()=>{l&&l()},[l]),k=j.useCallback(O=>{D1(O)||(qe(!1,O.toString()),a&&a(O))},[a]);function R(){const O=S.current;O&&O.classList.add("selecting")}function D(){const O=S.current;O&&O.classList.remove("selecting")}const L=j.useMemo(()=>c.getViewport({scale:g,rotation:f}),[c,f,g]);return j.useLayoutEffect(function(){if(!c||!v)return;const{current:B}=S;if(!B)return;B.innerHTML="";const F=c.streamTextContent({includeMarkedContent:!0}),W={container:B,textContentSource:F,viewport:L},Z=new ol(W),rt=Z;return Z.render().then(()=>{const dt=document.createElement("div");dt.className="endOfContent",B.append(dt);const lt=B.querySelectorAll('[role="presentation"]');if(t){let ut=0;v.items.forEach((P,V)=>{if(!cO(P))return;const K=lt[ut];if(!K)return;const ct=t({pageIndex:d,pageNumber:h,itemIndex:V,...P});K.innerHTML=ct,ut+=P.str&&P.hasEOL?2:1})}_()}).catch(k),()=>fa(rt)},[t,k,_,c,d,h,v,L]),y.jsx("div",{className:Fu("react-pdf__Page__textContent","textLayer"),onMouseUp:D,onMouseDown:R,ref:S})}const Px=1;function dO(r){const e={...R1(),...r},{_className:s="react-pdf__Page",_enableRegisterUnregisterPage:a=!0,canvasBackground:l,canvasRef:c,children:d,className:h,customRenderer:f,customTextRenderer:g,devicePixelRatio:m,error:x="Failed to load the page.",filterAnnotations:v,height:E,inputRef:S,loading:C="Loading page…",noData:T="No page specified.",onGetAnnotationsError:_,onGetAnnotationsSuccess:k,onGetStructTreeError:R,onGetStructTreeSuccess:D,onGetTextError:L,onGetTextSuccess:O,onLoadError:B,onLoadSuccess:F,onRenderAnnotationLayerError:W,onRenderAnnotationLayerSuccess:Z,onRenderError:rt,onRenderSuccess:dt,onRenderTextLayerError:lt,onRenderTextLayerSuccess:ut,pageIndex:P,pageNumber:V,pdf:K,registerPage:ct,renderAnnotationLayer:bt=!0,renderForms:z=!1,renderMode:H="canvas",renderTextLayer:q=!0,rotate:tt,scale:st=Px,unregisterPage:ot,width:at,...kt}=e,[et,xt]=Fr(),{value:ht,error:Ct}=et,At=j.useRef(null);ne(K);const yt=Ks(V)?V-1:P??null,Et=V??(Ks(P)?P+1:null),Vt=tt??(ht?ht.rotate:null),Xt=j.useMemo(()=>{if(!ht)return null;let ln=1;const Pi=st??Px;if(at||E){const Fn=ht.getViewport({scale:1,rotation:Vt});at?ln=at/Fn.width:E&&(ln=E/Fn.height)}return Pi*ln},[E,ht,Vt,st,at]);j.useEffect(function(){return()=>{Ks(yt)&&a&&ot&&ot(yt)}},[a,K,yt,ot]);function Sn(){if(F){if(!ht||!Xt)return;F(rp(ht,Xt))}if(a&&ct){if(!Ks(yt)||!At.current)return;ct(yt,At.current)}}function Qe(){Ct&&(qe(!1,Ct.toString()),B&&B(Ct))}j.useEffect(function(){xt({type:"RESET"})},[xt,K,yt]),j.useEffect(function(){if(!K||!Et)return;const Pi=xl(K.getPage(Et)),Fn=Pi;return Pi.promise.then(Gr=>{xt({type:"RESOLVE",value:Gr})}).catch(Gr=>{xt({type:"REJECT",error:Gr})}),()=>fa(Fn)},[xt,K,Et]),j.useEffect(()=>{if(ht!==void 0){if(ht===!1){Qe();return}Sn()}},[ht,Xt]);const In=j.useMemo(()=>Ks(yt)&&Et&&Ks(Vt)&&Ks(Xt)?{_className:s,canvasBackground:l,customTextRenderer:g,devicePixelRatio:m,filterAnnotations:v,onGetAnnotationsError:_,onGetAnnotationsSuccess:k,onGetStructTreeError:R,onGetStructTreeSuccess:D,onGetTextError:L,onGetTextSuccess:O,onRenderAnnotationLayerError:W,onRenderAnnotationLayerSuccess:Z,onRenderError:rt,onRenderSuccess:dt,onRenderTextLayerError:lt,onRenderTextLayerSuccess:ut,page:ht,pageIndex:yt,pageNumber:Et,renderForms:z,renderTextLayer:q,rotate:Vt,scale:Xt}:null,[s,l,g,m,v,_,k,R,D,L,O,W,Z,rt,dt,lt,ut,ht,yt,Et,z,q,Vt,Xt]),ui=j.useMemo(()=>C1(kt,()=>ht&&(Xt?rp(ht,Xt):void 0)),[kt,ht,Xt]),En=`${yt}@${Xt}/${Vt}`;function ya(){switch(H){case"custom":return ne(f),y.jsx(f,{},`${En}_custom`);case"none":return null;default:return y.jsx(lO,{canvasRef:c},`${En}_canvas`)}}function Ue(){return q?y.jsx(uO,{},`${En}_text`):null}function Gu(){return bt?y.jsx(nO,{},`${En}_annotations`):null}function vl(){function ln(Fn){return!!Fn?.page}if(!ln(In))throw new Error("page is undefined");const Pi=typeof d=="function"?d(In):d;return y.jsxs(O1.Provider,{value:In,children:[ya(),Ue(),Gu(),Pi]})}function Al(){return Et?K===null||ht===void 0||ht===null?y.jsx(Rr,{type:"loading",children:typeof C=="function"?C():C}):K===!1||ht===!1?y.jsx(Rr,{type:"error",children:typeof x=="function"?x():x}):vl():y.jsx(Rr,{type:"no-data",children:typeof T=="function"?T():T})}return y.jsx("div",{className:Fu(s,h),"data-page-number":Et,ref:L1(S,At),style:{"--scale-round-x":"1px","--scale-round-y":"1px","--scale-factor":"1","--user-unit":`${Xt}`,"--total-scale-factor":"calc(var(--scale-factor) * var(--user-unit))",backgroundColor:l||"white",position:"relative",minWidth:"min-content",minHeight:"min-content"},...ui,children:Al()})}KL();Ss.workerSrc="pdf.worker.mjs";Ss.workerSrc=`//unpkg.com/pdfjs-dist@${Ip}/build/pdf.worker.min.mjs`;const hO=()=>{const[r,t]=j.useState(0),[e,s]=j.useState(1),[a,l]=j.useState(1),c=({numPages:m})=>{t(m)},d=()=>s(m=>Math.max(m-1,1)),h=()=>s(m=>Math.min(m+1,r)),f=()=>l(m=>Math.min(m+.1,1.5)),g=()=>l(m=>Math.max(m-.1,.3));return y.jsxs(fO,{children:[y.jsxs(pO,{children:[y.jsxs(jf,{children:[y.jsx(yr,{onClick:d,disabled:e<=1,title:"Previous Page",children:"◀"}),y.jsxs(gO,{children:[y.jsx(mO,{type:"text",value:e,readOnly:!0}),y.jsxs(bO,{children:["of ",r]})]}),y.jsx(yr,{onClick:h,disabled:e>=r,title:"Next Page",children:"▶"})]}),y.jsx(Ix,{}),y.jsxs(jf,{children:[y.jsx(yr,{onClick:g,title:"Zoom Out",children:"−"}),y.jsxs(yO,{children:[Math.round(a*100),"%"]}),y.jsx(yr,{onClick:f,title:"Zoom In",children:"+"})]}),y.jsx(Ix,{}),y.jsxs(jf,{children:[y.jsx(yr,{as:"a",href:"/cv.pdf",download:"Alfonso_Pedro_Ridao_CV.pdf",title:"Save",children:"💾"}),y.jsx(yr,{as:"a",href:"/cv.pdf",target:"_blank",title:"Open",children:"🔗"})]})]}),y.jsx(xO,{children:y.jsx(eO,{file:"/cv.pdf",onLoadSuccess:c,loading:y.jsx(vO,{children:"Loading PDF..."}),error:y.jsx(AO,{children:"Failed to load PDF"}),children:y.jsx(dO,{pageNumber:e,scale:a,renderTextLayer:!1,renderAnnotationLayer:!1})})}),y.jsxs(wO,{children:[y.jsxs(Fx,{children:[y.jsx(SO,{children:"📕"}),y.jsx($x,{children:"Adobe Acrobat Reader 3.0"})]}),y.jsx(Fx,{children:y.jsx($x,{children:"alfonso_pedro_ridao.pdf"})})]})]})},fO=w.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  background: #808080;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
`,pO=w.div`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 6px;
  background: #c0c0c0;
  border-bottom: 1px solid #808080;
  flex-shrink: 0;
`,jf=w.div`
  display: flex;
  align-items: center;
  gap: 2px;
`,Ix=w.div`
  width: 1px;
  height: 20px;
  background: #808080;
  margin: 0 4px;
`,yr=w.button`
  min-width: 24px;
  height: 22px;
  padding: 2px 6px;
  font-size: 12px;
  background: #c0c0c0;
  border: 2px solid;
  border-top-color: #fff;
  border-left-color: #fff;
  border-right-color: #404040;
  border-bottom-color: #404040;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  text-decoration: none;
  color: #000;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:active:not(:disabled) {
    border-top-color: #404040;
    border-left-color: #404040;
    border-right-color: #fff;
    border-bottom-color: #fff;
  }

  &:disabled {
    color: #808080;
    cursor: not-allowed;
  }
`,gO=w.div`
  display: flex;
  align-items: center;
  gap: 4px;
`,mO=w.input`
  width: 24px;
  height: 18px;
  text-align: center;
  font-size: 11px;
  border: 2px solid;
  border-top-color: #808080;
  border-left-color: #808080;
  border-right-color: #fff;
  border-bottom-color: #fff;
  background: #fff;
`,bO=w.span`
  font-size: 11px;
  color: #000;
`,yO=w.span`
  font-size: 11px;
  min-width: 36px;
  text-align: center;
`,xO=w.div`
  flex: 1;
  background: #666;
  overflow: auto;
  display: flex;
  justify-content: center;
  padding: 10px;
`,vO=w.div`
  color: #fff;
  font-size: 14px;
  padding: 40px;
`,AO=w.div`
  color: #ff6666;
  font-size: 14px;
  padding: 40px;
`,wO=w.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2px 6px;
  background: #c0c0c0;
  border-top: 1px solid #fff;
  min-height: 20px;
  flex-shrink: 0;
`,Fx=w.div`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 1px 4px;
  border: 1px solid;
  border-top-color: #808080;
  border-left-color: #808080;
  border-right-color: #fff;
  border-bottom-color: #fff;
`,SO=w.span`
  font-size: 12px;
`,$x=w.span`
  font-size: 10px;
  color: #000;
`,EO="https://7sv2xijrq7.execute-api.eu-west-2.amazonaws.com";async function TO(r,t=[]){const e=await fetch(`${EO}/api/chat`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:r,history:t})});if(!e.ok)throw new Error(`Chat API error: ${e.status}`);return(await e.json()).response}const CO=({initialMessage:r})=>{const[t,e]=j.useState([]),[s,a]=j.useState(""),[l,c]=j.useState(!1),[d,h]=j.useState(!1),f=j.useRef(null),g=j.useRef(!1),m=()=>{f.current?.scrollIntoView({behavior:"smooth"})};j.useEffect(()=>{m()},[t]),j.useEffect(()=>{if(g.current)return;g.current=!0;const C=r||"Hey! Welcome to my Windows 95 site! I'm Alfonso's digital twin. Feel free to ask me anything about Alfonso, his projects, or just chat! 🌸";setTimeout(()=>{e([{role:"assistant",content:C}]),x()},1e3)},[r]);const x=()=>{try{const C=new Audio("/sounds/icq-message.mp3");C.volume=.5,C.play().catch(()=>{})}catch{}},v=async()=>{if(!s.trim()||l)return;const C=s.trim();a("");const T=[...t,{role:"user",content:C}];e(T),c(!0);try{const _=t.findIndex(D=>D.role==="user"),k=_>=0?t.slice(_):[],R=await TO(C,k);e([...T,{role:"assistant",content:R}]),x()}catch{e([...T,{role:"assistant",content:"Oops! Connection lost. Try again in a moment! 📡"}])}finally{c(!1)}},E=C=>{C.key==="Enter"&&!C.shiftKey&&(C.preventDefault(),v())},S=()=>{h(!0)};return d?y.jsxs(Hx,{children:[y.jsxs(GO,{children:[y.jsx(VO,{onClick:()=>h(!1),children:"←"}),y.jsxs(qO,{children:[y.jsx(Ux,{$online:!0,style:{fontSize:"16px"},children:"🌸"}),y.jsxs(YO,{children:[y.jsx(XO,{children:"Alfonso"}),y.jsx(WO,{children:"Online - 33809676"})]})]})]}),y.jsxs(QO,{children:[t.map((C,T)=>y.jsxs(KO,{$isUser:C.role==="user",children:[y.jsx(ZO,{children:C.role==="user"?"You":"Alfonso"}),y.jsx(JO,{children:C.content})]},T)),l&&y.jsxs(tj,{children:[y.jsx(Nf,{style:{animationDelay:"0ms"}}),y.jsx(Nf,{style:{animationDelay:"150ms"}}),y.jsx(Nf,{style:{animationDelay:"300ms"}}),y.jsx(ej,{children:"Alfonso is typing..."})]}),y.jsx("div",{ref:f})]}),y.jsxs(nj,{children:[y.jsx(ij,{value:s,onChange:C=>a(C.target.value),onKeyPress:E,placeholder:"Type a message...",disabled:l}),y.jsx(sj,{onClick:v,disabled:l||!s.trim(),children:"Send"})]})]}):y.jsxs(Hx,{children:[y.jsxs(MO,{children:[y.jsx(DO,{children:"🌸"}),y.jsx(RO,{children:"ICQ"})]}),y.jsxs(LO,{children:[y.jsxs(OO,{children:[y.jsx(jO,{children:"▼"}),y.jsx(NO,{children:"Online"})]}),y.jsxs(BO,{onClick:S,$online:!0,children:[y.jsx(Ux,{$online:!0,children:"🌸"}),y.jsxs(zO,{children:[y.jsx(PO,{children:"Alfonso"}),y.jsx(IO,{children:"33809676"})]}),t.length>0&&y.jsx(FO,{children:"!"})]})]}),y.jsxs($O,{children:[y.jsx(HO,{$online:!0}),y.jsx(UO,{children:"Online"})]})]})},_O=ue`
  0%, 80%, 100% { transform: translateY(0); }
  40% { transform: translateY(-6px); }
`,kO=ue`
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
`,Hx=w.div`
  display: flex;
  flex-direction: column;
  height: 100%;
  background: linear-gradient(180deg, #f0f0f0 0%, #d4d4d4 100%);
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
`,MO=w.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: linear-gradient(180deg, #89c489 0%, #5a9a5a 100%);
  border-bottom: 2px solid #3d6b3d;
`,DO=w.span`
  font-size: 24px;
`,RO=w.span`
  color: #fff;
  font-size: 16px;
  font-weight: bold;
  text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
`,LO=w.div`
  flex: 1;
  overflow-y: auto;
  background: #fff;
  border: 2px inset #808080;
  margin: 8px;
`,OO=w.div`
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 8px;
  background: #e8e8e8;
  border-bottom: 1px solid #c0c0c0;
  font-size: 11px;
  font-weight: bold;
`,jO=w.span`
  font-size: 8px;
`,NO=w.span`
  color: #006400;
`,BO=w.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  cursor: pointer;
  border-bottom: 1px solid #e0e0e0;

  &:hover {
    background: #e8f4e8;
  }
`,Ux=w.span`
  font-size: 20px;
  filter: ${r=>r.$online?"none":"grayscale(100%)"};
`,zO=w.div`
  flex: 1;
`,PO=w.div`
  font-size: 12px;
  font-weight: bold;
  color: #000;
`,IO=w.div`
  font-size: 10px;
  color: #666;
`,FO=w.div`
  width: 18px;
  height: 18px;
  background: #ff0000;
  color: #fff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: bold;
  animation: ${kO} 1s infinite;
`,$O=w.div`
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  background: #d4d4d4;
  border-top: 1px solid #fff;
`,HO=w.div`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: ${r=>r.$online?"#00ff00":"#808080"};
  border: 1px solid ${r=>r.$online?"#006400":"#404040"};
`,UO=w.span`
  font-size: 11px;
  color: #333;
`,GO=w.div`
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: linear-gradient(180deg, #89c489 0%, #5a9a5a 100%);
  border-bottom: 2px solid #3d6b3d;
`,VO=w.button`
  width: 24px;
  height: 24px;
  background: #c0c0c0;
  border: 2px outset #fff;
  cursor: pointer;
  font-size: 14px;
  display: flex;
  align-items: center;
  justify-content: center;

  &:active {
    border-style: inset;
  }
`,qO=w.div`
  display: flex;
  align-items: center;
  gap: 8px;
`,YO=w.div``,XO=w.div`
  color: #fff;
  font-size: 12px;
  font-weight: bold;
  text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
`,WO=w.div`
  color: #e0ffe0;
  font-size: 10px;
`,QO=w.div`
  flex: 1;
  overflow-y: auto;
  padding: 12px;
  background: #fff;
  border: 2px inset #808080;
  margin: 8px;
`,KO=w.div`
  max-width: 80%;
  margin-bottom: 12px;
  padding: 8px 12px;
  border-radius: 8px;
  background: ${r=>r.$isUser?"#dcf8c6":"#e8e8e8"};
  margin-left: ${r=>r.$isUser?"auto":"0"};
  margin-right: ${r=>r.$isUser?"0":"auto"};
  border: 1px solid ${r=>r.$isUser?"#a8d88a":"#c0c0c0"};
`,ZO=w.div`
  font-size: 10px;
  font-weight: bold;
  color: #006400;
  margin-bottom: 4px;
`,JO=w.div`
  font-size: 12px;
  color: #000;
  line-height: 1.4;
  word-wrap: break-word;
`,tj=w.div`
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px;
  color: #666;
`,Nf=w.div`
  width: 6px;
  height: 6px;
  background: #666;
  border-radius: 50%;
  animation: ${_O} 0.6s infinite;
`,ej=w.span`
  font-size: 11px;
  margin-left: 4px;
  font-style: italic;
`,nj=w.div`
  display: flex;
  gap: 8px;
  padding: 8px;
  background: #d4d4d4;
  border-top: 1px solid #fff;
`,ij=w.input`
  flex: 1;
  padding: 6px 8px;
  font-size: 12px;
  border: 2px inset #808080;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:focus {
    outline: none;
  }

  &:disabled {
    background: #e0e0e0;
  }
`,sj=w.button`
  padding: 6px 16px;
  font-size: 11px;
  background: #c0c0c0;
  border: 2px outset #fff;
  cursor: pointer;
  font-family: 'MS Sans Serif', Tahoma, sans-serif;

  &:active:not(:disabled) {
    border-style: inset;
  }

  &:disabled {
    color: #808080;
    cursor: not-allowed;
  }
`,aj={"my-computer":"/icons/my-computer.png","recycle-bin":"/icons/recycle-bin.png","cv-doc":"/icons/document.png",homepage:"/icons/internet.png",minesweeper:"/icons/minesweeper.png",icq:"/icons/icq-flower.png"},Gx={},rj=()=>{const[r,t]=j.useState([]),[e,s]=j.useState(!1),[a,l]=j.useState(100),[c,d]=j.useState(!1);j.useEffect(()=>{if(c)return;const _=setTimeout(()=>{h("icq","ICQ"),d(!0)},2e3);return()=>clearTimeout(_)},[c]);const h=j.useCallback((_,k)=>{if(Gx[_]){window.open(Gx[_],"_blank","noopener,noreferrer");return}r.find(D=>D.id===_)?(t(D=>D.map(L=>({...L,isMinimized:L.id===_?!1:L.isMinimized,isActive:L.id===_,zIndex:L.id===_?a:L.zIndex}))),l(D=>D+1)):(t(D=>[...D.map(L=>({...L,isActive:!1})),{id:_,title:k,icon:aj[_],isMinimized:!1,isActive:!0,zIndex:a}]),l(D=>D+1))},[r,a]),f=j.useCallback(_=>{t(k=>k.filter(R=>R.id!==_))},[]),g=j.useCallback(_=>{t(k=>k.map(R=>({...R,isMinimized:R.id===_?!0:R.isMinimized,isActive:R.id===_?!1:R.isActive})))},[]),m=j.useCallback(_=>{t(k=>k.map(R=>({...R,isActive:R.id===_,zIndex:R.id===_?a:R.zIndex}))),l(k=>k+1)},[a]),x=j.useCallback(_=>{const k=r.find(R=>R.id===_);k&&(k.isMinimized?(t(R=>R.map(D=>({...D,isMinimized:D.id===_?!1:D.isMinimized,isActive:D.id===_,zIndex:D.id===_?a:D.zIndex}))),l(R=>R+1)):k.isActive?g(_):m(_))},[r,a,g,m]),v=()=>{s(_=>!_)},E=()=>{e&&s(!1)},S=()=>{s(!1)},C=(_,k)=>{h(_,k)},T=j.useCallback(()=>{h("icq","ICQ")},[h]);return y.jsxs(oj,{onClick:E,children:[y.jsxs(lj,{children:[y.jsx(ar,{id:"my-computer",icon:"/icons/my-computer.png",label:"My Computer",onDoubleClick:h}),y.jsx(ar,{id:"recycle-bin",icon:"/icons/recycle-bin.png",label:"Recycle Bin",onDoubleClick:h}),y.jsx(ar,{id:"cv-doc",icon:"/icons/document.png",label:"CV.doc",onDoubleClick:h}),y.jsx(ar,{id:"homepage",icon:"/icons/internet.png",label:"Fonchi's Homepage",onDoubleClick:h}),y.jsx(ar,{id:"minesweeper",icon:"/icons/minesweeper.png",label:"Minesweeper",onDoubleClick:h}),y.jsx(ar,{id:"icq",icon:"/icons/icq-flower.png",label:"ICQ",onDoubleClick:h})]}),r.map((_,k)=>y.jsx(j_,{id:_.id,title:_.title,icon:_.icon,isActive:_.isActive,isMinimized:_.isMinimized,onClose:f,onMinimize:g,onFocus:m,zIndex:_.zIndex,initialPosition:{x:100+k*30,y:50+k*30},initialSize:_.id==="homepage"?{width:800,height:550}:_.id==="minesweeper"?{width:242,height:308}:_.id==="cv-doc"?{width:650,height:500}:_.id==="icq"?{width:300,height:450}:void 0,showMenuBar:_.id!=="homepage"&&_.id!=="minesweeper"&&_.id!=="cv-doc"&&_.id!=="icq",showStatusBar:_.id!=="homepage"&&_.id!=="minesweeper"&&_.id!=="cv-doc"&&_.id!=="icq",statusText:_.id==="my-computer"?"6 object(s)":_.id==="recycle-bin"?"0 object(s)":"",resizable:_.id!=="minesweeper",noPadding:_.id==="minesweeper"||_.id==="cv-doc"||_.id==="icq",children:_.id==="my-computer"?y.jsx(K_,{}):_.id==="homepage"?y.jsx(VM,{}):_.id==="minesweeper"?y.jsx(TD,{}):_.id==="cv-doc"?y.jsx(hO,{}):_.id==="icq"?y.jsx(CO,{}):_.id==="recycle-bin"?y.jsx(cj,{children:y.jsx(uj,{children:"Recycle Bin is empty."})}):y.jsxs("p",{children:["Content for ",_.title]})},_.id)),y.jsx(w_,{isOpen:e,onClose:S,onOpenApp:C}),y.jsx(o_,{openWindows:r,startMenuOpen:e,onStartClick:v,onWindowClick:x,onICQClick:T})]})},oj=w.div`
  width: 100vw;
  height: 100vh;
  background-color: #008080;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  overflow: hidden;
`,lj=w.div`
  position: absolute;
  top: 10px;
  left: 10px;
  bottom: 38px;
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  gap: 5px;
  padding: 5px;
  overflow: hidden;
`,cj=w.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: #fff;
`,uj=w.span`
  font-family: 'MS Sans Serif', Tahoma, sans-serif;
  font-size: 11px;
  color: #808080;
`,dj=dE`
  ${gE}

  *, *::before, *::after {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  html {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden;
    overscroll-behavior: none;
  }

  body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden;
    overscroll-behavior: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    font-family: 'MS Sans Serif', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #008080;
  }

  #root {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    overflow: hidden;
  }
`;function hj(){const[r,t]=j.useState("booting"),e=j.useCallback(()=>{t("desktop")},[]);return y.jsxs(lE,{theme:pE,children:[y.jsx(dj,{}),r==="booting"&&y.jsx(s_,{onBootComplete:e,duration:2e3}),r==="desktop"&&y.jsx(rj,{})]})}cS.createRoot(document.getElementById("root")).render(y.jsx(j.StrictMode,{children:y.jsx(hj,{})}));
